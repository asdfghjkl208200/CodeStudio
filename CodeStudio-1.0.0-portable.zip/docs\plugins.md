# Writing a CodeStudio plugin

A plugin adds commands, colour themes, languages, sidebar views and status bar items to CodeStudio.

Plugins live in:

```
%USERPROFILE%\.codestudio\plugins\        (Windows)
~/.codestudio/plugins/                    (Linux, macOS)
```

Both of the following are picked up on start-up, and from **Plugins → Reload Plugins**:

- a **jar** containing a `plugin.json` manifest at its root, plus the classes it names;
- a **directory** containing a `plugin.json`, optionally with jars beside it.

A `plugin.json` with no `main` field is a **declarative plugin**: it contributes only themes and
languages, and runs no code at all.

---

## The manifest

```json
{
  "id": "com.example.hello",
  "name": "Hello",
  "version": "1.0.0",
  "description": "Says hello.",
  "main": "com.example.HelloPlugin",
  "contributes": {
    "themes": [
      {
        "id": "midnight",
        "name": "Midnight",
        "base": "dark",
        "colors": { "accent": "#7C5CFF", "editorBg": "#101014" }
      }
    ],
    "languages": [
      {
        "id": "foo",
        "name": "Foo",
        "lexer": "GENERIC",
        "extensions": ["foo"],
        "lineComments": ["#"],
        "keywords": ["let", "fn"],
        "controlKeywords": ["if", "else", "return"],
        "types": ["Int", "Text"],
        "constants": ["true", "false"],
        "builtins": ["print"]
      }
    ]
  }
}
```

`main` is optional. `contributes` is optional. A plugin with neither does nothing.

### Theme colour names

A theme starts from `base` (`dark` or `light`) and overrides only what it names. Recognised keys:

`accent`, `editorBg`, `editorFg`, `sidebarBg`, `sidebarFg`, `activityBg`, `statusBg`, `statusFg`,
`titleBg`, `panelBg`, `tabActiveBg`, `tabInactiveBg`, `selection`, `lineHighlight`, `inputBg`,
`inputFg`, `error`, `warning`, `info`, `synKeyword`, `synControl`, `synType`, `synString`,
`synComment`, `synNumber`, `synFunction`, `synAnnotation`, `synConstant`, `synVar`.

An unrecognised name is reported as a problem against the plugin and skipped; the rest of the theme
still applies. That name list is a deliberate subset — around forty further colours exist on
`Theme`. To set those, write a code plugin and use `Theme.copyOf`:

```java
Theme mine = Theme.copyOf(Theme.get("dark"));
mine.tabBorder = new Color(0x33, 0x33, 0x3A);
context.addTheme("midnight", "Midnight", mine);
```

That route is strongly typed, so a misspelled field is a compile error rather than a silent skip.

A plugin cannot take an id already used by a built-in theme or language, and cannot replace another
plugin's.

---

## The plugin class

```java
package com.example;

import com.codestudio.api.CodeStudioPlugin;
import com.codestudio.api.PluginContext;

public class HelloPlugin implements CodeStudioPlugin {

    public String id()      { return "com.example.hello"; }
    public String name()    { return "Hello"; }
    public String version() { return "1.0.0"; }

    public String description() {
        return "Says hello, and tints the editor.";
    }

    @Override
    public void activate(PluginContext context) {
        context.addCommand(id() + ".greet", "Hello", "Say Hello", "ctrl alt H",
                () -> context.showMessage("Hello!"));

        context.addStatusItem(id() + ".badge", "Hello", () -> context.showMessage("Clicked"));
    }
}
```

`id()`, `name()` and `version()` are required. `activate` and `deactivate` have empty defaults.

`context.addCommand(id, category, title, keybinding, action)` — the command appears in the command
palette (Ctrl+Shift+P) under `category`, and in the **Plugins** menu. `keybinding` is optional; use
`""` for none.

`context.addView(id, title, icon, component)` — adds a sidebar view and an activity bar icon. `icon`
is a `javax.swing.Icon` of your own, or null for a neutral placeholder. Your icon is drawn exactly
as you supply it, so it does not follow the colour theme; either draw it in colours that work on
both, or implement `ThemeAware` on the component and repaint the icon yourself.

`addTheme`, `addLanguage`, `addStatusItem`, `showMessage`, `showError` and `log` are documented on
`PluginContext` itself.

Also available: `dataDirectory()` for private storage (use this rather than writing next to the jar,
which may be read-only), `workspaceRoot()` for the open folder or null, and `isChinese()`.

### Packaging

```sh
javac -encoding UTF-8 -cp <codestudio.jar> -d build src/com/example/*.java
jar --create --file hello.jar -C build .
```

The manifest goes at the jar root, so it must land in `build/plugin.json` before the `jar` command.
A plugin jar needs no `Main-Class`.

Compile against CodeStudio's own classes, and **do not bundle them**. A plugin that packages its own
copy of `com.codestudio.api` — or of Swing — cannot be loaded, because the classes it would
contribute through are not the ones the running IDE is using. The plugin is reported as failed with
that reason.

---

## Failure is contained

If `activate` throws, that plugin is marked failed, the exception is recorded against it in the
Extensions view and written to the Output channel, and **the other plugins and the IDE are
unaffected**. There is no need to guard every call defensively.

A plugin that will not compile, will not load, or is missing its manifest is likewise reported
against itself alone.

---

## What a plugin cannot do

Three limits, stated plainly rather than discovered later:

1. **No new tokenizer rules.** The `Lexer` enum is closed at nine values, of which a plugin may use
   `GENERIC`, `PYTHON` and `SHELL` — those three tokenize purely from the keyword, comment and
   string configuration in the manifest, so a language using them needs no new code. Markdown, CSS,
   YAML and the others are hand-written tokenizers that a plugin cannot reach.
2. **No completions, no snippets.** The editor has no completion engine at all, and adding one is a
   project of its own; there is nothing for a manifest to plug into. This round of plugins
   contributes commands, themes, languages, views and status items.
3. **Not VS Code extensions.** VS Code extensions are JavaScript running in a Node host. Supporting
   them would mean reimplementing that host. A CodeStudio plugin is a Java jar.
