@echo off
setlocal
cd /d "%~dp0"

if not exist codestudio.jar (
    call "%~dp0build.bat"
    if errorlevel 1 exit /b 1
)

rem No arguments: start the IDE detached without a console window.
rem Any argument (--smoke, --version, a file or folder) runs in this console.
if "%~1"=="" (
    start "" javaw -jar codestudio.jar
    exit /b 0
)

java -jar codestudio.jar %*
endlocal
