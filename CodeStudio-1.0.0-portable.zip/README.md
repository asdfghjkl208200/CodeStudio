# CodeStudio

A desktop IDE written in pure Java (Swing / Java2D), aiming at the everyday feature set of
Visual Studio Code. **Zero external dependencies** — a plain JDK is enough to build and run it.

It speaks Chinese as well as English, hosts plugins, and has local accounts plus optional
GitHub sign-in.

## Description

CodeStudio is a desktop code editor and IDE for Windows, macOS and Linux, written in plain Java
with the Swing toolkit and no third-party libraries at all; a plain JDK 17 or newer is enough to
build and run it. Its aim is the everyday feature set of Visual Studio Code: a tabbed editor with
split views, syntax highlighting for 31 languages, code folding, suggestions and snippets, find and
replace, project-wide search, an outline, a file explorer, an integrated terminal, Git integration,
running and problem reporting, and workspace-wide go to definition, find all references and rename.
The interface is available in English and Simplified Chinese and switched at runtime; plugins can
contribute commands, themes, languages, sidebar views and status items; and every local account
keeps its own workspace and open files.

```
60 source files · ~24,900 lines · 31 languages · 559 translated strings · no third-party jars
```

![CodeStudio](docs/screenshot.png)

*The packaged `CodeStudio.exe`, started on a folder: explorer tree, outline, activity bar and
status bar showing the detected repo, caret position, indentation, encoding and line endings.*

| | |
|---|---|
| ![Accounts](docs/screenshot-accounts.png) | ![Extensions](docs/screenshot-extensions.png) |
| **Accounts** — two local accounts, the signed-in one marked, and the note explaining why GitHub sign-in is off until you supply a client id. | **Extensions** — a code plugin, a declarative plugin, and a broken one. The failure is reported in full against that plugin alone; the other two are unaffected. |

Those two are rendered straight from the sources by `build/Render.java` rather than photographed, so
they are exactly what Swing draws and neither is at the mercy of window focus or DPI. The
`CodeStudio.exe` screenshot above is a real capture; see [Notes](#notes) for why both exist. The
Chinese workbench is in `docs/screenshot-zh.png`.

## Requirements

* JDK 17 or newer (developed and tested on JDK 26, Windows 11)
* Nothing else. No Maven, no Gradle, no downloaded libraries.

## Build & run

```bat
build.bat            :: compile src\ into out\ and package codestudio.jar
run.bat              :: start the IDE (detached, no console window)
run.bat --smoke      :: run the self test and print a report
run.bat some\folder  :: start with a file or folder open
```

On a POSIX shell use `sh build.sh` instead. The jar is self-contained:

```sh
java -jar codestudio.jar --version
java -jar codestudio.jar --smoke
java -jar codestudio.jar path/to/project
```

`--smoke` builds the core models, runs the highlighter, opens a document, compiles and runs a
real Java program through the runner, parses the resulting compiler errors, and finally
constructs, lays out and paints a real `MainWindow` off-screen. It exits non-zero if any check
fails, so it doubles as a CI gate. It also exercises the fold model, snippet expansion and the
workspace symbol scan, none of which need a window to be checked.

## Windows executable

```bat
package.bat            :: -> dist\CodeStudio\CodeStudio.exe
package.bat 1.2.0      :: package a different version
```

This uses `jpackage` (part of the JDK, nothing to install) to produce a **native Windows
application**: `CodeStudio.exe`, a proper app icon, and a private Java runtime trimmed by
`jlink`. The result is ~63 MB and **runs on a machine with no JDK installed** — that is the
difference between this and the jar.

```
dist\CodeStudio\
  CodeStudio.exe        the launcher, with the icon embedded
  app\codestudio.jar    the application
  runtime\              a trimmed Java runtime (java.desktop + jdk.compiler)
```

The exe needs `app\` and `runtime\` beside it, so distribute the **whole folder**. Both scripts
finish by zipping it to `dist\CodeStudio-1.0.0-win-x64.zip`, which is the same folder in one file
for moving around.

Because the bundle includes `jdk.compiler`, the packaged IDE also carries its own `javac`:
`Runner` probes `PATH` first and falls back to the executable next to its own JVM, so Java
files still compile and run on a clean machine. Verified by stripping Java from `PATH` and
running the packaged self test:

```
$ PATH="C:\Windows\System32" CodeStudio.exe --smoke
  [ ok ] run java   exit 0, $ ...\runtime\bin\javac.exe ... Hello.java
                    $ ...\runtime\bin\java.exe -cp ... Hello
                    hello from codestudio
```

A single-file installer (`.exe` with a setup wizard, Start-menu entry, uninstaller) is also
possible via `jpackage --type exe`, but that additionally needs the **WiX Toolset**, which is
not installed here. `package.bat` deliberately uses `app-image` so it works with a bare JDK.

## Archives under 25 MB

```bat
package-zip.bat        :: -> dist\CodeStudio-1.0.0-portable.zip   (~0.7 MB)
                       ::    dist\CodeStudio-1.0.0-source.zip     (~0.4 MB)
```

The portable zip *is* the program: `codestudio.jar`, `run.bat`, the README and `docs`. Unzip it
anywhere and run `run.bat`, or `java -jar codestudio.jar`. It needs a JDK 17 or newer on the
machine, and that is exactly why it fits in a fraction of a megabyte. The second zip is the
source tree it was built from.

It carries no Java runtime, and it cannot: a Swing runtime is 49 MB on disk and 33 MB zipped even
with `jdk.compiler` left out of it, so a self-contained build is far outside a 25 MB budget.
`package.bat` builds that self-contained version for when not needing a JDK matters more than the
size of the download.

## What's in it

### Editor
* Tabbed editor with **split view** — a document can be moved between two editor groups.
* Line numbers, a clickable **breakpoint gutter**, current-line highlight, indent guides.
* **Minimap** on the right edge.
* **Code folding**: a chevron in the gutter, `Ctrl+Shift+[` / `Ctrl+Shift+]` for the block at
  the caret, `Ctrl+K Ctrl+0` / `Ctrl+K Ctrl+J` for all of them. Folds come from braces, Python
  and YAML indentation, Markdown headings and `#region` markers, and a folded block shows its
  first and last line.
* **Suggestions as you type** (`Ctrl+Space`): snippets first, then the language's keywords,
  types and constants, the symbols of the current file, and the words already in the buffer.
  `Tab` or `Enter` inserts, `Esc` dismisses. The snippet library covers Java, C, C++, Python,
  JavaScript, Go, Rust, HTML, CSS and shell.
* **Go to definition** (`F12`), **find all references** (`Shift+F12`) and **rename symbol**
  (`F2`) across the workspace, from the text rather than from a language server, with a picker
  when a symbol has more than one answer. Rename edits open buffers in memory and rewrites the
  rest on disk, after showing what it is about to do.
* Syntax highlighting for 31 languages, driven by a hand-written lexer (comments, strings,
  numbers, keywords, types, functions, annotations, brackets) with per-language palettes.
* `Ctrl+F` / `Ctrl+H` find & replace with match case, whole word and regex options.
* Auto-indent on newline, `Tab`/`Shift+Tab` block indent, `Ctrl+/` toggle comment,
  `Shift+Alt+F` format document, bracket auto-closing and auto-surround.
* Line operations: duplicate (`Ctrl+D`), delete line (`Ctrl+Shift+K`), move line up/down
  (`Alt+Up` / `Alt+Down`), and a word wrap toggle (`Alt+Z`).
* Per-document undo/redo, dirty tracking, cursor position restore, encoding and EOL
  (LF / CRLF) indicators with a status-bar picker.
* External-change detection: if a file changes on disk, the editor offers to reload.

### Workspace & navigation
* Folder explorer with lazy file tree, file-type icons, context menu (new file/folder, rename,
  delete, reveal in OS, run in terminal, copy path).
* Fuzzy **Quick Open** (`Ctrl+P`), command palette (`Ctrl+Shift+P`), go to symbol (`Ctrl+Shift+O`),
  go to line (`Ctrl+G`), and workspace symbol search.
* Project-wide **search** (`Ctrl+Shift+F`) with include/exclude globs, case and regex options.
* **Outline** view derived from the active document, click to jump.
* Breadcrumbs and a tab context menu (close, close others, close saved, close to the right).

### Running & debugging
* Run the active file with `F5`, debug with `Ctrl+F5`, stop with `Shift+F5`.
* Toolchain probing for Java, C, C++, Python, Node, Go, Rust, Shell, plus `.csproj`/`package.json`
  style config discovery.
* Output streamed live into the Output / Debug / Tasks channels, with a **terminal panel**
  (real shell, ANSI colours, scrollback).
* Build and runtime errors are parsed from tool output (javac, gcc/clang, Python tracebacks,
  Node stack traces, Go) into the **Problems** view; double-click a problem to jump to the line.

### Source control
* Git integration: branch in the status bar, changed-file list with staged/unstaged state,
  colour-coded diff viewer, commit message entry, stage/unstage/discard, and refresh on demand.

### Language
* **Chinese and English**, switchable at runtime from `workbench.language` — the whole interface
  is rebuilt on the spot, no restart. `system` (the default) follows the machine's locale.
* 559 translated strings. Keys are the English text itself, so anything not in the table falls
  back to English rather than showing a raw key.
* `java build/I18nCoverage.java` sweeps the sources for interface text the table is missing. It
  is not part of `--smoke` — it reads source files, which the packaged app does not ship — and it
  exists because the table's own consistency check cannot see a *missing* entry.

### Plugins
* **Jar plugins** implementing `CodeStudioPlugin`, and **declarative plugins** — a `plugin.json`
  with no code, contributing themes and languages only.
* Contribute commands (palette + Plugins menu), colour themes, languages, sidebar views and
  status bar items.
* Extensions view: installed list, enable/disable, uninstall, install from jar, open the plugins
  folder, reload. A plugin that fails to load is marked and explained there, and takes nothing
  else down with it.
* See **[docs/plugins.md](docs/plugins.md)** — the API, the manifest schema, a worked example,
  and the three things a plugin cannot do.

### Accounts
* **Local accounts**, working with no configuration: PBKDF2-hashed password, nothing secret on
  disk. Each account keeps its own workspace — open folder, open files and focus are swapped on
  switch.
* **GitHub sign-in** using the real OAuth Device Flow, once you put your own `client_id` in the
  `account.githubClientId` setting. Until then the button is disabled and says why.
* The GitHub token is written **in plain text** to `~/.codestudio/accounts.properties`. It is not
  encrypted and it is not in the Windows credential store — this is a pure Java application and
  cannot reach it. The sign-in dialog says so, and offers *don't save the token (this session
  only)*.

### Shell & chrome
* Activity bar, sidebar, status bar, bottom panel with maximize/restore, and hide-all toggles.
* **Zen Mode** (`Ctrl+K Z`): hides the menu bar, activity bar, side bar, panel and status bar,
  goes full screen, and puts back exactly what it hid on the way out.
* Command palette with over 60 built-in commands, keybinding hints and fuzzy scoring.
* **Dark and light themes** with a full palette each; the theme applies to Swing's own
  look-and-feel defaults too (menus, popups, tooltips).
* Toast notifications with a notification history.
* A settings view over 45 keys, searchable and applied live, persisted to
  `~/.codestudio/settings.properties`; window geometry and the open-session list are restored
  on the next launch.

## Keyboard shortcuts

| | |
|---|---|
| `Ctrl+P` / `Ctrl+Shift+P` | Go to file / show all commands |
| `Ctrl+Shift+O` / `Ctrl+G` | Go to symbol / go to line and column |
| `F12` / `Shift+F12` / `F2` | Go to definition / find all references / rename symbol |
| `Ctrl+Space` | Trigger suggestion |
| `Ctrl+Shift+[` / `Ctrl+Shift+]` | Fold / unfold the block at the caret |
| `Ctrl+K Ctrl+0` / `Ctrl+K Ctrl+J` | Fold all / unfold all |
| `Ctrl+K Z` | Zen Mode |
| `Ctrl+F` / `Ctrl+H` / `Ctrl+Shift+F` | Find / replace / find in files |
| `Ctrl+N` / `Ctrl+O` / `Ctrl+Alt+O` | New file / open file / open folder |
| `Ctrl+S` / `Ctrl+Shift+S` / `Ctrl+Alt+S` | Save / save as / save all |
| `Ctrl+W` / `Ctrl+Alt+W` | Close editor / close all editors |
| `F5` / `Ctrl+F5` / `Shift+F5` | Start debugging / run without debugging / stop |
| `F8` / `Shift+F8` | Next / previous problem |
| `Ctrl+B` / `Ctrl+J` / `` Ctrl+` `` | Toggle sidebar / panel / terminal |
| `Ctrl+Shift+E` `F` `G` `D` | Explorer, search, source control, run and debug |
| `Ctrl+Shift+M` / `Ctrl+Shift+U` | Problems / output panel |
| `Ctrl+Shift+I` / `Ctrl+/` | Format document / toggle line comment |
| `Alt+Z` / `Ctrl+=` / `Ctrl+-` / `Ctrl+0` | Word wrap / zoom in / out / reset |
| `Ctrl+,` / `F11` | Settings / full screen |

`Ctrl+Tab` and `Ctrl+Shift+Tab` cycle editors, `Tab` / `Shift+Tab` indent and outdent a
selection, and `Ctrl+D`, `Ctrl+Shift+K`, `Alt+Up/Down` operate on lines. The Help menu's
*Keyboard Shortcuts* entry lists the rest.

## Layout

```
Codestudio/
  build.bat, build.sh     compile + package the jar
  package.bat, .sh        build the Windows application + zip it (dist\)
  package-zip.bat         zip the program and the sources, both under 25 MB (dist\)
  run.bat                 launcher for the jar
  codestudio.jar          built artifact
  dist/                   packaged app + zip (generated)
  build/                  icon and staging area (generated)
  docs/screenshot.png     taken from the packaged exe
  docs/plugins.md         plugin development guide
  build/I18nCoverage.java translation coverage sweep (run: java build/I18nCoverage.java)
  build/Render.java       renders a MainWindow to a PNG without showing it
  build/shot.ps1          screenshots a live window (the packaged exe, hover states)
  tools/MakeIcon.java     draws the .ico, outside src\ so it stays out of the jar
  sources.txt             generated file list for javac
  src/com/codestudio/
    Main.java             entry point, CLI flags, self test
    api/                  the plugin surface: what a plugin compiles against
      CodeStudioPlugin  PluginContext
    core/                 model layer, no Swing
      Theme  Settings  Language  SyntaxHighlighter  Strings
      DocumentBundle  Workspace  Git  Runner  Problems  Breakpoints
      Account  GitHubAuth  Json
      Folding  Snippets  Navigator
      plugin/PluginManager  discovery, loading, lifecycle
    ui/                   Swing layer
      MainWindow          assembly, global key dispatch, command registry
      SideBar  ActivityBar  StatusBar  PanelArea  Notifications
      ExplorerPanel  SearchPanel  GitPanel  RunPanel  SettingsPanel
      WelcomePanel  AccountsPanel  ExtensionsPanel  SignInDialog
      ProblemsView  OutputView  OutlinePanel
      EditorGroup  EditorPanel  CodeTextPane  LineNumberView  Minimap
      FindReplaceBar  QuickOpen  SavePrompt  Dialogs
      FoldEditorKit  CompletionPopup  ResultPicker
      UI  Icons  SectionHeader  WrapArea  FileTreeModel
      TerminalPanel  TerminalView
      ThemeAware  ActiveAware    what a hosted view implements
```

`api` is a package of its own so a plugin can see both `core` and Swing without `core` having to
import `ui`.

`core` never imports `ui`, so the model layer can be exercised headlessly — which is exactly
what `--smoke` does.

## Notes

* Long-running work (git status, project search, builds, toolchain probing) runs on daemon
  threads and marshals results back to the event dispatch thread.
* Global shortcuts are installed with a `KeyEventDispatcher` so they work no matter which
  component has focus, while deliberately leaving the key combinations the text editor owns.
* Settings are written with a short debounce so typing in a settings field doesn't thrash
  the disk.
* The UI font is resolved once, at startup, from a chain of families that can actually draw
  Chinese (`Microsoft YaHei UI`, `Noto Sans SC`, …, `SansSerif`). Java2D does no font fallback
  for a *physical* family, so a hardcoded `Segoe UI` renders every Chinese label as an empty box.
  The self test asserts the chosen family can draw Chinese whenever the language is Chinese, so
  this cannot regress quietly.
* **Two screenshot tools, for two different jobs.** `build/shot.ps1` photographs a live window,
  which is the only way to capture the packaged `.exe` or a hover state — and it is also a race.
  A shot taken before the IDE has been raised or has finished painting comes back as the terminal,
  a blank frame, or the *previous* view, and each of those reads as an application bug and sends
  you looking for one that does not exist. `build/Render.java` sidesteps the race by laying the
  window out and painting it into an image, off the window manager entirely. What it cannot do is
  photograph the exe.
* **Verification boundary.** GitHub sign-in has only been exercised as far as request
  construction, without network; a real end-to-end sign-in needs your own GitHub OAuth App. And
  `--smoke` cannot click anything — menu behaviour, hover states and terminal interaction still
  need a human.
