@echo off
setlocal
cd /d "%~dp0"

rem ============================================================
rem  Packs CodeStudio into dist\ as archives under 25 MB:
rem
rem    CodeStudio-<ver>-portable.zip   the program: the jar, the
rem                                    launcher, the README and the
rem                                    docs. Runs anywhere with a
rem                                    JDK 17 or newer.
rem    CodeStudio-<ver>-source.zip     the sources of that program.
rem
rem  Why not the native build: a Swing runtime does not fit in 25 MB.
rem  package.bat's app-image is 49 MB on disk and 33 MB zipped even
rem  with jdk.compiler left out, and the runtime is 90% of that.
rem  Use package.bat when a self-contained build matters more than the
rem  size of the download, and this one when it does not.
rem ============================================================

set APP_VERSION=%~1
if "%APP_VERSION%"=="" set APP_VERSION=1.0.0
set PORTABLE=dist\CodeStudio-%APP_VERSION%-portable.zip
set SOURCES=dist\CodeStudio-%APP_VERSION%-source.zip

echo === 1/3  Build the jar ===
call "%~dp0build.bat"
if errorlevel 1 exit /b 1

echo.
echo === 2/3  Pack the portable build ===
if not exist dist mkdir dist
if exist "%PORTABLE%" del /q "%PORTABLE%"
rem Compress-Archive puts each file at the archive root and each folder under its
rem own name, which is the shape wanted here: unzip and run.bat is sitting there.
powershell -NoProfile -Command "Compress-Archive -Path 'codestudio.jar','run.bat','README.md','docs' -DestinationPath '%PORTABLE%' -CompressionLevel Optimal"
if errorlevel 1 (
    echo PORTABLE PACKAGING FAILED
    exit /b 1
)

echo.
echo === 3/3  Pack the sources ===
if exist "%SOURCES%" del /q "%SOURCES%"
rem tar rather than Compress-Archive: it keeps the folder structure, so
rem build\Render.java does not arrive as a loose Render.java at the root.
rem tar.exe ships with Windows 10 and later.
tar -a -c -f "%SOURCES%" src tools docs build\Render.java build\I18nCoverage.java build\shot.ps1 build.bat build.sh package.bat package.sh package-zip.bat run.bat README.md sources.txt
if errorlevel 1 (
    echo SOURCE PACKAGING FAILED
    exit /b 1
)

echo.
powershell -NoProfile -Command "$p=Get-Item '%PORTABLE%'; $s=Get-Item '%SOURCES%'; Write-Host ($p.Name + '  ' + [math]::Round($p.Length/1MB,2) + ' MB'); Write-Host ($s.Name + '  ' + [math]::Round($s.Length/1MB,2) + ' MB'); if ($p.Length -gt 25MB -or $s.Length -gt 25MB) { Write-Host 'OVER THE 25 MB LIMIT'; exit 1 } else { Write-Host 'both archives are within 25 MB' }"
if errorlevel 1 (
    echo.
    echo SIZE LIMIT EXCEEDED
    exit /b 1
)

echo.
echo ============================================================
echo  The portable zip is the program: unzip it anywhere and run
echo  run.bat (or: java -jar codestudio.jar). It needs a JDK 17 or
echo  newer on the machine - it does not carry one, which is the
echo  whole reason it fits in 25 MB.
echo ============================================================
endlocal
