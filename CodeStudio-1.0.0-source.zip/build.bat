@echo off
setlocal
cd /d "%~dp0"

echo === Build CodeStudio ===
where javac >nul 2>nul
if errorlevel 1 (
    echo javac was not found on PATH. Install a JDK ^(17 or newer^) and try again.
    exit /b 1
)

if not exist out mkdir out
dir /s /b src\*.java > sources.txt
rem Counted with set /a rather than piping to find: on a machine where Git's usr\bin comes
rem first on PATH, a bare "find" resolves to the Unix find.exe and scans the whole drive.
set COUNT=0
for /f "usebackq" %%c in ("sources.txt") do set /a COUNT+=1
echo Sources: %COUNT%

javac -encoding UTF-8 -d out @sources.txt
if errorlevel 1 (
    echo.
    echo BUILD FAILED
    exit /b 1
)

echo Classes compiled into out\
jar --create --file codestudio.jar --main-class com.codestudio.Main -C out .
if errorlevel 1 (
    echo.
    echo JAR PACKAGING FAILED
    exit /b 1
)

echo Created codestudio.jar
echo.
echo Run it with:  run.bat
echo Self test:    run.bat --smoke
endlocal
