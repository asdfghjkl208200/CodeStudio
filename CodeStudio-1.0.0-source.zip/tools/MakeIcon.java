import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Draws the CodeStudio application icon and writes it as a multi-resolution .ico file.
 *
 * <p>Standalone on purpose: it lives outside {@code src/} so it never ends up inside
 * codestudio.jar. Build and run it with
 *
 * <pre>javac -d tools/out tools/MakeIcon.java &amp;&amp; java -cp tools/out MakeIcon build/CodeStudio.ico</pre>
 *
 * <p>Each size is drawn at 8x and box-filtered down, which keeps the chevrons crisp at 16px
 * without shipping a font.
 */
public final class MakeIcon {

    private static final int[] SIZES = {256, 128, 64, 48, 32, 24, 16};
    private static final int SUPERSAMPLE = 8;

    private MakeIcon() {
    }

    public static void main(String[] args) throws Exception {
        File target = new File(args.length > 0 ? args[0] : "CodeStudio.ico");
        File parent = target.getAbsoluteFile().getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }

        List<byte[]> pngs = new ArrayList<>();
        for (int size : SIZES) {
            byte[] png = render(size);
            System.out.println("  " + size + "x" + size + "  " + png.length + " bytes");
            pngs.add(png);
        }
        try (OutputStream out = new FileOutputStream(target)) {
            writeIco(out, pngs);
        }
        System.out.println("Wrote " + target.getAbsolutePath() + " (" + target.length() + " bytes)");
    }

    /** Draws one size and encodes it as PNG. */
    private static byte[] render(int size) throws Exception {
        int big = size * SUPERSAMPLE;
        BufferedImage image = new BufferedImage(big, big, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        paint(g, big);
        g.dispose();

        BufferedImage scaled;
        if (size >= 64) {
            scaled = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
            Graphics2D sg = scaled.createGraphics();
            sg.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            sg.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            sg.drawImage(image, 0, 0, size, size, null);
            sg.dispose();
        } else {
            scaled = boxFilter(image, size);
        }

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ImageIO.write(scaled, "png", bytes);
        return bytes.toByteArray();
    }

    /** Rounded gradient tile with a white {@code </>} mark. */
    private static void paint(Graphics2D g, int s) {
        float radius = s * 0.235f;
        RoundRectangle2D tile = new RoundRectangle2D.Float(
                s * 0.035f, s * 0.035f, s * 0.93f, s * 0.93f, radius, radius);
        g.setPaint(new GradientPaint(0, 0, new Color(0x2F7DF6), 0, s, new Color(0x7A4DF0)));
        g.fill(tile);

        // A soft highlight across the top half keeps the flat tile from looking dead.
        g.setPaint(new GradientPaint(0, s * 0.035f, new Color(255, 255, 255, 46),
                0, s * 0.52f, new Color(255, 255, 255, 0)));
        g.fill(tile);

        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(s * 0.082f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        Path2D left = new Path2D.Float();
        left.moveTo(s * 0.395f, s * 0.305f);
        left.lineTo(s * 0.225f, s * 0.500f);
        left.lineTo(s * 0.395f, s * 0.695f);
        g.draw(left);

        Path2D right = new Path2D.Float();
        right.moveTo(s * 0.605f, s * 0.305f);
        right.lineTo(s * 0.775f, s * 0.500f);
        right.lineTo(s * 0.605f, s * 0.695f);
        g.draw(right);

        g.draw(new java.awt.geom.Line2D.Float(s * 0.565f, s * 0.245f, s * 0.435f, s * 0.755f));
    }

    /** Area-average downscale — crisper than bilinear for the tiny sizes. */
    private static BufferedImage boxFilter(BufferedImage src, int size) {
        int factor = src.getWidth() / size;
        BufferedImage dst = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        int[] pixels = new int[factor * factor];
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                src.getRGB(x * factor, y * factor, factor, factor, pixels, 0, factor);
                long a = 0;
                long r = 0;
                long gg = 0;
                long b = 0;
                for (int pixel : pixels) {
                    int pa = (pixel >>> 24) & 0xFF;
                    a += pa;
                    r += ((pixel >> 16) & 0xFF) * pa;
                    gg += ((pixel >> 8) & 0xFF) * pa;
                    b += (pixel & 0xFF) * pa;
                }
                int count = pixels.length;
                int alpha = (int) (a / count);
                if (a == 0) {
                    dst.setRGB(x, y, 0);
                    continue;
                }
                int red = (int) (r / a);
                int green = (int) (gg / a);
                int blue = (int) (b / a);
                dst.setRGB(x, y, (alpha << 24) | (red << 16) | (green << 8) | blue);
            }
        }
        return dst;
    }

    /**
     * Writes a Vista-or-newer .ico container. Every entry is a PNG, which the Windows shell
     * has accepted since Windows Vista and which keeps the 256px entry small.
     */
    private static void writeIco(OutputStream out, List<byte[]> pngs) throws Exception {
        int count = pngs.size();
        int headerSize = 6 + count * 16;
        int offset = headerSize;

        writeShort(out, 0);          // reserved
        writeShort(out, 1);          // 1 = icon
        writeShort(out, count);

        for (int i = 0; i < count; i++) {
            byte[] png = pngs.get(i);
            int size = SIZES[i];
            out.write(size >= 256 ? 0 : size);   // width, 0 means 256
            out.write(size >= 256 ? 0 : size);   // height
            out.write(0);                        // palette size
            out.write(0);                        // reserved
            writeShort(out, 1);                  // colour planes
            writeShort(out, 32);                 // bits per pixel
            writeInt(out, png.length);
            writeInt(out, offset);
            offset += png.length;
        }
        for (byte[] png : pngs) {
            out.write(png);
        }
    }

    private static void writeShort(OutputStream out, int value) throws Exception {
        out.write(value & 0xFF);
        out.write((value >> 8) & 0xFF);
    }

    private static void writeInt(OutputStream out, int value) throws Exception {
        out.write(value & 0xFF);
        out.write((value >> 8) & 0xFF);
        out.write((value >> 16) & 0xFF);
        out.write((value >> 24) & 0xFF);
    }
}
