#!/bin/sh
# POSIX equivalent of package.bat. On Windows run it from Git Bash.
set -e
cd "$(dirname "$0")"

APP_VERSION="${1:-1.0.0}"

command -v jpackage >/dev/null 2>&1 || {
    echo "jpackage was not found on PATH. It ships with the JDK (17 or newer)."
    exit 1
}

echo "=== 1/5  Build the jar ==="
sh build.sh

echo
echo "=== 2/5  Draw the application icon ==="
mkdir -p build tools/out
javac -encoding UTF-8 -d tools/out tools/MakeIcon.java
java -cp tools/out MakeIcon build/CodeStudio.ico

echo
echo "=== 3/5  Stage the input ==="
rm -rf build/stage
mkdir -p build/stage
cp codestudio.jar build/stage/

echo
echo "=== 4/5  jpackage ==="
rm -rf dist/CodeStudio

jpackage \
  --type app-image \
  --name CodeStudio \
  --app-version "$APP_VERSION" \
  --vendor CodeStudio \
  --description "A Visual Studio Code style IDE written in pure Java" \
  --icon build/CodeStudio.ico \
  --input build/stage \
  --main-jar codestudio.jar \
  --main-class com.codestudio.Main \
  --dest dist \
  --add-modules java.base,java.desktop,java.logging,java.net.http,java.prefs,java.xml,jdk.compiler \
  --jlink-options "--strip-debug --no-header-files --no-man-pages --compress zip-6" \
  --java-options "-Xmx1g" \
  --java-options "-Dsun.java2d.dpiaware=true"

echo
echo "=== 5/5  Zip the folder ==="
# The exe is useless without app/ and runtime/ beside it, and a zip is how the folder travels. Made
# here rather than by hand so it can never lag the exe it is supposed to contain — it did once:
# the exe had been rebuilt twice over while the zip still held the version before both.
rm -f "dist/CodeStudio-$APP_VERSION-win-x64.zip"
if command -v zip >/dev/null 2>&1; then
    (cd dist && zip -q -r "CodeStudio-$APP_VERSION-win-x64.zip" CodeStudio)
elif command -v powershell >/dev/null 2>&1; then
    # Compress-Archive is slow next to zip, but it is on every Windows box and zip is not.
    powershell -NoProfile -Command \
        "Compress-Archive -Path 'dist/CodeStudio' -DestinationPath 'dist/CodeStudio-$APP_VERSION-win-x64.zip'" \
        || { echo "Could not create the zip. The folder is still complete."; }
else
    echo "Neither zip nor powershell is available; skipping. The folder is still complete."
fi

echo
echo "============================================================"
echo " Done:  dist/CodeStudio/CodeStudio.exe"
echo "        dist/CodeStudio-$APP_VERSION-win-x64.zip"
echo
echo " The whole dist/CodeStudio folder is the application; the exe"
echo " needs runtime/ and app/ beside it, so copy the folder."
echo
echo " Verify:  dist/CodeStudio/CodeStudio.exe --smoke"
echo "============================================================"
