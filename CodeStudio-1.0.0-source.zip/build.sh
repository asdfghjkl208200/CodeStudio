#!/bin/sh
# Builds CodeStudio with a plain JDK (no build tool, no dependencies).
set -e
cd "$(dirname "$0")"

mkdir -p out
find src -name "*.java" | sort > sources.txt
echo "Sources: $(wc -l < sources.txt)"

javac -encoding UTF-8 -d out @sources.txt
jar --create --file codestudio.jar --main-class com.codestudio.Main -C out .

echo "Built codestudio.jar"
echo "  run   : java -jar codestudio.jar"
echo "  verify: java -jar codestudio.jar --smoke"
