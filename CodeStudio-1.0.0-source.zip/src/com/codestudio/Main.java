package com.codestudio;

import com.codestudio.core.Account;
import com.codestudio.core.DocumentBundle;
import com.codestudio.core.Folding;
import com.codestudio.core.Git;
import com.codestudio.core.GitHubAuth;
import com.codestudio.core.Language;
import com.codestudio.core.Navigator;
import com.codestudio.core.Problems;
import com.codestudio.core.Runner;
import com.codestudio.core.Settings;
import com.codestudio.core.Snippets;
import com.codestudio.core.Strings;
import com.codestudio.core.SyntaxHighlighter;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import com.codestudio.core.plugin.PluginManager;
import com.codestudio.ui.MainWindow;
import com.codestudio.ui.QuickOpen;
import com.codestudio.ui.UI;
import java.io.File;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import javax.swing.SwingUtilities;
import javax.tools.JavaCompiler;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import javax.swing.text.AttributeSet;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/** Command line entry point. */
public final class Main {

    private Main() {
    }

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        System.setProperty("file.encoding", "UTF-8");

        List<String> opens = new ArrayList<>();
        boolean smoke = false;
        for (String arg : args) {
            switch (arg) {
                case "--smoke" -> smoke = true;
                case "--help", "-h" -> {
                    printUsage();
                    return;
                }
                case "--version", "-v" -> {
                    System.out.println("CodeStudio " + MainWindow.VERSION
                            + " (Java " + System.getProperty("java.version") + ")");
                    return;
                }
                default -> opens.add(arg);
            }
        }

        Settings settings = Settings.load();
        if (smoke) {
            System.exit(runSmokeTest(settings));
        }

        SwingUtilities.invokeLater(() -> {
            try {
                MainWindow window = new MainWindow(settings);
                window.start();
                for (String path : opens) {
                    window.openPath(path);
                }
            } catch (Throwable t) {
                t.printStackTrace();
                javax.swing.JOptionPane.showMessageDialog(null,
                        "CodeStudio failed to start:\n\n" + t,
                        "Startup Error", javax.swing.JOptionPane.ERROR_MESSAGE);
                System.exit(1);
            }
        });
    }

    private static void printUsage() {
        System.out.println("Usage: codestudio [options] [files or folders...]");
        System.out.println();
        System.out.println("  --smoke      Run the startup self test and exit");
        System.out.println("  --version    Print the version and exit");
        System.out.println("  --help       Print this help and exit");
    }

    /**
     * Exercises the layers the workbench relies on, then builds the real window.
     * Returns 0 when everything checked out.
     */
    private static int runSmokeTest(Settings settings) {
        int failures = 0;
        System.out.println("CodeStudio " + MainWindow.VERSION + " self test");
        System.out.println("  java        : " + System.getProperty("java.version")
                + " (" + System.getProperty("java.vendor") + ")");
        System.out.println("  os          : " + System.getProperty("os.name") + " " + System.getProperty("os.arch"));
        System.out.println("  settings    : " + settings.file());

        failures += check("settings defaults", Settings.DEFAULTS.size() > 30,
                Settings.DEFAULTS.size() + " keys");
        failures += check("theme dark/light", Theme.dark() != null && Theme.light() != null, "ok");
        failures += check("languages", Language.all().size() >= 20, Language.all().size() + " languages");
        failures += check("detect .java", "java".equals(id(Language.detect("Foo.java"))), id(Language.detect("Foo.java")));
        failures += check("detect .py", "python".equals(id(Language.detect("a.py"))), id(Language.detect("a.py")));
        failures += check("detect .md", "markdown".equals(id(Language.detect("README.md"))), id(Language.detect("README.md")));
        failures += check("mono font", UI.resolveMono("Consolas") != null, UI.resolveMono("Consolas"));
        failures += check("fuzzy score", QuickOpen.fuzzyScore("gm", "Git: Commit") > 0
                && QuickOpen.fuzzyScore("zzz", "Git: Commit") < 0, "ok");

        try {
            File dir = Files.createTempDirectory("codestudio-smoke").toFile();
            File temp = new File(dir, "Demo.java");
            Files.writeString(temp.toPath(),
                    "package smoke;\n\npublic class Demo {\n    public static void main(String[] a) {\n"
                            + "        System.out.println(\"hi\");\n    }\n}\n", StandardCharsets.UTF_8);
            DocumentBundle bundle = DocumentBundle.open(temp);
            failures += check("open document", bundle.content().contains("System.out.println"),
                    bundle.name() + " / " + bundle.encoding);
            SyntaxHighlighter highlighter = new SyntaxHighlighter(Theme.dark());
            highlighter.highlight(bundle.doc, bundle.language);
            int styled = countStyledRuns(bundle.doc);
            failures += check("highlighter", styled > 3, styled + " styled runs");
            bundle.doc.insertString(bundle.doc.getLength(), "\n// more\n", null);
            failures += check("dirty flag", bundle.isDirty(), "dirty after edit");
            failures += check("package fqn", "smoke.Demo".equals(Runner.fullyQualifiedName(temp)),
                    String.valueOf(Runner.fullyQualifiedName(temp)));
            Runner.Plan plan = new Runner(workspaceFor(settings)).planFor(temp, false);
            failures += check("run plan", plan.isValid() || plan.problem != null,
                    plan.isValid() ? plan.name + " (" + plan.steps.size() + " steps)" : String.valueOf(plan.problem));
            temp.delete();
            dir.delete();
        } catch (Exception e) {
            failures += check("document round trip", false, e.toString());
        }

        failures += checkProblems();
        failures += checkEditorIntelligence(settings);
        failures += checkWorkspace(settings);
        failures += checkRunPipeline(settings);
        failures += checkStrings(settings);
        failures += checkAccount();
        failures += checkGitHub();
        // Runs before the window is built: it repoints the plugins directory at a temporary
        // folder, and the window would otherwise pick that up.
        failures += checkPlugins();

        System.out.println("  toolchain   : " + summarizeToolchain());
        System.out.println("  git         : " + (Git.available() ? "available" : "not on PATH"));
        System.out.println("  graphics    : " + (java.awt.GraphicsEnvironment.isHeadless() ? "headless" : "display available"));

        if (!java.awt.GraphicsEnvironment.isHeadless()) {
            failures += checkWindow(settings);
        }
        System.out.println(failures == 0 ? "SELF TEST PASSED" : "SELF TEST FAILED (" + failures + " problems)");
        return failures == 0 ? 0 : 1;
    }

    private static Workspace workspaceFor(Settings settings) {
        return new Workspace(settings);
    }

    /** Counts the character runs the highlighter styled (used as a sanity signal). */
    private static int countStyledRuns(StyledDocument doc) {
        int runs = 0;
        int offset = 0;
        while (offset < doc.getLength()) {
            Element element = doc.getCharacterElement(offset);
            AttributeSet attributes = element.getAttributes();
            if (attributes != null && attributes.isDefined(StyleConstants.Foreground)) {
                runs++;
            }
            int end = element.getEndOffset();
            offset = end > offset ? end : offset + 1;
        }
        return runs;
    }

    private static String id(Language lang) {
        return lang == null ? "null" : lang.id;
    }

    private static int checkProblems() {
        Problems.Parser parser = new Problems.Parser();
        int ok = 0;
        Problems.Problem java = parser.parse("src\\Demo.java:12: error: ';' expected", null);
        if (java != null && java.line == 11 && java.severity == Problems.Severity.ERROR) {
            ok++;
        }
        Problems.Problem c = parser.parse("main.c:4:9: warning: unused variable 'x'", null);
        if (c != null && c.line == 3 && c.severity == Problems.Severity.WARNING) {
            ok++;
        }
        Problems.Problem go = parser.parse("./main.go:7:2: undefined: fmt", null);
        if (go != null && go.line == 6) {
            ok++;
        }
        Problems.Problem node = parser.parse("    at Object.<anonymous> (C:\\app\\index.js:9:13)", null);
        if (node != null && node.line == 8) {
            ok++;
        }
        return check("problem parsers", ok == 4, ok + "/4 formats recognised");
    }

    private static int checkWorkspace(Settings settings) {
        Workspace workspace = new Workspace(settings);
        File root = new File(".").getAbsoluteFile();
        workspace.setRoot(root);
        List<File> files = workspace.indexFiles();
        return check("workspace index", !files.isEmpty(), files.size() + " files in " + root.getName());
    }

    /**
     * Code folding, snippet expansion and symbol navigation.
     *
     * <p>All three are model-level on purpose: the interesting parts - which lines a fold hides,
     * where a snippet puts the caret, which lines look like a declaration - are decided without a
     * window, so they can be checked here rather than by clicking.
     */
    private static int checkEditorIntelligence(Settings settings) {
        int failures = 0;
        Language java = Language.detect("Demo.java");
        Language python = Language.detect("a.py");

        String source = "package demo;\n\npublic class Demo {\n"
                + "    private int count;\n\n"
                + "    void run() {\n"
                + "        for (int i = 0; i < count; i++) {\n"
                + "            System.out.println(i);\n"
                + "        }\n"
                + "    }\n"
                + "}\n";
        List<Folding.Region> regions = Folding.compute(source, java);
        failures += check("fold regions", regions.size() >= 2, regions.size() + " regions");
        boolean[] mask = Folding.hiddenLines(source, java, Folding.allFoldableStarts(source, java));
        boolean hidSomething = false;
        for (boolean hidden : mask) {
            hidSomething |= hidden;
        }
        boolean keptCloser = mask.length > 2 && !mask[mask.length - 2];
        failures += check("fold hides inner lines", hidSomething && keptCloser,
                mask.length + " lines, closing brace visible");
        failures += check("fold unfoldable text", Folding.compute("int a = 1;\n", java).isEmpty(), "no regions");

        String py = "def run():\n    for i in range(3):\n        print(i)\n    return 1\n";
        failures += check("indent fold", Folding.allFoldableStarts(py, python).size() == 2,
                Folding.allFoldableStarts(py, python).size() + " python blocks");
        String md = "# One\n\ntext\n\n## Two\n\nmore\n";
        failures += check("markdown fold",
                Folding.allFoldableStarts(md, Language.detect("a.md")).size() >= 1, "heading block");

        int[] caret = new int[1];
        String println = Snippets.expand(Snippets.matching(java, "sout").get(0).body, "    ", caret);
        failures += check("snippet expand", "System.out.println();".equals(println) && caret[0] == 19,
                println + " caret " + caret[0]);
        String def = Snippets.expand(Snippets.matching(python, "def").get(0).body, "    ", caret);
        failures += check("snippet indent", def.contains("\n        pass") && caret[0] == 4,
                def.replace("\n", "\\n") + " caret " + caret[0]);
        failures += check("snippet library", Snippets.matching(java, "for").size() >= 1
                && Snippets.matching(java, "zzz").isEmpty(),
                Snippets.all(java).size() + " snippets for java");

        String text = "    total = total + other;\n";
        int at = text.indexOf("total") + 3;
        failures += check("identifier at caret", "total".equals(Navigator.identifierAt(text, at)),
                Navigator.identifierAt(text, at));
        int[] count = new int[1];
        String renamed = Navigator.replaceWholeWord("total totals total_count total;", "total", "sum", count);
        failures += check("whole word rename", count[0] == 2 && renamed.equals("sum totals total_count sum;"),
                count[0] + " replaced");

        // A real, if tiny, workspace: the scan has to find the declaration and the uses, and the
        // rewrite has to land on disk.
        File dir = null;
        String previous = settings.get("files.lastFolder");
        try {
            dir = Files.createTempDirectory("codestudio-nav").toFile();
            File a = new File(dir, "A.java");
            Files.writeString(a.toPath(), "public class A {\n    int total;\n"
                    + "    void add() { total = total + 1; }\n}\n", StandardCharsets.UTF_8);
            File b = new File(dir, "B.java");
            Files.writeString(b.toPath(), "class B {\n    void use() { new A(); }\n}\n",
                    StandardCharsets.UTF_8);
            Workspace workspace = new Workspace(settings);
            workspace.setRoot(dir);
            List<Navigator.Hit> definitions = Navigator.definitions(workspace, "total");
            List<Navigator.Hit> references = Navigator.references(workspace, "total");
            failures += check("go to definition", definitions.size() == 1,
                    definitions.size() + " definitions, " + references.size() + " references");
            failures += check("find references", references.size() >= 3, references.size() + " hits");
            int written = Navigator.renameInFile(a, "total", "amount");
            String after = Files.readString(a.toPath(), StandardCharsets.UTF_8);
            failures += check("rename on disk", written == 3 && after.contains("amount = amount + 1"),
                    written + " rewrites");
        } catch (Exception e) {
            failures += check("symbol navigation", false, e.toString());
        } finally {
            settings.set("files.lastFolder", previous == null ? "" : previous);
            if (dir != null) {
                Workspace.deleteRecursive(dir);
            }
        }
        return failures;
    }

    /** Compiles and runs a real Java program through the runner, then checks error reporting. */
    private static int checkRunPipeline(Settings settings) {
        if (!Runner.exists("javac")) {
            System.out.println("  [skip] run pipeline   no javac on PATH");
            return 0;
        }
        int failures = 0;
        File dir = null;
        try {
            dir = Files.createTempDirectory("codestudio-run").toFile();
            File good = new File(dir, "Hello.java");
            Files.writeString(good.toPath(),
                    "public class Hello {\n    public static void main(String[] args) {\n"
                            + "        System.out.println(\"hello from codestudio\");\n    }\n}\n",
                    StandardCharsets.UTF_8);
            Runner runner = new Runner(workspaceFor(settings));
            RunResult result = runOnce(runner, good);
            failures += check("run java", result.exitCode() == 0
                            && result.output().contains("hello from codestudio"),
                    "exit " + result.exitCode() + ", " + result.output().strip().replace('\n', ' '));

            File bad = new File(dir, "Broken.java");
            Files.writeString(bad.toPath(),
                    "public class Broken {\n    void x() { int y = ; }\n}\n", StandardCharsets.UTF_8);
            RunResult broken = runOnce(runner, bad);
            Problems.Parser parser = new Problems.Parser();
            int found = 0;
            for (String line : broken.output().split("\n")) {
                if (parser.parse(line, dir) != null) {
                    found++;
                }
            }
            failures += check("compile errors", broken.exitCode() != 0 && found > 0,
                    found + " problems parsed from javac output");
        } catch (Exception e) {
            failures += check("run pipeline", false, e.toString());
        } finally {
            if (dir != null) {
                Workspace.deleteRecursive(dir);
            }
        }
        return failures;
    }

    /**
     * Translation table integrity, runtime switching, and whether the interface font can actually
     * draw the result.
     *
     * <p>The font check is here because it fails silently and completely: Java2D renders a missing
     * glyph as an empty box and does no fallback, so a Latin-only interface font turns every
     * Chinese label into a row of boxes while every other check still passes.
     */
    private static int checkStrings(Settings settings) {
        int failures = 0;
        List<String> problems = Strings.check();
        failures += check("i18n table", problems.isEmpty(),
                Strings.size() + " entries, " + problems.size() + " problems");
        for (String problem : problems) {
            System.out.println("             ! " + problem);
        }

        Strings.setLanguage(Strings.CHINESE);
        boolean switched = Strings.isChinese() && "文件".equals(Strings.get("File"));
        String formatted = Strings.format("{0} of {1}", 3, 7);
        boolean format = formatted.contains("3") && formatted.contains("7");
        // A message that merely begins with a label must not be half translated: "File not found: x"
        // starts with "File", which is a key, but is not itself a key.
        boolean untouched = "File not found: x".equals(Strings.prefix("File not found: x"));
        boolean joined = Strings.prefix("Copied: a.txt").startsWith("已复制");
        boolean font = UI.uiFontHasChinese();
        // The newest entries: folding, suggestions and symbol navigation are translated like the
        // rest, so a missing one would show up as English in an otherwise Chinese workbench.
        boolean newest = "折叠".equals(Strings.get("Fold"))
                && "重命名符号".equals(Strings.get("Rename Symbol"))
                && "转到定义".equals(Strings.get("Go to Definition"));
        Strings.setLanguage(settings.get("workbench.language"));

        failures += check("i18n switch", switched, Strings.current());
        failures += check("i18n format", format, formatted);
        failures += check("i18n prefix", untouched && joined, "joined message translated");
        failures += check("i18n new entries", newest, "fold / rename / definition");
        // The About box carries one fixed English paragraph on purpose. It is checked here because
        // it is the one piece of interface text that must *not* follow the language setting, and
        // because a broken encoding would show up as a row of boxes rather than failing anything
        // else.
        boolean described = MainWindow.DESCRIPTION.length() > 300
                && MainWindow.DESCRIPTION.contains("CodeStudio")
                && MainWindow.DESCRIPTION.contains("Visual Studio Code")
                && MainWindow.DESCRIPTION.chars().allMatch(c -> c < 128);
        failures += check("about description", described,
                MainWindow.DESCRIPTION.length() + " characters, plain ASCII");
        failures += check("ui font cjk", !Strings.isChinese() || font,
                UI.UI_FAMILY + (font ? " draws Chinese" : " has no Chinese glyphs"));
        return failures;
    }

    /**
     * Local accounts: creation, password verification, and a round trip through the file on disk.
     * Redirected to a temporary store so the user's real accounts file is never read or written.
     */
    private static int checkAccount() {
        int failures = 0;
        String previous = System.getProperty("codestudio.accounts.file");
        Path store;
        try {
            store = Files.createTempDirectory("codestudio-accounts").resolve("accounts.properties");
        } catch (Exception e) {
            return check("account store", false, e.toString());
        }
        System.setProperty("codestudio.accounts.file", store.toString());
        try {
            Account.reload();
            Account created = Account.createLocal("smoke", "correct horse battery");
            if (created == null) {
                failures += check("account create", false, "createLocal returned null");
            } else {
                boolean accepted = created.verify("correct horse battery");
                boolean rejected = !created.verify("wrong password");
                failures += check("account verify", accepted && rejected,
                        accepted ? "accepts and rejects" : "rejected the correct password");

                // Re-read from disk: the salt and hash must survive the round trip.
                Account.reload();
                Account reread = Account.byId(created.id);
                failures += check("account reload", reread != null && reread.verify("correct horse battery"),
                        reread == null ? "gone after reload" : "verified from disk");
            }
            if (Files.isRegularFile(store)) {
                String text = Files.readString(store, StandardCharsets.UTF_8);
                failures += check("account secrecy", !text.contains("correct horse battery"),
                        "password absent from the store");
            }
        } catch (Exception e) {
            failures += check("account store", false, e.toString());
        } finally {
            if (previous == null) {
                System.clearProperty("codestudio.accounts.file");
            } else {
                System.setProperty("codestudio.accounts.file", previous);
            }
            Account.reload();
            try {
                Files.deleteIfExists(store);
            } catch (Exception ignored) {
                // Left in the temporary directory; harmless.
            }
        }
        return failures;
    }

    /**
     * The device flow's request shape. Deliberately makes no network call: there is no client id
     * configured, and a self test must not depend on GitHub being reachable.
     */
    private static int checkGitHub() {
        boolean blank = !GitHubAuth.isConfigured("") && !GitHubAuth.isConfigured(null)
                && !GitHubAuth.isConfigured("   ");
        boolean configured = GitHubAuth.isConfigured("Iv1.0123456789abcdef");
        boolean code = GitHubAuth.deviceCodeBody("Iv1.abc", "read:user")
                .equals("client_id=Iv1.abc&scope=read%3Auser");
        boolean token = GitHubAuth.tokenBody("Iv1.abc", "dev-code")
                .contains("grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Adevice_code");
        Map<String, String> headers = GitHubAuth.userHeaders("tok123");
        boolean auth = "Bearer tok123".equals(headers.get("Authorization"))
                && headers.get("Accept") != null && headers.get("User-Agent") != null;
        // GitHub answers form-encoded unless asked for JSON, which the parser cannot read.
        boolean post = "application/json".equals(GitHubAuth.postHeaders().get("Accept"));
        return check("github request", blank && configured && code && token && auth && post,
                "blank client id disables sign-in, no network used");
    }

    /**
     * Compiles a plugin against {@code com.codestudio.api}, packages it as a jar with a manifest,
     * loads it through {@link PluginManager}, and checks that its command arrives — alongside a
     * deliberately broken plugin, to show the failure stays contained to itself.
     */
    private static int checkPlugins() {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            System.out.println("  plugins     : skipped, this runtime has no compiler");
            return 0;
        }
        int failures = 0;
        String previous = System.getProperty("codestudio.plugins.dir");
        Path root = null;
        PluginManager manager = null;
        try {
            root = Files.createTempDirectory("codestudio-plugins");
            Path plugins = Files.createDirectories(root.resolve("plugins"));
            Path classes = Files.createDirectories(root.resolve("classes"));
            Path src = Files.createDirectories(root.resolve("src")).resolve("DemoPlugin.java");
            Files.writeString(src, DEMO_PLUGIN, StandardCharsets.UTF_8);

            // Compiled against this application's own classpath, exactly as a plugin author would.
            StandardJavaFileManager files =
                    compiler.getStandardFileManager(null, null, StandardCharsets.UTF_8);
            boolean compiled;
            try {
                compiled = compiler.getTask(null, files, null,
                        List.of("-encoding", "UTF-8",
                                "-classpath", System.getProperty("java.class.path"),
                                "-d", classes.toString()),
                        null, files.getJavaFileObjects(src)).call();
            } finally {
                files.close();
            }
            if (!compiled) {
                return check("plugin compile", false, "javac rejected the demo plugin");
            }

            Map<String, byte[]> good = new LinkedHashMap<>();
            good.put("plugin.json", ("{\"id\":\"demo.hello\",\"name\":\"Demo Plugin\","
                    + "\"version\":\"1.0\",\"main\":\"demo.DemoPlugin\"}").getBytes(StandardCharsets.UTF_8));
            good.put("demo/DemoPlugin.class",
                    Files.readAllBytes(classes.resolve("demo").resolve("DemoPlugin.class")));
            writeJar(plugins.resolve("demo.jar"), good);

            // A manifest that names an entry class the jar does not contain.
            Map<String, byte[]> broken = new LinkedHashMap<>();
            broken.put("plugin.json", ("{\"id\":\"demo.broken\",\"name\":\"Broken Plugin\","
                    + "\"version\":\"1.0\",\"main\":\"demo.NotThere\"}").getBytes(StandardCharsets.UTF_8));
            writeJar(plugins.resolve("broken.jar"), broken);

            System.setProperty("codestudio.plugins.dir", plugins.toString());
            manager = new PluginManager();
            manager.setHost(new PluginManager.Host() {
                @Override
                public void showMessage(String pluginId, String message) {
                }

                @Override
                public void showError(String pluginId, String message, Throwable cause) {
                }

                @Override
                public void log(String pluginId, String message) {
                }
            });
            manager.reload();

            PluginManager.Info loaded = manager.info("demo.hello");
            PluginManager.Info failed = manager.info("demo.broken");
            boolean command = manager.commands().stream()
                    .anyMatch(c -> "demo.hello.say".equals(c.id()) && "Say Hello".equals(c.title()));
            failures += check("plugin loads", command && loaded != null && !loaded.failed(),
                    loaded == null ? "not discovered" : loaded.name() + " " + loaded.version());
            failures += check("plugin isolated",
                    failed != null && failed.failed() && loaded != null && !loaded.failed(),
                    failed == null ? "broken plugin not listed" : "one failed, the other unaffected");

            manager.setEnabled("demo.hello", false);
            boolean disabled = !manager.isEnabled("demo.hello") && manager.commands().isEmpty();
            manager.setEnabled("demo.hello", true);
            boolean enabled = manager.isEnabled("demo.hello") && !manager.commands().isEmpty();
            failures += check("plugin toggle", disabled && enabled, "disable then enable");
        } catch (Exception e) {
            failures += check("plugin pipeline", false, e.toString());
        } finally {
            // Unloading closes the jar handles; without that Windows will not delete them.
            if (manager != null) {
                for (PluginManager.Info info : manager.plugins()) {
                    try {
                        manager.uninstall(info.id());
                    } catch (Exception ignored) {
                        // Best effort; the directory lives under the system temporary folder.
                    }
                }
            }
            if (previous == null) {
                System.clearProperty("codestudio.plugins.dir");
            } else {
                System.setProperty("codestudio.plugins.dir", previous);
            }
            deleteTree(root);
        }
        return failures;
    }

    /** Writes a jar containing the given entries, without needing an external {@code jar} tool. */
    private static void writeJar(Path target, Map<String, byte[]> entries) throws Exception {
        try (OutputStream out = Files.newOutputStream(target);
             JarOutputStream jar = new JarOutputStream(out)) {
            for (Map.Entry<String, byte[]> e : entries.entrySet()) {
                jar.putNextEntry(new JarEntry(e.getKey()));
                jar.write(e.getValue());
                jar.closeEntry();
            }
        }
    }

    private static void deleteTree(Path root) {
        if (root == null) {
            return;
        }
        try (var paths = Files.walk(root)) {
            paths.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (Exception ignored) {
                    // A file still open elsewhere; the temporary directory will be reclaimed later.
                }
            });
        } catch (Exception ignored) {
            // Nothing further to do.
        }
    }

    /** The plugin the self test compiles, packages and loads. */
    private static final String DEMO_PLUGIN = """
            package demo;

            import com.codestudio.api.CodeStudioPlugin;
            import com.codestudio.api.PluginContext;

            public class DemoPlugin implements CodeStudioPlugin {
                public String id()      { return "demo.hello"; }
                public String name()    { return "Demo Plugin"; }
                public String version() { return "1.0"; }

                public void activate(PluginContext context) {
                    context.addCommand("demo.hello.say", "Demo", "Say Hello", "", () -> { });
                }
            }
            """;

    private static RunResult runOnce(Runner runner, File file) throws Exception {
        Runner.Plan plan = runner.planFor(file, false);
        if (!plan.isValid()) {
            return new RunResult(-1, String.valueOf(plan.problem));
        }
        StringBuilder output = new StringBuilder();
        java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
        int[] code = {-1};
        runner.start(plan, new Runner.Listener() {
            @Override
            public void onStarted(String commandLine, File directory) {
                output.append("$ ").append(commandLine).append('\n');
            }

            @Override
            public void onOutput(String line, boolean stderr) {
                output.append(line).append('\n');
            }

            @Override
            public void onFinished(int exitCode, long millis, boolean stopped) {
                code[0] = exitCode;
                done.countDown();
            }
        });
        if (!done.await(60, java.util.concurrent.TimeUnit.SECONDS)) {
            runner.stop();
            return new RunResult(-1, output + "\n(timed out)");
        }
        return new RunResult(code[0], output.toString());
    }

    private record RunResult(int exitCode, String output) {
    }

    private static int checkWindow(Settings settings) {
        final String[] error = {null};
        final Boolean[] editorInTree = {null};
        final Boolean[] described = {null};
        try {
            SwingUtilities.invokeAndWait(() -> {
                try {
                    MainWindow window = new MainWindow(settings);
                    window.setSize(1280, 820);
                    window.addNotify();
                    window.validate();

                    // Opening a file has to put its editor into the window's component tree. A group
                    // that is built but never attached leaves the editor area blank, and nothing
                    // else here would notice: the window still paints, and every model check passes.
                    File probe = File.createTempFile("codestudio-window", ".java");
                    Files.writeString(probe.toPath(), "class WindowProbe {\n    int x = 1;\n}\n",
                            StandardCharsets.UTF_8);
                    window.openPath(probe.getAbsolutePath());
                    window.validate();
                    editorInTree[0] = hasEditor(window);
                    described[0] = window.aboutText().contains(MainWindow.DESCRIPTION);
                    probe.delete();

                    java.awt.image.BufferedImage image = new java.awt.image.BufferedImage(
                            1280, 820, java.awt.image.BufferedImage.TYPE_INT_ARGB);
                    java.awt.Graphics2D g = image.createGraphics();
                    window.getContentPane().paint(g);
                    window.getJMenuBar().paint(g);
                    g.dispose();
                    window.dispose();
                } catch (Throwable t) {
                    error[0] = t.toString();
                    t.printStackTrace(System.out);
                }
            });
        } catch (Exception e) {
            error[0] = e.toString();
        }
        int failures = check("window builds", error[0] == null, error[0] == null ? "ok" : error[0]);
        failures += check("window shows the editor", Boolean.TRUE.equals(editorInTree[0]),
                "an open file reaches the window");
        failures += check("about box describes it", Boolean.TRUE.equals(described[0]),
                "the About box carries the English description");
        return failures;
    }

    /** Whether a text editor is somewhere in this component tree. */
    private static boolean hasEditor(java.awt.Component c) {
        if (c instanceof com.codestudio.ui.CodeTextPane) {
            return true;
        }
        if (c instanceof java.awt.Container container) {
            for (java.awt.Component child : container.getComponents()) {
                if (hasEditor(child)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static String summarizeToolchain() {
        List<String[]> tools = Runner.toolchain();
        if (tools.isEmpty()) {
            return "none detected on PATH";
        }
        StringBuilder sb = new StringBuilder();
        for (String[] tool : tools) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(tool[0]);
        }
        return sb.toString();
    }

    private static int check(String name, boolean ok, String detail) {
        System.out.println("  " + (ok ? "[ ok ] " : "[FAIL] ") + pad(name) + detail);
        return ok ? 0 : 1;
    }

    private static String pad(String name) {
        StringBuilder sb = new StringBuilder(name);
        while (sb.length() < 16) {
            sb.append(' ');
        }
        return sb.toString();
    }
}
