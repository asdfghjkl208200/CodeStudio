package com.codestudio.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Builds and executes programs in the workspace, streaming their output. */
public class Runner {

    /** One command of a run plan. */
    public static class Step {
        public final List<String> command;
        public final File directory;
        public final String label;

        public Step(String label, File directory, List<String> command) {
            this.label = label;
            this.directory = directory;
            this.command = command;
        }
    }

    /** A complete sequence of steps for a file. */
    public static class Plan {
        public final String name;
        public final File file;
        public final List<Step> steps = new ArrayList<>();
        public String problem;
        public String sourceType = "text";

        Plan(String name, File file) {
            this.name = name;
            this.file = file;
        }

        public boolean isValid() {
            return problem == null && !steps.isEmpty();
        }
    }

    /** Receives live output from a running task. */
    public interface Listener {
        void onStarted(String commandLine, File directory);

        void onOutput(String line, boolean stderr);

        void onFinished(int exitCode, long millis, boolean stopped);
    }

    /** A currently running or finished task. */
    public static class Task {
        public final Plan plan;
        private volatile Process process;
        private volatile boolean stopped;
        private final List<String> transcript = new ArrayList<>();

        Task(Plan plan) {
            this.plan = plan;
        }

        public boolean isRunning() {
            Process p = process;
            return p != null && p.isAlive();
        }

        public List<String> transcript() {
            synchronized (transcript) {
                return new ArrayList<>(transcript);
            }
        }

        void addLine(String line) {
            synchronized (transcript) {
                transcript.add(line);
                if (transcript.size() > 4000) {
                    transcript.remove(0);
                }
            }
        }

        /** Terminates the process tree. */
        public void stop() {
            stopped = true;
            Process p = process;
            if (p == null) {
                return;
            }
            try {
                p.descendants().forEach(ProcessHandle::destroyForcibly);
            } catch (Exception ignored) {
                // best effort
            }
            p.destroyForcibly();
        }
    }

    private final Workspace workspace;
    private volatile Task current;
    private volatile Listener listener;

    public Runner(Workspace workspace) {
        this.workspace = workspace;
    }

    public Task currentTask() {
        return current;
    }

    public boolean isRunning() {
        Task t = current;
        return t != null && t.isRunning();
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    /* ------------------------------------------------------------------ */
    /* tool detection                                                      */
    /* ------------------------------------------------------------------ */

    /**
     * Returns the first candidate that can actually be executed, or null. The returned string is
     * what goes on a command line: normally the bare name, but the absolute path of the copy
     * bundled inside our own runtime when nothing on PATH provides it.
     */
    public static String findTool(String... candidates) {
        for (String c : candidates) {
            if (probe(c)) {
                return c;
            }
            String bundled = bundledTool(c);
            if (bundled != null && probe(bundled)) {
                return bundled;
            }
        }
        return null;
    }

    public static boolean exists(String tool) {
        if (probe(tool)) {
            return true;
        }
        String bundled = bundledTool(tool);
        return bundled != null && probe(bundled);
    }

    /**
     * Absolute path of a tool shipped beside the JVM we are running on, or null. A packaged
     * CodeStudio carries its own runtime, so this is how it finds {@code javac} and {@code java}
     * on a machine with no JDK installed.
     */
    public static String bundledTool(String tool) {
        if (tool == null || tool.isBlank() || tool.contains("/") || tool.contains("\\")) {
            return null;
        }
        String home = System.getProperty("java.home");
        if (home == null || home.isBlank()) {
            return null;
        }
        String name = isWindows() && !tool.toLowerCase(Locale.ROOT).endsWith(".exe") ? tool + ".exe" : tool;
        File candidate = new File(new File(home, "bin"), name);
        return candidate.isFile() ? candidate.getAbsolutePath() : null;
    }

    /** Runs {@code <command> --version} and reports whether it started and exited. */
    private static boolean probe(String command) {
        if (command == null || command.isBlank()) {
            return false;
        }
        List<String> probe = new ArrayList<>();
        probe.add(command);
        probe.add("--version");
        try {
            ProcessBuilder pb = new ProcessBuilder(probe);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            try (InputStream in = p.getInputStream()) {
                while (in.read() >= 0) {
                    // drain so the process can exit
                }
            }
            return p.waitFor(6, TimeUnit.SECONDS);
        } catch (IOException e) {
            return false;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    /** Snapshot of the toolchain found on this machine. */
    public static List<String[]> toolchain() {
        List<String[]> out = new ArrayList<>();
        String java = findTool("java");
        if (java != null) {
            out.add(new String[]{"java", version(java)});
        }
        String javac = findTool("javac");
        if (javac != null) {
            out.add(new String[]{"javac", version(javac)});
        }
        String python = findTool("python", "python3", "py");
        if (python != null) {
            out.add(new String[]{"python", version(python)});
        }
        String node = findTool("node");
        if (node != null) {
            out.add(new String[]{"node", version(node)});
        }
        String npm = findTool("npm");
        if (npm != null) {
            out.add(new String[]{"npm", version(npm)});
        }
        String gcc = findTool("gcc", "cc", "clang");
        if (gcc != null) {
            out.add(new String[]{Strings.get("c compiler"), version(gcc)});
        }
        String gpp = findTool("g++", "clang++");
        if (gpp != null) {
            out.add(new String[]{Strings.get("c++ compiler"), version(gpp)});
        }
        String go = findTool("go");
        if (go != null) {
            out.add(new String[]{"go", version(go)});
        }
        String cargo = findTool("cargo");
        if (cargo != null) {
            out.add(new String[]{"cargo", version(cargo)});
        }
        String git = findTool("git");
        if (git != null) {
            out.add(new String[]{"git", version(git)});
        }
        return out;
    }

    private static String version(String tool) {
        List<String> cmd = new ArrayList<>();
        cmd.add(tool);
        cmd.add("--version");
        try {
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            String first;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                first = r.readLine();
            }
            p.waitFor(6, TimeUnit.SECONDS);
            return first == null ? "" : first.trim();
        } catch (Exception e) {
            return "";
        }
    }

    /* ------------------------------------------------------------------ */
    /* run plans                                                           */
    /* ------------------------------------------------------------------ */

    /** Builds the steps needed to build (and run) a file. */
    public Plan planFor(File file, boolean debug) {
        Plan plan = new Plan(file == null ? Strings.get("Untitled") : file.getName(), file);
        if (file == null) {
            plan.problem = Strings.get("Save the file before running it.");
            return plan;
        }
        String name = file.getName().toLowerCase(java.util.Locale.ROOT);
        File dir = file.getParentFile() == null ? new File(".") : file.getParentFile();
        File outDir = workspace.getRoot() != null ? new File(workspace.getRoot(), ".codestudio-bin") : new File(dir, ".codestudio-bin");

        if (name.endsWith(".java")) {
            plan.sourceType = "java";
            String javac = findTool("javac");
            String java = findTool("java");
            if (javac == null || java == null) {
                plan.problem = Strings.get("A JDK (javac and java) is required to run Java files.");
                return plan;
            }
            String fqn = fullyQualifiedName(file);
            List<String> compile = new ArrayList<>();
            compile.add(javac);
            compile.add("-encoding");
            compile.add("UTF-8");
            compile.add("-d");
            compile.add(outDir.getAbsolutePath());
            compile.add(file.getAbsolutePath());
            plan.steps.add(new Step("javac " + file.getName(), dir, compile));

            List<String> run = new ArrayList<>();
            run.add(java);
            if (debug) {
                run.add("-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=127.0.0.1:5005");
            }
            run.add("-cp");
            run.add(outDir.getAbsolutePath());
            run.add(fqn);
            plan.steps.add(new Step("java " + fqn, dir, run));
            return plan;
        }

        if (name.endsWith(".py")) {
            plan.sourceType = "python";
            String python = findTool("python", "python3", "py");
            if (python == null) {
                plan.problem = Strings.get("Python was not found on PATH.");
                return plan;
            }
            List<String> cmd = new ArrayList<>();
            cmd.add(python);
            cmd.add("-u");
            cmd.add(file.getAbsolutePath());
            plan.steps.add(new Step(python + " " + file.getName(), dir, cmd));
            return plan;
        }

        if (name.endsWith(".js") || name.endsWith(".mjs") || name.endsWith(".cjs")) {
            plan.sourceType = "javascript";
            String node = findTool("node");
            if (node == null) {
                plan.problem = Strings.get("Node.js was not found on PATH.");
                return plan;
            }
            List<String> cmd = new ArrayList<>();
            cmd.add(node);
            cmd.add(file.getAbsolutePath());
            plan.steps.add(new Step("node " + file.getName(), dir, cmd));
            return plan;
        }

        if (name.endsWith(".ts")) {
            plan.sourceType = "javascript";
            String tsnode = findTool("ts-node");
            String node = findTool("node");
            if (tsnode != null) {
                List<String> cmd = new ArrayList<>();
                cmd.add(tsnode);
                cmd.add(file.getAbsolutePath());
                plan.steps.add(new Step("ts-node " + file.getName(), dir, cmd));
                return plan;
            }
            if (node != null) {
                List<String> cmd = new ArrayList<>();
                cmd.add(node);
                cmd.add(file.getAbsolutePath());
                plan.steps.add(new Step("node " + file.getName(), dir, cmd));
                return plan;
            }
            plan.problem = Strings.get("Install ts-node or compile the file to JavaScript first.");
            return plan;
        }

        if (name.endsWith(".c")) {
            return compileAndRun(plan, dir, outDir, file, "c compiler", "gcc", "cc", "clang");
        }
        if (name.endsWith(".cpp") || name.endsWith(".cc") || name.endsWith(".cxx")) {
            return compileAndRun(plan, dir, outDir, file, "c++ compiler", "g++", "clang++", "g++");
        }
        if (name.endsWith(".go")) {
            plan.sourceType = "go";
            String go = findTool("go");
            if (go == null) {
                plan.problem = Strings.get("The Go toolchain was not found on PATH.");
                return plan;
            }
            List<String> cmd = new ArrayList<>();
            cmd.add(go);
            cmd.add("run");
            cmd.add(file.getAbsolutePath());
            plan.steps.add(new Step("go run " + file.getName(), dir, cmd));
            return plan;
        }
        if (name.endsWith(".rs")) {
            plan.sourceType = "rust";
            String rustc = findTool("rustc");
            if (rustc == null) {
                plan.problem = Strings.get("rustc was not found on PATH.");
                return plan;
            }
            File exe = new File(outDir, baseName(file) + (isWindows() ? ".exe" : ""));
            List<String> compile = new ArrayList<>();
            compile.add(rustc);
            compile.add("-o");
            compile.add(exe.getAbsolutePath());
            compile.add(file.getAbsolutePath());
            plan.steps.add(new Step("rustc " + file.getName(), dir, compile));
            List<String> run = new ArrayList<>();
            run.add(exe.getAbsolutePath());
            plan.steps.add(new Step(exe.getName(), dir, run));
            return plan;
        }
        if (name.endsWith(".sh")) {
            plan.sourceType = "shell";
            String shell = isWindows() ? findTool("bash", "sh") : findTool("bash", "sh");
            if (shell == null) {
                plan.problem = Strings.get("No shell (bash) was found on PATH.");
                return plan;
            }
            List<String> cmd = new ArrayList<>();
            cmd.add(shell);
            cmd.add(file.getAbsolutePath());
            plan.steps.add(new Step(shell + " " + file.getName(), dir, cmd));
            return plan;
        }
        if (name.endsWith(".bat") || name.endsWith(".cmd")) {
            plan.sourceType = "batch";
            List<String> cmd = new ArrayList<>();
            cmd.add("cmd");
            cmd.add("/c");
            cmd.add(file.getAbsolutePath());
            plan.steps.add(new Step("cmd /c " + file.getName(), dir, cmd));
            return plan;
        }
        if (name.endsWith(".jar")) {
            plan.sourceType = "java";
            String java = findTool("java");
            if (java == null) {
                plan.problem = Strings.get("A JDK is required to run jar files.");
                return plan;
            }
            List<String> cmd = new ArrayList<>();
            cmd.add(java);
            cmd.add("-jar");
            cmd.add(file.getAbsolutePath());
            plan.steps.add(new Step("java -jar " + file.getName(), dir, cmd));
            return plan;
        }

        plan.problem = Strings.format(
                "There is no runner configured for {0}.\nSupported: .java .py .js .ts .c .cpp .go .rs .sh .bat .jar",
                file.getName());
        return plan;
    }

    private Plan compileAndRun(Plan plan, File dir, File outDir, File file, String what, String... candidates) {
        plan.sourceType = "c";
        String compiler = findTool(candidates);
        if (compiler == null) {
            plan.problem = Strings.format("No {0} was found on PATH.", Strings.get(what));
            return plan;
        }
        outDir.mkdirs();
        File exe = new File(outDir, baseName(file) + (isWindows() ? ".exe" : ""));
        List<String> compile = new ArrayList<>();
        compile.add(compiler);
        compile.add("-g");
        compile.add("-Wall");
        compile.add("-o");
        compile.add(exe.getAbsolutePath());
        compile.add(file.getAbsolutePath());
        if (compiler.contains("++")) {
            compile.add("-std=c++17");
        }
        plan.steps.add(new Step(compiler + " " + file.getName(), dir, compile));
        List<String> run = new ArrayList<>();
        run.add(exe.getAbsolutePath());
        plan.steps.add(new Step(exe.getName(), dir, run));
        return plan;
    }

    private static String baseName(File f) {
        String n = f.getName();
        int dot = n.lastIndexOf('.');
        return dot < 0 ? n : n.substring(0, dot);
    }

    public static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT).contains("win");
    }

    /** Package aware class name used by the java launcher. */
    public static String fullyQualifiedName(File file) {
        String simple = baseName(file);
        try {
            String text = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("^\\s*package\\s+([\\w.]+)\\s*;", java.util.regex.Pattern.MULTILINE).matcher(text);
            if (m.find()) {
                return m.group(1) + "." + simple;
            }
        } catch (IOException ignored) {
            // fall back to the default package
        }
        return simple;
    }

    /* ------------------------------------------------------------------ */
    /* execution                                                           */
    /* ------------------------------------------------------------------ */

    /** Starts a plan. Returns the task handle immediately. */
    public Task start(Plan plan, Listener l) {
        stop();
        Task task = new Task(plan);
        current = task;
        this.listener = l;
        Thread t = new Thread(() -> execute(task, l), "runner");
        t.setDaemon(true);
        t.start();
        return task;
    }

    /** Alias used when the caller already registered a listener. */
    public Task start(Plan plan) {
        return start(plan, listener);
    }

    private void execute(Task task, Listener l) {
        long started = System.currentTimeMillis();
        int exit = 0;
        for (Step step : task.plan.steps) {
            if (task.stopped) {
                break;
            }
            String commandLine = String.join(" ", step.command);
            if (l != null) {
                l.onStarted(commandLine, step.directory);
            }
            task.addLine("$ " + commandLine);
            exit = runStep(task, step, l);
            if (exit != 0) {
                break;
            }
        }
        long millis = System.currentTimeMillis() - started;
        if (l != null) {
            l.onFinished(exit, millis, task.stopped);
        }
    }

    private int runStep(Task task, Step step, Listener l) {
        ProcessBuilder pb = new ProcessBuilder(step.command);
        if (step.directory != null && step.directory.isDirectory()) {
            pb.directory(step.directory);
        }
        pb.redirectErrorStream(true);
        pb.environment().put("PYTHONUNBUFFERED", "1");
        pb.environment().put("PYTHONIOENCODING", "utf-8");
        Process p;
        try {
            p = pb.start();
        } catch (IOException e) {
            if (l != null) {
                l.onOutput(Strings.format("Could not start: {0}", e.getMessage()), true);
            }
            return -1;
        }
        task.process = p;
        Charset cs = isWindows() ? Charset.forName("GBK") : StandardCharsets.UTF_8;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), cs))) {
            String line;
            while ((line = r.readLine()) != null) {
                task.addLine(line);
                if (l != null) {
                    l.onOutput(line, false);
                }
            }
        } catch (IOException e) {
            if (l != null) {
                l.onOutput(Strings.format("Output stream closed: {0}", e.getMessage()), true);
            }
        }
        try {
            if (!p.waitFor(10, TimeUnit.MINUTES)) {
                p.destroyForcibly();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            p.destroyForcibly();
        }
        if (task.stopped) {
            return 130;
        }
        return p.exitValue();
    }

    /** Stops the running task, if any. */
    public void stop() {
        Task t = current;
        if (t != null && t.isRunning()) {
            t.stop();
        }
    }

    /* ------------------------------------------------------------------ */
    /* configuration discovery                                             */
    /* ------------------------------------------------------------------ */

    /** A runnable entry shown in the Run view. */
    public static class Config {
        public final String name;
        public final File file;
        public final String kind;

        public Config(String name, File file, String kind) {
            this.name = name;
            this.file = file;
            this.kind = kind;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    /** Scans the workspace for files that can be launched. */
    public List<Config> discover() {
        List<Config> out = new ArrayList<>();
        for (File f : workspace.indexFiles()) {
            if (out.size() >= 60) {
                break;
            }
            String n = f.getName().toLowerCase(java.util.Locale.ROOT);
            if (n.endsWith(".java")) {
                if (containsMain(f)) {
                    out.add(new Config(f.getName(), f, "java"));
                }
            } else if (n.endsWith(".py") || n.endsWith(".js") || n.endsWith(".ts")
                    || n.endsWith(".go") || n.endsWith(".rs") || n.endsWith(".c")
                    || n.endsWith(".cpp") || n.endsWith(".sh")) {
                out.add(new Config(f.getName(), f, n.substring(n.lastIndexOf('.') + 1)));
            } else if (n.endsWith(".jar")) {
                out.add(new Config(f.getName(), f, "jar"));
            }
        }
        return out;
    }

    private static boolean containsMain(File f) {
        try {
            if (f.length() > 2 * 1024 * 1024) {
                return false;
            }
            String text = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
            return text.contains("static void main(") || text.contains("static void main (");
        } catch (IOException e) {
            return false;
        }
    }

    /** Directory that should be used as the working directory for a file. */
    public File workingDirectory(File file) {
        File root = workspace.getRoot();
        if (root != null) {
            return root;
        }
        if (file != null && file.getParentFile() != null) {
            return file.getParentFile();
        }
        Path cwd = Path.of("").toAbsolutePath();
        return cwd.toFile();
    }
}
