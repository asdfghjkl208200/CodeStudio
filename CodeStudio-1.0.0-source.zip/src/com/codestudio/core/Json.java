package com.codestudio.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A small JSON reader.
 *
 * <p>Hand-written for the same reason the lexer in {@link Language} and the icons in the UI layer
 * are: the project takes no dependencies. It covers the whole of RFC 8259 — objects, arrays,
 * strings with escapes and {@code \\uXXXX}, numbers, booleans and null — which is more than the two
 * callers need (GitHub API responses, and plugin manifests) but is barely more code than a partial
 * one.
 *
 * <p>Parsing produces {@code Map<String,Object>}, {@code List<Object>}, {@code String},
 * {@code Long} or {@code Double}, and {@code Boolean}/{@code null}. Integral numbers come back as
 * {@code Long} rather than {@code Double} so that ids and counts survive without a decimal point.
 *
 * <p>A malformed document throws {@link IllegalArgumentException} carrying the byte offset, rather
 * than returning a half-built tree that the caller would have to guess about.
 */
public final class Json {

    private final String text;
    private int at;

    private Json(String text) {
        this.text = text;
    }

    /**
     * Parses a complete JSON document.
     *
     * @throws IllegalArgumentException if the text is not valid JSON, or has trailing content
     */
    public static Object parse(String text) {
        if (text == null) {
            throw new IllegalArgumentException("no JSON text");
        }
        Json parser = new Json(text);
        parser.skipWhitespace();
        Object value = parser.readValue();
        parser.skipWhitespace();
        if (parser.at < text.length()) {
            throw parser.fail("trailing content after the top-level value");
        }
        return value;
    }

    /** Parses a document that must be a JSON object. Returns null when the text is not one. */
    public static Map<String, Object> parseObject(String text) {
        Object value;
        try {
            value = parse(text);
        } catch (IllegalArgumentException e) {
            return null;
        }
        return asObject(value);
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> asObject(Object value) {
        return value instanceof Map ? (Map<String, Object>) value : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> asArray(Object value) {
        return value instanceof List ? (List<Object>) value : null;
    }

    /* ------------------------------------------------------------------ */
    /* typed accessors, all tolerant of a missing or wrong-typed member    */
    /* ------------------------------------------------------------------ */

    public static String string(Map<String, Object> object, String key, String fallback) {
        Object value = object == null ? null : object.get(key);
        return value instanceof String s ? s : fallback;
    }

    public static boolean bool(Map<String, Object> object, String key, boolean fallback) {
        Object value = object == null ? null : object.get(key);
        return value instanceof Boolean b ? b : fallback;
    }

    public static int integer(Map<String, Object> object, String key, int fallback) {
        Object value = object == null ? null : object.get(key);
        if (value instanceof Number n) {
            return n.intValue();
        }
        if (value instanceof String s) {
            try {
                return Integer.parseInt(s.trim());
            } catch (NumberFormatException e) {
                return fallback;
            }
        }
        return fallback;
    }

    /** A string member that may also have been written as a number, such as a version. */
    public static String stringOrNumber(Map<String, Object> object, String key, String fallback) {
        Object value = object == null ? null : object.get(key);
        if (value instanceof String s) {
            return s;
        }
        if (value instanceof Number n) {
            return n instanceof Long l ? String.valueOf(l) : String.valueOf(n);
        }
        return fallback;
    }

    public static List<Object> array(Map<String, Object> object, String key) {
        List<Object> found = asArray(object == null ? null : object.get(key));
        return found == null ? List.of() : found;
    }

    /** The strings in an array member, skipping any element that is not a string. */
    public static List<String> strings(Map<String, Object> object, String key) {
        List<String> out = new ArrayList<>();
        for (Object element : array(object, key)) {
            if (element instanceof String s) {
                out.add(s);
            }
        }
        return out;
    }

    /* ------------------------------------------------------------------ */
    /* writing, for round tripping a manifest                              */
    /* ------------------------------------------------------------------ */

    /** Serialises a tree built by {@link #parse}. Used to write a plugin manifest back out. */
    public static String write(Object value) {
        StringBuilder out = new StringBuilder();
        writeValue(out, value);
        return out.toString();
    }

    private static void writeValue(StringBuilder out, Object value) {
        if (value == null) {
            out.append("null");
        } else if (value instanceof String s) {
            writeString(out, s);
        } else if (value instanceof Boolean || value instanceof Number) {
            out.append(value);
        } else if (value instanceof Map<?, ?> map) {
            out.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : map.entrySet()) {
                if (!first) {
                    out.append(',');
                }
                first = false;
                writeString(out, String.valueOf(e.getKey()));
                out.append(':');
                writeValue(out, e.getValue());
            }
            out.append('}');
        } else if (value instanceof List<?> list) {
            out.append('[');
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) {
                    out.append(',');
                }
                writeValue(out, list.get(i));
            }
            out.append(']');
        } else {
            writeString(out, String.valueOf(value));
        }
    }

    private static void writeString(StringBuilder out, String value) {
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                case '\b' -> out.append("\\b");
                case '\f' -> out.append("\\f");
                default -> {
                    if (c < 0x20) {
                        out.append(String.format("\\u%04x", (int) c));
                    } else {
                        out.append(c);
                    }
                }
            }
        }
        out.append('"');
    }

    /* ------------------------------------------------------------------ */
    /* the parser                                                          */
    /* ------------------------------------------------------------------ */

    private Object readValue() {
        if (at >= text.length()) {
            throw fail("unexpected end of input");
        }
        char c = text.charAt(at);
        return switch (c) {
            case '{' -> readObject();
            case '[' -> readArray();
            case '"' -> readString();
            case 't', 'f' -> readBoolean();
            case 'n' -> readNull();
            default -> readNumber();
        };
    }

    private Map<String, Object> readObject() {
        Map<String, Object> out = new LinkedHashMap<>();
        at++; // '{'
        skipWhitespace();
        if (peek() == '}') {
            at++;
            return out;
        }
        while (true) {
            skipWhitespace();
            if (peek() != '"') {
                throw fail("expected a member name");
            }
            String key = readString();
            skipWhitespace();
            if (peek() != ':') {
                throw fail("expected ':' after the member name");
            }
            at++;
            skipWhitespace();
            out.put(key, readValue());
            skipWhitespace();
            char c = peek();
            if (c == ',') {
                at++;
                continue;
            }
            if (c == '}') {
                at++;
                return out;
            }
            throw fail("expected ',' or '}'");
        }
    }

    private List<Object> readArray() {
        List<Object> out = new ArrayList<>();
        at++; // '['
        skipWhitespace();
        if (peek() == ']') {
            at++;
            return out;
        }
        while (true) {
            skipWhitespace();
            out.add(readValue());
            skipWhitespace();
            char c = peek();
            if (c == ',') {
                at++;
                continue;
            }
            if (c == ']') {
                at++;
                return out;
            }
            throw fail("expected ',' or ']'");
        }
    }

    private String readString() {
        at++; // opening quote
        StringBuilder out = new StringBuilder();
        while (true) {
            if (at >= text.length()) {
                throw fail("unterminated string");
            }
            char c = text.charAt(at++);
            if (c == '"') {
                return out.toString();
            }
            if (c != '\\') {
                out.append(c);
                continue;
            }
            if (at >= text.length()) {
                throw fail("unterminated escape");
            }
            char escape = text.charAt(at++);
            switch (escape) {
                case '"' -> out.append('"');
                case '\\' -> out.append('\\');
                case '/' -> out.append('/');
                case 'b' -> out.append('\b');
                case 'f' -> out.append('\f');
                case 'n' -> out.append('\n');
                case 'r' -> out.append('\r');
                case 't' -> out.append('\t');
                case 'u' -> out.append(readUnicodeEscape());
                default -> throw fail("unknown escape \\" + escape);
            }
        }
    }

    /**
     * Reads the four hex digits of a {@code \\u} escape. A surrogate pair arrives as two
     * consecutive escapes, and appending both halves in turn is exactly right for a Java string.
     */
    private char readUnicodeEscape() {
        if (at + 4 > text.length()) {
            throw fail("truncated \\u escape");
        }
        int value = 0;
        for (int i = 0; i < 4; i++) {
            int digit = Character.digit(text.charAt(at++), 16);
            if (digit < 0) {
                throw fail("bad hex digit in a \\u escape");
            }
            value = value * 16 + digit;
        }
        return (char) value;
    }

    private Boolean readBoolean() {
        if (text.startsWith("true", at)) {
            at += 4;
            return Boolean.TRUE;
        }
        if (text.startsWith("false", at)) {
            at += 5;
            return Boolean.FALSE;
        }
        throw fail("expected true or false");
    }

    private Object readNull() {
        if (!text.startsWith("null", at)) {
            throw fail("expected null");
        }
        at += 4;
        return null;
    }

    /**
     * Reads a number. An integral value that fits in a long is returned as a {@code Long}, so that
     * a count or an id does not come back as {@code 1.0E7}.
     */
    private Object readNumber() {
        int start = at;
        if (peek() == '-' || peek() == '+') {
            at++;
        }
        boolean integral = true;
        while (at < text.length()) {
            char c = text.charAt(at);
            if (c >= '0' && c <= '9') {
                at++;
            } else if (c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-') {
                integral = false;
                at++;
            } else {
                break;
            }
        }
        String literal = text.substring(start, at);
        if (literal.isEmpty() || "-".equals(literal) || "+".equals(literal)) {
            throw fail("expected a value");
        }
        if (integral) {
            try {
                return Long.valueOf(literal);
            } catch (NumberFormatException e) {
                // Too big for a long; fall through to a double rather than failing the whole parse.
            }
        }
        try {
            return Double.valueOf(literal);
        } catch (NumberFormatException e) {
            throw fail("malformed number \"" + literal + "\"");
        }
    }

    private char peek() {
        if (at >= text.length()) {
            throw fail("unexpected end of input");
        }
        return text.charAt(at);
    }

    private void skipWhitespace() {
        while (at < text.length()) {
            char c = text.charAt(at);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                at++;
            } else {
                break;
            }
        }
    }

    private IllegalArgumentException fail(String message) {
        return new IllegalArgumentException("JSON at offset " + at + ": " + message);
    }
}
