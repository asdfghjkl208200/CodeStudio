package com.codestudio.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The snippet library behind the completion popup.
 *
 * <p>A snippet body is plain text with one {@code $0} marker where the caret should land after
 * expansion -{@code for (int i = 0; i < n; i++) {$0}} places the caret between the braces. The
 * marker is removed on insert, so the expanded text is exactly what the user would have typed.
 *
 * <p>Snippets are keyed by language id and fall back to a shared set, so a language with no library
 * of its own still offers the general ones.
 */
public final class Snippets {

    public static final String CARET = "$0";

    /** One expandable template. */
    public static final class Snippet {
        /** What the user types to match it, e.g. {@code for}. */
        public final String trigger;
        /** Text shown in the suggestion list. */
        public final String label;
        /** Short kind hint shown on the right, e.g. "snippet". */
        public final String detail;
        /** The body, possibly multi-line, possibly containing {@link #CARET}. */
        public final String body;

        public Snippet(String trigger, String label, String detail, String body) {
            this.trigger = trigger;
            this.label = label;
            this.detail = detail;
            this.body = body;
        }

        /** Whether the trigger matches the typed prefix. */
        public boolean matches(String prefix) {
            return trigger.startsWith(prefix.toLowerCase(Locale.ROOT));
        }

        public boolean exact(String prefix) {
            return trigger.equalsIgnoreCase(prefix);
        }
    }

    private static final Map<String, List<Snippet>> BY_LANGUAGE = new LinkedHashMap<>();
    private static final List<Snippet> GENERAL = new ArrayList<>();

    static {
        GENERAL.add(s("region", "#region block", "#region $0\n#endregion"));
        GENERAL.add(s("todo", "TODO comment", "TODO: $0"));
        GENERAL.add(s("fileheader", "File header", "// $0\n"));

        List<Snippet> java = new ArrayList<>();
        java.add(s("main", "main method",
                "public static void main(String[] args) {$0\n}"));
        java.add(s("sout", "System.out.println", "System.out.println($0);"));
        java.add(s("serr", "System.err.println", "System.err.println($0);"));
        java.add(s("for", "for loop",
                "for (int i = 0; i < $0; i++) {\n}"));
        java.add(s("fori", "for loop over a collection",
                "for ($0 item : items) {\n}"));
        java.add(s("while", "while loop", "while ($0) {\n}"));
        java.add(s("if", "if statement", "if ($0) {\n}"));
        java.add(s("ifelse", "if / else", "if ($0) {\n} else {\n}"));
        java.add(s("try", "try / catch", "try {\n    $0\n} catch (Exception e) {\n}"));
        java.add(s("class", "class", "public class $0 {\n}"));
        java.add(s("meth", "method", "private void $0() {\n}"));
        java.add(s("psvm", "public static void main", "public static void main(String[] args) {\n    $0\n}"));
        BY_LANGUAGE.put("java", java);
        BY_LANGUAGE.put("kotlin", java);
        BY_LANGUAGE.put("csharp", java);

        List<Snippet> c = new ArrayList<>();
        c.add(s("main", "main function", "int main(int argc, char **argv) {\n    $0\n    return 0;\n}"));
        c.add(s("for", "for loop", "for (int i = 0; i < $0; i++) {\n}"));
        c.add(s("if", "if statement", "if ($0) {\n}"));
        c.add(s("inc", "#include", "#include <$0>"));
        c.add(s("printf", "printf", "printf(\"$0\\n\");"));
        BY_LANGUAGE.put("c", c);
        BY_LANGUAGE.put("cpp", c);

        List<Snippet> python = new ArrayList<>();
        python.add(s("main", "main guard", "if __name__ == \"__main__\":$0\n    main()"));
        python.add(s("def", "function", "def $0():\n    pass"));
        python.add(s("class", "class", "class $0:\n    def __init__(self):\n        pass"));
        python.add(s("for", "for loop", "for item in $0:\n    pass"));
        python.add(s("while", "while loop", "while $0:\n    pass"));
        python.add(s("if", "if statement", "if $0:\n    pass"));
        python.add(s("try", "try / except", "try:\n    $0\nexcept Exception as e:\n    pass"));
        python.add(s("print", "print", "print($0)"));
        python.add(s("with", "with open", "with open($0) as f:\n    pass"));
        BY_LANGUAGE.put("python", python);

        List<Snippet> js = new ArrayList<>();
        js.add(s("log", "console.log", "console.log($0);"));
        js.add(s("fn", "function", "function $0() {\n}"));
        js.add(s("arrow", "arrow function", "const $0 = () => {\n};"));
        js.add(s("for", "for loop", "for (let i = 0; i < $0; i++) {\n}"));
        js.add(s("forof", "for...of", "for (const item of $0) {\n}"));
        js.add(s("if", "if statement", "if ($0) {\n}"));
        js.add(s("try", "try / catch", "try {\n    $0\n} catch (err) {\n}"));
        js.add(s("freeze", "Object.freeze", "Object.freeze($0)"));
        BY_LANGUAGE.put("javascript", js);
        BY_LANGUAGE.put("typescript", js);
        BY_LANGUAGE.put("javascriptreact", js);
        BY_LANGUAGE.put("typescriptreact", js);

        List<Snippet> go = new ArrayList<>();
        go.add(s("main", "main package", "package main\n\nimport \"fmt\"\n\nfunc main() {\n    $0\n}"));
        go.add(s("func", "function", "func $0() {\n}"));
        go.add(s("err", "error check", "if err != nil {\n    return err\n}"));
        go.add(s("for", "for loop", "for i := 0; i < $0; i++ {\n}"));
        go.add(s("if", "if statement", "if $0 {\n}"));
        BY_LANGUAGE.put("go", go);

        List<Snippet> rust = new ArrayList<>();
        rust.add(s("fn", "function", "fn $0() {\n}"));
        rust.add(s("main", "main function", "fn main() {\n    $0\n}"));
        rust.add(s("for", "for loop", "for item in $0 {\n}"));
        rust.add(s("if", "if statement", "if $0 {\n}"));
        rust.add(s("match", "match", "match $0 {\n    _ => {}\n}"));
        BY_LANGUAGE.put("rust", rust);

        List<Snippet> html = new ArrayList<>();
        html.add(s("html", "HTML skeleton",
                "<!DOCTYPE html>\n<html>\n<head>\n    <meta charset=\"utf-8\">\n    <title>$0</title>\n</head>\n<body>\n</body>\n</html>"));
        html.add(s("div", "div", "<div>$0</div>"));
        html.add(s("script", "script", "<script>$0</script>"));
        BY_LANGUAGE.put("html", html);
        BY_LANGUAGE.put("xml", html);

        List<Snippet> css = new ArrayList<>();
        css.add(s("rule", "rule", "$0 {\n}"));
        css.add(s("flex", "flex container", "display: flex;\njustify-content: $0;"));
        BY_LANGUAGE.put("css", css);
        BY_LANGUAGE.put("scss", css);
        BY_LANGUAGE.put("less", css);

        List<Snippet> shell = new ArrayList<>();
        shell.add(s("sh", "shebang", "#!/bin/sh\n$0"));
        shell.add(s("for", "for loop", "for f in $0; do\n    echo \"$f\"\ndone"));
        shell.add(s("if", "if statement", "if [ $0 ]; then\nfi"));
        BY_LANGUAGE.put("shell", shell);
        BY_LANGUAGE.put("bash", shell);
    }

    private Snippets() {
    }

    private static Snippet s(String trigger, String label, String body) {
        return new Snippet(trigger, label, "snippet", body);
    }

    /** Every snippet that matches the prefix for a language, best (exact) matches first. */
    public static List<Snippet> matching(Language lang, String prefix) {
        String p = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT);
        List<Snippet> out = new ArrayList<>();
        List<Snippet> own = lang == null ? null : BY_LANGUAGE.get(lang.id);
        if (own != null) {
            for (Snippet s : own) {
                if (p.isEmpty() || s.matches(p)) {
                    out.add(s);
                }
            }
        }
        for (Snippet s : GENERAL) {
            if (p.isEmpty() || s.matches(p)) {
                out.add(s);
            }
        }
        out.sort((a, b) -> Boolean.compare(b.exact(p), a.exact(p)));
        return out;
    }

    public static List<Snippet> all(Language lang) {
        return matching(lang, "");
    }

    /**
     * Expands a snippet body at the caret's indentation.
     *
     * @param indent the leading whitespace of the line the snippet is inserted on, repeated on
     *               every line after the first
     * @param caret  receives the offset of the caret within the returned text
     */
    public static String expand(String body, String indent, int[] caret) {
        int marker = body.indexOf(CARET);
        String raw = marker < 0 ? body : body.substring(0, marker) + body.substring(marker + CARET.length());
        String pad = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder(raw.length() + 64);
        // Walking the marker out of the text takes the caret with it: everything before the marker is
        // copied as is, so the marker's position in the output is simply where it was consumed.
        int caretAt = -1;
        for (int i = 0; i < raw.length(); i++) {
            if (i == marker) {
                caretAt = sb.length();
            }
            char c = raw.charAt(i);
            sb.append(c);
            if (c == '\n') {
                sb.append(pad);
            }
        }
        if (caretAt < 0) {
            caretAt = sb.length();
        }
        if (caret != null && caret.length > 0) {
            caret[0] = Math.max(0, Math.min(caretAt, sb.length()));
        }
        return sb.toString();
    }
}
