package com.codestudio.core;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/**
 * A dependency-free syntax highlighter.
 *
 * <p>Text is tokenised with a hand written lexer and the resulting spans are
 * pushed into a {@link StyledDocument}. Every character of the document is
 * always covered by exactly one span so stale attributes can never leak.
 */
public class SyntaxHighlighter {

    public interface Sink {
        void accept(int start, int end, String style);
    }

    /* style keys */
    public static final String PLAIN = "plain";
    public static final String KEYWORD = "kw";
    public static final String CONTROL = "control";
    public static final String TYPE = "type";
    public static final String STRING = "string";
    public static final String COMMENT = "comment";
    public static final String NUMBER = "number";
    public static final String FUNC = "func";
    public static final String ANNO = "anno";
    public static final String CONST = "const";
    public static final String VAR = "var";
    public static final String OP = "op";
    public static final String PUNCT = "punct";
    public static final String TAG = "tag";
    public static final String ATTR = "attr";
    public static final String ATTRVAL = "attrval";
    public static final String HEADER = "header";
    public static final String BOLD = "bold";
    public static final String ITALIC = "italic";
    public static final String LINK = "link";
    public static final String ESCAPE = "escape";
    public static final String PROP = "prop";
    public static final String IMPORTANT = "important";
    public static final String INVALID = "invalid";

    /** Documents larger than this are not re-highlighted (keeps the IDE snappy). */
    public static final int MAX_HIGHLIGHT_LENGTH = 1_500_000;

    private final Map<String, SimpleAttributeSet> styles = new HashMap<>();
    private Theme theme;

    public SyntaxHighlighter(Theme theme) {
        setTheme(theme);
    }

    public Theme theme() {
        return theme;
    }

    public void setTheme(Theme theme) {
        this.theme = theme;
        styles.clear();
        put(PLAIN, theme.editorFg, false, false);
        put(KEYWORD, theme.synKeyword, false, false);
        put(CONTROL, theme.synControl, false, false);
        put(TYPE, theme.synType, false, false);
        put(STRING, theme.synString, false, false);
        put(COMMENT, theme.synComment, false, false);
        put(NUMBER, theme.synNumber, false, false);
        put(FUNC, theme.synFunction, false, false);
        put(ANNO, theme.synAnnotation, false, false);
        put(CONST, theme.synConstant, false, false);
        put(VAR, theme.synVar, false, false);
        put(OP, theme.synOp, false, false);
        put(PUNCT, theme.synPunct, false, false);
        put(TAG, theme.synTag, false, false);
        put(ATTR, theme.synAttr, false, false);
        put(ATTRVAL, theme.synAttrValue, false, false);
        put(HEADER, theme.synHeader, true, false);
        put(BOLD, theme.synBold, true, false);
        put(ITALIC, theme.synItalic, false, true);
        put(LINK, theme.synLink, false, false);
        put(ESCAPE, theme.synEscape, false, false);
        put(PROP, theme.synProperty, false, false);
        put(IMPORTANT, theme.synImportant, true, false);
        put(INVALID, theme.synInvalid, false, false);
    }

    public Color colorOf(String style) {
        SimpleAttributeSet a = styles.get(style);
        if (a == null) {
            return theme.editorFg;
        }
        Color c = StyleConstants.getForeground(a);
        return c == null ? theme.editorFg : c;
    }

    private void put(String key, Color fg, boolean bold, boolean italic) {
        SimpleAttributeSet a = new SimpleAttributeSet();
        StyleConstants.setForeground(a, fg);
        StyleConstants.setBold(a, bold);
        StyleConstants.setItalic(a, italic);
        styles.put(key, a);
    }

    public SimpleAttributeSet attributes(String key) {
        SimpleAttributeSet a = styles.get(key);
        return a == null ? styles.get(PLAIN) : a;
    }

    /** Re-highlight a whole document. */
    public void highlight(StyledDocument doc, Language lang) {
        int len = doc.getLength();
        if (len == 0 || len > MAX_HIGHLIGHT_LENGTH || lang == null || lang.lexer == Language.Lexer.PLAIN) {
            return;
        }
        String text;
        try {
            text = doc.getText(0, len);
        } catch (Exception e) {
            return;
        }
        // Reset everything first: every character is then guaranteed to be
        // covered by the spans we emit below, so stale colors cannot survive.
        doc.setCharacterAttributes(0, len, attributes(PLAIN), true);

        final Sink applier = (start, end, style) -> {
            if (start >= 0 && end > start && end <= doc.getLength()) {
                doc.setCharacterAttributes(start, end - start, attributes(style), true);
            }
        };
        tokenize(text, lang, applier);
    }

    /* ===================================================================== */
    /* tokenizer                                                             */
    /* ===================================================================== */

    private static boolean isIdentStart(char c) {
        return Character.isLetter(c) || c == '_' || c == '$';
    }

    private static boolean isIdentPart(char c) {
        return Character.isLetterOrDigit(c) || c == '_' || c == '$';
    }

    private static boolean isDigit(char c) {
        return c >= '0' && c <= '9';
    }

    /** Merge adjacent runs with the same style before touching the document. */
    private static final class Merger implements Sink {
        private final Sink out;
        private int start = -1;
        private int end = -1;
        private String style;

        Merger(Sink out) {
            this.out = out;
        }

        @Override
        public void accept(int s, int e, String st) {
            if (e <= s) {
                return;
            }
            if (style != null && style.equals(st) && s == end) {
                end = e;
                return;
            }
            flush();
            start = s;
            end = e;
            style = st;
        }

        void flush() {
            if (style != null) {
                out.accept(start, end, style);
                style = null;
            }
        }
    }

    public static void tokenize(String text, Language lang, Sink sink) {
        Merger m = new Merger(sink);
        switch (lang.lexer) {
            case MARKUP -> markup(text, lang, m);
            case MARKDOWN -> markdown(text, m);
            case CSS -> css(text, m);
            case YAML -> yaml(text, m);
            case PROPERTIES -> properties(text, m);
            case PYTHON -> code(text, lang, m, 0, text.length(), true, true);
            case SHELL -> code(text, lang, m, 0, text.length(), false, true);
            default -> code(text, lang, m, 0, text.length(), false, false);
        }
        m.flush();
    }

    /* ---------------- generic / python / shell lexer ---------------- */

    private static void code(String text, Language lang, Sink sink, int from, int to,
                             boolean tripleQuotes, boolean shellish) {
        int i = from;
        int n = Math.min(to, text.length());
        while (i < n) {
            char c = text.charAt(i);

            // ---- line comments ----
            if (lang.allowComments) {
                int lc = matchLineComment(text, lang, i, n);
                if (lc > 0) {
                    int e = i;
                    while (e < n && text.charAt(e) != '\n') {
                        e++;
                    }
                    sink.accept(i, e, COMMENT);
                    i = e;
                    continue;
                }
            }

            // ---- block comments ----
            if (lang.allowComments && lang.blockComments.length > 0) {
                String[] hit = null;
                for (String[] pair : lang.blockComments) {
                    if (text.startsWith(pair[0], i)) {
                        hit = pair;
                        break;
                    }
                }
                if (hit != null) {
                    int e = text.indexOf(hit[1], i + hit[0].length());
                    e = (e < 0 || e >= n) ? n : e + hit[1].length();
                    sink.accept(i, Math.min(e, n), COMMENT);
                    i = Math.min(e, n);
                    continue;
                }
            }

            // ---- annotations ----
            if (lang.atAnnotations && c == '@' && i + 1 < n && isIdentStart(text.charAt(i + 1))) {
                int e = i + 1;
                while (e < n && (isIdentPart(text.charAt(e)) || text.charAt(e) == '.')) {
                    e++;
                }
                sink.accept(i, e, ANNO);
                i = e;
                continue;
            }

            // ---- strings ----
            if (c == '"' || c == '\'' || c == '`') {
                int e = endOfString(text, i, n, c, tripleQuotes);
                sink.accept(i, e, STRING);
                i = e;
                continue;
            }

            // ---- numbers ----
            if (isDigit(c) || (c == '.' && i + 1 < n && isDigit(text.charAt(i + 1)))) {
                int e = i + 1;
                while (e < n) {
                    char d = text.charAt(e);
                    if (Character.isLetterOrDigit(d) || d == '.' || d == '_') {
                        // exponent sign
                        if ((d == 'e' || d == 'E' || d == 'p' || d == 'P') && e + 1 < n
                                && (text.charAt(e + 1) == '+' || text.charAt(e + 1) == '-')) {
                            e += 2;
                            continue;
                        }
                        e++;
                    } else {
                        break;
                    }
                }
                sink.accept(i, e, NUMBER);
                i = e;
                continue;
            }

            // ---- shell / php variables ----
            if ((lang.dollarVars || shellish) && c == '$' && i + 1 < n
                    && (isIdentStart(text.charAt(i + 1)) || text.charAt(i + 1) == '{')) {
                int e = i + 1;
                if (text.charAt(e) == '{') {
                    int close = text.indexOf('}', e);
                    e = close < 0 ? n : close + 1;
                } else {
                    while (e < n && isIdentPart(text.charAt(e))) {
                        e++;
                    }
                }
                sink.accept(i, e, VAR);
                i = e;
                continue;
            }

            // ---- identifiers / keywords ----
            if (isIdentStart(c)) {
                int e = i;
                while (e < n && isIdentPart(text.charAt(e))) {
                    e++;
                }
                String word = text.substring(i, e);
                sink.accept(i, e, classify(word, text, e, n, lang));
                i = e;
                continue;
            }

            // ---- operators & punctuation ----
            if (isOperator(c)) {
                sink.accept(i, i + 1, OP);
                i++;
                continue;
            }
            if (isPunct(c)) {
                sink.accept(i, i + 1, PUNCT);
                i++;
                continue;
            }
            // whitespace and everything else
            sink.accept(i, i + 1, PLAIN);
            i++;
        }
    }

    private static int matchLineComment(String text, Language lang, int i, int n) {
        for (String prefix : lang.lineComments) {
            if (prefix.isEmpty() || i + prefix.length() > n) {
                continue;
            }
            if (!text.startsWith(prefix, i)) {
                continue;
            }
            char first = prefix.charAt(0);
            if (Character.isLetter(first)) {
                // word-like comment marker (REM, ...) needs boundaries
                if (i > 0 && (isIdentPart(text.charAt(i - 1)))) {
                    continue;
                }
                int after = i + prefix.length();
                if (after < n && isIdentPart(text.charAt(after))) {
                    continue;
                }
            }
            return prefix.length();
        }
        return 0;
    }

    private static int endOfString(String text, int start, int n, char quote, boolean triple) {
        if (triple && start + 2 < n && text.charAt(start + 1) == quote && text.charAt(start + 2) == quote) {
            String q3 = String.valueOf(quote).repeat(3);
            int idx = text.indexOf(q3, start + 3);
            return idx < 0 ? n : Math.min(idx + 3, n);
        }
        int i = start + 1;
        while (i < n) {
            char c = text.charAt(i);
            if (c == '\\') {
                i += 2;
                continue;
            }
            if (c == quote) {
                return i + 1;
            }
            if (c == '\n') {
                // unterminated single line string - stop at EOL
                return i;
            }
            i++;
        }
        return n;
    }

    private static String classify(String word, String text, int end, int n, Language lang) {
        String key = lang.caseInsensitive ? word.toLowerCase(Locale.ROOT) : word;
        if (lang.control.contains(key)) {
            return CONTROL;
        }
        if (lang.keywords.contains(key)) {
            return KEYWORD;
        }
        if (lang.constants.contains(key)) {
            return CONST;
        }
        if (lang.types.contains(key)) {
            return TYPE;
        }
        if (lang.builtins.contains(key)) {
            return FUNC;
        }
        // identifier followed by '(' is treated as a call
        int j = end;
        while (j < n && (text.charAt(j) == ' ' || text.charAt(j) == '\t')) {
            j++;
        }
        if (j < n && text.charAt(j) == '(') {
            return FUNC;
        }
        // Type-ish naming convention (ClassName)
        if (!word.isEmpty() && Character.isUpperCase(word.charAt(0)) && word.length() > 1) {
            return TYPE;
        }
        return PLAIN;
    }

    private static boolean isOperator(char c) {
        return "+-*/%=<>!&|^~?".indexOf(c) >= 0;
    }

    private static boolean isPunct(char c) {
        return "(){}[];,.".indexOf(c) >= 0;
    }

    /* ---------------- HTML / XML ---------------- */

    private static void markup(String text, Language lang, Sink sink) {
        int n = text.length();
        int i = 0;
        while (i < n) {
            char c = text.charAt(i);
            if (text.startsWith("<!--", i)) {
                int e = text.indexOf("-->", i + 4);
                e = e < 0 ? n : e + 3;
                sink.accept(i, e, COMMENT);
                i = e;
                continue;
            }
            if (c == '<') {
                // DOCTYPE / processing instruction / closing tag
                int e = i + 1;
                boolean closing = e < n && text.charAt(e) == '/';
                if (closing) {
                    e++;
                }
                boolean decl = e < n && (text.charAt(e) == '!' || text.charAt(e) == '?');
                int nameStart = e;
                while (e < n && (isIdentPart(text.charAt(e)) || text.charAt(e) == '-' || text.charAt(e) == ':')) {
                    e++;
                }
                String tagName = text.substring(nameStart, e);
                sink.accept(i, Math.min(nameStart, n), PUNCT);
                if (e > nameStart) {
                    sink.accept(nameStart, e, decl ? HEADER : TAG);
                } else if (decl) {
                    sink.accept(nameStart, Math.min(e + 1, n), HEADER);
                }
                // attributes
                while (e < n && text.charAt(e) != '>') {
                    char a = text.charAt(e);
                    if (a == '"' || a == '\'') {
                        int se = endOfString(text, e, n, a, false);
                        sink.accept(e, se, ATTRVAL);
                        e = se;
                        continue;
                    }
                    if (isIdentStart(a)) {
                        int as = e;
                        while (e < n && (isIdentPart(text.charAt(e)) || text.charAt(e) == '-'
                                || text.charAt(e) == ':' || text.charAt(e) == '.')) {
                            e++;
                        }
                        sink.accept(as, e, ATTR);
                        continue;
                    }
                    if (a == '=') {
                        sink.accept(e, e + 1, PUNCT);
                        e++;
                        continue;
                    }
                    sink.accept(e, e + 1, PLAIN);
                    e++;
                }
                if (e < n) {
                    // '>' or '/>'
                    int gt = e;
                    int slash = (gt > i && text.charAt(gt - 1) == '/') ? gt - 1 : -1;
                    if (slash > i) {
                        sink.accept(slash, slash + 1, PUNCT);
                    }
                    sink.accept(gt, gt + 1, PUNCT);
                    e = gt + 1;
                }
                // embedded script / style
                String lower = tagName.toLowerCase(Locale.ROOT);
                if (!closing && !decl && (lower.equals("script") || lower.equals("style"))) {
                    String closeTag = "</" + lower;
                    int close = indexOfIgnoreCase(text, closeTag, e);
                    if (close < 0) {
                        close = n;
                    }
                    Language sub = Language.byId(lower.equals("script") ? "javascript" : "css");
                    String inner = text.substring(e, close);
                    final int base = e;
                    List<Object[]> tokens = new ArrayList<>();
                    tokenize(inner, sub, (s, en, st) -> tokens.add(new Object[]{s + base, en + base, st}));
                    for (Object[] t : tokens) {
                        sink.accept((Integer) t[0], (Integer) t[1], (String) t[2]);
                    }
                    i = close;
                    continue;
                }
                i = e;
                continue;
            }
            // plain text content
            int next = text.indexOf('<', i);
            next = next < 0 ? n : next;
            sink.accept(i, next, PLAIN);
            i = next;
        }
    }

    private static int indexOfIgnoreCase(String text, String needle, int from) {
        String lower = text.toLowerCase(Locale.ROOT);
        return lower.indexOf(needle.toLowerCase(Locale.ROOT), from);
    }

    /* ---------------- Markdown ---------------- */

    private static void markdown(String text, Sink sink) {
        int n = text.length();
        int lineStart = 0;
        boolean inFence = false;
        while (lineStart <= n) {
            int lineEnd = text.indexOf('\n', lineStart);
            if (lineEnd < 0) {
                lineEnd = n;
            }
            String line = text.substring(lineStart, lineEnd);
            String trimmed = line.stripLeading();
            if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
                sink.accept(lineStart, lineEnd, ESCAPE);
                inFence = !inFence;
            } else if (inFence) {
                sink.accept(lineStart, lineEnd, STRING);
            } else if (trimmed.startsWith("#")) {
                sink.accept(lineStart, lineEnd, HEADER);
            } else if (trimmed.startsWith(">")) {
                sink.accept(lineStart, lineEnd, COMMENT);
            } else if (trimmed.startsWith("---") || trimmed.startsWith("***") || trimmed.startsWith("___")) {
                sink.accept(lineStart, lineEnd, KEYWORD);
            } else {
                inlineMarkdown(text, lineStart, lineEnd, sink);
            }
            if (lineEnd >= n) {
                break;
            }
            sink.accept(lineEnd, lineEnd + 1, PLAIN);
            lineStart = lineEnd + 1;
        }
    }

    private static void inlineMarkdown(String text, int from, int to, Sink sink) {
        int i = from;
        // leading list marker
        String line = text.substring(from, to);
        String trimmed = line.stripLeading();
        int indent = line.length() - trimmed.length();
        if (trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("+ ")) {
            sink.accept(from + indent, from + indent + 1, KEYWORD);
            i = from + indent + 2;
        } else {
            int k = 0;
            while (k < trimmed.length() && isDigit(trimmed.charAt(k))) {
                k++;
            }
            if (k > 0 && k + 1 < trimmed.length() && (trimmed.charAt(k) == '.' || trimmed.charAt(k) == ')')
                    && trimmed.charAt(k + 1) == ' ') {
                sink.accept(from + indent, from + indent + k + 1, KEYWORD);
                i = from + indent + k + 2;
            }
        }
        while (i < to) {
            char c = text.charAt(i);
            if (c == '`') {
                int e = text.indexOf('`', i + 1);
                e = (e < 0 || e > to) ? to : e + 1;
                sink.accept(i, e, ESCAPE);
                i = e;
                continue;
            }
            if (c == '[') {
                int close = text.indexOf(']', i);
                if (close > 0 && close < to) {
                    int open = text.indexOf('(', close);
                    int end = open > 0 ? text.indexOf(')', open) : -1;
                    if (open > 0 && end > 0 && end <= to) {
                        sink.accept(i, close + 1, LINK);
                        sink.accept(open, end + 1, LINK);
                        i = end + 1;
                        continue;
                    }
                }
            }
            if ((c == '*' || c == '_') && i + 1 < to) {
                boolean dbl = text.charAt(i + 1) == c;
                String mark = dbl ? String.valueOf(c).repeat(2) : String.valueOf(c);
                int e = text.indexOf(mark, i + mark.length());
                if (e >= 0 && e < to) {
                    sink.accept(i, e + mark.length(), dbl ? BOLD : ITALIC);
                    i = e + mark.length();
                    continue;
                }
            }
            if (c == '\\' && i + 1 < to) {
                sink.accept(i, i + 2, ESCAPE);
                i += 2;
                continue;
            }
            i++;
        }
    }

    /* ---------------- CSS ---------------- */

    private static void css(String text, Sink sink) {
        int n = text.length();
        int i = 0;
        boolean inBlock = false;
        boolean inValue = false;
        while (i < n) {
            char c = text.charAt(i);
            if (text.startsWith("/*", i)) {
                int e = text.indexOf("*/", i + 2);
                e = e < 0 ? n : e + 2;
                sink.accept(i, e, COMMENT);
                i = e;
                continue;
            }
            if (c == '"' || c == '\'') {
                int e = endOfString(text, i, n, c, false);
                sink.accept(i, e, inValue ? ATTRVAL : STRING);
                i = e;
                continue;
            }
            if (c == '@') {
                int e = i + 1;
                while (e < n && (isIdentPart(text.charAt(e)) || text.charAt(e) == '-')) {
                    e++;
                }
                sink.accept(i, e, KEYWORD);
                i = e;
                continue;
            }
            if (c == '!') {
                int e = i + 1;
                while (e < n && Character.isLetter(text.charAt(e))) {
                    e++;
                }
                sink.accept(i, e, IMPORTANT);
                i = e;
                continue;
            }
            if (c == '{') {
                inBlock = true;
                inValue = false;
                sink.accept(i, i + 1, PUNCT);
                i++;
                continue;
            }
            if (c == '}') {
                inBlock = false;
                inValue = false;
                sink.accept(i, i + 1, PUNCT);
                i++;
                continue;
            }
            if (c == ';') {
                inValue = false;
                sink.accept(i, i + 1, PUNCT);
                i++;
                continue;
            }
            if (c == ':') {
                inValue = true;
                sink.accept(i, i + 1, PUNCT);
                i++;
                continue;
            }
            if (c == '#' && i + 1 < n && isHex(text.charAt(i + 1))) {
                int e = i + 1;
                while (e < n && isHex(text.charAt(e))) {
                    e++;
                }
                sink.accept(i, e, NUMBER);
                i = e;
                continue;
            }
            if (c == '$' && i + 1 < n) {
                int e = i + 1;
                while (e < n && (isIdentPart(text.charAt(e)) || text.charAt(e) == '-')) {
                    e++;
                }
                sink.accept(i, e, VAR);
                i = e;
                continue;
            }
            if (c == '-' && i + 1 < n && text.charAt(i + 1) == '-') {
                int e = i + 2;
                while (e < n && isIdentPart(text.charAt(e))) {
                    e++;
                }
                sink.accept(i, e, VAR);
                i = e;
                continue;
            }
            if (isDigit(c) || (c == '.' && i + 1 < n && isDigit(text.charAt(i + 1)))) {
                int e = i;
                while (e < n && (Character.isLetterOrDigit(text.charAt(e)) || text.charAt(e) == '.'
                        || text.charAt(e) == '%' || text.charAt(e) == '-')) {
                    e++;
                }
                sink.accept(i, e, NUMBER);
                i = e;
                continue;
            }
            if (isIdentStart(c) || c == '.' || c == '#' || c == '-' || c == '&' || c == '*') {
                int e = i;
                while (e < n && (isIdentPart(text.charAt(e)) || ".#-&*>:[]\"'=~|^$".indexOf(text.charAt(e)) >= 0)) {
                    e++;
                }
                String style;
                if (!inBlock) {
                    style = TAG;
                } else if (!inValue) {
                    style = ATTR;
                } else {
                    style = ATTRVAL;
                }
                sink.accept(i, e, style);
                i = e;
                continue;
            }
            if (isOperator(c)) {
                sink.accept(i, i + 1, OP);
                i++;
                continue;
            }
            sink.accept(i, i + 1, PLAIN);
            i++;
        }
    }

    private static boolean isHex(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }

    /* ---------------- YAML ---------------- */

    private static void yaml(String text, Sink sink) {
        int n = text.length();
        int lineStart = 0;
        while (lineStart <= n) {
            int lineEnd = text.indexOf('\n', lineStart);
            if (lineEnd < 0) {
                lineEnd = n;
            }
            String line = text.substring(lineStart, lineEnd);
            int indent = 0;
            while (indent < line.length() && line.charAt(indent) == ' ') {
                indent++;
            }
            int i = lineStart + indent;
            // list dash
            if (i < lineEnd && line.charAt(i - lineStart) == '-' && i + 1 <= lineEnd
                    && (i + 1 == lineEnd || line.charAt(i + 1 - lineStart) == ' ')) {
                sink.accept(i, i + 1, KEYWORD);
                i++;
            }
            int comment = indexOfComment(line, i - lineStart);
            int limit = comment < 0 ? lineEnd : lineStart + comment;
            int colon = -1;
            boolean inQuote = false;
            for (int k = i; k < limit; k++) {
                char ch = text.charAt(k);
                if (ch == '"' || ch == '\'') {
                    inQuote = !inQuote;
                } else if (ch == ':' && !inQuote) {
                    colon = k;
                    break;
                }
            }
            if (colon > i) {
                sink.accept(i, colon, PROP);
                sink.accept(colon, colon + 1, PUNCT);
                valueTokens(text, colon + 1, limit, sink);
            } else if (i < limit) {
                valueTokens(text, i, limit, sink);
            }
            if (comment >= 0) {
                sink.accept(lineStart + comment, lineEnd, COMMENT);
            }
            if (lineEnd >= n) {
                break;
            }
            sink.accept(lineEnd, lineEnd + 1, PLAIN);
            lineStart = lineEnd + 1;
        }
    }

    private static int indexOfComment(String line, int from) {
        boolean inQuote = false;
        char q = 0;
        for (int i = Math.max(0, from); i < line.length(); i++) {
            char c = line.charAt(i);
            if (inQuote) {
                if (c == q) {
                    inQuote = false;
                }
            } else if (c == '"' || c == '\'') {
                inQuote = true;
                q = c;
            } else if (c == '#' && (i == 0 || Character.isWhitespace(line.charAt(i - 1)))) {
                return i;
            }
        }
        return -1;
    }

    private static void valueTokens(String text, int from, int to, Sink sink) {
        int i = from;
        while (i < to) {
            char c = text.charAt(i);
            if (c == ' ' || c == '\t') {
                sink.accept(i, i + 1, PLAIN);
                i++;
                continue;
            }
            if (c == '"' || c == '\'') {
                int e = endOfString(text, i, to, c, false);
                sink.accept(i, Math.min(e, to), STRING);
                i = Math.min(e, to);
                continue;
            }
            if (c == '&' || c == '*' || c == '|' || c == '>') {
                int e = i + 1;
                while (e < to && isIdentPart(text.charAt(e))) {
                    e++;
                }
                sink.accept(i, e, VAR);
                i = e;
                continue;
            }
            if (isDigit(c)) {
                int e = i;
                while (e < to && (Character.isLetterOrDigit(text.charAt(e)) || text.charAt(e) == '.'
                        || text.charAt(e) == '-' || text.charAt(e) == ':')) {
                    e++;
                }
                sink.accept(i, e, NUMBER);
                i = e;
                continue;
            }
            int e = i;
            while (e < to && !Character.isWhitespace(text.charAt(e)) && text.charAt(e) != '#') {
                e++;
            }
            String word = text.substring(i, e);
            String style = switch (word.toLowerCase(Locale.ROOT)) {
                case "true", "false", "yes", "no", "on", "off", "null", "~" -> CONST;
                default -> PLAIN;
            };
            sink.accept(i, e, style);
            i = e;
        }
    }

    /* ---------------- .properties / .ini ---------------- */

    private static void properties(String text, Sink sink) {
        int n = text.length();
        int lineStart = 0;
        while (lineStart <= n) {
            int lineEnd = text.indexOf('\n', lineStart);
            if (lineEnd < 0) {
                lineEnd = n;
            }
            String line = text.substring(lineStart, lineEnd);
            int indent = 0;
            while (indent < line.length() && Character.isWhitespace(line.charAt(indent))) {
                indent++;
            }
            int i = lineStart + indent;
            String trimmed = line.strip();
            if (trimmed.startsWith("#") || trimmed.startsWith("!") || trimmed.startsWith(";")) {
                sink.accept(i, lineEnd, COMMENT);
            } else if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
                sink.accept(i, lineEnd, HEADER);
            } else {
                int eq = -1;
                for (int k = i; k < lineEnd; k++) {
                    char c = text.charAt(k);
                    if (c == '=' || c == ':') {
                        eq = k;
                        break;
                    }
                }
                if (eq > i) {
                    sink.accept(i, eq, PROP);
                    sink.accept(eq, eq + 1, PUNCT);
                    int e = eq + 1;
                    while (e < lineEnd && Character.isWhitespace(text.charAt(e))) {
                        e++;
                    }
                    if (e < lineEnd) {
                        sink.accept(e, lineEnd, STRING);
                    }
                } else if (i < lineEnd) {
                    sink.accept(i, lineEnd, PROP);
                }
            }
            if (lineEnd >= n) {
                break;
            }
            sink.accept(lineEnd, lineEnd + 1, PLAIN);
            lineStart = lineEnd + 1;
        }
    }
}
