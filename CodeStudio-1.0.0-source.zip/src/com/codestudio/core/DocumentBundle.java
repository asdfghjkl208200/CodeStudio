package com.codestudio.core;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.AbstractDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.StyledDocument;
import javax.swing.undo.CompoundEdit;
import javax.swing.undo.UndoManager;

/**
 * One open text file: its Swing document, language, dirty state and undo stack.
 * The same bundle can be displayed by several editors (split view).
 */
public class DocumentBundle {

    private static int untitledCounter = 1;

    public File file;
    public Language language;
    public final StyledDocument doc;
    public final UndoManager undo = new UndoManager();
    public String encoding = "UTF-8";
    public String eol = "\n";
    public long lastModified;
    public long openedAt;

    /** Caret position, remembered across tab switches. */
    public int caret = 0;
    public int selectionEnd = 0;

    private boolean dirty;
    private boolean loading;
    private int compoundDepth;
    private CompoundEdit compoundEdit;
    private UndoableEditListener compoundListener;
    private final List<Runnable> dirtyListeners = new ArrayList<>();

    private DocumentBundle(File file, Language language, StyledDocument doc) {
        this.file = file;
        this.language = language;
        this.doc = doc;
        this.openedAt = System.currentTimeMillis();
        doc.addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                touch();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                touch();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // attribute / syntax changes must not mark the file dirty
            }
        });
        doc.addUndoableEditListener(e -> {
            if (e.getEdit() instanceof AbstractDocument.DefaultDocumentEvent ev
                    && ev.getType() == DocumentEvent.EventType.CHANGE) {
                return;
            }
            if (compoundDepth > 0) {
                // collected by the active compound edit instead
                return;
            }
            undo.addEdit(e.getEdit());
        });
    }

    private void touch() {
        if (loading) {
            return;
        }
        if (!dirty) {
            dirty = true;
            fireDirty();
        }
    }

    public void addDirtyListener(Runnable r) {
        dirtyListeners.add(r);
    }

    private void fireDirty() {
        for (Runnable r : dirtyListeners) {
            r.run();
        }
    }

    public boolean isDirty() {
        return dirty;
    }

    public void setDirty(boolean d) {
        if (dirty != d) {
            dirty = d;
            fireDirty();
        }
    }

    public boolean isUntitled() {
        return file == null;
    }

    public String name() {
        return file == null ? "Untitled-" + untitledCounter : file.getName();
    }

    public String path() {
        return file == null ? "" : file.getAbsolutePath();
    }

    /* ------------------------------------------------------------------ */

    public static DocumentBundle newUntitled(Language lang) {
        DocumentBundle b = new DocumentBundle(null, lang, new DefaultStyledDocument());
        b.loading = true;
        try {
            b.doc.insertString(0, "", null);
        } catch (BadLocationException ignored) {
        }
        b.loading = false;
        b.dirty = true;
        return b;
    }

    public static DocumentBundle open(File f) throws IOException {
        byte[] bytes = Files.readAllBytes(f.toPath());
        Decoded decoded = decode(bytes);
        Language lang = Language.detect(f.getName());
        DocumentBundle b = new DocumentBundle(f, lang, new DefaultStyledDocument());
        b.encoding = decoded.charset;
        b.eol = detectEol(decoded.text);
        b.loading = true;
        try {
            b.doc.insertString(0, normalize(decoded.text), null);
            b.undo.discardAllEdits();
        } catch (BadLocationException ignored) {
        }
        b.loading = false;
        b.dirty = false;
        b.lastModified = f.lastModified();
        return b;
    }

    private record Decoded(String text, String charset) {
    }

    private static Decoded decode(byte[] bytes) {
        if (bytes.length >= 3 && (bytes[0] & 0xFF) == 0xEF && (bytes[1] & 0xFF) == 0xBB
                && (bytes[2] & 0xFF) == 0xBF) {
            return new Decoded(new String(bytes, 3, bytes.length - 3, StandardCharsets.UTF_8), "UTF-8 (BOM)");
        }
        if (bytes.length >= 2 && (bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xFE) {
            return new Decoded(new String(bytes, 2, bytes.length - 2, StandardCharsets.UTF_16LE), "UTF-16 LE");
        }
        // strict UTF-8 first
        try {
            CharsetDecoder dec = StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT);
            CharBuffer cb = dec.decode(ByteBuffer.wrap(bytes));
            return new Decoded(cb.toString(), "UTF-8");
        } catch (Exception ignored) {
            // fall through to the platform charset (GBK on Chinese Windows)
        }
        String fallback = System.getProperty("native.encoding", "GBK");
        try {
            Charset cs = Charset.forName(fallback);
            return new Decoded(new String(bytes, cs), cs.name());
        } catch (Exception ignored) {
            return new Decoded(new String(bytes, StandardCharsets.ISO_8859_1), "ISO-8859-1");
        }
    }

    private static String detectEol(String text) {
        int crlf = 0;
        int lf = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                if (i > 0 && text.charAt(i - 1) == '\r') {
                    crlf++;
                } else {
                    lf++;
                }
            }
        }
        return crlf > lf ? "\r\n" : "\n";
    }

    /** Everything in the Swing document uses \n; the original EOL is restored on save. */
    private static String normalize(String text) {
        return text.replace("\r\n", "\n").replace('\r', '\n');
    }

    /* ------------------------------------------------------------------ */

    public String content() {
        try {
            return doc.getText(0, doc.getLength());
        } catch (BadLocationException e) {
            return "";
        }
    }

    /** Replaces the whole buffer as a single undoable edit. */
    public void replaceAll(String text) {
        setContent(text, false);
    }

    /** Replaces the buffer and clears the undo history (used when (re)loading). */
    public void reload(String text) {
        setContent(text, true);
    }

    /** Groups several document edits into one undo step. */
    public void beginCompound() {
        if (compoundDepth++ == 0) {
            compoundEdit = new CompoundEdit();
            compoundListener = ev -> compoundEdit.addEdit(ev.getEdit());
            doc.addUndoableEditListener(compoundListener);
        }
    }

    public void endCompound() {
        if (compoundDepth == 0) {
            return;
        }
        if (--compoundDepth == 0 && compoundEdit != null) {
            doc.removeUndoableEditListener(compoundListener);
            compoundEdit.end();
            if (compoundEdit.canUndo()) {
                undo.addEdit(compoundEdit);
            }
            compoundEdit = null;
            compoundListener = null;
        }
    }

    private void setContent(String text, boolean discardUndo) {
        loading = true;
        try {
            doc.remove(0, doc.getLength());
            doc.insertString(0, text, null);
        } catch (BadLocationException ignored) {
        }
        loading = false;
        if (discardUndo) {
            undo.discardAllEdits();
        }
    }

    /** Writes the document back to disk. Returns false when it has no file yet. */
    public boolean save(Settings settings) throws IOException {
        if (file == null) {
            return false;
        }
        String text = content();
        if (settings.getBool("editor.trimOnSave")) {
            String trimmed = trimTrailing(text);
            if (!trimmed.equals(text)) {
                setContent(trimmed, false);
                text = trimmed;
            }
        }
        if ("\r\n".equals(eol)) {
            text = text.replace("\n", "\r\n");
        }
        Charset cs = charsetFor(encoding);
        Files.write(file.toPath(), text.getBytes(cs));
        lastModified = file.lastModified();
        setDirty(false);
        return true;
    }

    public boolean saveAs(File target, Settings settings) throws IOException {
        this.file = target;
        this.language = Language.detect(target.getName());
        return save(settings);
    }

    private static Charset charsetFor(String encoding) {
        if (encoding == null || encoding.startsWith("UTF-8")) {
            return StandardCharsets.UTF_8;
        }
        try {
            return Charset.forName(encoding);
        } catch (Exception e) {
            return StandardCharsets.UTF_8;
        }
    }

    private static String trimTrailing(String text) {
        StringBuilder sb = new StringBuilder(text.length());
        int i = 0;
        while (i < text.length()) {
            int nl = text.indexOf('\n', i);
            if (nl < 0) {
                sb.append(stripEnd(text, i, text.length()));
                break;
            }
            sb.append(stripEnd(text, i, nl)).append('\n');
            i = nl + 1;
        }
        return sb.toString();
    }

    private static String stripEnd(String s, int from, int to) {
        int end = to;
        while (end > from && (s.charAt(end - 1) == ' ' || s.charAt(end - 1) == '\t')) {
            end--;
        }
        return s.substring(from, end);
    }

    /** True when the file changed on disk since it was opened/saved. */
    public boolean changedOnDisk() {
        return file != null && file.isFile() && file.lastModified() > lastModified + 1;
    }

    public Path pathOrNull() {
        return file == null ? null : file.toPath();
    }

    @Override
    public String toString() {
        return name();
    }
}
