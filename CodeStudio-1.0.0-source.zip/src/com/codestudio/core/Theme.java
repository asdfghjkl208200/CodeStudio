package com.codestudio.core;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.UIManager;

/**
 * Color themes for the workbench. Two built-in themes modelled on the
 * well known Dark+ / Light+ palettes.
 */
public class Theme {

    public String id;
    public String name;
    public boolean dark;

    /* ---------- workbench ---------- */
    public Color titleBg, titleFg;
    public Color activityBg, activityFg, activityActiveFg, activityInactiveFg, activityBorder;
    public Color sidebarBg, sidebarFg, sectionHeader, sectionBorder;
    public Color editorBg, editorFg, editorBorder;
    public Color tabActiveBg, tabInactiveBg, tabActiveFg, tabInactiveFg, tabBorderTop;
    public Color panelBg, panelFg, panelBorder;
    public Color statusBg, statusFg, statusHover, statusBorder;
    public Color inputBg, inputFg, inputBorder, inputPlaceholder;
    public Color hover, listActive, listActiveFg, listHover, listSelectionInactive;
    public Color selection, selectionInactive, lineHighlight, lineHighlightBorder;
    public Color gutterFg, gutterActiveFg, cursor;
    public Color scrollbar, scrollbarHover, scrollbarActive;
    public Color minimapSlider, minimapSliderHover;
    public Color accent, error, warning, info;
    public Color badgeBg, badgeFg, dropBg;
    public Color widgetBg, widgetBorder, shadow;

    /* ---------- syntax ---------- */
    public Color synKeyword, synControl, synType, synString, synComment, synNumber;
    public Color synFunction, synAnnotation, synConstant, synVar, synOp, synPunct;
    public Color synTag, synAttr, synAttrValue, synHeader, synBold, synItalic, synLink, synEscape;
    public Color synProperty, synImportant, synInvalid;
    public Color bracketMatch, bracketMatchBorder;
    public Color occurrenceBg, occurrenceBorder;

    private static Color c(String hex) {
        return new Color(Integer.parseInt(hex.substring(1), 16));
    }

    public static Theme dark() {
        Theme t = new Theme();
        t.id = "dark";
        t.name = "Dark+ (default dark)";
        t.dark = true;

        t.titleBg = c("#3C3C3C");
        t.titleFg = c("#CCCCCC");
        t.activityBg = c("#333333");
        t.activityFg = c("#FFFFFF");
        t.activityActiveFg = c("#FFFFFF");
        t.activityInactiveFg = c("#7A7A7A");
        t.activityBorder = c("#007ACC");
        t.sidebarBg = c("#252526");
        t.sidebarFg = c("#CCCCCC");
        t.sectionHeader = c("#BBBBBB");
        t.sectionBorder = c("#3C3C3C");
        t.editorBg = c("#1E1E1E");
        t.editorFg = c("#D4D4D4");
        t.editorBorder = c("#2B2B2B");
        t.tabActiveBg = c("#1E1E1E");
        t.tabInactiveBg = c("#2D2D2D");
        t.tabActiveFg = c("#FFFFFF");
        t.tabInactiveFg = c("#969696");
        t.tabBorderTop = c("#007ACC");
        t.panelBg = c("#1E1E1E");
        t.panelFg = c("#CCCCCC");
        t.panelBorder = c("#2B2B2B");
        t.statusBg = c("#007ACC");
        t.statusFg = c("#FFFFFF");
        t.statusHover = c("#1F8AD2");
        t.statusBorder = c("#007ACC");
        t.inputBg = c("#3C3C3C");
        t.inputFg = c("#CCCCCC");
        t.inputBorder = c("#3C3C3C");
        t.inputPlaceholder = c("#8C8C8C");
        t.hover = c("#2A2D2E");
        t.listActive = c("#094771");
        t.listActiveFg = c("#FFFFFF");
        t.listHover = c("#2A2D2E");
        t.listSelectionInactive = c("#37373D");
        t.selection = c("#264F78");
        t.selectionInactive = c("#3A3D41");
        t.lineHighlight = c("#282828");
        t.lineHighlightBorder = c("#282828");
        t.gutterFg = c("#858585");
        t.gutterActiveFg = c("#C6C6C6");
        t.cursor = c("#AEAFAD");
        t.scrollbar = c("#424242");
        t.scrollbarHover = c("#4F4F4F");
        t.scrollbarActive = c("#5A5A5A");
        t.minimapSlider = new Color(121, 121, 121, 90);
        t.minimapSliderHover = new Color(150, 150, 150, 140);
        t.accent = c("#007ACC");
        t.error = c("#F14C4C");
        t.warning = c("#CCA700");
        t.info = c("#3794FF");
        t.badgeBg = c("#4D4D4D");
        t.badgeFg = c("#FFFFFF");
        t.dropBg = c("#062F4A");
        t.widgetBg = c("#252526");
        t.widgetBorder = c("#454545");
        t.shadow = new Color(0, 0, 0, 120);

        t.synKeyword = c("#569CD6");
        t.synControl = c("#C586C0");
        t.synType = c("#4EC9B0");
        t.synString = c("#CE9178");
        t.synComment = c("#6A9955");
        t.synNumber = c("#B5CEA8");
        t.synFunction = c("#DCDCAA");
        t.synAnnotation = c("#DCDCAA");
        t.synConstant = c("#569CD6");
        t.synVar = c("#9CDCFE");
        t.synOp = c("#D4D4D4");
        t.synPunct = c("#808080");
        t.synTag = c("#569CD6");
        t.synAttr = c("#9CDCFE");
        t.synAttrValue = c("#CE9178");
        t.synHeader = c("#569CD6");
        t.synBold = c("#569CD6");
        t.synItalic = c("#9CDCFE");
        t.synLink = c("#4EC9B0");
        t.synEscape = c("#D7BA7D");
        t.synProperty = c("#9CDCFE");
        t.synImportant = c("#569CD6");
        t.synInvalid = c("#F44747");
        t.bracketMatch = new Color(0, 122, 204, 60);
        t.bracketMatchBorder = c("#888888");
        t.occurrenceBg = new Color(87, 87, 87, 140);
        t.occurrenceBorder = c("#575757");
        return t;
    }

    public static Theme light() {
        Theme t = new Theme();
        t.id = "light";
        t.name = "Light+ (default light)";
        t.dark = false;

        t.titleBg = c("#DDDDDD");
        t.titleFg = c("#333333");
        t.activityBg = c("#2C2C2C");
        t.activityFg = c("#FFFFFF");
        t.activityActiveFg = c("#FFFFFF");
        t.activityInactiveFg = c("#8A8A8A");
        t.activityBorder = c("#007ACC");
        t.sidebarBg = c("#F3F3F3");
        t.sidebarFg = c("#3B3B3B");
        t.sectionHeader = c("#6F6F6F");
        t.sectionBorder = c("#E7E7E7");
        t.editorBg = c("#FFFFFF");
        t.editorFg = c("#000000");
        t.editorBorder = c("#E7E7E7");
        t.tabActiveBg = c("#FFFFFF");
        t.tabInactiveBg = c("#ECECEC");
        t.tabActiveFg = c("#333333");
        t.tabInactiveFg = c("#8E8E8E");
        t.tabBorderTop = c("#007ACC");
        t.panelBg = c("#FFFFFF");
        t.panelFg = c("#333333");
        t.panelBorder = c("#E7E7E7");
        t.statusBg = c("#007ACC");
        t.statusFg = c("#FFFFFF");
        t.statusHover = c("#1F8AD2");
        t.statusBorder = c("#007ACC");
        t.inputBg = c("#FFFFFF");
        t.inputFg = c("#333333");
        t.inputBorder = c("#CECECE");
        t.inputPlaceholder = c("#767676");
        t.hover = c("#E8E8E8");
        t.listActive = c("#0060C0");
        t.listActiveFg = c("#FFFFFF");
        t.listHover = c("#E8E8E8");
        t.listSelectionInactive = c("#E4E6F1");
        t.selection = c("#ADD6FF");
        t.selectionInactive = c("#E5EBF1");
        t.lineHighlight = c("#F5F5F5");
        t.lineHighlightBorder = c("#F0F0F0");
        t.gutterFg = c("#237893");
        t.gutterActiveFg = c("#0B216F");
        t.cursor = c("#000000");
        t.scrollbar = c("#C1C1C1");
        t.scrollbarHover = c("#A8A8A8");
        t.scrollbarActive = c("#8E8E8E");
        t.minimapSlider = new Color(100, 100, 100, 70);
        t.minimapSliderHover = new Color(100, 100, 100, 130);
        t.accent = c("#007ACC");
        t.error = c("#E51400");
        t.warning = c("#BF8803");
        t.info = c("#1A85FF");
        t.badgeBg = c("#C4C4C4");
        t.badgeFg = c("#333333");
        t.dropBg = c("#D6EBFF");
        t.widgetBg = c("#F3F3F3");
        t.widgetBorder = c("#C8C8C8");
        t.shadow = new Color(0, 0, 0, 60);

        t.synKeyword = c("#0000FF");
        t.synControl = c("#AF00DB");
        t.synType = c("#267F99");
        t.synString = c("#A31515");
        t.synComment = c("#008000");
        t.synNumber = c("#098658");
        t.synFunction = c("#795E26");
        t.synAnnotation = c("#795E26");
        t.synConstant = c("#0000FF");
        t.synVar = c("#001080");
        t.synOp = c("#000000");
        t.synPunct = c("#000000");
        t.synTag = c("#800000");
        t.synAttr = c("#E50000");
        t.synAttrValue = c("#0000FF");
        t.synHeader = c("#800000");
        t.synBold = c("#000080");
        t.synItalic = c("#267F99");
        t.synLink = c("#267F99");
        t.synEscape = c("#EE0000");
        t.synProperty = c("#001080");
        t.synImportant = c("#0000FF");
        t.synInvalid = c("#CD3131");
        t.bracketMatch = new Color(0, 122, 204, 45);
        t.bracketMatchBorder = c("#A0A0A0");
        t.occurrenceBg = new Color(173, 214, 255, 150);
        t.occurrenceBorder = c("#ADD6FF");
        return t;
    }

    /** Themes contributed by plugins, keyed by id. The two built-ins are resolved separately. */
    private static final Map<String, Theme> CONTRIBUTED = new LinkedHashMap<>();

    public static Theme get(String id) {
        Theme contributed = CONTRIBUTED.get(id);
        if (contributed != null) {
            return contributed;
        }
        return "light".equalsIgnoreCase(id) ? light() : dark();
    }

    /**
     * Registers a theme contributed by a plugin.
     *
     * <p>A plugin cannot shadow the built-in themes or another plugin: the id "dark" and "light" are
     * refused, as is an id already in the registry.
     *
     * @return true when the theme was registered
     */
    public static boolean register(String id, String name, Theme theme) {
        if (id == null || id.isBlank() || theme == null
                || "dark".equalsIgnoreCase(id) || "light".equalsIgnoreCase(id)
                || CONTRIBUTED.containsKey(id)) {
            return false;
        }
        theme.id = id;
        theme.name = name == null || name.isBlank() ? id : name;
        CONTRIBUTED.put(id, theme);
        return true;
    }

    public static boolean unregister(String id) {
        return CONTRIBUTED.remove(id) != null;
    }

    /** Drops every contributed theme; used when reloading plugins. */
    public static void clearContributed() {
        CONTRIBUTED.clear();
    }

    /** The ids to offer in the settings drop down: the built-ins, then whatever plugins added. */
    public static List<String> ids() {
        List<String> ids = new ArrayList<>();
        ids.add("dark");
        ids.add("light");
        ids.addAll(CONTRIBUTED.keySet());
        return ids;
    }

    /**
     * Short display name for a theme id, used by the settings drop down where the space is tight.
     * Distinct from {@link #name}, which is the fuller product name shown in the theme picker.
     */
    public static String displayName(String id) {
        Theme contributed = CONTRIBUTED.get(id);
        if (contributed != null) {
            return contributed.name;
        }
        if ("light".equalsIgnoreCase(id)) {
            return Strings.get("Light");
        }
        if ("dark".equalsIgnoreCase(id)) {
            return Strings.get("Dark");
        }
        return id;
    }

    /**
     * A copy of a theme, for a plugin that wants to adjust a few colors rather than name all forty.
     * The copy keeps the original's {@code id} and {@code name} until {@link #register} overwrites
     * them.
     */
    public static Theme copyOf(Theme source) {
        Theme t = new Theme();
        t.id = source.id;
        t.name = source.name;
        t.dark = source.dark;
        t.titleBg = source.titleBg;
        t.titleFg = source.titleFg;
        t.activityBg = source.activityBg;
        t.activityFg = source.activityFg;
        t.activityActiveFg = source.activityActiveFg;
        t.activityInactiveFg = source.activityInactiveFg;
        t.activityBorder = source.activityBorder;
        t.sidebarBg = source.sidebarBg;
        t.sidebarFg = source.sidebarFg;
        t.sectionHeader = source.sectionHeader;
        t.sectionBorder = source.sectionBorder;
        t.editorBg = source.editorBg;
        t.editorFg = source.editorFg;
        t.editorBorder = source.editorBorder;
        t.tabActiveBg = source.tabActiveBg;
        t.tabInactiveBg = source.tabInactiveBg;
        t.tabActiveFg = source.tabActiveFg;
        t.tabInactiveFg = source.tabInactiveFg;
        t.tabBorderTop = source.tabBorderTop;
        t.panelBg = source.panelBg;
        t.panelFg = source.panelFg;
        t.panelBorder = source.panelBorder;
        t.statusBg = source.statusBg;
        t.statusFg = source.statusFg;
        t.statusHover = source.statusHover;
        t.statusBorder = source.statusBorder;
        t.inputBg = source.inputBg;
        t.inputFg = source.inputFg;
        t.inputBorder = source.inputBorder;
        t.inputPlaceholder = source.inputPlaceholder;
        t.hover = source.hover;
        t.listActive = source.listActive;
        t.listActiveFg = source.listActiveFg;
        t.listHover = source.listHover;
        t.listSelectionInactive = source.listSelectionInactive;
        t.selection = source.selection;
        t.selectionInactive = source.selectionInactive;
        t.lineHighlight = source.lineHighlight;
        t.lineHighlightBorder = source.lineHighlightBorder;
        t.gutterFg = source.gutterFg;
        t.gutterActiveFg = source.gutterActiveFg;
        t.cursor = source.cursor;
        t.scrollbar = source.scrollbar;
        t.scrollbarHover = source.scrollbarHover;
        t.scrollbarActive = source.scrollbarActive;
        t.minimapSlider = source.minimapSlider;
        t.minimapSliderHover = source.minimapSliderHover;
        t.accent = source.accent;
        t.error = source.error;
        t.warning = source.warning;
        t.info = source.info;
        t.badgeBg = source.badgeBg;
        t.badgeFg = source.badgeFg;
        t.dropBg = source.dropBg;
        t.widgetBg = source.widgetBg;
        t.widgetBorder = source.widgetBorder;
        t.shadow = source.shadow;
        t.synKeyword = source.synKeyword;
        t.synControl = source.synControl;
        t.synType = source.synType;
        t.synString = source.synString;
        t.synComment = source.synComment;
        t.synNumber = source.synNumber;
        t.synFunction = source.synFunction;
        t.synAnnotation = source.synAnnotation;
        t.synConstant = source.synConstant;
        t.synVar = source.synVar;
        t.synOp = source.synOp;
        t.synPunct = source.synPunct;
        t.synTag = source.synTag;
        t.synAttr = source.synAttr;
        t.synAttrValue = source.synAttrValue;
        t.synHeader = source.synHeader;
        t.synBold = source.synBold;
        t.synItalic = source.synItalic;
        t.synLink = source.synLink;
        t.synEscape = source.synEscape;
        t.synProperty = source.synProperty;
        t.synImportant = source.synImportant;
        t.synInvalid = source.synInvalid;
        t.bracketMatch = source.bracketMatch;
        t.bracketMatchBorder = source.bracketMatchBorder;
        t.occurrenceBg = source.occurrenceBg;
        t.occurrenceBorder = source.occurrenceBorder;
        return t;
    }

    public static Theme other(Theme t) {
        return t.dark ? light() : dark();
    }

    /** Push the theme colors into the Swing defaults so dialogs/popups match. */
    public void applyToUIManager() {
        UIManager.put("Panel.background", panelBg);
        UIManager.put("Panel.foreground", panelFg);
        UIManager.put("OptionPane.background", widgetBg);
        UIManager.put("OptionPane.foreground", panelFg);
        UIManager.put("OptionPane.messageForeground", panelFg);
        UIManager.put("Label.background", widgetBg);
        UIManager.put("Label.foreground", panelFg);

        UIManager.put("MenuBar.background", titleBg);
        UIManager.put("MenuBar.foreground", titleFg);
        UIManager.put("MenuBar.border", null);
        UIManager.put("Menu.background", titleBg);
        UIManager.put("Menu.foreground", titleFg);
        UIManager.put("Menu.selectionBackground", accent);
        UIManager.put("Menu.selectionForeground", Color.WHITE);
        UIManager.put("Menu.borderPainted", Boolean.FALSE);
        UIManager.put("MenuItem.background", widgetBg);
        UIManager.put("MenuItem.foreground", panelFg);
        UIManager.put("MenuItem.selectionBackground", listActive);
        UIManager.put("MenuItem.selectionForeground", listActiveFg);
        UIManager.put("MenuItem.borderPainted", Boolean.FALSE);
        UIManager.put("Menu.borderPainted", Boolean.FALSE);
        UIManager.put("CheckBoxMenuItem.background", widgetBg);
        UIManager.put("CheckBoxMenuItem.foreground", panelFg);
        UIManager.put("CheckBoxMenuItem.selectionBackground", listActive);
        UIManager.put("CheckBoxMenuItem.selectionForeground", listActiveFg);
        UIManager.put("RadioButtonMenuItem.background", widgetBg);
        UIManager.put("RadioButtonMenuItem.foreground", panelFg);
        UIManager.put("PopupMenu.background", widgetBg);
        UIManager.put("PopupMenu.foreground", panelFg);
        UIManager.put("PopupMenu.border", javax.swing.BorderFactory.createLineBorder(widgetBorder));
        UIManager.put("Separator.background", widgetBg);
        UIManager.put("Separator.foreground", widgetBorder);

        UIManager.put("TextField.background", inputBg);
        UIManager.put("TextField.foreground", inputFg);
        UIManager.put("TextField.caretForeground", inputFg);
        UIManager.put("TextField.selectionBackground", selection);
        UIManager.put("TextField.selectionForeground", dark ? Color.WHITE : Color.BLACK);
        UIManager.put("TextArea.background", inputBg);
        UIManager.put("TextArea.foreground", inputFg);
        UIManager.put("TextPane.background", editorBg);
        UIManager.put("TextPane.foreground", editorFg);
        UIManager.put("FormattedTextField.background", inputBg);
        UIManager.put("FormattedTextField.foreground", inputFg);
        UIManager.put("PasswordField.background", inputBg);
        UIManager.put("PasswordField.foreground", inputFg);

        UIManager.put("List.background", sidebarBg);
        UIManager.put("List.foreground", sidebarFg);
        UIManager.put("List.selectionBackground", listActive);
        UIManager.put("List.selectionForeground", listActiveFg);
        UIManager.put("Tree.background", sidebarBg);
        UIManager.put("Tree.foreground", sidebarFg);
        UIManager.put("Tree.selectionBackground", listActive);
        UIManager.put("Tree.selectionForeground", listActiveFg);
        UIManager.put("Tree.line", sectionBorder);
        UIManager.put("Tree.hash", sectionBorder);
        UIManager.put("Table.background", panelBg);
        UIManager.put("Table.foreground", panelFg);
        UIManager.put("Table.selectionBackground", listActive);
        UIManager.put("Table.selectionForeground", listActiveFg);
        UIManager.put("Table.gridColor", panelBorder);
        UIManager.put("TableHeader.background", sidebarBg);
        UIManager.put("TableHeader.foreground", sidebarFg);
        UIManager.put("TableHeader.cellBorder", javax.swing.BorderFactory.createLineBorder(panelBorder));
        UIManager.put("Button.background", inputBg);
        UIManager.put("Button.foreground", inputFg);
        UIManager.put("ComboBox.background", inputBg);
        UIManager.put("ComboBox.foreground", inputFg);
        UIManager.put("ComboBox.selectionBackground", listActive);
        UIManager.put("ComboBox.selectionForeground", listActiveFg);
        UIManager.put("CheckBox.background", sidebarBg);
        UIManager.put("CheckBox.foreground", sidebarFg);
        UIManager.put("RadioButton.background", sidebarBg);
        UIManager.put("RadioButton.foreground", sidebarFg);
        UIManager.put("ToolTip.background", widgetBg);
        UIManager.put("ToolTip.foreground", panelFg);
        UIManager.put("ToolTip.border", javax.swing.BorderFactory.createLineBorder(widgetBorder));
        UIManager.put("ScrollPane.background", editorBg);
        UIManager.put("ScrollPane.border", null);
        UIManager.put("Viewport.background", editorBg);
        UIManager.put("SplitPane.background", panelBorder);
        UIManager.put("SplitPane.dividerSize", Integer.valueOf(3));
        UIManager.put("SplitPane.border", null);
        UIManager.put("TabbedPane.background", sidebarBg);
        UIManager.put("TabbedPane.foreground", sidebarFg);
        UIManager.put("TabbedPane.selected", tabActiveBg);
        UIManager.put("TabbedPane.contentBorderInsets", new java.awt.Insets(0, 0, 0, 0));
        UIManager.put("ScrollBar.background", panelBg);
        UIManager.put("ScrollBar.thumb", scrollbar);
        UIManager.put("ScrollBar.track", panelBg);
        UIManager.put("ProgressBar.background", panelBg);
        UIManager.put("ProgressBar.foreground", accent);
        UIManager.put("FileChooser.background", widgetBg);
        UIManager.put("FileChooser.foreground", panelFg);
    }
}
