package com.codestudio.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Persistent user settings, stored in {@code ~/.codestudio/settings.properties}.
 * A tiny key/value store with typed accessors and change listeners.
 */
public class Settings {

    public static final Path DIR = Paths.get(System.getProperty("user.home"), ".codestudio");
    private static final Path FILE = DIR.resolve("settings.properties");

    /** key -> default value. Also drives the Settings UI. */
    public static final Map<String, String> DEFAULTS = new LinkedHashMap<>();
    static {
        DEFAULTS.put("workbench.colorTheme", "dark");
        DEFAULTS.put("workbench.language", "system");     // system | en | zh
        // Left blank on purpose: GitHub sign-in stays disabled until the user registers their own
        // OAuth App and pastes its client id here. The device flow needs no client secret.
        DEFAULTS.put("account.githubClientId", "");
        DEFAULTS.put("workbench.zoomLevel", "0");
        DEFAULTS.put("workbench.sideBarVisible", "true");
        DEFAULTS.put("workbench.sideBarWidth", "260");
        DEFAULTS.put("workbench.panelVisible", "false");
        DEFAULTS.put("workbench.panelHeight", "220");
        DEFAULTS.put("workbench.outlineHeight", "220");
        DEFAULTS.put("workbench.activityView", "explorer");
        DEFAULTS.put("workbench.breadcrumbs", "true");
        DEFAULTS.put("workbench.confirmDelete", "true");
        DEFAULTS.put("workbench.autoRevealInExplorer", "true");

        DEFAULTS.put("editor.fontFamily", "Consolas");
        DEFAULTS.put("editor.fontSize", "14");
        DEFAULTS.put("editor.tabSize", "4");
        DEFAULTS.put("editor.insertSpaces", "true");
        DEFAULTS.put("editor.wordWrap", "false");
        DEFAULTS.put("editor.lineNumbers", "true");
        DEFAULTS.put("editor.minimap", "true");
        DEFAULTS.put("editor.autoCloseBrackets", "true");
        DEFAULTS.put("editor.highlightActiveLine", "true");
        DEFAULTS.put("editor.renderWhitespace", "false");
        DEFAULTS.put("editor.folding", "true");
        DEFAULTS.put("editor.quickSuggestions", "true");
        DEFAULTS.put("editor.trimOnSave", "true");
        DEFAULTS.put("editor.autoSave", "off");           // off | afterDelay | onFocusChange
        DEFAULTS.put("editor.autoSaveDelay", "1200");
        DEFAULTS.put("editor.showOccurrences", "true");

        DEFAULTS.put("files.autoGuessEncoding", "true");
        DEFAULTS.put("files.exclude", ".git;.idea;.vscode;__pycache__;node_modules;target;build;.gradle;out;dist");
        DEFAULTS.put("files.defaultEncoding", "UTF-8");
        DEFAULTS.put("files.eol", "auto");

        DEFAULTS.put("terminal.shell", "");
        DEFAULTS.put("terminal.fontSize", "13");
        DEFAULTS.put("terminal.scrollback", "2000");

        DEFAULTS.put("window.width", "1280");
        DEFAULTS.put("window.height", "820");
        DEFAULTS.put("window.x", "-1");
        DEFAULTS.put("window.y", "-1");
        DEFAULTS.put("window.maximized", "false");

        DEFAULTS.put("files.lastFolder", "");
        DEFAULTS.put("files.recent", "");
        DEFAULTS.put("workspace.openFiles", "");
        DEFAULTS.put("workspace.activeFile", "");
    }

    private final Properties props = new Properties();
    private final List<Runnable> listeners = new ArrayList<>();
    private javax.swing.Timer saveTimer;

    private Settings() {
    }

    public static Settings load() {
        Settings s = new Settings();
        s.props.putAll(DEFAULTS);
        try {
            if (Files.isRegularFile(FILE)) {
                try (InputStream in = Files.newInputStream(FILE)) {
                    Properties p = new Properties();
                    p.load(in);
                    // force String values, keep unknown keys out of the defaults map
                    for (String k : p.stringPropertyNames()) {
                        s.props.setProperty(k, p.getProperty(k, ""));
                    }
                }
            }
        } catch (IOException ignored) {
            // corrupt settings must never block startup
        }
        return s;
    }

    public String get(String key) {
        return props.getProperty(key, DEFAULTS.getOrDefault(key, ""));
    }

    public String get(String key, String def) {
        return props.getProperty(key, def);
    }

    public int getInt(String key) {
        try {
            return Integer.parseInt(get(key).trim());
        } catch (NumberFormatException e) {
            return Integer.parseInt(DEFAULTS.getOrDefault(key, "0"));
        }
    }

    public boolean getBool(String key) {
        return "true".equalsIgnoreCase(get(key).trim());
    }

    public void set(String key, Object value) {
        String v = String.valueOf(value);
        if (v.equals(props.getProperty(key))) {
            return;
        }
        props.setProperty(key, v);
        scheduleSave();
        for (Runnable r : new ArrayList<>(listeners)) {
            r.run();
        }
    }

    public void toggle(String key) {
        set(key, !getBool(key));
    }

    public void addListener(Runnable r) {
        listeners.add(r);
    }

    /** Fired (debounced) whenever settings change. */
    private void scheduleSave() {
        if (saveTimer == null) {
            saveTimer = new javax.swing.Timer(600, e -> saveNow());
            saveTimer.setRepeats(false);
        }
        saveTimer.restart();
    }

    public void saveNow() {
        try {
            Files.createDirectories(DIR);
            Properties out = new Properties() {
                @Override
                public java.util.Set<Map.Entry<Object, Object>> entrySet() {
                    List<Map.Entry<Object, Object>> list = new ArrayList<>(super.entrySet());
                    list.sort((a, b) -> String.valueOf(a.getKey()).compareTo(String.valueOf(b.getKey())));
                    return new java.util.LinkedHashSet<>(list);
                }
            };
            out.putAll(props);
            try (OutputStream os = Files.newOutputStream(FILE)) {
                out.store(os, "CodeStudio settings");
            }
        } catch (IOException ignored) {
        }
    }

    /* ---------- recent folders ---------- */

    public List<String> getRecentFolders() {
        List<String> list = new ArrayList<>();
        for (String s : get("files.recent").split("\\s*;\\s*")) {
            if (!s.isBlank() && !list.contains(s)) {
                list.add(s);
            }
        }
        return list;
    }

    public void pushRecentFolder(String path) {
        if (path == null || path.isBlank()) {
            return;
        }
        List<String> list = getRecentFolders();
        list.remove(path);
        list.add(0, path);
        while (list.size() > 12) {
            list.remove(list.size() - 1);
        }
        set("files.recent", String.join(";", list));
    }

    public Path file() {
        return FILE;
    }
}
