package com.codestudio.core.plugin;

import com.codestudio.api.CodeStudioPlugin;
import com.codestudio.api.PluginContext;
import com.codestudio.core.Json;
import com.codestudio.core.Language;
import com.codestudio.core.Settings;
import com.codestudio.core.Theme;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import javax.swing.Icon;
import javax.swing.JComponent;

/**
 * Discovers, loads and unloads plugins.
 *
 * <p>Two shapes are supported, and both are driven by a {@code plugin.json} manifest:
 *
 * <ul>
 *   <li><b>A jar.</b> {@code myplugin.jar} with the manifest at the jar root. A {@code main} member
 *       names a class implementing {@link CodeStudioPlugin}; it is loaded through a
 *       {@link URLClassLoader} and activated.</li>
 *   <li><b>A directory.</b> Either a code plugin — the manifest plus any jars the plugin ships, with
 *       {@code main} pointing at a class on that classpath — or a <i>lightweight</i> plugin with no
 *       {@code main} at all, which contributes only themes and languages declared in the manifest
 *       and runs no code.</li>
 * </ul>
 *
 * <p>A plugin that throws while loading or activating is recorded as failed, with the reason kept
 * for the extensions view. It never takes the others, or the IDE, down with it.
 *
 * <p>Contributions are collected here as plain data and installed by the UI layer, so this class
 * never touches the {@code ui} package — it references Swing only for the {@link JComponent} and
 * {@link Icon} a plugin hands over.
 */
public final class PluginManager {

    /** A command contributed by a plugin. */
    public record Command(String id, String category, String title, String keybinding, Runnable action) {
    }

    /** A sidebar view contributed by a plugin. */
    public record View(String pluginId, String id, String title, Icon icon, JComponent component) {
    }

    /** A status bar item contributed by a plugin. */
    public record StatusItem(String pluginId, String id, String text, Runnable onClick) {
    }

    /** What the extensions view shows about one installed plugin. */
    public record Info(String id, String name, String version, String description, String source,
                       String kind, boolean enabled, String error) {

        /** True when the plugin loaded but threw somewhere along the way. */
        public boolean failed() {
            return error != null && !error.isBlank();
        }
    }

    /** Where the code plugin's entry class lives; absent for a manifest-only plugin. */
    private static final String MAIN = "main";

    private final Path directory;
    private final Path stateFile;

    private final List<Command> commands = new ArrayList<>();
    private final List<View> views = new ArrayList<>();
    private final List<StatusItem> statusItems = new ArrayList<>();
    private final Map<String, Info> installed = new LinkedHashMap<>();
    private final Map<String, Path> sources = new LinkedHashMap<>();
    private final Map<String, CodeStudioPlugin> active = new LinkedHashMap<>();
    private final Map<String, URLClassLoader> loaders = new LinkedHashMap<>();
    private final Set<String> disabled = new LinkedHashSet<>();

    /** The UI installs this so {@code showMessage} and friends have somewhere to land. */
    private Host host;

    public PluginManager() {
        this(defaultDirectory());
    }

    PluginManager(Path directory) {
        this.directory = directory;
        this.stateFile = directory.resolve("state.properties");
    }

    /**
     * Where plugins live. Overridable through {@code codestudio.plugins.dir} so the self test can
     * work against a temporary directory instead of the user's real one.
     */
    private static Path defaultDirectory() {
        String override = System.getProperty("codestudio.plugins.dir");
        return override == null || override.isBlank()
                ? Settings.DIR.resolve("plugins")
                : Paths.get(override);
    }

    public Path directory() {
        return directory;
    }

    /**
     * The services a plugin reaches the running IDE through. Implemented by the UI layer, because
     * showing a notification or writing to the Output channel is a UI concern.
     */
    public interface Host {
        void showMessage(String pluginId, String message);

        void showError(String pluginId, String message, Throwable cause);

        void log(String pluginId, String message);
    }

    public void setHost(Host host) {
        this.host = host;
    }

    /* ------------------------------------------------------------------ */
    /* contributions                                                       */
    /* ------------------------------------------------------------------ */

    public List<Command> commands() {
        return Collections.unmodifiableList(commands);
    }

    public List<View> views() {
        return Collections.unmodifiableList(views);
    }

    public List<StatusItem> statusItems() {
        return Collections.unmodifiableList(statusItems);
    }

    /** Every discovered plugin, loaded or not, in the order it will be shown. */
    public List<Info> plugins() {
        return Collections.unmodifiableList(new ArrayList<>(installed.values()));
    }

    public Info info(String id) {
        return installed.get(id);
    }

    /* ------------------------------------------------------------------ */
    /* loading                                                             */
    /* ------------------------------------------------------------------ */

    /** Discards every contribution and loads the directory from scratch. */
    public void reload() {
        unloadAll();
        commands.clear();
        views.clear();
        statusItems.clear();
        installed.clear();
        sources.clear();
        // Both registries must be emptied, or a reload would report every plugin's theme and
        // language as a duplicate of the copy the previous load installed.
        Theme.clearContributed();
        Language.clearContributed();
        readState();
        discover();
    }

    /** Deactivates every loaded plugin and closes its loader. Contributions are left alone. */
    private void unloadAll() {
        for (Map.Entry<String, CodeStudioPlugin> e : active.entrySet()) {
            try {
                e.getValue().deactivate();
            } catch (Throwable t) {
                record(e.getKey(), t.toString());
            }
        }
        active.clear();
        for (Map.Entry<String, URLClassLoader> e : loaders.entrySet()) {
            try {
                // Closing releases the jar handle, which matters on Windows: without this the file
                // cannot be deleted or replaced while the IDE is running.
                e.getValue().close();
            } catch (IOException ignored) {
                // Nothing useful to do; the handle is released when the process exits.
            }
        }
        loaders.clear();
    }

    /** Walks the plugins directory and loads each entry. */
    private void discover() {
        if (!Files.isDirectory(directory)) {
            return;
        }
        List<Path> entries = new ArrayList<>();
        try (var stream = Files.list(directory)) {
            stream.filter(p -> Files.isDirectory(p)
                            || p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar"))
                    .sorted()
                    .forEach(entries::add);
        } catch (IOException e) {
            return;
        }
        for (Path entry : entries) {
            try {
                if (Files.isDirectory(entry)) {
                    loadDirectory(entry);
                } else {
                    loadJar(entry);
                }
            } catch (Throwable t) {
                // A malformed manifest or an unreadable file: record it and move on.
                String name = entry.getFileName().toString();
                installed.put(name, new Info(name, name, "", "", name, "unknown", false, describe(t)));
            }
        }
    }

    private void loadJar(Path jar) throws IOException {
        String manifestText;
        try (JarFile file = new JarFile(jar.toFile())) {
            JarEntry entry = file.getJarEntry("plugin.json");
            if (entry == null) {
                installed.put(jar.getFileName().toString(), new Info(jar.getFileName().toString(),
                        jar.getFileName().toString(), "", "", jar.getFileName().toString(),
                        "jar", false, "plugin.json is missing from the jar"));
                return;
            }
            try (InputStream in = file.getInputStream(entry)) {
                manifestText = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
        }
        Map<String, Object> manifest = Json.parseObject(manifestText);
        if (manifest == null) {
            installed.put(jar.getFileName().toString(), new Info(jar.getFileName().toString(),
                    jar.getFileName().toString(), "", "", jar.getFileName().toString(),
                    "jar", false, "plugin.json is not a JSON object"));
            return;
        }
        String main = Json.string(manifest, MAIN, null);
        URL[] classpath = {jar.toUri().toURL()};
        register(manifest, jar, jar.getFileName().toString(), "jar", main, classpath);
    }

    private void loadDirectory(Path dir) throws IOException {
        Path manifestFile = dir.resolve("plugin.json");
        if (!Files.isRegularFile(manifestFile)) {
            return; // Not a plugin; ignore rather than reporting an error for every stray folder.
        }
        String text = Files.readString(manifestFile, StandardCharsets.UTF_8);
        Map<String, Object> manifest = Json.parseObject(text);
        if (manifest == null) {
            String name = dir.getFileName().toString();
            installed.put(name, new Info(name, name, "", "", name, "directory", false,
                    "plugin.json is not a JSON object"));
            return;
        }
        // Every jar in the directory is on the plugin's classpath, so a plugin may ship several.
        List<URL> classpath = new ArrayList<>();
        try (var stream = Files.list(dir)) {
            for (Path p : stream.sorted().toList()) {
                if (p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar")) {
                    classpath.add(p.toUri().toURL());
                }
            }
        }
        register(manifest, dir, dir.getFileName().toString(), "directory",
                Json.string(manifest, MAIN, null), classpath.toArray(new URL[0]));
    }

    /** Records a plugin from its manifest and, when it has an entry class, activates it. */
    private void register(Map<String, Object> manifest, Path source, String fallbackName,
                          String kind, String main, URL[] classpath) {
        String id = Json.string(manifest, "id", fallbackName);
        String name = Json.string(manifest, "name", id);
        String version = Json.stringOrNumber(manifest, "version", "");
        String description = Json.string(manifest, "description", "");
        boolean enabled = !disabled.contains(id);

        sources.put(id, source);
        installed.put(id, new Info(id, name, version, description, source.getFileName().toString(),
                main == null || main.isBlank() ? kind + " (declarative)" : kind, enabled, null));

        if (!enabled) {
            return;
        }

        // Declarative contributions first: a manifest-only plugin has nothing but these.
        String error = contributeFromManifest(id, manifest);
        if (error != null) {
            record(id, error);
        }
        if (main == null || main.isBlank()) {
            return;
        }
        if (classpath.length == 0) {
            record(id, "the manifest names an entry class but the plugin ships no jar");
            return;
        }

        URLClassLoader loader = null;
        try {
            loader = new URLClassLoader(classpath, PluginManager.class.getClassLoader());
            Class<?> type = Class.forName(main, true, loader);
            if (!CodeStudioPlugin.class.isAssignableFrom(type)) {
                record(id, main + " does not implement com.codestudio.api.CodeStudioPlugin");
                loader.close();
                return;
            }
            CodeStudioPlugin plugin = (CodeStudioPlugin) type.getDeclaredConstructor().newInstance();
            loaders.put(id, loader);
            active.put(id, plugin);
            try {
                plugin.activate(new Context(id));
            } catch (Throwable t) {
                // Activation failed: the plugin stays listed as failed, but its loader is kept open
                // so that disabling it later can still call deactivate without a class-loading error.
                record(id, describe(t));
            }
        } catch (NoClassDefFoundError | ClassNotFoundException | NoSuchMethodException e) {
            record(id, "could not load " + main + ": " + describe(e)
                    + " (a plugin must not bundle its own copy of com.codestudio.api)");
            close(loader);
        } catch (Throwable t) {
            record(id, describe(t));
            close(loader);
        }
    }

    private static void close(URLClassLoader loader) {
        if (loader != null) {
            try {
                loader.close();
            } catch (IOException ignored) {
                // Released when the process exits.
            }
        }
    }

    private void record(String id, String error) {
        Info current = installed.get(id);
        if (current == null) {
            return;
        }
        installed.put(id, new Info(current.id(), current.name(), current.version(),
                current.description(), current.source(), current.kind(), current.enabled(), error));
    }

    /* ------------------------------------------------------------------ */
    /* declarative contributions                                           */
    /* ------------------------------------------------------------------ */

    /**
     * Applies the {@code contributes} section of a manifest: themes and languages, declared as data
     * with no code involved.
     *
     * @return an error description, or null when everything applied
     */
    private String contributeFromManifest(String pluginId, Map<String, Object> manifest) {
        Object contributes = manifest.get("contributes");
        Map<String, Object> section = Json.asObject(contributes);
        if (section == null) {
            return null;
        }
        StringBuilder problems = new StringBuilder();

        for (Object element : Json.array(section, "themes")) {
            Map<String, Object> theme = Json.asObject(element);
            if (theme == null) {
                continue;
            }
            String id = Json.string(theme, "id", null);
            if (id == null) {
                problems.append("a theme has no id; ");
                continue;
            }
            // Start from a built-in so the manifest only has to name the colors it changes.
            String base = Json.string(theme, "base", "dark");
            Theme built = Theme.copyOf(Theme.get(base));
            Map<String, Object> colors = Json.asObject(theme.get("colors"));
            if (colors != null) {
                for (Map.Entry<String, Object> e : colors.entrySet()) {
                    if (!applyColor(built, e.getKey(), String.valueOf(e.getValue()))) {
                        problems.append("unknown color \"").append(e.getKey()).append("\" in theme ")
                                .append(id).append("; ");
                    }
                }
            }
            if (!Theme.register(id, Json.string(theme, "name", id), built)) {
                problems.append("theme id \"").append(id).append("\" is already taken; ");
            }
        }

        for (Object element : Json.array(section, "languages")) {
            Map<String, Object> lang = Json.asObject(element);
            if (lang == null) {
                continue;
            }
            String id = Json.string(lang, "id", null);
            String name = Json.string(lang, "name", id);
            if (id == null) {
                problems.append("a language has no id; ");
                continue;
            }
            Language.Lexer lexer = lexer(Json.string(lang, "lexer", "GENERIC"));
            Language language = Language.contributed(id, name, lexer);
            if (language == null) {
                problems.append("language id \"").append(id)
                        .append("\" is taken or its lexer is not data-driven; ");
                continue;
            }
            language.ext(Json.strings(lang, "extensions").toArray(new String[0]));
            language.file(Json.strings(lang, "filenames").toArray(new String[0]));
            language.kw(Json.strings(lang, "keywords").toArray(new String[0]));
            language.ctl(Json.strings(lang, "controlKeywords").toArray(new String[0]));
            language.ty(Json.strings(lang, "types").toArray(new String[0]));
            language.co(Json.strings(lang, "constants").toArray(new String[0]));
            language.bi(Json.strings(lang, "builtins").toArray(new String[0]));
            List<String> lineComments = Json.strings(lang, "lineComments");
            if (!lineComments.isEmpty()) {
                language.lineComments(lineComments.toArray(new String[0]));
            }
            String badge = Json.string(lang, "badge", null);
            if (badge != null) {
                language.badge(Json.string(lang, "badgeColor", "#888888"), badge);
            }
            if (Json.bool(lang, "caseInsensitive", false)) {
                language.caseInsensitive(true);
            }
        }
        return problems.isEmpty() ? null : problems.toString().trim();
    }

    private static Language.Lexer lexer(String name) {
        try {
            return Language.Lexer.valueOf(name.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return Language.Lexer.GENERIC;
        }
    }

    /**
     * Maps a manifest color name onto a theme field. A deliberate subset: the colors a theme is
     * usually judged by. A plugin that wants to set all forty uses the Java API and
     * {@link Theme#copyOf} instead, which is strongly typed and cannot misspell a key.
     *
     * @return false when the name is not one this understands
     */
    private static boolean applyColor(Theme t, String key, String hex) {
        Color c;
        try {
            String value = hex.trim();
            if (!value.startsWith("#")) {
                value = "#" + value;
            }
            c = new Color(Integer.parseInt(value.substring(1), 16), value.length() > 7);
        } catch (RuntimeException e) {
            return false;
        }
        switch (key == null ? "" : key) {
            case "accent" -> t.accent = c;
            case "editorBg" -> t.editorBg = c;
            case "editorFg" -> t.editorFg = c;
            case "sidebarBg" -> t.sidebarBg = c;
            case "sidebarFg" -> t.sidebarFg = c;
            case "activityBg" -> t.activityBg = c;
            case "statusBg" -> t.statusBg = c;
            case "statusFg" -> t.statusFg = c;
            case "titleBg" -> t.titleBg = c;
            case "panelBg" -> t.panelBg = c;
            case "tabActiveBg" -> t.tabActiveBg = c;
            case "tabInactiveBg" -> t.tabInactiveBg = c;
            case "selection" -> t.selection = c;
            case "lineHighlight" -> t.lineHighlight = c;
            case "inputBg" -> t.inputBg = c;
            case "inputFg" -> t.inputFg = c;
            case "error" -> t.error = c;
            case "warning" -> t.warning = c;
            case "info" -> t.info = c;
            case "synKeyword" -> t.synKeyword = c;
            case "synControl" -> t.synControl = c;
            case "synType" -> t.synType = c;
            case "synString" -> t.synString = c;
            case "synComment" -> t.synComment = c;
            case "synNumber" -> t.synNumber = c;
            case "synFunction" -> t.synFunction = c;
            case "synAnnotation" -> t.synAnnotation = c;
            case "synConstant" -> t.synConstant = c;
            case "synVar" -> t.synVar = c;
            default -> {
                return false;
            }
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* enable, disable, install, remove                                    */
    /* ------------------------------------------------------------------ */

    public boolean isEnabled(String id) {
        return !disabled.contains(id);
    }

    public void setEnabled(String id, boolean enabled) {
        if (enabled) {
            disabled.remove(id);
        } else {
            disabled.add(id);
        }
        writeState();
        reload();
    }

    /** Copies a jar into the plugins directory and reloads. Returns the new file, or null. */
    public Path install(Path jar) {
        try {
            Files.createDirectories(directory);
            Path target = directory.resolve(jar.getFileName().toString());
            Files.copy(jar, target, StandardCopyOption.REPLACE_EXISTING);
            reload();
            return target;
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Deletes a plugin from disk. The plugin is unloaded first so its jar is not still open, which
     * on Windows would make the delete fail.
     */
    public boolean uninstall(String id) {
        Path source = sources.get(id);
        if (source == null) {
            return false;
        }
        unloadAll();
        boolean removed;
        try {
            if (Files.isDirectory(source)) {
                deleteRecursive(source.toFile());
            } else {
                Files.deleteIfExists(source);
            }
            removed = true;
        } catch (IOException e) {
            removed = false;
        }
        disabled.remove(id);
        writeState();
        reload();
        return removed;
    }

    private static void deleteRecursive(File file) throws IOException {
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) {
                deleteRecursive(child);
            }
        }
        Files.deleteIfExists(file.toPath());
    }

    /* ------------------------------------------------------------------ */
    /* enabled/disabled state                                              */
    /* ------------------------------------------------------------------ */

    private void readState() {
        disabled.clear();
        if (!Files.isRegularFile(stateFile)) {
            return;
        }
        Properties props = new Properties();
        try (Reader in = Files.newBufferedReader(stateFile, StandardCharsets.UTF_8)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (String id : props.getProperty("disabled", "").split("\n")) {
            if (!id.isBlank()) {
                disabled.add(id.trim());
            }
        }
    }

    private void writeState() {
        Properties props = new Properties();
        props.setProperty("disabled", String.join("\n", disabled));
        try {
            Files.createDirectories(directory);
            try (Writer out = Files.newBufferedWriter(stateFile, StandardCharsets.UTF_8)) {
                props.store(out, "CodeStudio plugins: which are disabled.");
            }
        } catch (IOException ignored) {
            // Losing the flag is not worth interrupting the user over.
        }
    }

    /* ------------------------------------------------------------------ */
    /* the context handed to plugins                                       */
    /* ------------------------------------------------------------------ */

    /** Collects what a plugin contributes. One instance per plugin, so the id is never ambiguous. */
    private final class Context implements PluginContext {

        private final String pluginId;

        Context(String pluginId) {
            this.pluginId = pluginId;
        }

        @Override
        public String pluginId() {
            return pluginId;
        }

        @Override
        public Path dataDirectory() {
            Path dir = directory.resolve(pluginId).resolve("data");
            try {
                Files.createDirectories(dir);
            } catch (IOException ignored) {
                // The caller will see the failure when it tries to write.
            }
            return dir;
        }

        @Override
        public Path workspaceRoot() {
            return host instanceof WorkspaceAware aware ? aware.workspaceRoot() : null;
        }

        @Override
        public boolean isChinese() {
            return com.codestudio.core.Strings.isChinese();
        }

        @Override
        public void addCommand(String id, String category, String title, String keybinding,
                               Runnable action) {
            if (id == null || id.isBlank() || action == null) {
                return;
            }
            commands.add(new Command(id, category == null || category.isBlank() ? pluginId : category,
                    title == null || title.isBlank() ? id : title,
                    keybinding == null ? "" : keybinding, action));
        }

        @Override
        public boolean addTheme(String id, String name, Theme theme) {
            return Theme.register(id, name, theme);
        }

        @Override
        public boolean addLanguage(Language language) {
            if (language == null) {
                return false;
            }
            // The language already went through Language.contributed to be constructible at all;
            // registering it here only needs the id to be present.
            return Language.find(language.id) != null;
        }

        @Override
        public void addView(String id, String title, Icon icon, JComponent view) {
            if (id == null || id.isBlank() || view == null) {
                return;
            }
            views.add(new View(pluginId, id, title == null || title.isBlank() ? id : title, icon, view));
        }

        @Override
        public void addStatusItem(String id, String text, Runnable onClick) {
            if (id == null || id.isBlank()) {
                return;
            }
            statusItems.add(new StatusItem(pluginId, id, text == null ? "" : text, onClick));
        }

        @Override
        public void showMessage(String message) {
            if (host != null) {
                host.showMessage(pluginId, message);
            }
        }

        @Override
        public void showError(String message, Throwable cause) {
            if (host != null) {
                host.showError(pluginId, message, cause);
            }
        }

        @Override
        public void log(String message) {
            if (host != null) {
                host.log(pluginId, message);
            }
        }
    }

    /** A host that can also report the open folder, implemented by the UI layer. */
    public interface WorkspaceAware {
        Path workspaceRoot();
    }

    /** A short description of a throwable, for the extensions view. */
    private static String describe(Throwable t) {
        String message = t.getMessage();
        return message == null || message.isBlank()
                ? t.getClass().getSimpleName()
                : t.getClass().getSimpleName() + ": " + message;
    }
}
