package com.codestudio.core;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** The breakpoint store shared by the editors, the gutter and the Run view. */
public final class Breakpoints {

    /** A single breakpoint. */
    public static class Point {
        public final File file;
        public final int line;
        public boolean enabled = true;

        Point(File file, int line) {
            this.file = file;
            this.line = line;
        }

        @Override
        public String toString() {
            return (file == null ? "?" : file.getName()) + ":" + (line + 1);
        }
    }

    private static final List<Point> POINTS = new ArrayList<>();
    private static final List<Runnable> LISTENERS = new ArrayList<>();
    private static int revision;

    private Breakpoints() {
    }

    public static void addListener(Runnable r) {
        LISTENERS.add(r);
    }

    public static int revision() {
        return revision;
    }

    private static void fire() {
        revision++;
        for (Runnable r : new ArrayList<>(LISTENERS)) {
            r.run();
        }
    }

    public static List<Point> all() {
        return new ArrayList<>(POINTS);
    }

    public static List<Point> forFile(File file) {
        List<Point> out = new ArrayList<>();
        for (Point p : POINTS) {
            if (sameFile(p.file, file)) {
                out.add(p);
            }
        }
        return out;
    }

    public static boolean has(File file, int line) {
        return find(file, line) != null;
    }

    public static Point find(File file, int line) {
        for (Point p : POINTS) {
            if (p.line == line && sameFile(p.file, file)) {
                return p;
            }
        }
        return null;
    }

    /** Adds the breakpoint when missing, removes it otherwise. Returns true when one was added. */
    public static boolean toggle(File file, int line) {
        if (file == null) {
            return false;
        }
        Point existing = find(file, line);
        if (existing != null) {
            POINTS.remove(existing);
            fire();
            return false;
        }
        POINTS.add(new Point(file, line));
        fire();
        return true;
    }

    public static void remove(Point p) {
        if (POINTS.remove(p)) {
            fire();
        }
    }

    public static void removeFile(File file) {
        if (POINTS.removeIf(p -> sameFile(p.file, file))) {
            fire();
        }
    }

    public static void setEnabled(Point p, boolean on) {
        if (p.enabled != on) {
            p.enabled = on;
            fire();
        }
    }

    public static void clear() {
        if (POINTS.isEmpty()) {
            return;
        }
        POINTS.clear();
        fire();
    }

    /** Lines that are currently enabled, grouped for the debug launcher. */
    public static List<Point> enabled() {
        List<Point> out = new ArrayList<>();
        for (Point p : POINTS) {
            if (p.enabled) {
                out.add(p);
            }
        }
        return out;
    }

    /** Breakpoints are stored per canonical path so renames do not duplicate them. */
    private static boolean sameFile(File a, File b) {
        if (a == null || b == null) {
            return a == b;
        }
        try {
            return Objects.equals(a.getCanonicalPath(), b.getCanonicalPath());
        } catch (Exception e) {
            return a.getAbsoluteFile().equals(b.getAbsoluteFile());
        }
    }
}
