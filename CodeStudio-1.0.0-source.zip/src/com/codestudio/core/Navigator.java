package com.codestudio.core;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Go to definition, find all references and rename symbol, over the workspace index.
 *
 * <p>VS Code answers these from a language server. There is no server here and no dependency to
 * add one with, so the answers come from the text: a whole-word scan of every indexed file, with
 * definition-shaped lines ranked first. That is the same bargain the rest of the IDE makes -
 * pattern matching good enough to navigate a real project with, and honest about being a heuristic.
 */
public final class Navigator {

    /** One place a symbol was found. */
    public static final class Hit {
        public final File file;
        /** 1-based. */
        public final int line;
        /** 1-based. */
        public final int column;
        /** The line itself, trimmed for display. */
        public final String text;
        public final boolean definition;

        public Hit(File file, int line, int column, String text, boolean definition) {
            this.file = file;
            this.line = line;
            this.column = column;
            this.text = text;
            this.definition = definition;
        }
    }

    private static final int MAX_FILES = 5000;
    private static final int MAX_HITS = 400;
    private static final long MAX_FILE_BYTES = 2L * 1024 * 1024;
    private static final int MAX_PREVIEW = 160;

    private Navigator() {
    }

    /* ------------------------------------------------------------------ */
    /* identifiers                                                         */
    /* ------------------------------------------------------------------ */

    public static boolean isIdentifierChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_' || c == '$';
    }

    public static boolean isIdentifier(String s) {
        if (s == null || s.isEmpty()) {
            return false;
        }
        if (!Character.isJavaIdentifierStart(s.charAt(0)) && s.charAt(0) != '$') {
            return false;
        }
        for (int i = 1; i < s.length(); i++) {
            if (!isIdentifierChar(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * The identifier the caret sits in or touches. Unlike a naive "scan left" this also answers
     * when the caret is immediately after the word, which is where it is right after typing one.
     */
    public static String identifierAt(String text, int offset) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        int pos = Math.max(0, Math.min(offset, text.length()));
        int start = pos;
        int end = pos;
        if (start > 0 && !isIdentifierChar(text.charAt(start - 1))) {
            // caret after whitespace or punctuation: still allow the word starting here
            while (end < text.length() && isIdentifierChar(text.charAt(end))) {
                end++;
            }
            return text.substring(start, end);
        }
        while (start > 0 && isIdentifierChar(text.charAt(start - 1))) {
            start--;
        }
        while (end < text.length() && isIdentifierChar(text.charAt(end))) {
            end++;
        }
        return text.substring(start, end);
    }

    /** The whole-word matcher used by reference search and rename. */
    public static Pattern wholeWord(String word) {
        return Pattern.compile("(?<![\\w$])" + Pattern.quote(word) + "(?![\\w$])");
    }

    /* ------------------------------------------------------------------ */
    /* search                                                              */
    /* ------------------------------------------------------------------ */

    public static List<Hit> definitions(Workspace workspace, String word) {
        return scan(workspace, word, true);
    }

    public static List<Hit> references(Workspace workspace, String word) {
        return scan(workspace, word, false);
    }

    private static List<Hit> scan(Workspace workspace, String word, boolean onlyDefinitions) {
        List<Hit> hits = new ArrayList<>();
        if (workspace == null || !isIdentifier(word)) {
            return hits;
        }
        Pattern pattern = wholeWord(word);
        List<File> files = new ArrayList<>(workspace.indexFiles());
        // An open, unsaved buffer is searched from memory below; searching the stale copy on disk
        // would report a definition that the user has already deleted.
        Set<String> inMemory = new LinkedHashSet<>();
        for (DocumentBundle b : workspace.documents()) {
            if (b.file != null) {
                inMemory.add(key(b.file));
            }
        }
        int visited = 0;
        for (File f : files) {
            if (visited++ > MAX_FILES || hits.size() >= MAX_HITS) {
                break;
            }
            if (f == null || !f.isFile() || f.length() > MAX_FILE_BYTES || inMemory.contains(key(f))) {
                continue;
            }
            String text = read(f);
            if (text != null) {
                collect(text, f, pattern, onlyDefinitions, hits, MAX_HITS);
            }
        }
        for (DocumentBundle b : workspace.documents()) {
            if (b.file == null || b.content().isBlank()) {
                continue;
            }
            collect(b.content(), b.file, pattern, onlyDefinitions, hits, MAX_HITS);
        }
        hits.sort(Comparator.comparing((Hit h) -> !h.definition)
                .thenComparing(h -> h.file == null ? "" : h.file.getAbsolutePath())
                .thenComparingInt(h -> h.line));
        return hits;
    }

    private static void collect(String text, File file, Pattern pattern, boolean onlyDefinitions,
                                List<Hit> hits, int limit) {
        if (text == null || text.isEmpty()) {
            return;
        }
        Matcher m = pattern.matcher(text);
        while (m.find() && hits.size() < limit) {
            int at = m.start();
            int line = 1;
            int lineStart = 0;
            for (int i = 0; i < at; i++) {
                if (text.charAt(i) == '\n') {
                    line++;
                    lineStart = i + 1;
                }
            }
            int lineEnd = text.indexOf('\n', at);
            if (lineEnd < 0) {
                lineEnd = text.length();
            }
            String preview = text.substring(lineStart, Math.min(lineEnd, lineStart + MAX_PREVIEW)).strip();
            boolean definition = looksLikeDefinition(text.substring(lineStart, lineEnd), m.group(),
                    at - lineStart);
            if (!onlyDefinitions || definition) {
                hits.add(new Hit(file, line, at - lineStart + 1, preview, definition));
            }
        }
    }

    /**
     * Whether a line introduces the name rather than using it. The patterns cover the declaration
     * syntax of the languages this IDE knows; anything unrecognised is reported as a use, which is
     * the safe direction to be wrong in.
     */
    static boolean looksLikeDefinition(String line, String word, int column) {
        String before = line.substring(0, Math.max(0, Math.min(column, line.length())));
        String after = line.substring(Math.max(0, Math.min(column + word.length(), line.length())));
        String trimmedBefore = before.strip();
        // `class Foo`, `def foo`, `func foo`, `fn foo`, `type foo`, `let foo =` ...
        if (trimmedBefore.matches(".*\\b(class|interface|enum|record|struct|trait|impl|type|def|func|"
                + "fn|function|fun|const|let|var|static|final|public|private|protected|export|object|"
                + "namespace|module|package|defpackage|aspect|protocol|annotation|typedef)$")) {
            return true;
        }
        // `Foo()`, `int Foo =`, `Foo :` -a declaration that names a callable or a value.
        String rest = after.stripLeading();
        if (rest.startsWith("(")) {
            return !trimmedBefore.endsWith(".") && !trimmedBefore.matches(".*\\b(new|return)$");
        }
        if (rest.startsWith("=") || rest.startsWith(":=") || rest.startsWith(";")) {
            return isDeclarationPrefix(trimmedBefore);
        }
        // A bare label or a typed declaration (`count: int`) only when nothing precedes the name,
        // so an object literal's keys are not mistaken for definitions.
        return rest.startsWith(":") && trimmedBefore.isEmpty();
    }

    /**
     * Whether what precedes the name still looks like the start of a declaration. A declaration
     * names its symbol at the start of a statement, so only modifiers, a type, or a comma separated
     * run of names may come before it; any statement punctuation means this is an assignment inside
     * a body, which is a use rather than a definition.
     */
    private static boolean isDeclarationPrefix(String before) {
        for (int i = 0; i < before.length(); i++) {
            switch (before.charAt(i)) {
                case '{', '}', ';', '(', ')', '=' -> {
                    return false;
                }
                default -> {
                    // keep looking
                }
            }
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* rename                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Rewrites one file, replacing whole-word occurrences.
     *
     * @return the number of replacements, or -1 when the file could not be written
     */
    public static int renameInFile(File file, String word, String replacement) {
        String text = read(file);
        if (text == null) {
            return 0;
        }
        int[] count = new int[1];
        String updated = replaceWholeWord(text, word, replacement, count);
        if (count[0] == 0) {
            return 0;
        }
        try {
            Files.writeString(file.toPath(), updated, StandardCharsets.UTF_8);
            return count[0];
        } catch (IOException e) {
            return -1;
        }
    }

    /** Whole-word replacement in memory; {@code count} receives the number of hits. */
    public static String replaceWholeWord(String text, String word, String replacement, int[] count) {
        int[] c = count == null ? new int[1] : count;
        c[0] = 0;
        if (text == null || !isIdentifier(word)) {
            return text;
        }
        Matcher m = wholeWord(word).matcher(text);
        StringBuilder sb = new StringBuilder(text.length());
        while (m.find()) {
            c[0]++;
            m.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private static String read(File f) {
        try {
            if (!Workspace.isProbablyText(f)) {
                return null;
            }
            byte[] bytes = Files.readAllBytes(f.toPath());
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private static String key(File f) {
        return f.getAbsolutePath().toLowerCase(Locale.ROOT);
    }
}
