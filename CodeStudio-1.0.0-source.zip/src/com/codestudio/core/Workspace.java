package com.codestudio.core;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** The set of folders and open documents the workbench is currently working on. */
public class Workspace {

    public interface Listener {
        void workspaceChanged();
    }

    private final Settings settings;
    private final Map<String, DocumentBundle> open = new LinkedHashMap<>();
    private final List<Listener> listeners = new ArrayList<>();
    public File root;
    private List<File> cachedIndex;
    private long indexTime;

    public Workspace(Settings settings) {
        this.settings = settings;
    }

    public void addListener(Listener l) {
        listeners.add(l);
    }

    private void fire() {
        for (Listener l : new ArrayList<>(listeners)) {
            l.workspaceChanged();
        }
    }

    public File getRoot() {
        return root;
    }

    public String rootName() {
        return root == null ? "" : root.getName();
    }

    public void setRoot(File dir) {
        this.root = dir;
        this.cachedIndex = null;
        if (dir != null) {
            settings.pushRecentFolder(dir.getAbsolutePath());
            settings.set("files.lastFolder", dir.getAbsolutePath());
        }
        fire();
    }

    /* ---------------- documents ---------------- */

    public DocumentBundle get(File f) {
        return open.get(key(f));
    }

    private static String key(File f) {
        try {
            return f.getCanonicalPath().toLowerCase(Locale.ROOT);
        } catch (IOException e) {
            return f.getAbsolutePath().toLowerCase(Locale.ROOT);
        }
    }

    public DocumentBundle open(File f) throws IOException {
        DocumentBundle b = open.get(key(f));
        if (b == null) {
            b = DocumentBundle.open(f);
            open.put(key(f), b);
        }
        return b;
    }

    public DocumentBundle openUntitled(Language lang) {
        DocumentBundle b = DocumentBundle.newUntitled(lang);
        open.put("untitled:" + System.nanoTime(), b);
        return b;
    }

    public void register(DocumentBundle b) {
        if (b.file != null) {
            open.put(key(b.file), b);
        }
    }

    public void close(DocumentBundle b) {
        open.values().removeIf(x -> x == b);
        fire();
    }

    public Collection<DocumentBundle> documents() {
        return new ArrayList<>(open.values());
    }

    public List<DocumentBundle> dirtyDocuments() {
        List<DocumentBundle> list = new ArrayList<>();
        for (DocumentBundle b : open.values()) {
            if (b.isDirty()) {
                list.add(b);
            }
        }
        return list;
    }

    public int saveAll() {
        int n = 0;
        for (DocumentBundle b : dirtyDocuments()) {
            if (b.file == null) {
                continue;
            }
            try {
                if (b.save(settings)) {
                    n++;
                }
            } catch (IOException ignored) {
            }
        }
        fire();
        return n;
    }

    /* ---------------- file index (quick open / search / pickers) ---------------- */

    public Set<String> excludedDirs() {
        Set<String> set = new LinkedHashSet<>();
        for (String s : settings.get("files.exclude").split("\\s*;\\s*")) {
            if (!s.isBlank()) {
                set.add(s.toLowerCase(Locale.ROOT));
            }
        }
        return set;
    }

    /** All files under the root, skipping well known junk folders. Cached briefly. */
    public List<File> indexFiles() {
        if (root == null) {
            return new ArrayList<>();
        }
        if (cachedIndex != null && System.currentTimeMillis() - indexTime < 8000) {
            return cachedIndex;
        }
        List<File> out = new ArrayList<>();
        Set<String> excluded = excludedDirs();
        walk(root, out, excluded, 0);
        cachedIndex = out;
        indexTime = System.currentTimeMillis();
        return out;
    }

    public void invalidateIndex() {
        cachedIndex = null;
    }

    private static void walk(File dir, List<File> out, Set<String> excluded, int depth) {
        if (depth > 16 || out.size() > 40000) {
            return;
        }
        File[] children = dir.listFiles();
        if (children == null) {
            return;
        }
        java.util.Arrays.sort(children, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (File c : children) {
            String name = c.getName();
            if (name.startsWith(".") && !"github".equalsIgnoreCase(name)) {
                continue;
            }
            if (c.isDirectory()) {
                if (excluded.contains(name.toLowerCase(Locale.ROOT))) {
                    continue;
                }
                walk(c, out, excluded, depth + 1);
            } else {
                out.add(c);
            }
        }
    }

    /** Path relative to the workspace root, or an absolute path when outside it. */
    public String relative(File f) {
        if (f == null) {
            return "";
        }
        if (root == null) {
            return f.getAbsolutePath();
        }
        Path r = root.toPath().toAbsolutePath();
        Path p = f.toPath().toAbsolutePath();
        try {
            return r.relativize(p).toString();
        } catch (IllegalArgumentException e) {
            return f.getAbsolutePath();
        }
    }

    public static boolean isProbablyText(File f) {
        String name = f.getName().toLowerCase(Locale.ROOT);
        String[] binary = {"jar", "class", "exe", "dll", "so", "dylib", "zip", "gz", "tar", "7z", "rar",
            "png", "jpg", "jpeg", "gif", "bmp", "ico", "webp", "mp3", "mp4", "avi", "mov", "wav", "pdf",
            "doc", "docx", "xls", "xlsx", "ppt", "pptx", "ttf", "otf", "woff", "woff2", "bin", "o", "obj",
            "pyc", "pyo", "db", "sqlite", "lock"};
        int dot = name.lastIndexOf('.');
        if (dot < 0) {
            return true;
        }
        String ext = name.substring(dot + 1);
        for (String b : binary) {
            if (b.equals(ext)) {
                return false;
            }
        }
        return true;
    }

    public static boolean deleteRecursive(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) {
                    deleteRecursive(k);
                }
            }
        }
        return f.delete();
    }

    public static String uniqueChildName(File dir, String base, String ext) {
        File f = ext.isEmpty() ? new File(dir, base) : new File(dir, base + "." + ext);
        int i = 1;
        while (f.exists()) {
            f = new File(dir, (ext.isEmpty() ? base : base + "." + ext));
            String n = ext.isEmpty() ? base + i : base + i + "." + ext;
            f = new File(dir, n);
            i++;
        }
        return f.getName();
    }

    public static boolean canWrite(File f) {
        return f == null || f.getParentFile() == null || Files.isWritable(f.getParentFile().toPath());
    }
}
