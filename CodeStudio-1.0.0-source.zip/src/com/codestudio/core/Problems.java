package com.codestudio.core;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Collector for compiler and runtime diagnostics shown in the Problems panel. */
public class Problems {

    public enum Severity {
        ERROR, WARNING, INFO
    }

    /** A single diagnostic. */
    public static class Problem {
        public final File file;
        public final int line;
        public final int column;
        public final String message;
        public final Severity severity;
        public final String source;

        public Problem(File file, int line, int column, String message, Severity severity, String source) {
            this.file = file;
            this.line = line;
            this.column = column;
            this.message = message;
            this.severity = severity;
            this.source = source;
        }

        @Override
        public String toString() {
            return (file == null ? "" : file.getName()) + ":" + (line + 1) + " " + message;
        }
    }

    private final List<Problem> problems = new ArrayList<>();
    private final List<Runnable> listeners = new ArrayList<>();

    /** Bumped on every mutation so views can detect changes cheaply. */
    private int revision;

    public void addListener(Runnable r) {
        listeners.add(r);
    }

    private void fire() {
        revision++;
        for (Runnable r : new ArrayList<>(listeners)) {
            r.run();
        }
    }

    public int revision() {
        return revision;
    }

    public void clear() {
        if (problems.isEmpty()) {
            return;
        }
        problems.clear();
        fire();
    }

    public void add(Problem p) {
        if (p == null) {
            return;
        }
        for (Problem existing : problems) {
            if (existing.line == p.line && existing.severity == p.severity
                    && existing.message.equals(p.message)
                    && java.util.Objects.equals(existing.file, p.file)) {
                return;
            }
        }
        problems.add(p);
        fire();
    }

    public void addAll(List<Problem> list) {
        boolean changed = false;
        for (Problem p : list) {
            if (p == null) {
                continue;
            }
            boolean dup = false;
            for (Problem existing : problems) {
                if (existing.line == p.line && existing.severity == p.severity
                        && existing.message.equals(p.message)
                        && java.util.Objects.equals(existing.file, p.file)) {
                    dup = true;
                    break;
                }
            }
            if (!dup) {
                problems.add(p);
                changed = true;
            }
        }
        if (changed) {
            fire();
        }
    }

    /** Replaces every problem coming from the given file. */
    public void replaceFor(File file, List<Problem> list) {
        problems.removeIf(p -> java.util.Objects.equals(p.file, file));
        problems.addAll(list);
        fire();
    }

    public List<Problem> all() {
        return new ArrayList<>(problems);
    }

    public int count(Severity severity) {
        int n = 0;
        for (Problem p : problems) {
            if (p.severity == severity) {
                n++;
            }
        }
        return n;
    }

    public int errorCount() {
        return count(Severity.ERROR);
    }

    public int warningCount() {
        return count(Severity.WARNING);
    }

    public boolean isEmpty() {
        return problems.isEmpty();
    }

    /* ------------------------------------------------------------------ */
    /* parsing                                                             */
    /* ------------------------------------------------------------------ */

    private static final Pattern JAVAC = Pattern.compile(
            "^(.*?\\.java):(\\d+):(?:(\\d+):)?\\s*(error|warning|note):\\s*(.*)$");
    private static final Pattern GCC = Pattern.compile(
            "^(.*?\\.(?:c|cc|cpp|cxx|h|hpp)):(\\d+):(\\d+):\\s*(fatal error|error|warning|note|info):\\s*(.*)$");
    private static final Pattern GO = Pattern.compile(
            "^(.*?\\.go):(\\d+):(\\d+):\\s*(.*)$");
    private static final Pattern GENERIC = Pattern.compile(
            "^(.*?\\.\\w{1,8}):(\\d+)(?::(\\d+))?:\\s*(error|warning|Error|Warning)?:?\\s*(.*)$");
    private static final Pattern PY_FILE = Pattern.compile(
            "^\\s*File \"(.*?)\", line (\\d+)(?:, in (.*))?\\s*$");
    private static final Pattern PY_NAMED = Pattern.compile(
            "^\\s*(\\w*Error|\\w*Warning|\\w*Exception|SyntaxError):\\s*(.*)$");
    private static final Pattern NODE_STACK = Pattern.compile(
            "^\\s*at .*\\((.*?\\.(?:js|mjs|cjs|ts|jsx|tsx)):(\\d+):(\\d+)\\)\\s*$");

    /** Parses one line of process output. */
    public static class Parser {
        private File pendingPyFile;
        private int pendingPyLine;
        private boolean pendingPy;

        public Problem parse(String line, File workingDirectory) {
            if (line == null || line.isBlank()) {
                return null;
            }
            Matcher m;

            if ((m = JAVAC.matcher(line)).matches()) {
                return make(workingDirectory, m.group(1), m.group(2), m.group(3), m.group(5), m.group(4), "javac");
            }
            if ((m = GCC.matcher(line)).matches()) {
                return make(workingDirectory, m.group(1), m.group(2), m.group(3), m.group(5), m.group(4),
                        "compiler");
            }
            if ((m = GO.matcher(line)).matches()) {
                return make(workingDirectory, m.group(1), m.group(2), m.group(3), m.group(4), "error", "go");
            }
            if ((m = NODE_STACK.matcher(line)).matches()) {
                return make(workingDirectory, m.group(1), m.group(2), m.group(3), line.trim(), "error", "node");
            }
            if ((m = PY_FILE.matcher(line)).matches()) {
                pendingPyFile = resolve(workingDirectory, m.group(1));
                pendingPyLine = safeInt(m.group(2));
                pendingPy = true;
                return null;
            }
            if (pendingPy) {
                String trimmed = line.trim();
                if (trimmed.isEmpty()) {
                    return null;
                }
                if ((m = PY_NAMED.matcher(trimmed)).matches()) {
                    String name = m.group(1);
                    Severity sev = name.toLowerCase(java.util.Locale.ROOT).contains("warning")
                            ? Severity.WARNING : Severity.ERROR;
                    Problem p = new Problem(pendingPyFile, pendingPyLine, 0,
                            name + ": " + m.group(2), sev, "python");
                    pendingPy = false;
                    return p;
                }
                if (!line.startsWith(" ") && !line.startsWith("\t")) {
                    Problem p = new Problem(pendingPyFile, pendingPyLine, 0, trimmed, Severity.ERROR, "python");
                    pendingPy = false;
                    return p;
                }
                return null;
            }
            if ((m = GENERIC.matcher(line)).matches()) {
                String path = m.group(1);
                if (path.startsWith(" ") || path.startsWith("\t") || path.contains("://")) {
                    return null;
                }
                String kind = m.group(4);
                Severity sev = kind != null && kind.toLowerCase(java.util.Locale.ROOT).contains("warn")
                        ? Severity.WARNING : Severity.ERROR;
                String message = m.group(5);
                if (message == null || message.isBlank()) {
                    return null;
                }
                return make(workingDirectory, path, m.group(2), m.group(3), message, kind, "output");
            }
            return null;
        }

        public void reset() {
            pendingPy = false;
            pendingPyFile = null;
            pendingPyLine = 0;
        }
    }

    private static Problem make(File cwd, String path, String line, String col, String message,
                               String kind, String source) {
        Severity sev;
        String lower = message == null ? "" : message.toLowerCase(java.util.Locale.ROOT);
        if (kind != null && kind.toLowerCase(java.util.Locale.ROOT).contains("warn")) {
            sev = Severity.WARNING;
        } else if (kind != null && (kind.equalsIgnoreCase("note") || kind.equalsIgnoreCase("info"))) {
            sev = Severity.INFO;
        } else if (lower.startsWith("warning")) {
            sev = Severity.WARNING;
        } else {
            sev = Severity.ERROR;
        }
        return new Problem(resolve(cwd, path), safeInt(line), safeInt(col), message, sev, source);
    }

    private static int safeInt(String s) {
        if (s == null) {
            return 0;
        }
        try {
            return Math.max(0, Integer.parseInt(s.trim()) - 1);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static File resolve(File cwd, String path) {
        if (path == null || path.isBlank()) {
            return null;
        }
        File f = new File(path);
        if (f.isAbsolute()) {
            return f;
        }
        return cwd == null ? f : new File(cwd, path);
    }
}
