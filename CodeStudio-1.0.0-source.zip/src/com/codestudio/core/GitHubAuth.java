package com.codestudio.core;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;

/**
 * GitHub sign-in through the OAuth <b>device flow</b> (RFC 8628).
 *
 * <p>The device flow is the right fit here because it needs no client secret and no redirect URI,
 * so nothing has to be embedded in or listened for by a desktop app. The user is shown a short code,
 * enters it on github.com, and this class polls until GitHub hands back a token:
 *
 * <ol>
 *   <li>{@link #requestCode} — POST to {@code /login/device/code}, yielding a user code and an
 *       interval to poll at.</li>
 *   <li>{@link #awaitToken} — polls {@code /login/oauth/access_token} at that interval until the
 *       user authorizes, the code expires, or the caller cancels.</li>
 *   <li>{@link #fetchUser} — GET {@code /api/user} for the login, name and avatar.</li>
 * </ol>
 *
 * <h2>Setup, and why this is off by default</h2>
 *
 * <p>A GitHub OAuth App is required for its {@code client_id}. Register one at
 * <a href="https://github.com/settings/developers">github.com/settings/developers</a> — the device
 * flow needs no secret, so only the id is used — then paste it into the
 * {@code account.githubClientId} setting. Until that is filled in, {@link #isConfigured} is false
 * and the UI disables GitHub sign-in rather than failing at the first request.
 *
 * <p>These methods block, and the class holds no Swing types: callers run it on a background thread
 * and marshal the result to the event dispatch thread themselves. That keeps {@code core}
 * headlessly testable.
 */
public final class GitHubAuth {

    public static final String DEVICE_CODE_URL = "https://github.com/login/device/code";
    public static final String TOKEN_URL = "https://github.com/login/oauth/access_token";
    public static final String USER_URL = "https://api.github.com/user";

    /** GitHub's documented floor for the polling interval. */
    private static final int MIN_INTERVAL_SECONDS = 5;
    /** Added to the interval when GitHub answers {@code slow_down}, per the spec. */
    private static final int SLOW_DOWN_STEP_SECONDS = 5;

    private GitHubAuth() {
    }

    /* ------------------------------------------------------------------ */
    /* value types                                                         */
    /* ------------------------------------------------------------------ */

    /**
     * A pending sign-in.
     *
     * @param verificationUriComplete the verification page with the code pre-filled, when GitHub
     *                                supplies one; otherwise null
     */
    public record DeviceCode(String deviceCode, String userCode, String verificationUri,
                             String verificationUriComplete, int intervalSeconds,
                             int expiresInSeconds) {

        /** The URL to open in a browser: the pre-filled one when available. */
        public String browserUrl() {
            return verificationUriComplete != null && !verificationUriComplete.isBlank()
                    ? verificationUriComplete
                    : verificationUri;
        }
    }

    /** The signed-in user's profile. */
    public record User(String login, String name, String avatarUrl) {

        /** What to show in the UI: the display name when set, otherwise the login. */
        public String display() {
            return name == null || name.isBlank() ? login : name;
        }
    }

    /** Anything that ended the flow without a token, with a message fit to show the user. */
    public static final class AuthException extends Exception {
        private static final long serialVersionUID = 1L;

        public AuthException(String message) {
            super(message);
        }

        public AuthException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /** Progress callbacks, all delivered on the thread that called {@link #awaitToken}. */
    public interface Progress {
        /** A human-readable status line. */
        void status(String message);

        /** How long is left before the code expires. */
        void waiting(int secondsRemaining);
    }

    /* ------------------------------------------------------------------ */
    /* configuration                                                       */
    /* ------------------------------------------------------------------ */

    /** Whether a client id has been supplied; sign-in cannot start without one. */
    public static boolean isConfigured(String clientId) {
        return clientId != null && !clientId.isBlank();
    }

    /* ------------------------------------------------------------------ */
    /* step 1: ask for a code                                              */
    /* ------------------------------------------------------------------ */

    /** Requests a device code. Blocks on one HTTP round trip. */
    public static DeviceCode requestCode(String clientId, String scope) throws AuthException {
        if (!isConfigured(clientId)) {
            throw new AuthException("No GitHub client id is configured.");
        }
        String body = deviceCodeBody(clientId, scope);
        Map<String, Object> response = post(DEVICE_CODE_URL, body);
        String deviceCode = Json.string(response, "device_code", null);
        String userCode = Json.string(response, "user_code", null);
        String uri = Json.string(response, "verification_uri", null);
        if (deviceCode == null || userCode == null || uri == null) {
            throw new AuthException("GitHub did not return a device code: " + describe(response));
        }
        return new DeviceCode(
                deviceCode,
                userCode,
                uri,
                Json.string(response, "verification_uri_complete", null),
                Math.max(MIN_INTERVAL_SECONDS, Json.integer(response, "interval", MIN_INTERVAL_SECONDS)),
                Json.integer(response, "expires_in", 900));
    }

    /* ------------------------------------------------------------------ */
    /* step 2: wait for authorization                                      */
    /* ------------------------------------------------------------------ */

    /**
     * Polls until the user authorizes, the code expires, or {@code cancelled} returns true.
     *
     * @return the access token
     * @throws AuthException on expiry, denial, cancellation, or a transport failure
     */
    public static String awaitToken(String clientId, DeviceCode code, Progress progress,
                                    BooleanSupplier cancelled) throws AuthException {
        int interval = Math.max(MIN_INTERVAL_SECONDS, code.intervalSeconds());
        long deadline = System.currentTimeMillis() + code.expiresInSeconds() * 1000L;
        String body = tokenBody(clientId, code.deviceCode());

        while (true) {
            if (cancelled != null && cancelled.getAsBoolean()) {
                throw new AuthException("Sign-in was cancelled.");
            }
            long remaining = deadline - System.currentTimeMillis();
            if (remaining <= 0) {
                throw new AuthException("The code expired before it was authorized.");
            }
            if (progress != null) {
                progress.waiting((int) (remaining / 1000));
            }

            // Sleep in slices so cancelling is felt immediately rather than after a full interval.
            if (!sleep(interval * 1000L, cancelled)) {
                throw new AuthException("Sign-in was cancelled.");
            }

            Map<String, Object> response = post(TOKEN_URL, body);
            String token = Json.string(response, "access_token", null);
            if (token != null && !token.isBlank()) {
                return token;
            }
            String error = Json.string(response, "error", "");
            switch (error) {
                case "authorization_pending" -> {
                    // Still waiting on the user; keep polling.
                }
                case "slow_down" -> {
                    interval += SLOW_DOWN_STEP_SECONDS;
                    if (progress != null) {
                        progress.status("github.slowdown");
                    }
                }
                case "expired_token" -> throw new AuthException("The code expired before it was authorized.");
                case "access_denied" -> throw new AuthException("Access was denied on GitHub.");
                case "incorrect_device_code" -> throw new AuthException("GitHub rejected the device code.");
                case "unsupported_grant_type" -> throw new AuthException(
                        "GitHub rejected the request: the device flow is not enabled for this client id.");
                case "incorrect_client_credentials" -> throw new AuthException(
                        "GitHub rejected the client id. Check the account.githubClientId setting.");
                default -> throw new AuthException("GitHub returned: " + describe(response));
            }
        }
    }

    /** Sleeps for the whole duration, or returns false as soon as cancellation is signalled. */
    private static boolean sleep(long millis, BooleanSupplier cancelled) throws AuthException {
        long end = System.currentTimeMillis() + millis;
        while (System.currentTimeMillis() < end) {
            if (cancelled != null && cancelled.getAsBoolean()) {
                return false;
            }
            try {
                Thread.sleep(Math.min(200, Math.max(1, end - System.currentTimeMillis())));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* step 3: who just signed in                                          */
    /* ------------------------------------------------------------------ */

    /** Fetches the profile for a token. Blocks on one HTTP round trip. */
    public static User fetchUser(String token) throws AuthException {
        HttpResponse<String> response = send(HttpRequest.newBuilder(URI.create(USER_URL))
                .timeout(Duration.ofSeconds(30))
                .header("Accept", "application/vnd.github+json")
                .header("Authorization", "Bearer " + token)
                .header("User-Agent", USER_AGENT)
                .GET()
                .build());
        if (response.statusCode() != 200) {
            throw new AuthException("GitHub rejected the token (HTTP " + response.statusCode() + ").");
        }
        Map<String, Object> body = Json.parseObject(response.body());
        String login = Json.string(body, "login", null);
        if (login == null) {
            throw new AuthException("GitHub did not return a login name.");
        }
        return new User(login, Json.string(body, "name", null), Json.string(body, "avatar_url", null));
    }

    /* ------------------------------------------------------------------ */
    /* wire format                                                         */
    /* ------------------------------------------------------------------ */

    private static final String USER_AGENT = "CodeStudio";

    /**
     * The body of the device-code request. Exposed so the self test can check the wire format
     * without making a network call.
     */
    public static String deviceCodeBody(String clientId, String scope) {
        String body = "client_id=" + encode(clientId);
        if (scope != null && !scope.isBlank()) {
            body += "&scope=" + encode(scope);
        }
        return body;
    }

    /** The body of each token poll. */
    public static String tokenBody(String clientId, String deviceCode) {
        return "client_id=" + encode(clientId)
                + "&device_code=" + encode(deviceCode)
                + "&grant_type=" + encode("urn:ietf:params:oauth:grant-type:device_code");
    }

    /** The headers sent with the profile request. */
    public static Map<String, String> userHeaders(String token) {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("Accept", "application/vnd.github+json");
        headers.put("Authorization", "Bearer " + token);
        headers.put("User-Agent", USER_AGENT);
        return headers;
    }

    /** The headers sent with both POSTs. */
    public static Map<String, String> postHeaders() {
        Map<String, String> headers = new LinkedHashMap<>();
        // Without this GitHub answers form-encoded, which is not what the parser expects.
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/x-www-form-urlencoded");
        headers.put("User-Agent", USER_AGENT);
        return headers;
    }

    private static String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8);
    }

    private static Map<String, Object> post(String url, String body) throws AuthException {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8));
        for (Map.Entry<String, String> e : postHeaders().entrySet()) {
            builder.header(e.getKey(), e.getValue());
        }
        HttpResponse<String> response = send(builder.build());
        if (response.statusCode() / 100 != 2) {
            throw new AuthException("GitHub returned HTTP " + response.statusCode() + ".");
        }
        Map<String, Object> parsed = Json.parseObject(response.body());
        if (parsed == null) {
            throw new AuthException("GitHub returned a response that is not JSON.");
        }
        return parsed;
    }

    private static HttpResponse<String> send(HttpRequest request) throws AuthException {
        try {
            return HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(20))
                    .followRedirects(HttpClient.Redirect.NORMAL)
                    .build()
                    .send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new AuthException("Could not reach GitHub: " + e.getMessage(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new AuthException("The request was interrupted.");
        }
    }

    /** A short, safe rendering of a response for an error message. */
    private static String describe(Map<String, Object> response) {
        String error = Json.string(response, "error", null);
        if (error != null) {
            String description = Json.string(response, "error_description", "");
            return description.isBlank() ? error : error + " (" + description + ")";
        }
        return response.isEmpty() ? "an empty response" : response.keySet().toString();
    }
}
