package com.codestudio.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** Thin wrapper around the {@code git} command line client. */
public final class Git {

    /** One entry of {@code git status}. */
    public static class Entry {
        public final File file;
        public final char index;
        public final char work;
        public final boolean untracked;
        public final boolean ignored;

        Entry(File file, char index, char work, boolean untracked, boolean ignored) {
            this.file = file;
            this.index = index;
            this.work = work;
            this.untracked = untracked;
            this.ignored = ignored;
        }

        /** True when the change is already in the index. */
        public boolean isStaged() {
            return !untracked && index != ' ' && index != '?';
        }

        /** True when there are work tree changes that are not staged yet. */
        public boolean hasWorkTreeChange() {
            return untracked || (work != ' ' && work != '?');
        }

        /** The letter shown next to the file in the source control view. */
        public char letter() {
            if (untracked) {
                return 'U';
            }
            char c = work != ' ' && work != '?' ? work : index;
            return c == ' ' ? '?' : c;
        }

        public String kind() {
            return switch (letter()) {
                case 'M' -> Strings.get("Modified");
                case 'A' -> Strings.get("Added");
                case 'D' -> Strings.get("Deleted");
                case 'R' -> Strings.get("Renamed");
                case 'C' -> Strings.get("Copied");
                case 'U' -> Strings.get("Untracked");
                case 'T' -> Strings.get("Type changed");
                default -> Strings.get("Changed");
            };
        }
    }

    /** Snapshot of the repository state. */
    public static class Status {
        public File root;
        public String branch = "";
        public String upstream = "";
        public int ahead;
        public int behind;
        public final List<Entry> entries = new ArrayList<>();
        public String error;

        public boolean isRepo() {
            return root != null;
        }

        public List<Entry> staged() {
            List<Entry> out = new ArrayList<>();
            for (Entry e : entries) {
                if (e.isStaged()) {
                    out.add(e);
                }
            }
            return out;
        }

        public List<Entry> unstaged() {
            List<Entry> out = new ArrayList<>();
            for (Entry e : entries) {
                if (e.hasWorkTreeChange()) {
                    out.add(e);
                }
            }
            return out;
        }
    }

    private Git() {
    }

    /** Walks up from {@code start} looking for a {@code .git} directory. */
    public static File findRoot(File start) {
        File dir = start;
        if (dir == null) {
            return null;
        }
        if (!dir.isDirectory()) {
            dir = dir.getParentFile();
        }
        while (dir != null) {
            if (new File(dir, ".git").exists()) {
                return dir;
            }
            dir = dir.getParentFile();
        }
        return null;
    }

    private static List<String> command(String... args) {
        List<String> cmd = new ArrayList<>();
        cmd.add("git");
        cmd.add("-c");
        cmd.add("core.quotepath=false");
        cmd.add("-c");
        cmd.add("color.ui=false");
        for (String a : args) {
            cmd.add(a);
        }
        return cmd;
    }

    /** Runs git and returns the raw exit code; stdout/stderr are appended to the buffers. */
    public static int exec(File cwd, StringBuilder out, StringBuilder err, String... args) {
        ProcessBuilder pb = new ProcessBuilder(command(args));
        if (cwd != null) {
            pb.directory(cwd);
        }
        pb.redirectErrorStream(false);
        try {
            Process p = pb.start();
            StringBuilder stdout = new StringBuilder();
            StringBuilder stderr = new StringBuilder();
            Thread t1 = drain(p.getInputStream(), stdout);
            Thread t2 = drain(p.getErrorStream(), stderr);
            boolean done = p.waitFor(30, TimeUnit.SECONDS);
            if (!done) {
                p.destroyForcibly();
            }
            t1.join(2000);
            t2.join(2000);
            if (out != null) {
                out.append(stdout);
            }
            if (err != null) {
                err.append(stderr);
            }
            return done ? p.exitValue() : -1;
        } catch (IOException e) {
            if (err != null) {
                err.append(e.getMessage() == null ? Strings.get("git is not available") : e.getMessage());
            }
            return -1;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return -1;
        }
    }

    private static Thread drain(InputStream in, StringBuilder sink) {
        Thread t = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                char[] buf = new char[4096];
                int n;
                while ((n = r.read(buf)) > 0) {
                    sink.append(buf, 0, n);
                }
            } catch (IOException ignored) {
                // stream closed when the process was killed
            }
        }, "git-drain");
        t.setDaemon(true);
        t.start();
        return t;
    }

    /** True when a usable git executable exists. */
    public static boolean available() {
        StringBuilder out = new StringBuilder();
        StringBuilder err = new StringBuilder();
        return exec(null, out, err, "--version") == 0;
    }

    public static Status status(File dir) {
        Status s = new Status();
        File root = findRoot(dir);
        if (root == null) {
            s.error = Strings.get("Not a git repository");
            return s;
        }
        s.root = root;

        StringBuilder out = new StringBuilder();
        StringBuilder err = new StringBuilder();
        int code = exec(root, out, err, "status", "--porcelain=v1", "-z", "--branch");
        if (code != 0) {
            s.error = err.length() == 0 ? Strings.get("git status failed") : err.toString().trim();
            return s;
        }
        parseStatus(root, out.toString(), s);
        return s;
    }

    private static void parseStatus(File root, String raw, Status s) {
        String[] parts = raw.split("\0", -1);
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i];
            if (p.isEmpty()) {
                continue;
            }
            if (p.startsWith("## ")) {
                parseBranch(p.substring(3), s);
                continue;
            }
            if (p.length() < 4) {
                continue;
            }
            char idx = p.charAt(0);
            char wt = p.charAt(1);
            String path = p.substring(3);
            if (idx == 'R' || idx == 'C') {
                // rename/copy records carry the source path as the next NUL separated field
                if (i + 1 < parts.length) {
                    i++;
                }
            }
            if (idx == '!' || wt == '!') {
                continue;
            }
            File f = new File(root, path);
            s.entries.add(new Entry(f, idx, wt, idx == '?', false));
        }
    }

    private static void parseBranch(String line, Status s) {
        String text = line.trim();
        int dots = text.indexOf("...");
        if (dots > 0) {
            s.branch = text.substring(0, dots).trim();
            String rest = text.substring(dots + 3);
            int bracket = rest.indexOf('[');
            if (bracket >= 0) {
                s.upstream = rest.substring(0, bracket).trim();
                String info = rest.substring(bracket + 1).replace("]", "");
                for (String token : info.split(",")) {
                    token = token.trim();
                    if (token.startsWith("ahead ")) {
                        s.ahead = parseInt(token.substring(6));
                    } else if (token.startsWith("behind ")) {
                        s.behind = parseInt(token.substring(7));
                    }
                }
            } else {
                s.upstream = rest.trim();
            }
        } else {
            s.branch = text.replace("No commits yet on ", "").trim();
        }
        if (s.branch.isEmpty()) {
            s.branch = "HEAD";
        }
    }

    private static int parseInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** Convenience for fire-and-forget commands; returns stderr (empty when it worked). */
    public static String run(File root, String... args) {
        StringBuilder out = new StringBuilder();
        StringBuilder err = new StringBuilder();
        int code = exec(root, out, err, args);
        if (code == 0) {
            return "";
        }
        String message = err.toString().trim();
        if (message.isEmpty()) {
            message = out.toString().trim();
        }
        return message.isEmpty() ? Strings.format("git {0} failed", args[0]) : message;
    }

    public static String diff(File root, File file, boolean staged) {
        StringBuilder out = new StringBuilder();
        StringBuilder err = new StringBuilder();
        String rel = relativize(root, file);
        if (staged) {
            exec(root, out, err, "diff", "--cached", "--", rel);
        } else {
            exec(root, out, err, "diff", "--", rel);
        }
        String text = out.toString();
        if (text.isEmpty() && !staged) {
            // untracked files have no diff; show the whole file instead
            try {
                if (file.isFile() && file.length() < 512 * 1024) {
                    text = new String(java.nio.file.Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
                }
            } catch (IOException ignored) {
                // fall through with the empty diff
            }
        }
        return text;
    }

    public static List<String> branches(File root) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        StringBuilder err = new StringBuilder();
        if (exec(root, sb, err, "branch", "--format=%(refname:short)") == 0) {
            for (String line : sb.toString().split("\n")) {
                String b = line.trim();
                if (!b.isEmpty()) {
                    out.add(b);
                }
            }
        }
        return out;
    }

    /** Path of {@code file} relative to the repository root, using forward slashes. */
    public static String relativize(File root, File file) {
        if (root == null || file == null) {
            return "";
        }
        try {
            String rootPath = root.getCanonicalPath();
            String filePath = file.getCanonicalPath();
            if (filePath.startsWith(rootPath)) {
                String rel = filePath.substring(rootPath.length());
                while (rel.startsWith("\\") || rel.startsWith("/")) {
                    rel = rel.substring(1);
                }
                return rel.replace('\\', '/');
            }
        } catch (IOException ignored) {
            // fall back to the absolute path
        }
        return file.getAbsolutePath().replace('\\', '/');
    }
}
