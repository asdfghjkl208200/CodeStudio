package com.codestudio.core;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * A user account, and the store that holds them.
 *
 * <p>Two kinds exist. A {@code local} account is created and checked entirely on this machine and
 * never touches the network. A {@code github} account is signed in through GitHub's OAuth device
 * flow (see {@link GitHubAuth}) and carries an access token.
 *
 * <p>Accounts are persisted to {@code ~/.codestudio/accounts.properties}.
 *
 * <h2>What is and is not protected</h2>
 *
 * <p>A local account's password is never stored. It is run through PBKDF2-HMAC-SHA256 with a
 * random 16-byte salt and 120,000 iterations, and only the derived key is written. That makes an
 * offline guessing attack against the file expensive; it does not make the file secret.
 *
 * <p><b>A GitHub access token is stored in the clear.</b> Reading the Windows credential store
 * (DPAPI) or a platform keychain needs native bindings, and this project has no dependencies
 * outside the JDK, so there is nowhere safe to put it. Anyone who can read the file can read the
 * token. The sign-in UI states this plainly and offers to keep the token in memory for the current
 * session only ({@link #setToken(String, boolean)} with {@code save=false}).
 *
 * <p>This class holds no Swing types and can be exercised headlessly, like the rest of {@code core}.
 */
public final class Account {

    /** Created and verified on this machine only. */
    public static final String LOCAL = "local";
    /** Signed in through GitHub, carrying an access token. */
    public static final String GITHUB = "github";

    private static final Path DEFAULT_FILE = Settings.DIR.resolve("accounts.properties");

    private static final int ITERATIONS = 120_000;
    private static final int KEY_BITS = 256;
    private static final int SALT_BYTES = 16;

    private static final Map<String, Account> ACCOUNTS = new LinkedHashMap<>();
    private static String currentId;
    private static boolean loaded;

    public final String id;
    public final String kind;
    /** What the user is called; for GitHub this is the profile name when there is one. */
    public String displayName;
    /** The sign-in name: the chosen local username, or the GitHub login. */
    public final String login;
    public String avatarUrl;
    public final long createdAt;

    /** Local accounts only: the salt and derived key, both Base64. */
    private String salt;
    private String passwordHash;

    /** GitHub only: the access token currently in memory, and whether a copy is on disk. */
    private String token;
    private boolean tokenSaved;

    private Account(String id, String kind, String login, String displayName, String avatarUrl,
                    long createdAt) {
        this.id = id;
        this.kind = kind;
        this.login = login;
        this.displayName = displayName == null || displayName.isBlank() ? login : displayName;
        this.avatarUrl = avatarUrl;
        this.createdAt = createdAt;
    }

    /* ------------------------------------------------------------------ */
    /* queries                                                             */
    /* ------------------------------------------------------------------ */

    public boolean isLocal() {
        return LOCAL.equals(kind);
    }

    public boolean isGitHub() {
        return GITHUB.equals(kind);
    }

    /** The GitHub access token, or null when there is none. */
    public String token() {
        return token;
    }

    /** Whether the token is also written to disk, as opposed to being kept for this session only. */
    public boolean tokenSaved() {
        return tokenSaved;
    }

    public boolean hasToken() {
        return token != null && !token.isBlank();
    }

    /** A stable public id used for per-account session storage, e.g. {@code github:octocat}. */
    public String sessionKey() {
        return id;
    }

    /* ------------------------------------------------------------------ */
    /* local password                                                      */
    /* ------------------------------------------------------------------ */

    private static byte[] derive(String password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            // PBKDF2WithHmacSHA256 is required of every Java platform, so this cannot happen on a
            // conforming runtime. Fold it into an unchecked failure rather than pretending the
            // password was checked.
            throw new IllegalStateException("PBKDF2-HMAC-SHA256 unavailable", e);
        } finally {
            spec.clearPassword();
        }
    }

    /**
     * Checks a password against this account. Always false for a GitHub account, which has no local
     * password to check.
     */
    public boolean verify(String password) {
        if (!isLocal() || password == null || salt == null || passwordHash == null) {
            return false;
        }
        byte[] expected = Base64.getDecoder().decode(passwordHash);
        byte[] actual = derive(password, Base64.getDecoder().decode(salt));
        // Constant-time compare: a timing difference here would leak how much of the hash matched.
        return MessageDigest.isEqual(expected, actual);
    }

    private void setPassword(String password) {
        byte[] saltBytes = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(saltBytes);
        this.salt = Base64.getEncoder().encodeToString(saltBytes);
        this.passwordHash = Base64.getEncoder().encodeToString(derive(password, saltBytes));
    }

    /* ------------------------------------------------------------------ */
    /* mutation                                                            */
    /* ------------------------------------------------------------------ */

    /**
     * Creates a local account. The name must be unused, and the password must not be blank.
     * Returns null when the name is taken or the input is unusable.
     */
    public static Account createLocal(String name, String password) {
        load();
        String login = name == null ? "" : name.trim();
        if (login.isEmpty() || password == null || password.isEmpty()) {
            return null;
        }
        String id = LOCAL + ":" + login.toLowerCase(Locale.ROOT);
        if (ACCOUNTS.containsKey(id)) {
            return null;
        }
        Account a = new Account(id, LOCAL, login, login, null, System.currentTimeMillis());
        a.setPassword(password);
        ACCOUNTS.put(id, a);
        save();
        return a;
    }

    /**
     * Creates or updates the account for a GitHub sign-in, keyed on the GitHub login so signing in
     * again updates rather than duplicates.
     */
    public static Account upsertGitHub(String login, String displayName, String avatarUrl) {
        load();
        if (login == null || login.isBlank()) {
            return null;
        }
        String id = GITHUB + ":" + login.toLowerCase(Locale.ROOT);
        Account a = ACCOUNTS.get(id);
        if (a == null) {
            a = new Account(id, GITHUB, login, displayName, avatarUrl, System.currentTimeMillis());
            ACCOUNTS.put(id, a);
        } else {
            a.displayName = displayName == null || displayName.isBlank() ? login : displayName;
            a.avatarUrl = avatarUrl;
        }
        return a;
    }

    /**
     * Stores the access token for a GitHub account.
     *
     * @param saveToDisk when false the token lives only in memory until the app exits, which is the
     *                   option offered to users who would rather not leave it in a plain file
     */
    public void setToken(String value, boolean saveToDisk) {
        this.token = value == null || value.isBlank() ? null : value;
        this.tokenSaved = saveToDisk && token != null;
        save();
    }

    public void clearToken() {
        this.token = null;
        this.tokenSaved = false;
        save();
    }

    /** Removes an account and its stored secrets. */
    public static boolean remove(String id) {
        load();
        if (ACCOUNTS.remove(id) == null) {
            return false;
        }
        if (id.equals(currentId)) {
            currentId = null;
        }
        save();
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* the registry                                                        */
    /* ------------------------------------------------------------------ */

    public static List<Account> all() {
        load();
        return Collections.unmodifiableList(new ArrayList<>(ACCOUNTS.values()));
    }

    public static Account byId(String id) {
        load();
        return id == null ? null : ACCOUNTS.get(id);
    }

    /** The signed-in account, or null when nobody is signed in. */
    public static Account current() {
        load();
        return currentId == null ? null : ACCOUNTS.get(currentId);
    }

    /** Signs in. Pass null to sign out without removing the account. */
    public static void setCurrent(String id) {
        load();
        currentId = id == null || !ACCOUNTS.containsKey(id) ? null : id;
        save();
    }

    public static boolean isEmpty() {
        return all().isEmpty();
    }

    /* ------------------------------------------------------------------ */
    /* persistence                                                         */
    /* ------------------------------------------------------------------ */

    /** Re-reads the file, discarding anything held in memory. */
    public static synchronized void reload() {
        loaded = false;
        ACCOUNTS.clear();
        currentId = null;
        load();
    }

    private static synchronized void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        if (!Files.isRegularFile(file())) {
            return;
        }
        Properties props = new Properties();
        // Reader/Writer rather than the InputStream overloads: those decode as ISO-8859-1, which
        // would mangle a non-ASCII display name.
        try (Reader in = new InputStreamReader(Files.newInputStream(file()), StandardCharsets.UTF_8)) {
            props.load(in);
        } catch (IOException e) {
            return; // A corrupt or unreadable file leaves the registry empty rather than failing.
        }
        currentId = props.getProperty("current");
        for (String id : props.getProperty("ids", "").split("\n")) {
            String key = id.trim();
            if (key.isEmpty()) {
                continue;
            }
            String prefix = "account." + key + ".";
            String kind = props.getProperty(prefix + "kind", LOCAL);
            String login = props.getProperty(prefix + "login", key);
            Account a = new Account(key, kind, login,
                    props.getProperty(prefix + "displayName", login),
                    props.getProperty(prefix + "avatarUrl", null),
                    parseLong(props.getProperty(prefix + "createdAt")));
            a.salt = props.getProperty(prefix + "salt");
            a.passwordHash = props.getProperty(prefix + "passwordHash");
            a.token = props.getProperty(prefix + "token");
            a.tokenSaved = a.token != null;
            ACCOUNTS.put(key, a);
        }
    }

    private static long parseLong(String text) {
        try {
            return Long.parseLong(text == null ? "" : text.trim());
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    /** Writes the registry back. Safe to call often; it is small. */
    public static synchronized void save() {
        Properties props = new Properties();
        StringBuilder ids = new StringBuilder();
        for (Account a : ACCOUNTS.values()) {
            if (ids.length() > 0) {
                ids.append('\n');
            }
            ids.append(a.id);
            String prefix = "account." + a.id + ".";
            props.setProperty(prefix + "kind", a.kind);
            props.setProperty(prefix + "login", a.login == null ? "" : a.login);
            props.setProperty(prefix + "displayName", a.displayName == null ? "" : a.displayName);
            props.setProperty(prefix + "createdAt", String.valueOf(a.createdAt));
            if (a.avatarUrl != null) {
                props.setProperty(prefix + "avatarUrl", a.avatarUrl);
            }
            if (a.salt != null) {
                props.setProperty(prefix + "salt", a.salt);
            }
            if (a.passwordHash != null) {
                props.setProperty(prefix + "passwordHash", a.passwordHash);
            }
            // Only written when the user asked for the token to be remembered. Otherwise it stays
            // in memory for this session and is gone on exit.
            if (a.token != null && a.tokenSaved) {
                props.setProperty(prefix + "token", a.token);
            }
        }
        props.setProperty("ids", ids.toString());
        if (currentId != null) {
            props.setProperty("current", currentId);
        }
        try {
            Files.createDirectories(Settings.DIR);
            try (Writer out = new OutputStreamWriter(Files.newOutputStream(file()), StandardCharsets.UTF_8)) {
                props.store(out, "CodeStudio accounts. GitHub tokens are stored in plain text.");
            }
        } catch (IOException e) {
            // Losing the file is not worth crashing the IDE over; the session keeps working.
        }
    }

    /**
     * The file the accounts live in, for the About box and the accounts panel.
     *
     * <p>Overridable through the {@code codestudio.accounts.file} system property so the self test
     * can exercise the round trip against a temporary file instead of the real one.
     */
    public static Path file() {
        String override = System.getProperty("codestudio.accounts.file");
        return override == null || override.isBlank() ? DEFAULT_FILE : Paths.get(override);
    }

    /** Test seam: forgets everything, including whether the file has been read. */
    static void resetForTest() {
        ACCOUNTS.clear();
        currentId = null;
        loaded = false;
    }
}
