package com.codestudio.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Foldable regions, derived from the buffer text.
 *
 * <p>Three sources are combined, in the order VS Code would find them: explicit
 * {@code #region} / {@code #endregion} markers, then the language's natural blocks -braces for
 * the C family, indentation for Python and YAML, headings for Markdown.
 *
 * <p>A region never hides its first line. Folding a block keeps the header visible and hides the
 * lines up to (and including) {@link Region#endLine}; the closing bracket stays visible, which is
 * what makes a folded buffer still readable.
 *
 * <p>This is the model half only -it knows nothing about Swing and is exercised headlessly by the
 * self test.
 */
public final class Folding {

    /** One foldable block. */
    public static final class Region {
        /** 0-based line that stays visible (the line with the opening bracket / header). */
        public final int startLine;
        /** 0-based last hidden line. Always greater than {@link #startLine}. */
        public final int endLine;

        public Region(int startLine, int endLine) {
            this.startLine = startLine;
            this.endLine = endLine;
        }

        public int hiddenCount() {
            return Math.max(0, endLine - startLine);
        }

        @Override
        public String toString() {
            return "fold[" + startLine + ".." + endLine + "]";
        }
    }

    /** Guard against pathological input: a minified file can match thousands of times. */
    private static final int MAX_REGIONS = 20000;
    private static final int MAX_STACK = 20000;

    private Folding() {
    }

    /* ------------------------------------------------------------------ */

    /** Every foldable region in the text, sorted by start line. */
    public static List<Region> compute(String text, Language lang) {
        List<Region> out = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return out;
        }
        String[] lines = lines(text);
        markerRegions(lines, out);
        Language.Lexer lexer = lang == null ? Language.Lexer.PLAIN : lang.lexer;
        switch (lexer) {
            case MARKDOWN -> headingRegions(lines, out);
            case PYTHON, YAML -> indentRegions(lines, out);
            default -> braceRegions(lines, lang, out);
        }
        out.sort(Comparator.comparingInt(r -> r.startLine));
        return dedupe(out);
    }

    /** Regions that can be toggled from a given line, i.e. the ones starting there. */
    public static List<Region> regionsAt(List<Region> regions, int line) {
        List<Region> out = new ArrayList<>();
        for (Region r : regions) {
            if (r.startLine == line) {
                out.add(r);
            }
        }
        return out;
    }

    /**
     * The line mask the editor renders from: a line is hidden when any folded region covers it.
     *
     * @param foldedStarts 0-based start lines of the regions the user has folded
     */
    public static boolean[] hiddenLines(String text, Language lang, Set<Integer> foldedStarts) {
        boolean[] hidden = new boolean[lineCount(text)];
        if (foldedStarts == null || foldedStarts.isEmpty()) {
            return hidden;
        }
        for (Region r : compute(text, lang)) {
            if (!foldedStarts.contains(r.startLine)) {
                continue;
            }
            for (int line = r.startLine + 1; line <= r.endLine && line < hidden.length; line++) {
                hidden[line] = true;
            }
        }
        return hidden;
    }

    /** Folds every region that hides at least one line, outermost first. */
    public static Set<Integer> allFoldableStarts(String text, Language lang) {
        Set<Integer> out = new LinkedHashSet<>();
        for (Region r : compute(text, lang)) {
            if (r.hiddenCount() > 0) {
                out.add(r.startLine);
            }
        }
        return out;
    }

    public static int lineCount(String text) {
        if (text == null || text.isEmpty()) {
            return 1;
        }
        int n = 1;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                n++;
            }
        }
        return n;
    }

    public static String[] lines(String text) {
        return text.split("\n", -1);
    }

    /* ------------------------------------------------------------------ */
    /* explicit #region markers                                            */
    /* ------------------------------------------------------------------ */

    private static void markerRegions(String[] lines, List<Region> out) {
        Deque<Integer> open = new ArrayDeque<>();
        for (int i = 0; i < lines.length; i++) {
            String kind = markerKind(lines[i]);
            if (kind == null) {
                continue;
            }
            if (kind.equals("begin")) {
                open.push(i);
            } else if (!open.isEmpty()) {
                int start = open.pop();
                if (i - start > 1) {
                    out.add(new Region(start, i - 1));
                }
            }
        }
    }

    /** "begin" for {@code #region}, "end" for {@code #endregion}, else null. */
    private static String markerKind(String line) {
        String t = line.strip();
        if (t.isEmpty()) {
            return null;
        }
        int at = 0;
        // optional comment leader, then the marker
        while (at < t.length() && (t.charAt(at) == '/' || t.charAt(at) == '#' || t.charAt(at) == '-'
                || t.charAt(at) == ';' || t.charAt(at) == '*')) {
            at++;
        }
        if (at >= t.length() || t.charAt(at) != '#') {
            // `// region` and `/* region */` are not universal, so only the # form is accepted
            // unless the line starts with a comment leader directly followed by "region".
            String rest = t.substring(at).stripLeading();
            if (rest.toLowerCase(Locale.ROOT).startsWith("region")) {
                return "begin";
            }
            if (rest.toLowerCase(Locale.ROOT).startsWith("endregion")) {
                return "end";
            }
            return null;
        }
        String rest = t.substring(at + 1).stripLeading().toLowerCase(Locale.ROOT);
        if (rest.startsWith("region")) {
            return "begin";
        }
        if (rest.startsWith("endregion")) {
            return "end";
        }
        return null;
    }

    /* ------------------------------------------------------------------ */
    /* braces                                                              */
    /* ------------------------------------------------------------------ */

    private static void braceRegions(String[] lines, Language lang, List<Region> out) {
        Deque<int[]> stack = new ArrayDeque<>();
        String[] lineComments = lang == null ? new String[]{"//"} : lang.lineComments;
        String[][] blockComments = lang == null ? new String[][]{{"/*", "*/"}} : lang.blockComments;
        String[] strings = lang == null ? new String[]{"\"", "'"} : lang.stringDelims;
        String blockEnd = null;

        for (int i = 0; i < lines.length && out.size() < MAX_REGIONS; i++) {
            String line = lines[i];
            int j = 0;
            while (j < line.length()) {
                if (blockEnd != null) {
                    int close = line.indexOf(blockEnd, j);
                    if (close < 0) {
                        break;
                    }
                    j = close + blockEnd.length();
                    blockEnd = null;
                    continue;
                }
                if (startsWithAny(line, j, lineComments)) {
                    break;
                }
                String opened = startsWithOne(line, j, blockComments);
                if (opened != null) {
                    blockEnd = opened;
                    j += 2;
                    continue;
                }
                char c = line.charAt(j);
                if (isQuote(strings, c)) {
                    j = skipString(line, j, c);
                    continue;
                }
                if (c == '{' || c == '[' || c == '(') {
                    if (stack.size() < MAX_STACK) {
                        stack.push(new int[]{i, c});
                    }
                } else if (c == '}' || c == ']' || c == ')') {
                    char want = c == '}' ? '{' : c == ']' ? '[' : '(';
                    while (!stack.isEmpty() && stack.peek()[1] != want) {
                        stack.pop();
                    }
                    if (!stack.isEmpty()) {
                        int start = stack.pop()[0];
                        if (i - start > 1) {
                            out.add(new Region(start, i - 1));
                        }
                    }
                }
                j++;
            }
        }
    }

    private static boolean isQuote(String[] delims, char c) {
        for (String d : delims) {
            if (d.length() == 1 && d.charAt(0) == c) {
                return true;
            }
        }
        return false;
    }

    /** Offset just past the closing quote, or the end of the line when it never closes. */
    private static int skipString(String line, int start, char quote) {
        int i = start + 1;
        while (i < line.length()) {
            char c = line.charAt(i);
            if (c == '\\') {
                i += 2;
                continue;
            }
            if (c == quote) {
                return i + 1;
            }
            i++;
        }
        return line.length();
    }

    private static boolean startsWithAny(String line, int at, String[] tokens) {
        if (tokens == null) {
            return false;
        }
        for (String t : tokens) {
            if (!t.isEmpty() && line.startsWith(t, at)) {
                return true;
            }
        }
        return false;
    }

    /** The closing token of the block comment that starts at {@code at}, or null. */
    private static String startsWithOne(String line, int at, String[][] blocks) {
        if (blocks == null) {
            return null;
        }
        for (String[] b : blocks) {
            if (b.length == 2 && line.startsWith(b[0], at)) {
                return b[1];
            }
        }
        return null;
    }

    /* ------------------------------------------------------------------ */
    /* indentation (Python, YAML)                                          */
    /* ------------------------------------------------------------------ */

    private static void indentRegions(String[] lines, List<Region> out) {
        for (int i = 0; i < lines.length && out.size() < MAX_REGIONS; i++) {
            String header = lines[i];
            if (header.isBlank()) {
                continue;
            }
            String trimmed = header.stripTrailing();
            if (!trimmed.endsWith(":")) {
                continue;
            }
            // a trailing comment after the colon still opens a block
            if (trimmed.endsWith(":") && trimmed.stripLeading().startsWith("#")) {
                continue;
            }
            int indent = indentOf(header);
            int end = i;
            for (int k = i + 1; k < lines.length; k++) {
                if (lines[k].isBlank()) {
                    continue;
                }
                if (indentOf(lines[k]) <= indent) {
                    break;
                }
                end = k;
            }
            // One hidden line is enough: a block such as `for x in y:` with a single body line
            // still folds, which is what a reader expects to be able to collapse.
            if (end > i) {
                out.add(new Region(i, end));
            }
        }
    }

    private static int indentOf(String line) {
        int i = 0;
        int width = 0;
        while (i < line.length() && (line.charAt(i) == ' ' || line.charAt(i) == '\t')) {
            width += line.charAt(i) == '\t' ? 4 : 1;
            i++;
        }
        return width;
    }

    /* ------------------------------------------------------------------ */
    /* markdown                                                            */
    /* ------------------------------------------------------------------ */

    private static void headingRegions(String[] lines, List<Region> out) {
        for (int i = 0; i < lines.length && out.size() < MAX_REGIONS; i++) {
            int level = headingLevel(lines[i]);
            if (level == 0) {
                continue;
            }
            int end = -1;
            for (int k = i + 1; k < lines.length; k++) {
                int next = headingLevel(lines[k]);
                if (next > 0 && next <= level) {
                    end = k - 1;
                    break;
                }
            }
            if (end < 0) {
                end = lastContentLine(lines);
            }
            if (end > i) {
                out.add(new Region(i, end));
            }
        }
    }

    private static int headingLevel(String line) {
        String t = line.stripLeading();
        int n = 0;
        while (n < t.length() && t.charAt(n) == '#') {
            n++;
        }
        if (n == 0 || n > 6 || n >= t.length() || t.charAt(n) != ' ') {
            return 0;
        }
        return n;
    }

    private static int lastContentLine(String[] lines) {
        for (int i = lines.length - 1; i >= 0; i--) {
            if (!lines[i].isBlank()) {
                return i;
            }
        }
        return 0;
    }

    private static List<Region> dedupe(List<Region> regions) {
        List<Region> out = new ArrayList<>(regions.size());
        Region previous = null;
        for (Region r : regions) {
            if (previous != null && previous.startLine == r.startLine && previous.endLine == r.endLine) {
                continue;
            }
            if (r.endLine > r.startLine) {
                out.add(r);
            }
            previous = r;
        }
        return out;
    }
}
