package com.codestudio.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Language definition: used both for the syntax highlighter and for the
 * status bar language picker.
 */
public class Language {

    /** Which lexer family to use when tokenising. */
    public enum Lexer { GENERIC, PYTHON, SHELL, MARKUP, MARKDOWN, CSS, YAML, PROPERTIES, PLAIN }

    public String id = "plaintext";
    public String name = "Plain Text";
    public Lexer lexer = Lexer.PLAIN;
    public final List<String> extensions = new ArrayList<>();
    public final List<String> filenames = new ArrayList<>();

    public String[] lineComments = {"//"};
    public String[][] blockComments = {{"/*", "*/"}};
    public String[] stringDelims = {"\"", "'"};

    public Set<String> keywords = new LinkedHashSet<>();
    public Set<String> control = new LinkedHashSet<>();
    public Set<String> types = new LinkedHashSet<>();
    public Set<String> constants = new LinkedHashSet<>();
    public Set<String> builtins = new LinkedHashSet<>();

    public boolean caseInsensitive = false;
    public boolean allowComments = true;
    public boolean dollarVars = false;
    public boolean atAnnotations = true;
    /** Explorer badge tint + short label. */
    public String color = "#888888";
    public String badge = "";

    protected Language(String id, String name, Lexer lexer) {
        this.id = id;
        this.name = name;
        this.lexer = lexer;
        if (lexer == Lexer.PLAIN) {
            lineComments = new String[0];
            blockComments = new String[0][];
            stringDelims = new String[0];
        }
    }

    public Language ext(String... e) {
        extensions.addAll(Arrays.asList(e));
        return this;
    }

    public Language file(String... f) {
        filenames.addAll(Arrays.asList(f));
        return this;
    }

    public Language kw(String... k) {
        keywords.addAll(Arrays.asList(k));
        return this;
    }

    public Language ctl(String... k) {
        control.addAll(Arrays.asList(k));
        return this;
    }

    public Language ty(String... k) {
        types.addAll(Arrays.asList(k));
        return this;
    }

    public Language co(String... k) {
        constants.addAll(Arrays.asList(k));
        return this;
    }

    public Language bi(String... k) {
        builtins.addAll(Arrays.asList(k));
        return this;
    }

    public Language badge(String color, String text) {
        this.color = color;
        this.badge = text;
        return this;
    }

    public Language caseInsensitive(boolean b) {
        this.caseInsensitive = b;
        return this;
    }

    public boolean matches(String fileName) {
        String lower = fileName.toLowerCase(Locale.ROOT);
        for (String f : filenames) {
            if (f.equalsIgnoreCase(fileName)) {
                return true;
            }
        }
        if (lower.equals("dockerfile") || lower.startsWith("dockerfile.")) {
            return id.equals("dockerfile");
        }
        if (lower.equals("makefile") || lower.equals("gnumakefile")) {
            return id.equals("makefile");
        }
        int dot = lower.lastIndexOf('.');
        if (dot < 0) {
            return false;
        }
        String e = lower.substring(dot + 1);
        return extensions.contains(e);
    }

    @Override
    public String toString() {
        return name;
    }

    /* ===================================================================== */

    private static final List<Language> ALL = new ArrayList<>();
    /** Ids added through {@link #contributed}, which are the only ones {@link #remove} will drop. */
    private static final Set<String> CONTRIBUTED_IDS = new LinkedHashSet<>();
    private static Language plain;

    static {
        plain = new Language("plaintext", "Plain Text", Lexer.PLAIN).badge("#8A8A8A", "TXT");
        ALL.add(plain);

        ALL.add(new Language("java", "Java", Lexer.GENERIC).ext("java")
                .kw("abstract", "assert", "class", "enum", "extends", "final", "implements", "import",
                        "instanceof", "interface", "native", "new", "package", "private", "protected",
                        "public", "record", "sealed", "permits", "static", "strictfp", "super", "synchronized",
                        "this", "throws", "transient", "volatile", "var", "yield", "module", "requires",
                        "exports", "opens", "provides", "uses", "non-sealed")
                .ctl("break", "case", "catch", "continue", "default", "do", "else", "finally", "for", "if",
                        "return", "switch", "throw", "try", "while")
                .ty("boolean", "byte", "char", "double", "float", "int", "long", "short", "void", "String",
                        "Object", "Integer", "Double", "Long", "Float", "Boolean", "Character", "Byte", "Short",
                        "List", "ArrayList", "Map", "HashMap", "Set", "HashSet", "LinkedHashMap", "TreeMap",
                        "Collection", "Collections", "Arrays", "Optional", "Stream", "Exception", "RuntimeException",
                        "IllegalArgumentException", "IOException", "Thread", "Runnable", "Class", "System",
                        "Math", "StringBuilder", "StringBuffer", "Objects", "Comparator", "Function", "Consumer",
                        "Supplier", "Predicate", "LocalDate", "LocalDateTime", "Path", "Files", "File")
                .co("true", "false", "null")
                .bi("print", "println", "printf", "length", "size", "get", "set", "add", "remove", "put",
                        "contains", "equals", "hashCode", "toString", "valueOf", "main", "of", "stream", "map",
                        "filter", "collect", "forEach", "toList", "orElse", "isPresent", "append")
                .badge("#E76F00", "J"));

        ALL.add(new Language("javascript", "JavaScript", Lexer.GENERIC)
                .ext("js", "mjs", "cjs", "jsx").file(".babelrc", ".eslintrc", ".prettierrc")
                .kw("async", "await", "class", "const", "debugger", "delete", "export", "extends", "function",
                        "get", "import", "in", "instanceof", "let", "new", "of", "set", "static", "super", "this",
                        "typeof", "var", "void", "with", "yield", "from", "as", "target")
                .ctl("break", "case", "catch", "continue", "default", "do", "else", "finally", "for", "if",
                        "return", "switch", "throw", "try", "while")
                .ty("Array", "Boolean", "Date", "Error", "Function", "JSON", "Map", "Math", "Number", "Object",
                        "Promise", "Proxy", "RegExp", "Set", "String", "Symbol", "WeakMap", "WeakSet", "BigInt",
                        "Infinity", "NaN", "undefined", "globalThis", "Intl", "Reflect")
                .co("true", "false", "null", "undefined", "NaN", "Infinity")
                .bi("console", "document", "window", "process", "require", "module", "exports", "fetch",
                        "setTimeout", "setInterval", "clearTimeout", "clearInterval", "parseInt", "parseFloat",
                        "isNaN", "alert", "localStorage", "JSON", "Promise", "Buffer", "global")
                .badge("#F1E05A", "JS"));

        ALL.add(new Language("typescript", "TypeScript", Lexer.GENERIC)
                .ext("ts", "tsx", "mts", "cts")
                .kw("abstract", "any", "as", "async", "await", "class", "const", "declare", "enum", "export",
                        "extends", "implements", "import", "in", "infer", "interface", "is", "keyof", "let",
                        "namespace", "new", "of", "private", "protected", "public", "readonly", "satisfies",
                        "static", "super", "this", "type", "typeof", "var", "yield", "from", "get", "set")
                .ctl("break", "case", "catch", "continue", "default", "do", "else", "finally", "for", "if",
                        "return", "switch", "throw", "try", "while")
                .ty("Array", "Boolean", "Date", "Error", "Function", "JSON", "Map", "Math", "Number", "Object",
                        "Promise", "Record", "Partial", "Readonly", "Set", "String", "Symbol", "unknown", "never",
                        "void", "number", "string", "boolean", "object", "bigint")
                .co("true", "false", "null", "undefined")
                .bi("console", "document", "window", "process", "require", "fetch", "Promise")
                .badge("#3178C6", "TS"));

        ALL.add(new Language("python", "Python", Lexer.PYTHON).ext("py", "pyw", "pyi")
                .kw("and", "as", "assert", "async", "await", "class", "def", "del", "global", "import", "in",
                        "is", "lambda", "nonlocal", "not", "or", "pass", "self", "cls")
                .ctl("break", "continue", "elif", "else", "except", "finally", "for", "if", "raise", "return",
                        "try", "while", "with", "yield", "match", "case")
                .ty("bool", "bytes", "complex", "dict", "float", "frozenset", "int", "list", "object", "set",
                        "str", "tuple", "type", "Exception", "ValueError", "TypeError", "KeyError",
                        "IndexError", "RuntimeError", "FileNotFoundError", "None", "Any", "List", "Dict",
                        "Optional", "Callable", "Iterable", "Self")
                .co("True", "False", "None", "NotImplemented", "Ellipsis", "__name__", "__main__")
                .bi("print", "len", "range", "enumerate", "zip", "map", "filter", "sum", "min", "max", "abs",
                        "sorted", "reversed", "open", "input", "int", "str", "float", "list", "dict", "set",
                        "tuple", "isinstance", "hasattr", "getattr", "setattr", "super", "repr", "format",
                        "eval", "exec", "globals", "locals", "id", "hash", "iter", "next", "vars", "dir")
                .badge("#3572A5", "PY"));

        ALL.add(new Language("html", "HTML", Lexer.MARKUP).ext("html", "htm", "xhtml", "vue", "svelte")
                .badge("#E34C26", "<>"));

        ALL.add(new Language("xml", "XML", Lexer.MARKUP)
                .ext("xml", "xsd", "xsl", "xslt", "svg", "plist", "pom", "csproj", "props", "resx", "ui", "fxml")
                .file(".project", ".classpath")
                .badge("#8CB34A", "X"));

        ALL.add(new Language("css", "CSS", Lexer.CSS).ext("css", "scss", "less", "sass")
                .badge("#2965F1", "CSS"));

        ALL.add(new Language("json", "JSON", Lexer.GENERIC)
                .ext("json", "jsonc", "webmanifest", "map", "lock")
                .file(".babelrc", "package-lock.json", "tsconfig.json", ".eslintrc.json")
                .co("true", "false", "null")
                .badge("#CBCB41", "{}"));

        ALL.add(new Language("markdown", "Markdown", Lexer.MARKDOWN).ext("md", "markdown", "mdx")
                .badge("#083FA1", "M"));

        ALL.add(new Language("yaml", "YAML", Lexer.YAML).ext("yml", "yaml")
                .co("true", "false", "null", "yes", "no", "on", "off")
                .badge("#CB171E", "Y"));

        ALL.add(new Language("c", "C", Lexer.GENERIC).ext("c", "h")
                .kw("auto", "const", "enum", "extern", "inline", "register", "restrict", "sizeof", "static",
                        "struct", "typedef", "union", "volatile", "_Bool", "_Complex")
                .ctl("break", "case", "continue", "default", "do", "else", "for", "goto", "if", "return",
                        "switch", "while")
                .ty("char", "double", "float", "int", "long", "short", "signed", "unsigned", "void", "size_t",
                        "FILE", "int8_t", "int16_t", "int32_t", "int64_t", "uint8_t", "uint32_t", "uint64_t",
                        "bool", "ssize_t", "time_t")
                .co("NULL", "true", "false", "EOF", "stdin", "stdout", "stderr")
                .bi("printf", "scanf", "malloc", "free", "calloc", "realloc", "memcpy", "memset", "strlen",
                        "strcpy", "strcmp", "fopen", "fclose", "fread", "fwrite", "exit", "atoi")
                .badge("#555555", "C"));

        ALL.add(new Language("cpp", "C++", Lexer.GENERIC).ext("cpp", "cxx", "cc", "hpp", "hxx", "hh", "inl")
                .kw("alignas", "alignof", "auto", "class", "concept", "constexpr", "const_cast", "decltype",
                        "delete", "dynamic_cast", "enum", "explicit", "export", "extern", "final", "friend",
                        "inline", "mutable", "namespace", "new", "noexcept", "operator", "override", "private",
                        "protected", "public", "reinterpret_cast", "requires", "sizeof", "static", "static_cast",
                        "struct", "template", "this", "thread_local", "typedef", "typename", "union", "using",
                        "virtual", "volatile")
                .ctl("break", "case", "catch", "continue", "default", "do", "else", "for", "goto", "if",
                        "return", "switch", "throw", "try", "while", "co_await", "co_return", "co_yield")
                .ty("bool", "char", "char8_t", "char16_t", "char32_t", "double", "float", "int", "long",
                        "short", "signed", "unsigned", "void", "wchar_t", "string", "vector", "map", "set",
                        "unordered_map", "unordered_set", "shared_ptr", "unique_ptr", "pair", "tuple", "size_t")
                .co("true", "false", "nullptr", "NULL")
                .bi("std", "cout", "cin", "cerr", "endl", "printf", "malloc", "free", "move", "forward",
                        "make_shared", "make_unique", "begin", "end", "push_back", "emplace_back", "size")
                .badge("#F34B7D", "C++"));

        ALL.add(new Language("csharp", "C#", Lexer.GENERIC).ext("cs")
                .kw("abstract", "as", "async", "await", "base", "class", "const", "delegate", "enum", "event",
                        "explicit", "extern", "implicit", "in", "interface", "internal", "is", "lock", "namespace",
                        "new", "operator", "out", "override", "params", "partial", "private", "protected", "public",
                        "readonly", "record", "ref", "sealed", "static", "struct", "this", "throw", "typeof",
                        "unsafe", "using", "var", "virtual", "volatile", "yield", "get", "set", "init", "with")
                .ctl("break", "case", "catch", "continue", "default", "do", "else", "finally", "for", "foreach",
                        "goto", "if", "return", "switch", "try", "while")
                .ty("bool", "byte", "char", "decimal", "double", "float", "int", "long", "object", "sbyte",
                        "short", "string", "uint", "ulong", "ushort", "void", "List", "Dictionary", "Task",
                        "IEnumerable", "Console", "String", "Array", "Exception")
                .co("true", "false", "null", "this", "base")
                .bi("Console", "WriteLine", "Write", "ToString", "Length", "Count", "Add")
                .badge("#178600", "C#"));

        ALL.add(new Language("go", "Go", Lexer.GENERIC).ext("go")
                .kw("chan", "const", "defer", "func", "go", "import", "interface", "map", "package", "range",
                        "select", "struct", "type", "var", "fallthrough")
                .ctl("break", "case", "continue", "default", "else", "for", "goto", "if", "return", "switch")
                .ty("bool", "byte", "complex64", "complex128", "error", "float32", "float64", "int", "int8",
                        "int16", "int32", "int64", "rune", "string", "uint", "uint8", "uint16", "uint32",
                        "uint64", "uintptr", "any")
                .co("true", "false", "nil", "iota")
                .bi("append", "cap", "close", "copy", "delete", "len", "make", "new", "panic", "print",
                        "println", "recover", "fmt", "Println", "Printf", "Sprintf", "Errorf")
                .badge("#00ADD8", "GO"));

        ALL.add(new Language("rust", "Rust", Lexer.GENERIC).ext("rs")
                .kw("as", "async", "await", "const", "crate", "dyn", "enum", "extern", "fn", "impl", "in",
                        "let", "mod", "move", "mut", "pub", "ref", "self", "Self", "static", "struct", "super",
                        "trait", "type", "unsafe", "use", "where")
                .ctl("break", "continue", "else", "for", "if", "loop", "match", "return", "while")
                .ty("bool", "char", "f32", "f64", "i8", "i16", "i32", "i64", "i128", "isize", "str", "String",
                        "u8", "u16", "u32", "u64", "u128", "usize", "Vec", "Option", "Result", "Box", "Rc",
                        "Arc", "HashMap", "HashSet", "Some", "None", "Ok", "Err")
                .co("true", "false", "None", "Some", "Ok", "Err")
                .bi("println!", "print!", "format!", "vec!", "panic!", "unwrap", "expect", "iter", "collect",
                        "into", "clone", "to_string", "new", "push", "len", "main")
                .badge("#DEA584", "RS"));

        ALL.add(new Language("php", "PHP", Lexer.GENERIC).ext("php", "phtml")
                .lineComments(new String[]{"//", "#"})
                .kw("abstract", "and", "as", "class", "const", "declare", "echo", "extends", "final", "function",
                        "global", "implements", "include", "include_once", "instanceof", "interface", "namespace",
                        "new", "or", "print", "private", "protected", "public", "require", "require_once", "static",
                        "trait", "use", "var", "xor", "match", "fn", "readonly", "enum")
                .ctl("break", "case", "catch", "continue", "default", "do", "else", "elseif", "finally", "for",
                        "foreach", "goto", "if", "return", "switch", "throw", "try", "while", "yield")
                .ty("array", "bool", "callable", "float", "int", "iterable", "mixed", "object", "string", "void",
                        "Exception", "Closure", "self", "parent")
                .co("true", "false", "null", "TRUE", "FALSE", "NULL")
                .badge("#4F5D95", "PHP"));

        ALL.add(new Language("ruby", "Ruby", Lexer.PYTHON).ext("rb", "erb", "gemspec").file("Gemfile", "Rakefile")
                .lineComments(new String[]{"#"})
                .kw("alias", "attr_accessor", "attr_reader", "attr_writer", "begin", "class", "def", "end",
                        "include", "extend", "lambda", "module", "new", "require", "require_relative", "self",
                        "then", "unless", "until", "yield", "do")
                .ctl("break", "case", "catch", "else", "elsif", "ensure", "for", "if", "next", "redo",
                        "rescue", "retry", "return", "throw", "when", "while")
                .co("true", "false", "nil", "__FILE__", "__LINE__")
                .bi("puts", "print", "p", "gets", "each", "map", "select", "reject", "inject", "length",
                        "size", "push", "pop", "to_s", "to_i", "to_sym", "freeze", "nil?")
                .badge("#701516", "RB"));

        ALL.add(new Language("shell", "Shell Script", Lexer.SHELL)
                .ext("sh", "bash", "zsh", "fish", "ksh", "profile", "bashrc", "zshrc")
                .file(".bashrc", ".profile", ".bash_profile", ".zshrc", ".env")
                .badge("#89E051", "SH"));

        ALL.add(new Language("batch", "Batch", Lexer.SHELL).ext("bat", "cmd")
                .lineComments(new String[]{"REM", "rem", "::"})
                .badge("#C1F12E", "BAT"));

        ALL.add(new Language("powershell", "PowerShell", Lexer.SHELL)
                .ext("ps1", "psm1", "psd1")
                .lineComments(new String[]{"#"})
                .kw("function", "param", "begin", "process", "end", "class", "enum", "filter", "return")
                .ctl("if", "else", "elseif", "switch", "foreach", "for", "while", "do", "until", "try",
                        "catch", "finally", "throw", "break", "continue")
                .badge("#012456", "PS"));

        ALL.add(new Language("sql", "SQL", Lexer.GENERIC).ext("sql", "ddl", "dml")
                .lineComments(new String[]{"--"})
                .caseInsensitive(true)
                .kw("add", "alter", "as", "asc", "begin", "by", "column", "commit", "constraint", "create",
                        "database", "default", "desc", "distinct", "drop", "exec", "exists", "foreign", "from",
                        "full", "group", "having", "index", "inner", "insert", "into", "join", "key", "left",
                        "like", "limit", "not", "offset", "on", "order", "outer", "primary", "procedure",
                        "references", "right", "rollback", "select", "set", "table", "top", "transaction",
                        "trigger", "union", "unique", "update", "values", "view", "where", "with")
                .ty("bigint", "bit", "blob", "boolean", "char", "date", "datetime", "decimal", "double",
                        "float", "int", "integer", "json", "numeric", "real", "smallint", "text", "time",
                        "timestamp", "varchar")
                .co("null", "true", "false")
                .bi("count", "sum", "avg", "min", "max", "coalesce", "cast", "now", "concat", "upper", "lower")
                .badge("#E38C00", "SQL"));

        ALL.add(new Language("kotlin", "Kotlin", Lexer.GENERIC).ext("kt", "kts")
                .kw("abstract", "actual", "annotation", "as", "class", "companion", "const", "constructor",
                        "crossinline", "data", "enum", "expect", "external", "final", "fun", "import", "in",
                        "infix", "init", "inner", "interface", "internal", "lateinit", "noinline", "object",
                        "open", "operator", "out", "override", "package", "private", "protected", "public",
                        "reified", "sealed", "suspend", "tailrec", "this", "typealias", "val", "var", "vararg")
                .ctl("break", "continue", "do", "else", "for", "if", "return", "throw", "try", "catch",
                        "finally", "when", "while")
                .ty("Any", "Boolean", "Byte", "Char", "Double", "Float", "Int", "Long", "Nothing", "Short",
                        "String", "Unit", "List", "Map", "Set", "Array", "IntArray")
                .co("true", "false", "null", "it")
                .bi("println", "print", "readLine", "listOf", "mapOf", "setOf", "mutableListOf", "let",
                        "apply", "also", "run", "with", "takeIf", "forEach")
                .badge("#A97BFF", "KT"));

        ALL.add(new Language("swift", "Swift", Lexer.GENERIC).ext("swift")
                .kw("actor", "associatedtype", "async", "await", "class", "convenience", "deinit", "enum",
                        "extension", "fileprivate", "final", "func", "import", "init", "inout", "internal",
                        "lazy", "let", "mutating", "nonmutating", "open", "operator", "override", "private",
                        "protocol", "public", "required", "static", "struct", "subscript", "typealias", "var",
                        "weak", "unowned", "guard")
                .ctl("break", "case", "catch", "continue", "default", "defer", "do", "else", "fallthrough",
                        "for", "if", "in", "repeat", "return", "switch", "throw", "try", "where", "while")
                .ty("Any", "AnyObject", "Array", "Bool", "Character", "Dictionary", "Double", "Float", "Int",
                        "Optional", "Set", "String", "Void", "Result", "Error")
                .co("true", "false", "nil", "self", "super")
                .bi("print", "map", "filter", "reduce", "append", "count", "isEmpty", "description")
                .badge("#F05138", "SW"));

        ALL.add(new Language("lua", "Lua", Lexer.GENERIC).ext("lua")
                .lineComments(new String[]{"--"})
                .kw("and", "do", "end", "function", "in", "local", "not", "or", "repeat", "then", "until")
                .ctl("break", "else", "elseif", "for", "if", "return", "while", "goto")
                .co("true", "false", "nil", "_G", "self")
                .bi("print", "pairs", "ipairs", "type", "tostring", "tonumber", "table", "string", "math",
                        "io", "os", "require", "setmetatable", "getmetatable", "pcall", "error", "insert",
                        "remove", "concat", "format", "sub", "len")
                .badge("#000080", "LUA"));

        ALL.add(new Language("r", "R", Lexer.PYTHON).ext("r", "rmd")
                .lineComments(new String[]{"#"})
                .kw("function", "library", "require", "return", "in", "repeat")
                .ctl("if", "else", "for", "while", "next", "break")
                .co("TRUE", "FALSE", "NULL", "NA", "NaN", "Inf")
                .bi("print", "cat", "c", "list", "data.frame", "matrix", "vector", "mean", "median", "sd",
                        "sum", "length", "seq", "rep", "read.csv", "write.csv", "plot", "lm", "summary")
                .badge("#198CE7", "R"));

        ALL.add(new Language("properties", "Properties", Lexer.PROPERTIES)
                .ext("properties", "ini", "cfg", "conf", "env", "toml", "prefs", "editorconfig")
                .file(".editorconfig", ".gitconfig", ".gitignore_global")
                .badge("#6A9955", "P"));

        ALL.add(new Language("dockerfile", "Dockerfile", Lexer.SHELL).ext("dockerfile")
                .file("Dockerfile")
                .lineComments(new String[]{"#"})
                .kw("from", "run", "cmd", "label", "maintainer", "expose", "env", "add", "copy", "entrypoint",
                        "volume", "user", "workdir", "arg", "onbuild", "stopsignal", "healthcheck", "shell",
                        "as")
                .caseInsensitive(true)
                .badge("#384D54", "D"));

        ALL.add(new Language("makefile", "Makefile", Lexer.SHELL).ext("mk", "mak").file("Makefile", "makefile")
                .lineComments(new String[]{"#"})
                .badge("#427819", "MK"));

        ALL.add(new Language("diff", "Diff", Lexer.PLAIN).ext("diff", "patch")
                .badge("#8A8A8A", "±"));

        ALL.add(new Language("text", "Log", Lexer.PLAIN).ext("log", "txt", "text", "out", "csv", "tsv")
                .badge("#8A8A8A", "TXT"));
    }

    /** Extension-less convenience setters used by the builders above. */
    public Language lineComments(String[] lc) {
        this.lineComments = lc;
        return this;
    }

    public static Language plain() {
        return plain;
    }

    public static List<Language> all() {
        return ALL;
    }

    /** The language with this id, or null. Unlike {@link #byId} this does not fall back to plain. */
    public static Language find(String id) {
        for (Language l : ALL) {
            if (l.id.equals(id)) {
                return l;
            }
        }
        return null;
    }

    /**
     * Registers a language contributed by a plugin.
     *
     * <p>The lexer has to be one of the data-driven kinds — {@link Lexer#GENERIC}, {@link
     * Lexer#PYTHON} or {@link Lexer#SHELL}. Those three tokenize entirely from the configuration
     * carried on this object (comments, string delimiters, keywords, types, functions, annotations),
     * which covers the great majority of languages. The remaining kinds — Markdown, CSS, YAML,
     * properties — have hand-written tokenizers in {@link SyntaxHighlighter} and cannot be
     * reproduced by configuration, so a plugin cannot add a language that needs one.
     *
     * @return the new language, or null when the id is blank or already taken
     */
    public static Language contributed(String id, String name, Lexer lexer) {
        if (id == null || id.isBlank() || name == null || name.isBlank() || find(id) != null) {
            return null;
        }
        switch (lexer == null ? Lexer.GENERIC : lexer) {
            case GENERIC, PYTHON, SHELL -> {
            }
            default -> {
                return null;
            }
        }
        Language language = new Language(id, name, lexer == null ? Lexer.GENERIC : lexer);
        ALL.add(language);
        CONTRIBUTED_IDS.add(id);
        return language;
    }

    /** Best-effort detection by file name; never returns null. */
    public static Language detect(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return plain;
        }
        for (Language l : ALL) {
            if (l.filenames.isEmpty() && !"dockerfile".equals(l.id) && !"makefile".equals(l.id)) {
                continue;
            }
            if (l.matches(fileName)) {
                return l;
            }
        }
        for (Language l : ALL) {
            if (l.matches(fileName)) {
                return l;
            }
        }
        return plain;
    }

    public static Language byId(String id) {
        Language found = find(id);
        return found == null ? plain : found;
    }

    /**
     * Removes a language a plugin contributed. Only ids that came from {@link #contributed} can be
     * removed, so a plugin can never delete a built-in language.
     */
    public static boolean remove(String id) {
        if (id == null || !CONTRIBUTED_IDS.remove(id)) {
            return false;
        }
        ALL.removeIf(l -> l.id.equals(id));
        return true;
    }

    /**
     * Drops every contributed language, leaving the built-ins untouched.
     *
     * <p>Called when plugins are reloaded. Without it a second load would find each contributed id
     * already taken and report a conflict against a plugin that is in fact loading correctly.
     */
    public static void clearContributed() {
        for (String id : new ArrayList<>(CONTRIBUTED_IDS)) {
            remove(id);
        }
        CONTRIBUTED_IDS.clear();
    }
}
