package com.codestudio.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The UI translation table.
 *
 * <p>Keys are the English source text itself rather than invented identifiers. That keeps call
 * sites readable ({@code Strings.get("Save")}), deduplicates automatically, and — most
 * importantly — means a missing entry degrades to English rather than showing a raw key to the
 * user. Adding a language means adding one map.
 *
 * <p>Strings that interpolate use {@code {0}}, {@code {1}} … placeholders and go through
 * {@link #format}. The placeholders must appear in the translation too; {@link #check()} enforces
 * that so a translator cannot silently drop an argument.
 *
 * <p>Only Simplified Chinese is provided. {@link #SYSTEM} resolves from the JVM default locale, so
 * a Chinese Windows installation starts in Chinese without any configuration.
 */
public final class Strings {

    /** Follow the operating system's language. */
    public static final String SYSTEM = "system";
    public static final String ENGLISH = "en";
    public static final String CHINESE = "zh";

    private static final Map<String, String> ZH = new LinkedHashMap<>();
    private static final List<String> MODES = List.of(SYSTEM, ENGLISH, CHINESE);

    private static String mode = SYSTEM;
    /** True when text should be looked up in {@link #ZH}. */
    private static boolean chinese;

    static {
        chinese = resolvesToChinese(SYSTEM);
    }

    private Strings() {
    }

    /* ------------------------------------------------------------------ */
    /* lookup                                                              */
    /* ------------------------------------------------------------------ */

    /** Translates English source text. Unknown text is returned unchanged. */
    public static String get(String english) {
        if (english == null) {
            return "";
        }
        if (!chinese) {
            return english;
        }
        String translated = ZH.get(english);
        return translated == null ? english : translated;
    }

    /** Translates, then substitutes {@code {0}}, {@code {1}} … with the arguments. */
    public static String format(String english, Object... args) {
        String text = get(english);
        for (int i = 0; i < args.length; i++) {
            String token = "{" + i + "}";
            int at = text.indexOf(token);
            while (at >= 0) {
                text = text.substring(0, at) + args[i] + text.substring(at + token.length());
                at = text.indexOf(token, at);
            }
        }
        return text;
    }

    /**
     * Translates a message that was assembled by concatenation, such as
     * {@code notify("Deleted " + name)}. {@link #get} matches exactly and cannot help there,
     * because the assembled text is not itself a key.
     *
     * <p>Only keys ending in a space or a colon are eligible, and the longest one wins. That
     * restriction is what makes it safe: a plain label such as "File" or "Copy" is never treated as
     * a prefix, so a message that merely begins with one of those words is left alone instead of
     * being half-translated. Where nothing matches the text comes back unchanged.
     */
    public static String prefix(String text) {
        if (text == null) {
            return "";
        }
        if (!chinese || text.isEmpty()) {
            return text;
        }
        String exact = ZH.get(text);
        if (exact != null) {
            return exact;
        }
        String best = null;
        for (String key : ZH.keySet()) {
            if (key.length() >= text.length() || !isJoinable(key) || !text.startsWith(key)) {
                continue;
            }
            if (best == null || key.length() > best.length()) {
                best = key;
            }
        }
        return best == null ? text : ZH.get(best) + text.substring(best.length());
    }

    /** Whether a key reads as a message fragment meant to be joined with something after it. */
    private static boolean isJoinable(String key) {
        if (key.isEmpty()) {
            return false;
        }
        char last = key.charAt(key.length() - 1);
        return last == ' ' || last == ':';
    }

    /**
     * Display name for a language id from {@link Language#all()}. Language names are data, not
     * literals in the source, so they are keyed by id instead of by their English text.
     */
    public static String languageName(String id, String fallback) {
        if (!chinese || id == null) {
            return fallback;
        }
        String translated = LANGUAGE_NAMES.get(id);
        return translated == null ? fallback : translated;
    }

    /* ------------------------------------------------------------------ */
    /* locale selection                                                    */
    /* ------------------------------------------------------------------ */

    private static boolean resolvesToChinese(String which) {
        if (CHINESE.equals(which)) {
            return true;
        }
        if (ENGLISH.equals(which)) {
            return false;
        }
        return Locale.getDefault().getLanguage().toLowerCase(Locale.ROOT).startsWith("zh");
    }

    /** Sets the language from a stored setting value. Returns true when the result changed. */
    public static boolean setLanguage(String value) {
        String wanted = value == null || value.isBlank() ? SYSTEM : value;
        boolean before = chinese;
        mode = wanted;
        chinese = resolvesToChinese(wanted);
        return before != chinese;
    }

    /** The setting value: {@link #SYSTEM}, {@link #ENGLISH} or {@link #CHINESE}. */
    public static String mode() {
        return mode;
    }

    /** The language actually in effect, never {@link #SYSTEM}. */
    public static String current() {
        return chinese ? CHINESE : ENGLISH;
    }

    public static boolean isChinese() {
        return chinese;
    }

    /** Selectable values for the settings drop down. */
    public static List<String> modes() {
        return MODES;
    }

    /** Human readable name for a setting value, shown in the drop down. */
    public static String modeLabel(String value) {
        return switch (value == null ? "" : value) {
            case CHINESE -> "简体中文";
            case ENGLISH -> "English";
            default -> "跟随系统 / System";
        };
    }

    /** Whether a translation exists, used by the self test. */
    public static boolean has(String english) {
        return ZH.containsKey(english);
    }

    public static int size() {
        return ZH.size();
    }

    /**
     * Validates the table: every entry must be non-empty and must carry exactly the same
     * {0}/{1}… placeholders as its English source. Returns a list of problems, empty when clean.
     */
    public static List<String> check() {
        List<String> problems = new ArrayList<>();
        for (Map.Entry<String, String> e : ZH.entrySet()) {
            String en = e.getKey();
            String zh = e.getValue();
            if (zh == null || zh.isBlank()) {
                problems.add("empty translation: " + en);
                continue;
            }
            List<String> inEnglish = placeholders(en);
            List<String> inChinese = placeholders(zh);
            if (!inEnglish.equals(inChinese)) {
                problems.add("placeholder mismatch: \"" + en + "\" -> \"" + zh + "\""
                        + " (" + inEnglish + " vs " + inChinese + ")");
            }
        }
        return problems;
    }

    private static List<String> placeholders(String text) {
        List<String> found = new ArrayList<>();
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) != '{' || i + 2 >= text.length() || text.charAt(i + 2) != '}') {
                continue;
            }
            char digit = text.charAt(i + 1);
            if (digit >= '0' && digit <= '9') {
                found.add("{" + digit + "}");
            }
        }
        found.sort(String::compareTo);
        return found;
    }

    private static void zh(String english, String translation) {
        ZH.put(english, translation);
    }

    /* ------------------------------------------------------------------ */
    /* language display names                                              */
    /* ------------------------------------------------------------------ */

    private static final Map<String, String> LANGUAGE_NAMES = new HashMap<>();

    static {
        LANGUAGE_NAMES.put("plaintext", "纯文本");
        LANGUAGE_NAMES.put("java", "Java");
        LANGUAGE_NAMES.put("javascript", "JavaScript");
        LANGUAGE_NAMES.put("typescript", "TypeScript");
        LANGUAGE_NAMES.put("python", "Python");
        LANGUAGE_NAMES.put("c", "C");
        LANGUAGE_NAMES.put("cpp", "C++");
        LANGUAGE_NAMES.put("csharp", "C#");
        LANGUAGE_NAMES.put("go", "Go");
        LANGUAGE_NAMES.put("rust", "Rust");
        LANGUAGE_NAMES.put("kotlin", "Kotlin");
        LANGUAGE_NAMES.put("swift", "Swift");
        LANGUAGE_NAMES.put("php", "PHP");
        LANGUAGE_NAMES.put("ruby", "Ruby");
        LANGUAGE_NAMES.put("perl", "Perl");
        LANGUAGE_NAMES.put("lua", "Lua");
        LANGUAGE_NAMES.put("r", "R");
        LANGUAGE_NAMES.put("scala", "Scala");
        LANGUAGE_NAMES.put("dart", "Dart");
        LANGUAGE_NAMES.put("sql", "SQL");
        LANGUAGE_NAMES.put("shell", "Shell 脚本");
        LANGUAGE_NAMES.put("powershell", "PowerShell");
        LANGUAGE_NAMES.put("batch", "批处理");
        LANGUAGE_NAMES.put("html", "HTML");
        LANGUAGE_NAMES.put("css", "CSS");
        LANGUAGE_NAMES.put("scss", "SCSS");
        LANGUAGE_NAMES.put("json", "JSON");
        LANGUAGE_NAMES.put("xml", "XML");
        LANGUAGE_NAMES.put("yaml", "YAML");
        LANGUAGE_NAMES.put("markdown", "Markdown");
        LANGUAGE_NAMES.put("properties", "属性文件");
    }

    /* ------------------------------------------------------------------ */
    /* the table                                                           */
    /* ------------------------------------------------------------------ */

    static {
        // --- menu bar and menu titles ---
        zh("File", "文件");
        zh("Edit", "编辑");
        zh("Selection", "选择");
        zh("View", "视图");
        zh("Go", "转到");
        zh("Run", "运行");
        zh("Terminal", "终端");
        zh("Help", "帮助");
        zh("Open Recent", "最近打开");
        zh("Preferences", "首选项");
        zh("Git", "Git");

        // --- File menu ---
        zh("New Text File", "新建文本文件");
        zh("New File...", "新建文件...");
        zh("Open File...", "打开文件...");
        zh("Open Folder...", "打开文件夹...");
        zh("Save", "保存");
        zh("Save As...", "另存为...");
        zh("Save All", "全部保存");
        zh("Close Editor", "关闭编辑器");
        zh("Close All Editors", "关闭所有编辑器");
        zh("Exit", "退出");
        zh("Settings", "设置");
        zh("Keyboard Shortcuts", "键盘快捷方式");

        // --- Edit / Selection menus ---
        zh("Cut", "剪切");
        zh("Copy", "复制");
        zh("Paste", "粘贴");
        zh("Find", "查找");
        zh("Replace", "替换");
        zh("Find in Files", "在文件中查找");
        zh("Toggle Line Comment", "切换行注释");
        zh("Format Document", "格式化文档");
        zh("Indent", "增加缩进");
        zh("Outdent", "减少缩进");
        zh("Select All", "全选");
        zh("Select Current Line", "选中当前行");
        zh("Expand Line Selection", "扩展行选择");

        // --- View menu ---
        zh("Command Palette...", "命令面板...");
        zh("Open View...", "打开视图...");
        zh("Explorer", "资源管理器");
        zh("Search", "搜索");
        zh("Source Control", "源代码管理");
        zh("Run and Debug", "运行和调试");
        zh("Problems", "问题");
        zh("Output", "输出");
        zh("Debug Console", "调试控制台");
        zh("Toggle Primary Side Bar", "切换主侧边栏");
        zh("Toggle Panel", "切换面板");
        zh("Toggle Maximized Panel", "切换最大化面板");
        zh("Full Screen", "全屏");
        zh("Toggle Full Screen", "切换全屏");
        zh("Zoom In", "放大");
        zh("Zoom Out", "缩小");
        zh("Reset Zoom", "重置缩放");
        zh("Color Theme", "颜色主题");
        zh("Split Editor", "拆分编辑器");
        zh("Unsplit Editor", "取消拆分");
        zh("Toggle Word Wrap", "切换自动换行");
        zh("Toggle Terminal", "切换终端");

        // --- Go menu ---
        zh("Go to File...", "转到文件...");
        zh("Go to Symbol in Editor...", "转到编辑器中的符号...");
        zh("Go to Line/Column...", "转到行/列...");
        zh("Next Problem", "下一个问题");
        zh("Previous Problem", "上一个问题");
        zh("Next Editor", "下一个编辑器");
        zh("Previous Editor", "上一个编辑器");

        // --- Run menu ---
        zh("Start Debugging", "开始调试");
        zh("Run Without Debugging", "以非调试模式运行");
        zh("Stop", "停止");
        zh("Show Run and Debug", "显示运行和调试");
        zh("Remove All Breakpoints", "移除所有断点");
        zh("Detected Toolchain", "检测到的工具链");

        // --- Terminal menu ---
        zh("New Terminal", "新建终端");
        zh("New Terminal in Workspace Folder", "在工作区文件夹中新建终端");
        zh("Kill Terminal", "终止终端");
        zh("Clear Terminal", "清除终端");
        zh("Run Active File in Terminal", "在终端中运行活动文件");

        // --- Help menu ---
        zh("Welcome", "欢迎");
        zh("Documentation", "文档");
        zh("About CodeStudio", "关于 CodeStudio");

        // --- command palette categories and extra commands ---
        zh("Refresh Explorer", "刷新资源管理器");
        zh("Reveal Active File in Explorer", "在资源管理器中显示活动文件");
        zh("Toggle Auto Save", "切换自动保存");
        zh("Clone Repository", "克隆仓库");
        zh("Clone Git Repository", "克隆 Git 仓库");
        zh("Refresh Source Control", "刷新源代码管理");
        zh("Switch Branch...", "切换分支...");
        zh("Create Branch", "创建分支");
        zh("Create Branch...", "创建分支...");
        zh("Open Settings", "打开设置");
        zh("Open Settings (JSON)", "打开设置(JSON)");
        zh("Reset Settings", "重置设置");
        zh("Create New Terminal", "新建终端");
        zh("Show All Commands", "显示所有命令");
        zh("Show Debug Console", "显示调试控制台");
        zh("Show Explorer", "显示资源管理器");
        zh("Show Output", "显示输出");
        zh("Show Problems", "显示问题");
        zh("Show Search", "显示搜索");
        zh("Show Source Control", "显示源代码管理");

        // --- editor tab context menu ---
        zh("Close", "关闭");
        zh("Close Others", "关闭其他");
        zh("Close Saved", "关闭已保存");
        zh("Close All", "全部关闭");
        zh("Copy Path", "复制路径");
        zh("Copy Relative Path", "复制相对路径");
        zh("Copied: ", "已复制：");
        zh("Reveal in Explorer", "在资源管理器中显示");
        zh("Reveal in File Manager", "在文件管理器中显示");
        zh("Keep Open", "保持打开");

        // --- notifications and status messages ---
        zh("A program is already running. Stop it first.", "已有程序正在运行，请先停止。");
        zh("Cloning into ", "正在克隆到 ");
        zh("Could not create ", "无法创建 ");
        zh("Could not open ", "无法打开 ");
        zh("Could not open the file manager: ", "无法打开文件管理器：");
        zh("Could not reopen with ", "无法用以下方式重新打开 ");
        zh("Document formatted", "文档已格式化");
        zh("Editor split. Documents live in one group at a time.",
                "编辑器已拆分。同一文档在同一时间只属于一个编辑组。");
        zh("Encoding set to ", "编码已设为 ");
        zh("No active editor", "没有活动的编辑器");
        zh("No branches found", "未找到分支");
        zh("No editor to save", "没有可保存的编辑器");
        zh("No problems detected", "未检测到问题");
        zh("Nothing is running", "当前没有正在运行的任务");
        zh("Open a file to run it", "请先打开要运行的文件");
        zh("Open a folder first", "请先打开一个文件夹");
        zh("Opened folder ", "已打开文件夹 ");
        zh("Path no longer exists", "路径已不存在");
        zh("Path not found: ", "未找到路径：");
        zh("Reloaded ", "已重新加载 ");
        zh("Save the file before running it", "运行前请先保存文件");
        zh("Settings reset to defaults", "设置已重置为默认值");
        zh("Stopped", "已停止");
        zh("This buffer has no file on disk", "此缓冲区在磁盘上没有对应文件");
        zh("This folder is not a Git repository", "此文件夹不是 Git 仓库");
        zh("Could not save ", "无法保存 ");
        zh("Saved ", "已保存 ");
        zh("No recent folders", "暂无最近打开的文件夹");
        zh("No repository", "无仓库");
        zh("Notifications", "通知");
        zh("No notifications yet.", "暂无通知。");
        zh("Auto Save", "自动保存");
        zh("Word Wrap", "自动换行");
        zh("Minimap", "缩略图");

        // --- dialogs ---
        zh("OK", "确定");
        zh("Cancel", "取消");
        zh("Don't Save", "不保存");
        zh("Name of the new branch:", "新分支的名称：");
        zh("Name of the new file:", "新文件的名称：");
        zh("Name of the new folder:", "新文件夹的名称：");
        zh("New File", "新建文件");
        zh("New Folder", "新建文件夹");
        zh("Rename", "重命名");
        zh("Delete", "删除");
        zh("Save File", "保存文件");
        zh("Open File", "打开文件");
        zh("Open Folder", "打开文件夹");
        zh("Select Folder", "选择文件夹");
        zh("Exit CodeStudio", "退出 CodeStudio");

        // --- language names for the settings drop down ---
        zh("Plain Text", "纯文本");
        zh("Property File", "属性文件");

        // --- settings drop down values ---
        zh("Dark", "深色");
        zh("Light", "浅色");
        zh("off", "关闭");
        zh("auto", "自动");
        zh("after a delay", "延迟后");
        zh("on focus change", "焦点变化时");

        // --- about box ---
        zh("A Visual Studio Code style IDE written in pure Java with the Swing toolkit.",
                "一个用纯 Java 和 Swing 工具包编写的 Visual Studio Code 风格 IDE。");
        zh("No extension marketplace and no account sign-in, by design.",
                "设计上不含扩展市场与账户登录。");
        zh("Settings file: ", "设置文件：");

        // --- activity bar, status bar, welcome ---
        zh("Explorer (Ctrl+Shift+E)", "资源管理器 (Ctrl+Shift+E)");
        zh("Search (Ctrl+Shift+F)", "搜索 (Ctrl+Shift+F)");
        zh("Source Control (Ctrl+Shift+G)", "源代码管理 (Ctrl+Shift+G)");
        zh("Run and Debug (Ctrl+Shift+D)", "运行和调试 (Ctrl+Shift+D)");
        zh("Extensions", "扩展");
        zh("Settings (Ctrl+,)", "设置 (Ctrl+,)");
        zh("Ln {0}, Col {1}", "行 {0}，列 {1}");
        zh("Ln {0}, Col {1} ({2} selected)", "行 {0}，列 {1}（已选中 {2} 个字符）");
        zh("Spaces: {0}", "空格：{0}");
        zh("Tab Size: {0}", "制表符大小：{0}");
        zh("{0} errors, {1} warnings", "{0} 个错误，{1} 个警告");
        zh("Click to switch branch", "点击切换分支");
        zh("Go to line", "转到行");
        zh("Select indentation", "选择缩进");
        zh("Select encoding", "选择编码");
        zh("Select end of line sequence", "选择行尾序列");
        zh("Select language mode", "选择语言模式");
        zh("Switch color theme", "切换颜色主题");
        zh("A Java workbench for editing, searching, running and versioning your code.",
                "一个用于编辑、搜索、运行和版本控制代码的 Java 工作台。");
        zh("Start", "开始");
        zh("Recent", "最近");
        zh("Clone Git Repository...", "克隆 Git 仓库...");
        zh("No recent folders yet", "暂无最近打开的文件夹");
        zh("Switch Theme", "切换主题");

        // --- explorer, outline, open editors ---
        zh("Open Editors", "打开的编辑器");
        zh("Open Editors: {0}", "打开的编辑器：{0}");
        zh("Outline", "大纲");
        zh("No Folder", "未打开文件夹");
        zh("Collapse Folders", "折叠文件夹");
        zh("Collapse All", "全部折叠");
        zh("Refresh", "刷新");
        zh("Open", "打开");
        zh("Open Folder as Workspace", "将文件夹作为工作区打开");
        zh("Rename...", "重命名...");
        zh("Open in Terminal", "在终端中打开");
        zh("No open editors", "没有打开的编辑器");
        zh("Unsaved file", "未保存的文件");
        zh("{0}  -  modified", "{0}  -  已修改");
        zh("Rename failed", "重命名失败");
        zh("New name for \"{0}\":", "“{0}”的新名称：");
        zh("A file named \"{0}\" already exists.", "名为“{0}”的文件已存在。");
        zh("Are you sure you want to delete the file \"{0}\"?", "确定要删除文件“{0}”吗？");
        zh("Are you sure you want to delete the folder \"{0}\"?\n\n"
                        + "All of its contents will be deleted.",
                "确定要删除文件夹“{0}”吗？\n\n其所有内容都将被删除。");
        zh("Delete {0}", "删除 {0}");
        zh("No symbols found", "未找到符号");
        zh("No matching symbols", "没有匹配的符号");
        zh("Filter symbols", "筛选符号");
        zh("{0}  (line {1})", "{0}  （第 {1} 行）");
        zh("File already exists: ", "文件已存在：");
        zh("Folder already exists: ", "文件夹已存在：");
        zh("Could not create folder ", "无法创建文件夹 ");
        zh("Renamed to ", "已重命名为 ");
        zh("Deleted ", "已删除 ");
        zh("Could not delete ", "无法删除 ");

        // --- runner: why a file cannot be run ---
        zh("Untitled", "无标题");
        zh("Save the file before running it.", "运行前请先保存文件。");
        zh("A JDK (javac and java) is required to run Java files.",
                "运行 Java 文件需要 JDK（javac 和 java）。");
        zh("A JDK is required to run jar files.", "运行 jar 文件需要 JDK。");
        zh("Python was not found on PATH.", "在 PATH 中未找到 Python。");
        zh("Node.js was not found on PATH.", "在 PATH 中未找到 Node.js。");
        zh("Install ts-node or compile the file to JavaScript first.",
                "请先安装 ts-node，或先将该文件编译为 JavaScript。");
        zh("The Go toolchain was not found on PATH.", "在 PATH 中未找到 Go 工具链。");
        zh("rustc was not found on PATH.", "在 PATH 中未找到 rustc。");
        zh("No shell (bash) was found on PATH.", "在 PATH 中未找到 shell（bash）。");
        zh("No {0} was found on PATH.", "在 PATH 中未找到 {0}。");
        zh("There is no runner configured for {0}.\n"
                        + "Supported: .java .py .js .ts .c .cpp .go .rs .sh .bat .jar",
                "没有为 {0} 配置运行器。\n"
                        + "支持：.java .py .js .ts .c .cpp .go .rs .sh .bat .jar");
        zh("Could not start: {0}", "无法启动：{0}");
        zh("Output stream closed: {0}", "输出流已关闭：{0}");
        zh("c compiler", "C 编译器");
        zh("c++ compiler", "C++ 编译器");

        // --- git change kinds and errors ---
        zh("Modified", "已修改");
        zh("Added", "已添加");
        zh("Deleted", "已删除");
        zh("Renamed", "已重命名");
        zh("Copied", "已复制");
        zh("Untracked", "未跟踪");
        zh("Type changed", "类型已更改");
        zh("Changed", "已更改");
        zh("git is not available", "git 不可用");
        zh("Not a git repository", "不是 Git 仓库");
        zh("git status failed", "git status 执行失败");
        zh("git {0} failed", "git {0} 执行失败");

        // --- bottom panel: problems, output, terminal ---
        zh("Errors", "错误");
        zh("Warnings", "警告");
        zh("Info", "信息");
        zh("Message", "消息");
        zh("Line", "行");
        zh("No problems have been detected in the workspace.", "工作区中未检测到问题。");
        zh("Filter problems", "筛选问题");
        zh("Clear", "清除");
        zh("Maximize Panel", "最大化面板");
        zh("Close Panel", "关闭面板");
        zh("Go to Problem", "转到问题");
        zh("Copy Message", "复制消息");
        zh("Reveal in File Explorer", "在文件资源管理器中显示");
        zh("Active terminal", "活动终端");
        zh("Click to focus this terminal", "单击以聚焦此终端");
        zh("Tasks", "任务");
        zh("Could not start {0}: {1}", "无法启动 {0}：{1}");
        zh("Set the \"terminal.shell\" setting to a valid shell command.",
                "请将 \"terminal.shell\" 设置设为有效的 shell 命令。");
        zh("[process exited]", "[进程已退出]");
        zh("The terminal process has exited. Press Restart to open a new one.",
                "终端进程已退出。按“重启”打开新终端。");
        zh("Could not write to the shell: {0}", "无法写入 shell：{0}");
        zh("This problem has no file associated with it", "此问题没有关联的文件");

        // --- settings panel chrome ---
        zh("Workbench", "工作台");
        zh("Text Editor", "文本编辑器");
        zh("Files", "文件");
        zh("Window", "窗口");
        zh("Workspace", "工作区");
        zh("Search settings", "搜索设置");
        zh("Settings are stored in {0} and applied immediately.",
                "设置保存在 {0} 中，修改后立即生效。");

        // --- editor tabs, breadcrumbs and the find/replace bar ---
        zh("No editors open", "没有打开的编辑器");
        zh("Unsaved", "未保存");
        zh("{0}  (unsaved)", "{0}  （未保存）");
        zh("Run File", "运行文件");
        zh("More Actions...", "更多操作...");
        zh("Toggle Replace", "切换替换");
        zh("Match Case", "区分大小写");
        zh("Match Whole Word", "全字匹配");
        zh("Use Regular Expression", "使用正则表达式");
        zh("Previous Match (Shift+Enter)", "上一个匹配项 (Shift+Enter)");
        zh("Next Match (Enter)", "下一个匹配项 (Enter)");
        zh("Close (Esc)", "关闭 (Esc)");
        zh("Replace All", "全部替换");
        zh("No results", "无结果");
        zh("Bad regex", "正则表达式无效");
        zh("of {0}", "共 {0} 项");
        zh("{0} of {1}", "第 {0} 项，共 {1} 项");
        zh("{0} replaced", "已替换 {0} 处");

        // --- quick open and the shortcuts sheet ---
        zh("Show all commands...", "显示所有命令...");
        zh("Go to file...", "转到文件...");
        zh("Go to symbol...", "转到符号...");
        zh("Go to line...", "转到行...");
        zh("Show keyboard shortcuts...", "显示键盘快捷方式...");
        zh("No matching commands", "没有匹配的命令");
        zh("No matching files", "没有匹配的文件");
        zh("No matching results", "没有匹配的结果");
        zh("No matching shortcuts", "没有匹配的快捷键");
        zh("{0} commands", "{0} 个命令");
        zh("{0} files", "{0} 个文件");
        zh("{0} symbols", "{0} 个符号");
        zh("Keyboard shortcuts", "键盘快捷方式");
        zh("Enter to open, Tab to switch, Esc to dismiss", "Enter 打开，Tab 切换，Esc 关闭");
        zh("Go to Line {0}", "转到第 {0} 行");

        // --- search across files ---
        zh("files to include", "要包含的文件");
        zh("files to exclude", "要排除的文件");
        zh("Toggle Details", "切换详细信息");
        zh("Invalid pattern: ", "无效的模式：");
        zh("Open a folder to search across files", "请先打开一个文件夹以跨文件搜索");
        zh("Searching...", "正在搜索...");
        zh("Search failed: ", "搜索失败：");
        zh("No results found", "未找到结果");
        zh("No results found in the workspace", "工作区中未找到结果");
        zh("{0} results in {1} files", "在 {1} 个文件中找到 {0} 个结果");
        zh("(limit reached)", "（已达上限）");
        zh("Replace in Files", "在文件中替换");
        zh("Replace {0} occurrences across {1} files?\n\nThis overwrites the files on disk.",
                "在 {1} 个文件中替换 {0} 处匹配？\n\n这将覆盖磁盘上的文件。");
        zh("Could not write ", "无法写入 ");
        zh("Replaced {0} occurrences in {1} files", "已在 {1} 个文件中替换 {0} 处匹配");
        zh("Replaced in ", "已替换 ");
        zh("Replace All in File", "在文件中全部替换");
        zh("Open Match", "打开匹配项");
        zh("<html><b>Line {0}</b><br>{1}</html>", "<html><b>第 {0} 行</b><br>{1}</html>");
        zh("Nothing to replace", "没有可替换的内容");

        // --- source control ---
        zh("Commit All", "全部提交");
        zh("More Actions", "更多操作");
        zh("Commit message (Ctrl+Enter to commit)", "提交信息（按 Ctrl+Enter 提交）");
        zh("Commit", "提交");
        zh("Commit Options", "提交选项");
        zh("Open a folder to see source control", "请先打开一个文件夹以查看源代码管理");
        zh("{0} changes, {1} staged", "{0} 个更改，{1} 个已暂存");
        zh("{0} changes", "{0} 个更改");
        zh("No changes", "没有更改");
        zh("Commit the staged changes", "提交已暂存的更改");
        zh("Enter a commit message first", "请先输入提交信息");
        zh("Stage some changes first", "请先暂存一些更改");
        zh("Enter a commit message", "请输入提交信息");
        zh("Nothing is staged. Stage all changes and commit them?",
                "没有暂存的更改。是否暂存所有更改并提交？");
        zh("Stage All and Commit", "暂存全部并提交");
        zh("Committed: ", "已提交：");
        zh("stage all and commit", "暂存全部并提交");
        zh("stage all", "暂存全部");
        zh("unstage all", "取消暂存全部");
        zh("Discard All Changes", "放弃所有更改");
        zh("Discard every unstaged change? This cannot be undone.",
                "放弃所有未暂存的更改？此操作无法撤销。");
        zh("Discarded changes in {0} files", "已放弃 {0} 个文件中的更改");
        zh("Could not {0}: {1}", "无法{0}：{1}");
        zh("create branch", "创建分支");
        zh("switch to ", "切换到 ");
        zh("Stage All Changes", "暂存所有更改");
        zh("Unstage All Changes", "取消暂存所有更改");
        zh("Amend Last Commit...", "修改上次提交...");
        zh("Pull", "拉取");
        zh("Push", "推送");
        zh("pull", "拉取");
        zh("push", "推送");
        zh("amend", "修改提交");
        zh("Discard Changes", "放弃更改");
        zh("Open Changes", "打开更改");
        zh("Unstage Changes", "取消暂存更改");
        zh("Stage Changes", "暂存更改");
        zh("Delete the untracked file \"{0}\"?", "确定要删除未跟踪的文件“{0}”吗？");
        zh("Discard the changes made to \"{0}\"?\n\nThis cannot be undone.",
                "放弃对“{0}”所做的更改？\n\n此操作无法撤销。");
        zh("Staged Changes", "已暂存的更改");
        zh("Changes", "更改");
        zh("(staged)", "（已暂存）");

        // --- run and debug panel ---
        zh("Refresh Configurations", "刷新配置");
        zh("Remove All", "全部移除");
        zh("No runnable files found in this folder.", "此文件夹中未找到可运行的文件。");
        zh("Launch Configurations: {0}", "启动配置：{0}");
        zh("No breakpoints. Click the left gutter of a file to add one.",
                "没有断点。单击文件左侧的装订线可添加断点。");
        zh("Breakpoints: {0}", "断点：{0}");
        zh("Running {0}...", "正在运行 {0}...");
        zh("No language toolchains were found on PATH.", "在 PATH 中未找到任何语言工具链。");
        zh("Enable or disable this breakpoint", "启用或禁用此断点");
        zh("Remove breakpoint", "移除断点");

        // --- accounts ---
        zh("Accounts", "账户");
        zh("Add Local Account", "添加本地账户");
        zh("Sign in with GitHub", "使用 GitHub 登录");
        zh("Sign Out", "退出登录");
        zh("Sign out of this account?", "退出此账户？");
        zh("Switch to this Account", "切换到此账户");
        zh("Remove Account", "移除账户");
        zh("Remove this account?", "移除此账户？");
        zh("No accounts yet", "暂无账户");
        zh("Signed in as {0}", "已登录为 {0}");
        zh("Not signed in", "未登录");
        zh("Local account", "本地账户");
        zh("GitHub account", "GitHub 账户");
        zh("User name", "用户名");
        zh("Password", "密码");
        zh("Confirm password", "确认密码");
        zh("The two passwords do not match.", "两次输入的密码不一致。");
        zh("Enter a user name and a password.", "请输入用户名和密码。");
        zh("Signed in", "已登录");
        zh("Signed out", "已退出登录");
        zh("Account switched", "已切换账户");
        zh("Show the accounts view", "显示账户视图");
        zh("Signed in with GitHub as {0}", "已通过 GitHub 登录为 {0}");
        zh("GitHub sign-in is not configured.",
                "尚未配置 GitHub 登录。");
        zh("To enable it, register an OAuth App on GitHub and paste its client id into the "
                        + "\"account.githubClientId\" setting. No client secret is needed.",
                "要启用该功能，请在 GitHub 上注册一个 OAuth 应用，并将其 client id 填入 "
                        + "\"account.githubClientId\" 设置。无需 client secret。");
        zh("Copy Code and Open Browser", "复制代码并打开浏览器");
        zh("Waiting for authorization...", "正在等待授权...");
        zh("Expires in {0} seconds", "{0} 秒后过期");
        zh("Authorization cancelled.", "授权已取消。");
        zh("Authorization expired. Try again.", "授权已过期，请重试。");
        zh("Authorization was denied.", "授权被拒绝。");
        zh("Signed in to GitHub.", "已登录 GitHub。");
        zh("Don't save the token (this session only)", "不保存令牌（仅本次会话有效）");
        zh("The token is written in plain text to {0}. It is not encrypted, and it is not "
                        + "stored in the Windows credential store: this is a pure Java application "
                        + "and has no access to it.",
                "令牌将以明文写入 {0}。它没有加密，也没有保存在 Windows 凭据管理器中："
                        + "本程序是纯 Java 应用，无法访问凭据管理器。");
        zh("Clear Stored Token", "清除已保存的令牌");
        zh("Stored token cleared.", "已清除保存的令牌。");

        // --- plugins ---
        zh("Plugins", "插件");
        zh("Installed", "已安装");
        zh("Enabled", "已启用");
        zh("Disabled", "已禁用");
        zh("Enable", "启用");
        zh("Disable", "禁用");
        zh("Uninstall", "卸载");
        zh("Install from jar...", "从 jar 安装...");
        zh("Plugins Folder", "插件目录");
        zh("Open Plugins Folder", "打开插件目录");
        zh("Reload Plugins", "重新加载插件");
        zh("Plugins reloaded", "已重新加载插件");
        zh("No plugins installed", "未安装任何插件");
        zh("Failed to load", "加载失败");
        zh("{0} plugins, {1} failed", "{0} 个插件，{1} 个加载失败");
        zh("{0} plugins", "{0} 个插件");
        zh("Uninstall {0}?", "卸载 {0}？");
        zh("This deletes the plugin's files from disk. This cannot be undone.",
                "这将从磁盘删除该插件的文件，且无法撤销。");
        zh("Not a valid plugin: plugin.json is missing.", "不是有效的插件：缺少 plugin.json。");
        zh("Could not install the plugin.", "无法安装该插件。");
        zh("Plugin installed. Restart or reload to activate it.", "插件已安装。重启或重新加载后生效。");
        zh("Contributed by {0}", "由 {0} 提供");
        zh("Commands", "命令");
        zh("Themes", "主题");
        zh("Languages", "语言");
        zh("Manage Extensions", "管理扩展");

        // --- menu entries and messages that tie the two together ---
        zh("Manage Accounts", "管理账户");
        zh("Add Local Account...", "添加本地账户...");
        zh("Sign in with GitHub...", "使用 GitHub 登录...");
        zh("Signed in as {0}.", "已登录为 {0}。");
        zh("Signed out. This workbench is now empty.", "已退出登录。此工作区现在为空。");
        zh("Language: {0}", "语言：{0}");
        zh("{0} plugin(s) loaded, {1} command(s) contributed.",
                "已加载 {0} 个插件，贡献了 {1} 条命令。");

        // --- accounts, continued ---
        zh("The account is checked on this machine only. The password itself is never stored - "
                        + "only a PBKDF2 hash of it.",
                "此账户仅在本机校验。密码本身不会被保存——只保存它的 PBKDF2 哈希值。");
        zh("Add a local account checked on this machine, or sign in with GitHub.",
                "添加一个在本机校验的本地账户，或使用 GitHub 登录。");
        zh("Accounts are stored in {0}.", "账户保存在 {0}。");
        zh("Clear the saved GitHub token for \"{0}\"? You will need to sign in again.",
                "清除 \"{0}\" 已保存的 GitHub 令牌？你将需要重新登录。");
        zh("Removed {0}.", "已移除 {0}。");
        zh("not saved to disk", "未保存到磁盘");
        zh("Could not remove the account: ", "无法移除账户：");
        zh("An account listener failed: ", "账户监听器出错：");
        zh("Creating the account...", "正在创建账户...");
        zh("That name is already taken. Choose another.", "该名称已被占用，请换一个。");

        // --- GitHub device flow ---
        zh("Connect this app to your GitHub account with a short code.",
                "用一段短代码将此应用连接到你的 GitHub 账户。");
        zh("Sign in with GitHub instead", "改用 GitHub 登录");
        zh("Use a local account instead", "改用本地账户");
        zh("Enter this code on GitHub:", "在 GitHub 上输入此代码：");
        zh("Code copied. Enter it on GitHub.", "代码已复制。请在 GitHub 上输入。");
        zh("Requesting a sign-in code from GitHub...", "正在向 GitHub 申请登录代码...");
        zh("Fetching your GitHub profile...", "正在获取你的 GitHub 个人资料...");
        zh("GitHub asked us to slow down; still waiting.", "GitHub 要求放慢轮询速度，仍在等待。");
        zh("Sign-in failed.", "登录失败。");
        zh("Could not open a browser. Open {0} and enter the code yourself.",
                "无法打开浏览器。请自行打开 {0} 并输入代码。");
        zh("GitHub did not return a usable account.", "GitHub 未返回可用的账户。");
        zh("GitHub did not return a login name.", "GitHub 未返回登录名。");
        zh("GitHub did not return a device code: ", "GitHub 未返回设备代码：");
        zh("GitHub rejected the device code.", "GitHub 拒绝了该设备代码。");
        zh("GitHub rejected the client id. Check the account.githubClientId setting.",
                "GitHub 拒绝了该 client id。请检查 account.githubClientId 设置。");
        zh("GitHub rejected the request: the device flow is not enabled for this client id.",
                "GitHub 拒绝了该请求：此 client id 未启用设备流程。");
        zh("GitHub rejected the token (HTTP ", "GitHub 拒绝了该令牌（HTTP ");
        zh("GitHub returned HTTP ", "GitHub 返回 HTTP ");
        zh("GitHub returned: ", "GitHub 返回：");
        zh("Could not reach GitHub: ", "无法连接 GitHub：");
        zh("The request was interrupted.", "请求被中断。");
        zh("Sign-in was cancelled.", "登录已取消。");
        zh("The code expired before it was authorized.", "代码在授权之前已过期。");
        zh("Access was denied on GitHub.", "在 GitHub 上被拒绝授权。");

        // --- extensions view ---
        zh("Plugin jar", "插件 jar");
        zh("Reload", "重新加载");
        zh("Open plugins folder", "打开插件文件夹");
        zh("Uninstall Extension", "卸载扩展");
        zh("Uninstalled {0}", "已卸载 {0}");
        zh("Could not uninstall {0}.", "无法卸载 {0}。");
        zh("Installed {0}", "已安装 {0}");
        zh("Could not install {0}. The plugin was not copied into {1}.",
                "无法安装 {0}。插件未被复制到 {1}。");
        zh("Uninstall \"{0}\"?\n\nIts files will be deleted from disk ({1}). "
                        + "This cannot be undone.",
                "确定要卸载“{0}”吗？\n\n其文件将从磁盘上删除（{1}）。此操作无法撤销。");
        zh("Delete {0} from disk", "从磁盘删除 {0}");
        zh("jar", "jar");
        zh("directory", "目录");
        zh("unknown", "未知");
        zh("jar (declarative)", "jar（声明式）");
        zh("directory (declarative)", "目录（声明式）");
        zh("The extensions view hit an error: {0}", "扩展视图发生错误：{0}");
        zh("{0} extensions", "{0} 个扩展");
        zh("{0} extensions, {1} failed", "{0} 个扩展，{1} 个失败");
        zh("No extensions installed yet. Plugins are loaded from {0}. Add a jar containing a "
                        + "plugin.json manifest, or a folder containing a declarative plugin.json.",
                "尚未安装任何扩展。插件从 {0} 加载。可放入包含 plugin.json 清单的 jar，"
                        + "或包含声明式 plugin.json 的文件夹。");

        // --- gaps found by a coverage sweep of the older panels ---
        // These were never translated; the table's own check proves consistency, not coverage, so
        // nothing had ever compared the table against the strings the code actually asks for.
        zh("New Folder...", "新建文件夹...");
        zh("Delete File", "删除文件");
        zh("Discard", "放弃更改");
        zh("stage ", "暂存 ");
        zh("unstage ", "取消暂存 ");
        zh("Undo", "撤销");
        zh("Redo", "重做");
        zh("Clear All", "全部清除");
        zh("Reset to Defaults", "恢复默认设置");
        zh("Open settings.properties", "打开 settings.properties");
        zh("Save Failed", "保存失败");
        zh("Do you want to save the changes you made to ", "是否保存对以下文件所做的更改：");
        zh("?\n\nYour changes will be lost if you don't save them.",
                "？\n\n如果不保存，这些更改将会丢失。");

        // --- folding, suggestions, symbol navigation and Zen Mode ---
        zh("Fold", "折叠");
        zh("Unfold", "展开");
        zh("Toggle Fold", "切换折叠");
        zh("Fold All", "全部折叠");
        zh("Unfold All", "全部展开");
        zh("Trigger Suggest", "触发建议");
        zh("Rename Symbol", "重命名符号");
        zh("Go to Definition", "转到定义");
        zh("Find All References", "查找所有引用");
        zh("Toggle Zen Mode", "切换禅模式");
        zh("{0} result(s)", "{0} 个结果");
        zh("snippet", "代码片段");
        zh("keyword", "关键字");
        zh("control", "控制");
        zh("type", "类型");
        zh("constant", "常量");
        zh("function", "函数");
        zh("word", "单词");
        zh("class", "类");
        zh("method", "方法");
        zh("heading", "标题");
        zh("rule", "规则");
        zh("Nothing to fold on this line", "此行没有可折叠的内容");
        zh("Open a file to fold", "请先打开一个文件再折叠");
        zh("Nothing to fold in this file", "此文件没有可折叠的内容");
        zh("{0} block(s) folded", "已折叠 {0} 个代码块");
        zh("Open a file first", "请先打开一个文件");
        zh("Put the caret on a symbol first", "请先把光标放在一个符号上");
        zh("No definition found for {0}", "未找到 {0} 的定义");
        zh("No references found for {0}", "未找到 {0} 的引用");
        zh("Searching for {0}...", "正在查找 {0}...");
        zh("Definitions of {0}", "{0} 的定义");
        zh("References to {0}", "{0} 的引用");
        zh("Rename {0} to:", "将 {0} 重命名为：");
        zh("That is not a valid identifier: ", "不是有效的标识符：");
        zh("Nothing to rename for {0}", "{0} 没有可重命名的内容");
        zh("Renamed {0} occurrence(s) in {1} file(s)", "已在 {1} 个文件中重命名 {0} 处");
        zh("Could not write ", "无法写入 ");
        zh("Zen Mode on. Ctrl+K Z leaves it.", "已进入禅模式。按 Ctrl+K Z 退出。");
        zh("Zen Mode off.", "已退出禅模式。");
    }
}
