package com.codestudio.api;

import com.codestudio.core.Language;
import com.codestudio.core.Theme;
import java.nio.file.Path;
import javax.swing.Icon;
import javax.swing.JComponent;

/**
 * What a plugin is handed when it activates: the contribution points, plus a few services.
 *
 * <p>Every {@code add*} method may be called during {@link CodeStudioPlugin#activate} or later —
 * contributions are collected and then applied by the host, so nothing here blocks or requires a
 * particular thread. Call the {@code add*} methods from the event dispatch thread if they need to
 * take effect immediately; from another thread they will appear the next time the host installs
 * contributions.
 *
 * <p>This interface lives in its own package because it is the one place that needs both the model
 * layer ({@link Theme}, {@link Language}) and Swing. The {@code core} package deliberately depends
 * on neither Swing nor the UI, and this separation keeps that true.
 */
public interface PluginContext {

    /** The id of the plugin this context belongs to, as returned by {@link CodeStudioPlugin#id()}. */
    String pluginId();

    /**
     * A directory private to this plugin, created on demand. Use it for caches and state rather than
     * writing next to the jar, which may be read-only.
     */
    Path dataDirectory();

    /** The open folder, or null when none is open. */
    Path workspaceRoot();

    /** Whether the UI is currently in Chinese, for a plugin that wants to localise its own text. */
    boolean isChinese();

    /**
     * Adds a command to the command palette.
     *
     * @param id     a unique id, conventionally prefixed with the plugin id
     * @param category the palette grouping, also used as the submenu name under the Plugins menu
     * @param title  the label shown in the palette
     * @param keybinding a key stroke such as {@code "ctrl+alt+h"}, or "" for none
     */
    void addCommand(String id, String category, String title, String keybinding, Runnable action);

    /**
     * Registers a color theme. Must be called with the colors already filled in; see
     * {@link Theme#copyOf} to start from a built-in rather than naming all forty colors.
     *
     * <p>Returns false, without throwing, when the id is blank, is "dark" or "light", or is already
     * taken. A plugin cannot shadow a built-in theme.
     */
    boolean addTheme(String id, String name, Theme theme);

    /**
     * Registers a language.
     *
     * <p>The language must use {@link Language.Lexer#GENERIC}, {@link Language.Lexer#PYTHON} or
     * {@link Language.Lexer#SHELL}; those tokenize purely from configuration. Returns false when the
     * id is taken or the lexer is one of the hand-written kinds.
     */
    boolean addLanguage(Language language);

    /**
     * Adds a view to the activity bar and sidebar.
     *
     * @param icon shown in the activity bar, or null to draw a neutral default. Plugins pass a
     *             Swing {@link Icon}; the IDE's built-in named icons are not part of this API,
     *             because that name set is closed and would be a trap.
     */
    void addView(String id, String title, Icon icon, JComponent view);

    /**
     * Adds an item to the status bar.
     *
     * @param onClick run when the item is clicked, or null for an item that does nothing
     */
    void addStatusItem(String id, String text, Runnable onClick);

    /** Shows a transient notification. */
    void showMessage(String message);

    /** Shows an error notification, with the stack trace written to the Output channel. */
    void showError(String message, Throwable cause);

    /** Writes a line to this plugin's channel in the Output view. */
    void log(String message);
}
