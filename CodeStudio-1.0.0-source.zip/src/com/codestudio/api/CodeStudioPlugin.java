package com.codestudio.api;

/**
 * The interface a CodeStudio plugin implements.
 *
 * <p>A plugin is a jar containing a {@code plugin.json} manifest that names this class, plus the
 * class itself and anything it needs. It is loaded in-process through a {@link java.net.URLClassLoader}
 * whose parent is the application's own loader, so the plugin sees the same {@code core} and Swing
 * classes the IDE does and must not bundle its own copies of them.
 *
 * <h2>Writing one</h2>
 *
 * <pre>{@code
 * public class MyPlugin implements CodeStudioPlugin {
 *     private PluginContext ctx;
 *
 *     public String id()      { return "com.example.myplugin"; }
 *     public String name()    { return "My Plugin"; }
 *     public String version() { return "1.0.0"; }
 *
 *     public void activate(PluginContext ctx) {
 *         this.ctx = ctx;
 *         ctx.addCommand(id() + ".hello", "My Plugin", "Say Hello", "", ctx::showMessage);
 *     }
 *
 *     public void deactivate() { }
 * }
 * }</pre>
 *
 * <p>Package it with the manifest at the jar root:
 *
 * <pre>{@code
 * jar --create --file myplugin.jar --main-class ... -C build .
 * }</pre>
 *
 * and drop it in {@code ~/.codestudio/plugins/}. A plugin jar needs no {@code Main-Class}; the
 * manifest's {@code main} field names the entry class instead.
 *
 * <h2>Failure is contained</h2>
 *
 * <p>If {@link #activate} throws, that plugin is marked failed and the exception is reported
 * against it alone — the IDE keeps running and the other plugins still load. There is no need to
 * catch defensively around every call.
 *
 * <h2>What a plugin is not</h2>
 *
 * <p>This is not VS Code's extension model. VS Code extensions are JavaScript running in a Node
 * host; supporting those would mean reimplementing that host. A CodeStudio plugin is Java, and its
 * reach is limited to the contributions {@link PluginContext} offers — commands, themes, languages,
 * sidebar views and status bar items. It cannot add a tokenizer for a language whose lexer is
 * hand-written, and it cannot contribute code completion, because the editor has no completion
 * engine to contribute to.
 */
public interface CodeStudioPlugin {

    /** A stable, unique id, conventionally reverse-DNS: {@code com.example.myplugin}. */
    String id();

    /** The name shown in the extensions view. */
    String name();

    /** A version string. Not parsed; shown as-is. */
    String version();

    default String description() {
        return "";
    }

    /**
     * Called once after the plugin is constructed and its context is ready. Register contributions
     * here.
     *
     * @throws Exception any failure, which is caught, recorded against this plugin, and shown in
     *                   the extensions view; other plugins are unaffected
     */
    default void activate(PluginContext context) throws Exception {
    }

    /**
     * Called when the plugin is disabled, unloaded or the IDE is closing. Contributions are removed
     * by the host; a plugin only needs to release resources of its own, such as threads or files.
     */
    default void deactivate() {
    }
}
