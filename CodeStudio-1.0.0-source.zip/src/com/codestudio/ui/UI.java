package com.codestudio.ui;

import com.codestudio.core.Theme;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JToolTip;
import javax.swing.Scrollable;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

/** Small shared UI helpers and themed widgets. */
public final class UI {

    /**
     * The interface font family, resolved at start-up.
     *
     * <p>It must be a family that covers Chinese, and that is not cosmetic. Java2D draws a missing
     * glyph as an empty box; it does no font fallback for a physical family. {@code Segoe UI} — the
     * obvious choice on Windows — has no CJK coverage at all, so Chinese text rendered in it comes
     * out as a row of boxes. Only families such as {@code Microsoft YaHei UI} carry both scripts.
     *
     * <p>This is resolved once and never varies with the language setting. A family that changed
     * with the language would leave the font already installed on every long-lived component stale
     * — switching back would show boxes — so the single CJK-capable family is the safe choice. The
     * Latin letterforms of YaHei are close enough to Segoe UI that the difference is not noticeable
     * at interface sizes, and it is what Windows itself uses for its own Chinese UI.
     *
     * <p>The logical families ({@code SansSerif} and friends) do receive Windows font linking and so
     * can also draw Chinese; physical families do not. That is why the last candidate is logical.
     */
    public static final String[] UI_CANDIDATES = {
        "Microsoft YaHei UI", "微软雅黑", "Noto Sans SC", "Source Han Sans SC",
        "Noto Sans CJK SC", "Microsoft JhengHei UI", "SansSerif"
    };

    public static final String UI_FAMILY = resolveUi();
    public static final String MONO_FAMILY = "Consolas";
    public static final String[] MONO_CANDIDATES = {
        "Consolas", "JetBrains Mono", "Cascadia Mono", "Fira Code", "Source Code Pro",
        "DejaVu Sans Mono", "Monospaced"
    };

    /** Text used to probe a font for Chinese coverage; every character is common in the UI. */
    private static final String CJK_PROBE = "文件编辑视图终端帮助设置";

    private UI() {
    }

    /** The first installed interface family that can actually draw Chinese. */
    private static String resolveUi() {
        java.util.List<String> installed = installedFamilies();
        for (String candidate : UI_CANDIDATES) {
            if (installed.contains(candidate)) {
                return candidate;
            }
        }
        return Font.SANS_SERIF;
    }

    private static java.util.List<String> installedFamilies() {
        return java.util.Arrays.asList(java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment()
                .getAvailableFontFamilyNames());
    }

    /**
     * Whether a font can draw Chinese. A warning is worth raising when this is false, because the
     * whole interface would then be unreadable boxes rather than merely off-brand.
     */
    public static boolean canDrawChinese(Font font) {
        return font.canDisplayUpTo(CJK_PROBE) < 0;
    }

    /** Whether the resolved interface font draws Chinese, for the self test and the about box. */
    public static boolean uiFontHasChinese() {
        return canDrawChinese(ui(12f));
    }

    public static Font ui(float size) {
        return new Font(UI_FAMILY, Font.PLAIN, Math.round(size));
    }

    public static Font uiBold(float size) {
        return new Font(UI_FAMILY, Font.BOLD, Math.round(size));
    }

    public static Font ui(float size, int style) {
        return new Font(UI_FAMILY, style, Math.round(size));
    }

    public static Font mono(String family, float size) {
        return new Font(family == null || family.isBlank() ? MONO_FAMILY : family, Font.PLAIN, Math.round(size));
    }

    /** Resolves an installed monospaced font, falling back to the JVM default. */
    public static String resolveMono(String preferred) {
        java.util.List<String> installed = installedFamilies();
        if (preferred != null && !preferred.isBlank() && installed.contains(preferred)) {
            return preferred;
        }
        for (String cand : MONO_CANDIDATES) {
            if (installed.contains(cand)) {
                return cand;
            }
        }
        return Font.MONOSPACED;
    }

    public static Border line(Color c) {
        return BorderFactory.createLineBorder(c);
    }

    public static Border pad(int top, int left, int bottom, int right) {
        return BorderFactory.createEmptyBorder(top, left, bottom, right);
    }

    public static Border matte(Color c, int t, int l, int b, int r) {
        return BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(t, l, b, r, c),
                BorderFactory.createEmptyBorder(0, 0, 0, 0));
    }

    public static String esc(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    public static String hex(Color c) {
        return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
    }

    public static Color alpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), a);
    }

    public static Color mix(Color a, Color b, float ratio) {
        float r = Math.max(0, Math.min(1, ratio));
        return new Color(
                Math.round(a.getRed() + (b.getRed() - a.getRed()) * r),
                Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * r),
                Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * r));
    }

    public static Color isDark(Color c) {
        double lum = (0.299 * c.getRed() + 0.587 * c.getGreen() + 0.114 * c.getBlue()) / 255.0;
        return lum < 0.5 ? Color.WHITE : Color.BLACK;
    }

    /* ------------------------------------------------------------------ */

    /** A flat, theme aware button that paints its own hover / pressed state. */
    public static class FlatButton extends JButton {
        private Theme theme;
        private boolean hoverPainted = true;

        public FlatButton(String text, Icon icon, Theme theme) {
            super(text, icon);
            this.theme = theme;
            setBorderPainted(false);
            setContentAreaFilled(false);
            setFocusPainted(false);
            setOpaque(false);
            setForeground(theme.sidebarFg);
            setFont(ui(12f));
            setMargin(new Insets(0, 0, 0, 0));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        public void setTheme(Theme t) {
            this.theme = t;
            repaint();
        }

        public void setHoverPainted(boolean b) {
            this.hoverPainted = b;
        }

        @Override
        protected void paintComponent(Graphics g) {
            if (hoverPainted && (getModel().isRollover() || getModel().isPressed())) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? UI.mix(theme.hover, theme.editorFg, 0.08f) : theme.hover);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.dispose();
            }
            super.paintComponent(g);
        }
    }

    public static JButton iconButton(Icon icon, String tooltip, Theme theme, Runnable action) {
        FlatButton b = new FlatButton("", icon, theme);
        b.setToolTipText(tooltip);
        b.setPreferredSize(new Dimension(26, 26));
        b.setMaximumSize(new Dimension(26, 26));
        if (action != null) {
            b.addActionListener(e -> action.run());
        }
        return b;
    }

    public static JButton smallButton(String text, Theme theme, Runnable action) {
        FlatButton b = new FlatButton(text, null, theme);
        b.setBorder(BorderFactory.createCompoundBorder(line(theme.inputBorder),
                BorderFactory.createEmptyBorder(2, 8, 2, 8)));
        b.setForeground(theme.panelFg);
        b.setOpaque(false);
        if (action != null) {
            b.addActionListener(e -> action.run());
        }
        return b;
    }

    public static JButton primaryButton(String text, Theme theme, Runnable action) {
        FlatButton b = new FlatButton(text, null, theme);
        b.setForeground(Color.WHITE);
        b.setOpaque(true);
        b.setBackground(theme.accent);
        b.setBorder(BorderFactory.createEmptyBorder(5, 14, 5, 14));
        b.setHoverPainted(false);
        if (action != null) {
            b.addActionListener(e -> action.run());
        }
        return b;
    }

    public static JLabel label(String text, Color fg, Font font) {
        JLabel l = new JLabel(text);
        l.setForeground(fg);
        l.setFont(font);
        return l;
    }

    public static JPanel row(java.awt.LayoutManager lm, Color bg) {
        JPanel p = new JPanel(lm);
        p.setBackground(bg);
        p.setOpaque(bg != null);
        return p;
    }

    /** Adds a hover background highlight to any component. */
    public static void hoverHighlight(JComponent c, Color normal, Color hover) {
        c.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                c.setBackground(hover);
                c.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                c.setBackground(normal);
                c.repaint();
            }
        });
    }

    public static JScrollPane scroll(Component view, Theme theme) {
        JScrollPane sp = new JScrollPane(view);
        sp.setBorder(null);
        sp.setViewportBorder(null);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.getHorizontalScrollBar().setUnitIncrement(16);
        styleScrollBar(sp.getVerticalScrollBar(), theme);
        styleScrollBar(sp.getHorizontalScrollBar(), theme);
        return sp;
    }

    /**
     * The vertical stack of rows a sidebar view is built from, ready for {@code list.add(row)}.
     *
     * <p>The panel is {@link Scrollable} and tracks the viewport width, and that is the point of it.
     * {@link javax.swing.ViewportLayout} sizes a plain, non-scrollable view to its <em>preferred</em>
     * width and then centres it, so a column of rows narrower than the sidebar ends up floating in
     * the middle of it. Tracking the width also means anything that wraps inside a row wraps to the
     * width it actually has, rather than to the width of its longest unwrapped line.
     *
     * <p>The caller sets the background and border; both differ between panels.
     */
    public static JPanel column() {
        JPanel p = new Column();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        return p;
    }

    private static final class Column extends JPanel implements Scrollable {

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(java.awt.Rectangle visible, int orientation, int direction) {
            return 18;
        }

        @Override
        public int getScrollableBlockIncrement(java.awt.Rectangle visible, int orientation, int direction) {
            return visible.height;
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }
    }

    public static void styleScrollBar(JScrollBar bar, Theme theme) {
        bar.setUI(new FlatScrollBarUI(theme));
        bar.setPreferredSize(new Dimension(11, 11));
        bar.setBackground(theme.panelBg);
    }

    public static void themeScrollBar(JScrollPane sp, Theme theme) {
        sp.getVerticalScrollBar().setUI(new FlatScrollBarUI(theme));
        sp.getHorizontalScrollBar().setUI(new FlatScrollBarUI(theme));
    }

    /** Thin, arrow-less, overlay style scrollbar. */
    public static class FlatScrollBarUI extends BasicScrollBarUI {
        private final Theme theme;

        public FlatScrollBarUI(Theme theme) {
            this.theme = theme;
        }

        @Override
        protected void configureScrollBarColors() {
            this.thumbColor = theme.scrollbar;
            this.trackColor = theme.panelBg;
        }

        @Override
        protected JButton createDecreaseButton(int orientation) {
            return zeroButton();
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            return zeroButton();
        }

        private JButton zeroButton() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            b.setMinimumSize(new Dimension(0, 0));
            b.setMaximumSize(new Dimension(0, 0));
            b.setBorder(BorderFactory.createEmptyBorder());
            return b;
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
            g.setColor(theme.panelBg);
            g.fillRect(r.x, r.y, r.width, r.height);
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.width <= 0 || r.height <= 0 || !scrollbar.isEnabled()) {
                return;
            }
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            boolean hover = isThumbRollover();
            g2.setColor(hover ? theme.scrollbarHover : theme.scrollbar);
            if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
                g2.fillRoundRect(r.x + 2, r.y + 2, Math.max(4, r.width - 4), r.height - 4, 6, 6);
            } else {
                g2.fillRoundRect(r.x + 2, r.y + 2, r.width - 4, Math.max(4, r.height - 4), 6, 6);
            }
            g2.dispose();
        }
    }

    /** A left rounded accent bar used by list rows. */
    public static void paintRounded(Graphics2D g2, Rectangle r, Color color, int arc) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(color);
        g2.fillRoundRect(r.x, r.y, r.width, r.height, arc, arc);
    }

    public static void fade(Graphics2D g2, float alpha) {
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
    }

    public static void dashedLine(Graphics2D g2, int x1, int y1, int x2, int y2, Color c) {
        Graphics2D g = (Graphics2D) g2.create();
        g.setColor(c);
        g.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1f,
                new float[]{3f, 3f}, 0f));
        g.drawLine(x1, y1, x2, y2);
        g.dispose();
    }

    /** Tooltip that respects the dark theme (default Swing tooltips look wrong). */
    public static class ThemedToolTip extends JToolTip {
        private final Theme theme;

        public ThemedToolTip(Theme theme) {
            this.theme = theme;
            setBackground(theme.widgetBg);
            setForeground(theme.panelFg);
            setFont(ui(12f));
            setBorder(BorderFactory.createCompoundBorder(line(theme.widgetBorder),
                    BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        }
    }

    public static AbstractButton setIconColor(AbstractButton b, Icon icon) {
        b.setIcon(icon);
        return b;
    }
}
