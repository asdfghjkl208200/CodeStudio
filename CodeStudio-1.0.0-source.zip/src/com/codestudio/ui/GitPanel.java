package com.codestudio.ui;

import com.codestudio.core.Git;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/** Source control view backed by the git command line client. */
public class GitPanel extends JPanel implements ThemeAware, ActiveAware {

    public interface Actions {
        void openFile(File file);

        void openDiff(File file, boolean staged);

        void notify(String message, boolean error);

        void revealInOS(File file);

        void filesChanged(List<File> files);
    }

    private static final String STAGED_GROUP = "Staged Changes";
    private static final String CHANGES_GROUP = "Changes";

    private final Settings settings;
    private final Workspace workspace;
    private Theme theme;
    private Actions actions;

    private final SectionHeader header;
    private final JLabel branchLabel = new JLabel(Strings.get("No repository"));
    private final JLabel branchIcon = new JLabel();
    private final JPanel branchRow;
    private final JTextArea message = new JTextArea(3, 20);
    private final JButton commitButton;
    private JButton commitOptionsButton;
    private final JLabel hint = new JLabel(" ");

    private final DefaultMutableTreeNode root = new DefaultMutableTreeNode("root");
    private final DefaultTreeModel model = new DefaultTreeModel(root);
    private final JTree tree = new JTree(model);
    private final JScrollPane treeScroll;

    private final Timer poll;
    private Git.Status current = new Git.Status();
    private boolean busy;
    private String lastSignature = "";

    public GitPanel(Settings settings, Workspace workspace, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.workspace = workspace;
        this.theme = theme;
        setBackground(theme.sidebarBg);

        header = new SectionHeader("Source Control", theme);
        header.addAction("refresh", "Refresh", () -> refreshAsync(true));
        header.addAction("check", "Commit All", this::commit);
        header.addAction("ellipsis", "More Actions", this::showMoreMenu);

        branchRow = new JPanel(new BorderLayout(6, 0));
        branchRow.setBackground(theme.sidebarBg);
        branchRow.setBorder(BorderFactory.createEmptyBorder(2, 10, 4, 8));
        branchRow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        branchIcon.setIcon(Icons.of("git-branch", 14, theme.sidebarFg));
        branchLabel.setFont(UI.ui(12.5f));
        branchLabel.setForeground(theme.sidebarFg);
        branchRow.add(branchIcon, BorderLayout.WEST);
        branchRow.add(branchLabel, BorderLayout.CENTER);
        branchRow.setToolTipText(Strings.get("Click to switch branch"));
        branchRow.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                showBranchMenu();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                branchRow.setBackground(theme.hover);
                branchRow.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                branchRow.setBackground(theme.sidebarBg);
                branchRow.repaint();
            }
        });

        message.setFont(UI.ui(12.5f));
        message.setBackground(theme.inputBg);
        message.setForeground(theme.inputFg);
        message.setCaretColor(theme.inputFg);
        message.setLineWrap(true);
        message.setWrapStyleWord(true);
        message.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)));
        message.setToolTipText(Strings.get("Commit message (Ctrl+Enter to commit)"));
        message.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateCommitEnabled();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateCommitEnabled();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateCommitEnabled();
            }
        });
        message.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && e.isControlDown()) {
                    e.consume();
                    commit();
                }
            }
        });

        JPanel messageBox = new JPanel(new BorderLayout(0, 4));
        messageBox.setBackground(theme.sidebarBg);
        messageBox.setBorder(BorderFactory.createEmptyBorder(0, 8, 4, 8));
        messageBox.add(message, BorderLayout.CENTER);

        commitButton = UI.primaryButton(Strings.get("Commit"), theme, this::commit);
        commitButton.setEnabled(false);
        JPanel buttons = new JPanel(new BorderLayout(4, 0));
        buttons.setBackground(theme.sidebarBg);
        buttons.add(commitButton, BorderLayout.CENTER);
        commitOptionsButton = UI.iconButton(Icons.of("ellipsis", 14, theme.sidebarFg),
                Strings.get("Commit Options"), theme, this::showCommitMenu);
        buttons.add(commitOptionsButton, BorderLayout.EAST);
        messageBox.add(buttons, BorderLayout.SOUTH);

        JPanel north = new JPanel();
        north.setLayout(new javax.swing.BoxLayout(north, javax.swing.BoxLayout.Y_AXIS));
        north.setBackground(theme.sidebarBg);
        north.add(header);
        north.add(branchRow);
        north.add(messageBox);
        JPanel sep = new JPanel();
        sep.setBackground(theme.sectionBorder);
        sep.setPreferredSize(new Dimension(10, 1));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        north.add(sep);

        tree.setRootVisible(false);
        tree.setShowsRootHandles(true);
        tree.setRowHeight(21);
        tree.setBackground(theme.sidebarBg);
        tree.setCellRenderer(new Renderer());
        tree.setToggleClickCount(-1);
        tree.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popup(e);
                } else if (e.getButton() == MouseEvent.BUTTON1) {
                    TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                    if (path != null) {
                        DefaultMutableTreeNode n = (DefaultMutableTreeNode) path.getLastPathComponent();
                        Object u = n.getUserObject();
                        if (u instanceof Group) {
                            if (tree.isExpanded(path)) {
                                tree.collapsePath(path);
                            } else {
                                tree.expandPath(path);
                            }
                        } else if (u instanceof RowEntry re && actions != null) {
                            actions.openDiff(re.entry.file, re.staged);
                        }
                    }
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popup(e);
                }
            }
        });
        tree.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    TreePath path = tree.getSelectionPath();
                    if (path != null) {
                        Object u = ((DefaultMutableTreeNode) path.getLastPathComponent()).getUserObject();
                        if (u instanceof RowEntry re && actions != null) {
                            actions.openDiff(re.entry.file, re.staged);
                        }
                    }
                }
            }
        });

        treeScroll = UI.scroll(tree, theme);
        treeScroll.getViewport().setBackground(theme.sidebarBg);

        hint.setFont(UI.ui(11.5f));
        hint.setForeground(UI.alpha(theme.sidebarFg, 180));
        hint.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 8));

        add(north, BorderLayout.NORTH);
        add(treeScroll, BorderLayout.CENTER);
        add(hint, BorderLayout.SOUTH);

        poll = new Timer(4000, e -> refreshAsync(false));
        poll.start();
        refreshAsync(true);
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    /** Restarts the polling timer; called when the panel becomes visible. */
    public void setActive(boolean active) {
        if (active) {
            poll.start();
            refreshAsync(true);
        } else {
            poll.stop();
        }
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.sidebarBg);
        header.setTheme(t);
        branchRow.setBackground(t.sidebarBg);
        message.setBackground(t.inputBg);
        message.setForeground(t.inputFg);
        message.setCaretColor(t.inputFg);
        message.setBorder(BorderFactory.createCompoundBorder(UI.line(t.inputBorder),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)));
        tree.setBackground(t.sidebarBg);
        tree.setCellRenderer(new Renderer());
        treeScroll.getViewport().setBackground(t.sidebarBg);
        UI.themeScrollBar(treeScroll, t);
        branchLabel.setForeground(t.sidebarFg);
        branchIcon.setIcon(Icons.of("git-branch", 14, t.sidebarFg));
        hint.setForeground(UI.alpha(t.sidebarFg, 180));
        repaint();
    }

    /**
     * Re-applies every visible string after a language change: the section header redoes its title
     * and action tooltips, the two text fields redo their hints, and the current repository state
     * is rendered again so the branch label, the change summary, the group rows and the per-row
     * tooltips all pick up the new language.
     */
    public void retranslate() {
        header.retranslate();
        branchRow.setToolTipText(Strings.get("Click to switch branch"));
        message.setToolTipText(Strings.get("Commit message (Ctrl+Enter to commit)"));
        commitButton.setText(Strings.get("Commit"));
        if (commitOptionsButton != null) {
            commitOptionsButton.setToolTipText(Strings.get("Commit Options"));
        }
        tree.setCellRenderer(new Renderer());
        apply(current, current.error);
        tree.repaint();
        repaint();
    }

    /* ------------------------------------------------------------------ */

    /** Reloads the repository state on a background thread. */
    public void refreshAsync(boolean explicit) {
        if (busy) {
            return;
        }
        File rootDir = workspace.getRoot();
        if (rootDir == null) {
            current = new Git.Status();
            // kept untranslated so apply() renders it once and retranslate() can render it again
            current.error = "Open a folder to see source control";
            apply(current, current.error);
            return;
        }
        busy = true;
        Thread t = new Thread(() -> {
            Git.Status s = Git.status(rootDir);
            SwingUtilities.invokeLater(() -> {
                busy = false;
                current = s;
                apply(s, s.error);
            });
        }, "git-status");
        t.setDaemon(true);
        t.start();
    }

    private void apply(Git.Status s, String error) {
        if (!s.isRepo()) {
            String problem = Strings.get(error == null || error.isBlank() ? "No repository" : error);
            branchLabel.setText(problem);
            branchLabel.setForeground(UI.alpha(theme.sidebarFg, 190));
            branchIcon.setIcon(Icons.of("git-branch", 14, UI.alpha(theme.sidebarFg, 150)));
            root.removeAllChildren();
            model.reload();
            hint.setText(error == null || error.isBlank() ? " " : problem);
            updateCommitEnabled();
            return;
        }
        String branchText = s.branch;
        if (s.ahead > 0) {
            branchText += "  ↑" + s.ahead;
        }
        if (s.behind > 0) {
            branchText += "  ↓" + s.behind;
        }
        branchLabel.setText(branchText);
        branchLabel.setForeground(theme.sidebarFg);
        branchIcon.setIcon(Icons.of("git-branch", 14, theme.sidebarFg));

        String signature = s.branch + "|" + s.entries.size() + "|" + s.entries.stream()
                .map(e -> e.letter() + Git.relativize(s.root, e.file)).sorted().reduce("", String::concat);
        boolean changed = !signature.equals(lastSignature);
        lastSignature = signature;
        if (changed) {
            rebuildTree(s);
        }

        int staged = s.staged().size();
        int total = s.entries.size();
        if (total == 0) {
            hint.setText(Strings.get("No changes"));
        } else {
            hint.setText(staged > 0
                    ? Strings.format("{0} changes, {1} staged", total, staged)
                    : Strings.format("{0} changes", total));
        }
        updateCommitEnabled();
    }

    private void rebuildTree(Git.Status s) {
        List<String> expanded = expandedGroups();
        root.removeAllChildren();

        List<Git.Entry> staged = s.staged();
        if (!staged.isEmpty()) {
            DefaultMutableTreeNode g = new DefaultMutableTreeNode(new Group(STAGED_GROUP, staged.size()));
            for (Git.Entry e : staged) {
                g.add(new DefaultMutableTreeNode(new RowEntry(e, true)));
            }
            root.add(g);
        }
        List<Git.Entry> unstaged = s.unstaged();
        if (!unstaged.isEmpty()) {
            DefaultMutableTreeNode g = new DefaultMutableTreeNode(new Group(CHANGES_GROUP, unstaged.size()));
            for (Git.Entry e : unstaged) {
                g.add(new DefaultMutableTreeNode(new RowEntry(e, false)));
            }
            root.add(g);
        }
        model.reload();
        if (expanded.isEmpty()) {
            for (int i = 0; i < tree.getRowCount(); i++) {
                tree.expandRow(i);
            }
        } else {
            for (int i = 0; i < root.getChildCount(); i++) {
                DefaultMutableTreeNode g = (DefaultMutableTreeNode) root.getChildAt(i);
                if (g.getUserObject() instanceof Group grp && expanded.contains(grp.name)) {
                    tree.expandPath(new TreePath(new Object[]{root, g}));
                }
            }
        }
        if (root.getChildCount() == 1 && expanded.isEmpty()) {
            tree.expandRow(0);
        }
    }

    private List<String> expandedGroups() {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < tree.getRowCount(); i++) {
            TreePath p = tree.getPathForRow(i);
            if (p == null || p.getPathCount() != 2) {
                continue;
            }
            if (((DefaultMutableTreeNode) p.getLastPathComponent()).getUserObject() instanceof Group g) {
                out.add(g.name);
            }
        }
        return out;
    }

    private void updateCommitEnabled() {
        boolean hasStaged = !current.staged().isEmpty();
        boolean hasMessage = !message.getText().isBlank();
        commitButton.setEnabled(hasStaged && hasMessage);
        commitButton.setToolTipText(Strings.get(hasStaged
                ? (hasMessage ? "Commit the staged changes" : "Enter a commit message first")
                : "Stage some changes first"));
    }

    /* ------------------------------------------------------------------ */
    /* actions                                                             */
    /* ------------------------------------------------------------------ */

    private void commit() {
        if (!current.isRepo()) {
            return;
        }
        String text = message.getText().trim();
        if (text.isEmpty()) {
            warn("Enter a commit message");
            return;
        }
        if (current.staged().isEmpty()) {
            int choice = Dialogs.confirm(this, theme, Strings.get("Commit"),
                    Strings.get("Nothing is staged. Stage all changes and commit them?"),
                    Strings.get("Stage All and Commit"), Strings.get("Cancel"));
            if (choice != 0) {
                return;
            }
            runGit(Strings.get("stage all and commit"), "add", "-A", "-u");
        }
        String[] result = new String[1];
        Thread t = new Thread(() -> {
            StringBuilder out = new StringBuilder();
            StringBuilder err = new StringBuilder();
            int code = Git.exec(current.root, out, err, "commit", "-m", text);
            result[0] = code == 0 ? "" : (err.toString().trim().isEmpty()
                    ? out.toString().trim() : err.toString().trim());
            SwingUtilities.invokeLater(() -> {
                if (result[0].isEmpty()) {
                    message.setText("");
                    if (actions != null) {
                        actions.notify(Strings.get("Committed: ") + firstLine(text), false);
                    }
                } else {
                    warn(result[0]);
                }
                refreshAsync(true);
            });
        }, "git-commit");
        t.setDaemon(true);
        t.start();
    }

    private static String firstLine(String s) {
        int nl = s.indexOf('\n');
        return nl < 0 ? s : s.substring(0, nl);
    }

    private void stageAll() {
        runGit(Strings.get("stage all"), "add", "-A");
    }

    private void unstageAll() {
        runGit(Strings.get("unstage all"), "reset", "-q", "HEAD");
    }

    private void discardAll() {
        int choice = Dialogs.confirm(this, theme, Strings.get("Discard All Changes"),
                Strings.get("Discard every unstaged change? This cannot be undone."),
                Strings.get("Discard"), Strings.get("Cancel"));
        if (choice != 0) {
            return;
        }
        File rootDir = current.root;
        List<Git.Entry> unstaged = current.unstaged();
        Thread t = new Thread(() -> {
            for (Git.Entry e : unstaged) {
                String rel = Git.relativize(rootDir, e.file);
                if (e.untracked) {
                    Workspace.deleteRecursive(e.file);
                } else {
                    Git.run(rootDir, "checkout", "--", rel);
                }
            }
            SwingUtilities.invokeLater(() -> {
                if (actions != null) {
                    actions.notify(Strings.format("Discarded changes in {0} files",
                            unstaged.size()), false);
                    actions.filesChanged(stagedFiles());
                }
                refreshAsync(true);
            });
        }, "git-discard-all");
        t.setDaemon(true);
        t.start();
    }

    private List<File> stagedFiles() {
        List<File> out = new ArrayList<>();
        for (Git.Entry e : current.entries) {
            out.add(e.file);
        }
        return out;
    }

    private void runGit(String what, String... args) {
        if (!current.isRepo()) {
            return;
        }
        File rootDir = current.root;
        Thread t = new Thread(() -> {
            String error = Git.run(rootDir, args);
            SwingUtilities.invokeLater(() -> {
                if (!error.isEmpty()) {
                    warn(Strings.format("Could not {0}: {1}", what, error));
                }
                refreshAsync(true);
            });
        }, "git-op");
        t.setDaemon(true);
        t.start();
    }

    private void warn(String text) {
        hint.setText(Strings.get(text));
        hint.setForeground(theme.error);
        if (actions != null) {
            actions.notify(text, true);
        }
    }

    private void showBranchMenu() {
        if (!current.isRepo()) {
            return;
        }
        JPopupMenu menu = new JPopupMenu();
        JMenuItem refreshItem = new JMenuItem(Strings.get("Refresh"));
        refreshItem.addActionListener(e -> refreshAsync(true));
        menu.add(refreshItem);
        menu.addSeparator();
        for (String b : Git.branches(current.root)) {
            JMenuItem item = new JMenuItem((b.equals(current.branch) ? "✓  " : "    ") + b);
            item.setFont(UI.ui(12f));
            item.addActionListener(e -> checkout(b));
            menu.add(item);
        }
        JMenuItem create = new JMenuItem(Strings.get("Create Branch..."));
        create.setFont(UI.ui(12f));
        create.addActionListener(e -> {
            String name = Dialogs.prompt(this, theme, Strings.get("Create Branch"),
                    Strings.get("Name of the new branch:"), "");
            if (name != null && !name.isBlank()) {
                runGit(Strings.get("create branch"), "checkout", "-b", name.trim());
            }
        });
        menu.addSeparator();
        menu.add(create);
        menu.show(branchRow, 6, branchRow.getHeight());
    }

    private void checkout(String branch) {
        if (branch == null || branch.equals(current.branch)) {
            return;
        }
        runGit(Strings.get("switch to ") + branch, "checkout", branch);
    }

    private void showCommitMenu() {
        JPopupMenu menu = new JPopupMenu();
        JMenuItem stage = new JMenuItem(Strings.get("Stage All Changes"));
        stage.setFont(UI.ui(12f));
        stage.addActionListener(e -> stageAll());
        menu.add(stage);
        JMenuItem unstage = new JMenuItem(Strings.get("Unstage All Changes"));
        unstage.setFont(UI.ui(12f));
        unstage.addActionListener(e -> unstageAll());
        menu.add(unstage);
        menu.addSeparator();
        JMenuItem amend = new JMenuItem(Strings.get("Amend Last Commit..."));
        amend.setFont(UI.ui(12f));
        amend.addActionListener(e -> {
            String text = message.getText().trim();
            if (text.isEmpty()) {
                warn("Enter a commit message first");
                return;
            }
            runGit(Strings.get("amend"), "commit", "--amend", "-m", text);
        });
        menu.add(amend);
        JMenuItem pull = new JMenuItem(Strings.get("Pull"));
        pull.setFont(UI.ui(12f));
        pull.addActionListener(e -> runGit(Strings.get("pull"), "pull"));
        menu.add(pull);
        JMenuItem push = new JMenuItem(Strings.get("Push"));
        push.setFont(UI.ui(12f));
        push.addActionListener(e -> runGit(Strings.get("push"), "push"));
        menu.add(push);
        menu.addSeparator();
        JMenuItem discard = new JMenuItem(Strings.get("Discard All Changes"));
        discard.setFont(UI.ui(12f));
        discard.addActionListener(e -> discardAll());
        menu.add(discard);
        menu.show(this, Math.max(0, getWidth() - 200), 90);
    }

    private void showMoreMenu() {
        showCommitMenu();
    }

    private void popup(MouseEvent e) {
        TreePath path = tree.getPathForLocation(e.getX(), e.getY());
        if (path == null) {
            return;
        }
        tree.setSelectionPath(path);
        Object u = ((DefaultMutableTreeNode) path.getLastPathComponent()).getUserObject();
        JPopupMenu menu = new JPopupMenu();

        if (u instanceof Group g) {
            addItem(menu, "Stage All Changes", () -> runGit(Strings.get("stage all"), "add", "-A"));
            addItem(menu, "Unstage All Changes",
                    () -> runGit(Strings.get("unstage all"), "reset", "-q", "HEAD"));
            addItem(menu, "Discard All Changes", this::discardAll);
            menu.addSeparator();
            addItem(menu, "Refresh", () -> refreshAsync(true));
            menu.show(tree, e.getX(), e.getY());
            return;
        }
        if (!(u instanceof RowEntry re)) {
            return;
        }
        Git.Entry entry = re.entry;
        addItem(menu, "Open File", () -> {
            if (actions != null) {
                actions.openFile(entry.file);
            }
        });
        addItem(menu, "Open Changes", () -> {
            if (actions != null) {
                actions.openDiff(entry.file, re.staged);
            }
        });
        menu.addSeparator();
        if (re.staged) {
            addItem(menu, "Unstage Changes", () -> {
                String rel = Git.relativize(current.root, entry.file);
                runGit(Strings.get("unstage ") + entry.file.getName(),
                        "reset", "-q", "HEAD", "--", rel);
            });
        } else {
            addItem(menu, "Stage Changes", () -> {
                String rel = Git.relativize(current.root, entry.file);
                runGit(Strings.get("stage ") + entry.file.getName(), "add", "--", rel);
            });
        }
        addItem(menu, "Discard Changes", () -> discardEntry(entry));
        menu.addSeparator();
        if (entry.untracked) {
            addItem(menu, "Delete File", () -> {
                int choice = Dialogs.confirm(this, theme, Strings.get("Delete File"),
                        Strings.format("Delete the untracked file \"{0}\"?",
                                entry.file.getName()),
                        Strings.get("Delete"), Strings.get("Cancel"));
                if (choice == 0) {
                    Workspace.deleteRecursive(entry.file);
                    refreshAsync(true);
                }
            });
        }
        addItem(menu, "Copy Path", () -> java.awt.Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new java.awt.datatransfer.StringSelection(entry.file.getAbsolutePath()), null));
        addItem(menu, "Copy Relative Path", () -> java.awt.Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new java.awt.datatransfer.StringSelection(
                        Git.relativize(current.root, entry.file)), null));
        addItem(menu, "Reveal in File Explorer", () -> {
            if (actions != null) {
                actions.revealInOS(entry.file);
            }
        });
        menu.show(tree, e.getX(), e.getY());
    }

    private void addItem(JPopupMenu menu, String text, Runnable action) {
        JMenuItem item = new JMenuItem(Strings.get(text));
        item.setFont(UI.ui(12f));
        item.addActionListener(e -> action.run());
        menu.add(item);
    }

    private void discardEntry(Git.Entry entry) {
        int choice = Dialogs.confirm(this, theme, Strings.get("Discard Changes"),
                Strings.format("Discard the changes made to \"{0}\"?"
                        + "\n\nThis cannot be undone.", entry.file.getName()),
                Strings.get("Discard"), Strings.get("Cancel"));
        if (choice != 0) {
            return;
        }
        File rootDir = current.root;
        String rel = Git.relativize(rootDir, entry.file);
        Thread t = new Thread(() -> {
            if (entry.untracked) {
                Workspace.deleteRecursive(entry.file);
            } else {
                Git.run(rootDir, "checkout", "--", rel);
            }
            SwingUtilities.invokeLater(() -> {
                if (actions != null) {
                    actions.filesChanged(List.of(entry.file));
                }
                refreshAsync(true);
            });
        }, "git-discard");
        t.setDaemon(true);
        t.start();
    }

    /* ------------------------------------------------------------------ */

    /** Tree user object for the "Staged Changes" / "Changes" group rows. */
    private static class Group {
        final String name;
        final int count;

        Group(String name, int count) {
            this.name = name;
            this.count = count;
        }
    }

    /** Tree user object for a single changed file. */
    private static class RowEntry {
        final Git.Entry entry;
        final boolean staged;

        RowEntry(Git.Entry entry, boolean staged) {
            this.entry = entry;
            this.staged = staged;
        }

        @Override
        public String toString() {
            return entry.file.getName();
        }
    }

    private class Renderer extends DefaultTreeCellRenderer {

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded,
                                                      boolean leaf, int row, boolean hasFocus) {
            Object u = value instanceof DefaultMutableTreeNode n ? n.getUserObject() : null;
            JLabel c = (JLabel) super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, false);
            c.setFont(UI.ui(12.5f));
            c.setOpaque(true);
            c.setBorder(BorderFactory.createEmptyBorder(1, 2, 1, 4));
            setToolTipText(null);

            if (u instanceof Group g) {
                c.setText(Strings.get(g.name) + "  " + g.count);
                c.setFont(UI.uiBold(11.5f));
                c.setForeground(selected ? theme.listActiveFg : theme.sectionHeader);
                c.setIcon(Icons.of(expanded ? "chevron-down" : "chevron-right", 13, theme.sectionHeader));
            } else if (u instanceof RowEntry re) {
                File f = re.entry.file;
                String rel = workspace.relative(f);
                int slash = rel.lastIndexOf('/');
                String name = slash < 0 ? rel : rel.substring(slash + 1);
                String dir = slash < 0 ? "" : rel.substring(0, slash + 1);
                c.setText("<html>" + UI.esc(name) + " <font color='#"
                        + String.format("%06X", theme.sidebarFg.getRGB() & 0xFFFFFF) + "80'>"
                        + UI.esc(dir) + "</font></html>");
                c.setIcon(Icons.of("file", 14, statusColor(re.entry)));
                setToolTipText(f.getAbsolutePath() + "  -  " + re.entry.kind()
                        + (re.staged ? " " + Strings.get("(staged)") : ""));
                if (selected) {
                    c.setText(name);
                }
            } else {
                c.setText(String.valueOf(value));
                c.setIcon(null);
            }

            Color bg = theme.sidebarBg;
            Color fg = theme.sidebarFg;
            if (selected) {
                if (tree.isFocusOwner()) {
                    bg = theme.listActive;
                    fg = theme.listActiveFg;
                } else {
                    bg = theme.listSelectionInactive;
                }
            }
            if (u instanceof RowEntry && !selected) {
                fg = theme.sidebarFg;
            }
            c.setBackground(bg);
            c.setForeground(fg);
            return c;
        }

        private Color statusColor(Git.Entry e) {
            return switch (e.letter()) {
                case 'M' -> theme.warning;
                case 'A', 'U' -> theme.dark ? new Color(0x73C991) : new Color(0x16825D);
                case 'D' -> theme.error;
                case 'R', 'C' -> theme.info;
                default -> theme.sidebarFg;
            };
        }
    }

    /** Status letter drawn to the right of the row. */
    private static class StatusBadge implements javax.swing.Icon {
        private final char letter;
        private final Color color;

        StatusBadge(char letter, Color color) {
            this.letter = letter;
            this.color = color;
        }

        @Override
        public int getIconWidth() {
            return 14;
        }

        @Override
        public int getIconHeight() {
            return 14;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setFont(UI.uiBold(11f));
            g2.drawString(String.valueOf(letter), x + 3, y + 11);
            g2.dispose();
        }
    }

    public int changeCount() {
        return current.entries.size();
    }
}
