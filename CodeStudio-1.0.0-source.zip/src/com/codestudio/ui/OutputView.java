package com.codestudio.ui;

import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/** The Output panel: named channels of plain text. */
public class OutputView extends JPanel {

    private static final int MAX_CHARS = 300_000;

    /**
     * Channel ids. They are also the display names, so they stay untranslated in the model and are
     * only translated on the way to the drop down, see {@link #retranslate}.
     */
    public static final String TASKS = "Tasks";
    public static final String CODESTUDIO = "CodeStudio";
    public static final String DEBUG = "Debug Console";

    private final Settings settings;
    private Theme theme;

    private final Map<String, StringBuilder> channels = new LinkedHashMap<>();
    private final DefaultComboBoxModel<String> names = new DefaultComboBoxModel<>();
    private final JComboBox<String> channelBox = new JComboBox<>(names);
    private final JTextPane pane = new JTextPane();
    private final JScrollPane scroll;
    private String current = TASKS;

    public OutputView(Settings settings, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.theme = theme;
        setBackground(theme.panelBg);

        for (String name : new String[]{TASKS, CODESTUDIO, DEBUG}) {
            channels.put(name, new StringBuilder());
            names.addElement(name);
        }

        channelBox.setFont(UI.ui(12f));
        channelBox.setBackground(theme.panelBg);
        channelBox.setForeground(theme.panelFg);
        channelBox.setFocusable(false);
        channelBox.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 0));
        channelBox.setPreferredSize(new Dimension(170, 24));
        // Items stay the raw channel ids; only the rendering is translated.
        channelBox.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public java.awt.Component getListCellRendererComponent(javax.swing.JList<?> source,
                    Object value, int index, boolean selected, boolean focus) {
                Object shown = value == null ? null : Strings.get(String.valueOf(value));
                return super.getListCellRendererComponent(source, shown, index, selected, focus);
            }
        });
        channelBox.addActionListener(e -> {
            Object sel = channelBox.getSelectedItem();
            if (sel != null && !sel.equals(current)) {
                current = String.valueOf(sel);
                render();
            }
        });

        pane.setEditable(false);
        pane.setFont(UI.mono(settings.get("editor.fontFamily"), settings.getInt("editor.fontSize") - 1));
        pane.setBackground(theme.panelBg);
        pane.setForeground(theme.panelFg);
        pane.setBorder(BorderFactory.createEmptyBorder(4, 8, 6, 8));

        scroll = UI.scroll(pane, theme);
        scroll.getViewport().setBackground(theme.panelBg);

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(theme.panelBg);
        top.add(channelBox, BorderLayout.WEST);

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
    }

    /** Appends text to a channel, creating it on demand. */
    public void append(String channel, String text) {
        if (channel == null) {
            channel = CODESTUDIO;
        }
        StringBuilder sb = channels.get(channel);
        if (sb == null) {
            sb = new StringBuilder();
            channels.put(channel, sb);
            names.addElement(channel);
        }
        sb.append(text);
        if (sb.length() > MAX_CHARS) {
            sb.delete(0, sb.length() - MAX_CHARS / 2);
        }
        if (channel.equals(current)) {
            SwingUtilities.invokeLater(() -> appendToPane(text));
        }
    }

    public void appendLine(String channel, String text) {
        append(channel, text + System.lineSeparator());
    }

    private void appendToPane(String text) {
        StyledDocument doc = pane.getStyledDocument();
        SimpleAttributeSet attrs = new SimpleAttributeSet();
        StyleConstants.setFontFamily(attrs, settings.get("editor.fontFamily"));
        StyleConstants.setFontSize(attrs, settings.getInt("editor.fontSize") - 1);
        try {
            doc.insertString(doc.getLength(), text, attrs);
        } catch (BadLocationException ignored) {
            // nothing to do
        }
        if (doc.getLength() > MAX_CHARS) {
            try {
                doc.remove(0, doc.getLength() - MAX_CHARS / 2);
            } catch (BadLocationException ignored) {
                // ignore
            }
        }
        JScrollBar bar = scroll.getVerticalScrollBar();
        bar.setValue(bar.getMaximum());
    }

    private void render() {
        StringBuilder sb = channels.get(current);
        pane.setText(sb == null ? "" : sb.toString());
        JScrollBar bar = scroll.getVerticalScrollBar();
        bar.setValue(bar.getMaximum());
    }

    public void showChannel(String channel) {
        if (channel == null || !channels.containsKey(channel)) {
            return;
        }
        current = channel;
        channelBox.setSelectedItem(channel);
        render();
    }

    public String currentChannel() {
        return current;
    }

    /** Clears the visible channel (or every channel when {@code all} is true). */
    public void clear(boolean all) {
        if (all) {
            channels.replaceAll((k, v) -> new StringBuilder());
        } else {
            channels.put(current, new StringBuilder());
        }
        pane.setText("");
    }

    public void clear() {
        clear(false);
    }

    /**
     * Re-applies the channel names after a language change. The channel ids themselves are never
     * translated, so this only has to refresh the drop down rendering.
     */
    public void retranslate() {
        channelBox.revalidate();
        channelBox.repaint();
        render();
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.panelBg);
        pane.setBackground(t.panelBg);
        pane.setForeground(t.panelFg);
        scroll.getViewport().setBackground(t.panelBg);
        UI.themeScrollBar(scroll, t);
        channelBox.setBackground(t.panelBg);
        channelBox.setForeground(t.panelFg);
        repaint();
    }
}
