package com.codestudio.ui;

import com.codestudio.core.DocumentBundle;
import com.codestudio.core.Folding;
import com.codestudio.core.Language;
import com.codestudio.core.Navigator;
import com.codestudio.core.Settings;
import com.codestudio.core.Snippets;
import com.codestudio.core.SyntaxHighlighter;
import com.codestudio.core.Theme;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JTextPane;
import javax.swing.KeyStroke;
import javax.swing.Popup;
import javax.swing.PopupFactory;
import javax.swing.Scrollable;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultCaret;
import javax.swing.text.Element;
import javax.swing.text.Highlighter;
import javax.swing.text.JTextComponent;
import javax.swing.text.NavigationFilter;
import javax.swing.text.Position;
import javax.swing.text.StyleConstants;
import javax.swing.text.TabSet;
import javax.swing.text.TabStop;

/**
 * The text editor widget: syntax highlighting, smart indentation, bracket
 * matching, occurrence highlighting, comment toggling and code navigation.
 */
public class CodeTextPane extends JTextPane implements Scrollable {

    private final DocumentBundle bundle;
    private final Settings settings;
    private final SyntaxHighlighter highlighter;
    private Theme theme;

    private boolean wrap;
    private int tabSize = 4;
    private boolean insertSpaces = true;
    private boolean autoClose = true;
    private boolean highlightLine = true;
    private boolean showOccurrences = true;
    private boolean renderWhitespace = false;

    private final Timer highlightTimer;
    private boolean highlighting;

    private String textCache;
    private boolean textCacheValid;
    private boolean contentWidthDirty = true;
    private int cachedContentWidth;

    /* --- folding --- */
    private boolean foldingEnabled = true;
    private final Set<Integer> foldedStarts = new LinkedHashSet<>();
    private boolean[] foldMask;
    private boolean foldMaskValid;
    /** Paragraph views built by {@link FoldEditorKit}, held weakly so replaced ones can go. */
    private final Map<javax.swing.text.View, Boolean> foldViews = new java.util.WeakHashMap<>();

    /* --- suggestions --- */
    private boolean suggestOnType = true;
    private final Timer suggestTimer;
    private Popup suggestPopup;
    private CompletionPopup suggestPanel;
    private boolean suppressSuggest;
    private String wordCacheSource;
    private List<String> wordCache = List.of();

    private final List<Runnable> stateListeners = new ArrayList<>();

    private Object lineHighlightTag;
    private int lineHighlightFrom = -1;
    private int lineHighlightTo = -1;
    private Object bracketTag1;
    private Object bracketTag2;
    private final List<Object> occurrenceTags = new ArrayList<>();

    private final RowPainter linePainter;
    private final CellPainter bracketPainter;
    private final CellPainter occurrencePainter;

    public CodeTextPane(DocumentBundle bundle, Settings settings, SyntaxHighlighter highlighter, Theme theme) {
        this.bundle = bundle;
        this.settings = settings;
        this.highlighter = highlighter;
        this.theme = theme;

        // A StyledEditorKit that gives folded paragraphs no height; everything else is untouched.
        setEditorKit(new FoldEditorKit(this));
        setDocument(bundle.doc);
        setOpaque(true);
        setBorder(null);
        setMargin(new Insets(4, 6, 240, 6));
        setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
        setDragEnabled(true);

        DefaultCaret caret = new DefaultCaret();
        caret.setBlinkRate(530);
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        setCaret(caret);

        readPrefs();
        linePainter = new RowPainter(this.theme.lineHighlight);
        bracketPainter = new CellPainter(this.theme.bracketMatch, this.theme.bracketMatchBorder);
        occurrencePainter = new CellPainter(this.theme.occurrenceBg, this.theme.occurrenceBorder);

        applyTheme(theme);
        applyFont();
        applyTabStops();

        highlightTimer = new Timer(160, e -> runHighlight());
        highlightTimer.setRepeats(false);

        // Suggestions are debounced: typing a word must not rebuild the candidate list on every
        // keystroke of a burst.
        suggestTimer = new Timer(70, e -> showSuggestions(false));
        suggestTimer.setRepeats(false);

        bundle.doc.addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                invalidate();
                onInserted(e);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                invalidate();
                if (!suppressSuggest) {
                    hideSuggestions();
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // ignore our own syntax updates
            }

            private void invalidate() {
                if (highlighting) {
                    return;
                }
                textCacheValid = false;
                contentWidthDirty = true;
                foldMaskValid = false;
                highlightTimer.restart();
                fireState();
            }
        });

        // The caret must never come to rest inside a folded block: the offsets are still valid, but
        // the caret would be invisible, so a position that lands inside a fold snaps to its end.
        setNavigationFilter(new NavigationFilter() {
            @Override
            public void setDot(FilterBypass fb, int dot, Position.Bias bias) {
                fb.setDot(visibleOffset(dot), bias);
            }

            @Override
            public void moveDot(FilterBypass fb, int dot, Position.Bias bias) {
                fb.moveDot(visibleOffset(dot), bias);
            }
        });

        addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                hideSuggestions();
            }
        });

        addCaretListener(new CaretListener() {
            @Override
            public void caretUpdate(CaretEvent e) {
                bundle.caret = e.getDot();
                bundle.selectionEnd = e.getMark();
                if (highlightLine) {
                    updateLineHighlight();
                }
                updateBrackets();
                updateOccurrences();
                fireState();
            }
        });

        installKeyBindings();
        SwingUtilities.invokeLater(this::refreshDecorations);
    }

    /* ------------------------------------------------------------------ */
    /* configuration                                                       */
    /* ------------------------------------------------------------------ */

    public void readPrefs() {
        wrap = settings.getBool("editor.wordWrap");
        tabSize = Math.max(1, settings.getInt("editor.tabSize"));
        insertSpaces = settings.getBool("editor.insertSpaces");
        autoClose = settings.getBool("editor.autoCloseBrackets");
        highlightLine = settings.getBool("editor.highlightActiveLine");
        showOccurrences = settings.getBool("editor.showOccurrences");
        renderWhitespace = settings.getBool("editor.renderWhitespace");
        foldingEnabled = settings.getBool("editor.folding");
        suggestOnType = settings.getBool("editor.quickSuggestions");
        if (!suggestOnType) {
            hideSuggestions();
        }
    }

    public void applyFont() {
        Font f = UI.mono(UI.resolveMono(settings.get("editor.fontFamily")), settings.getInt("editor.fontSize"));
        setFont(f);
        contentWidthDirty = true;
        applyTabStops();
        revalidate();
        repaint();
    }

    private void applyTabStops() {
        FontMetrics fm = getFontMetrics(getFont());
        int space = fm.charWidth(' ');
        int stop = Math.max(1, space * tabSize);
        int count = Math.max(2, (getWidth() > 0 ? getWidth() : 1200) / stop + 2);
        TabStop[] stops = new TabStop[Math.min(count, 200)];
        for (int i = 0; i < stops.length; i++) {
            stops[i] = new TabStop(stop * (i + 1));
        }
        javax.swing.text.SimpleAttributeSet para = new javax.swing.text.SimpleAttributeSet();
        StyleConstants.setTabSet(para, new TabSet(stops));
        try {
            bundle.doc.setParagraphAttributes(0, bundle.doc.getLength(), para, false);
        } catch (Exception ignored) {
        }
    }

    public void applyTheme(Theme t) {
        this.theme = t;
        setBackground(t.editorBg);
        setForeground(t.editorFg);
        setCaretColor(t.cursor);
        setSelectionColor(t.selection);
        setSelectedTextColor(t.dark ? Color.WHITE : Color.BLACK);
        setDisabledTextColor(t.gutterFg);
        linePainter.color = t.lineHighlight;
        bracketPainter.fill = t.bracketMatch;
        bracketPainter.border = t.bracketMatchBorder;
        occurrencePainter.fill = t.occurrenceBg;
        occurrencePainter.border = t.occurrenceBorder;
        if (suggestPanel != null) {
            suggestPanel.setTheme(t);
        }
        runHighlight();
        refreshDecorations();
        repaint();
    }

    /** Highlights the whole buffer right away (used after loading / theme change). */
    public void runHighlight() {
        if (highlighting) {
            return;
        }
        highlighting = true;
        try {
            highlighter.highlight(bundle.doc, bundle.language);
        } finally {
            highlighting = false;
        }
    }

    public void setLanguage(com.codestudio.core.Language lang) {
        bundle.language = lang;
        textCacheValid = false;
        runHighlight();
        fireState();
    }

    public DocumentBundle bundle() {
        return bundle;
    }

    public void addStateListener(Runnable r) {
        stateListeners.add(r);
    }

    private void fireState() {
        for (Runnable r : stateListeners) {
            r.run();
        }
    }

    public void refreshDecorations() {
        updateLineHighlight();
        updateBrackets();
        updateOccurrences();
    }

    /* ------------------------------------------------------------------ */
    /* folding                                                             */
    /* ------------------------------------------------------------------ */

    public boolean isLineHidden(int line) {
        boolean[] mask = foldMask();
        return line >= 0 && line < mask.length && mask[line];
    }

    public boolean isFoldingEnabled() {
        return foldingEnabled;
    }

    private boolean[] foldMask() {
        if (!foldMaskValid || foldMask == null) {
            foldMask = foldingEnabled
                    ? Folding.hiddenLines(text(), bundle.language, foldedStarts)
                    : new boolean[Math.max(1, lineCount())];
            foldMaskValid = true;
        }
        return foldMask;
    }

    /** The lines the user has folded, so the gutter can draw the open/closed indicators. */
    public Set<Integer> foldedLines() {
        return new LinkedHashSet<>(foldedStarts);
    }

    /** The innermost foldable region that starts on this line, or null. */
    private Folding.Region regionAt(int line) {
        for (Folding.Region r : Folding.compute(text(), bundle.language)) {
            if (r.startLine == line) {
                return r;
            }
        }
        return null;
    }

    /** The fold start that should be toggled for a click on (or a caret on) a line. */
    public int foldStartFor(int line) {
        int best = -1;
        for (Folding.Region r : Folding.compute(text(), bundle.language)) {
            if (r.startLine <= line && line <= r.endLine && r.startLine > best) {
                best = r.startLine;
            }
        }
        return best;
    }

    public boolean canFold(int line) {
        return foldingEnabled && regionAt(line) != null;
    }

    /** Toggles the block that starts on a line. Returns false when there is nothing to fold. */
    public boolean toggleFold(int line) {
        if (!foldingEnabled || regionAt(line) == null) {
            return false;
        }
        if (!foldedStarts.remove(line)) {
            foldedStarts.add(line);
        }
        applyFoldChange();
        return true;
    }

    /** Toggles the innermost block that contains the line. */
    public boolean toggleFoldAtCaret() {
        int start = foldStartFor(caretLine());
        if (start < 0) {
            return false;
        }
        return toggleFold(start);
    }

    public boolean foldAtCaret() {
        int start = foldStartFor(caretLine());
        if (start < 0) {
            return false;
        }
        if (foldedStarts.add(start)) {
            applyFoldChange();
        }
        return true;
    }

    public boolean unfoldAtCaret() {
        int start = foldStartFor(caretLine());
        if (start < 0) {
            return false;
        }
        if (foldedStarts.remove(start)) {
            applyFoldChange();
            return true;
        }
        return true;
    }

    public void foldAll() {
        foldedStarts.clear();
        foldedStarts.addAll(Folding.allFoldableStarts(text(), bundle.language));
        applyFoldChange();
    }

    public void unfoldAll() {
        if (foldedStarts.isEmpty()) {
            return;
        }
        foldedStarts.clear();
        applyFoldChange();
    }

    private void applyFoldChange() {
        foldMaskValid = false;
        hideSuggestions();
        // Tell the paragraphs that their height changed. Doing it through the views leaves the
        // document, the caret and the editor's key maps exactly as they were.
        for (javax.swing.text.View view : foldViews.keySet()) {
            view.preferenceChanged(null, false, true);
        }
        revalidate();
        repaint();
        fireState();
    }

    /**
     * Called by {@link FoldEditorKit} as it builds a paragraph view. The views are held weakly: one
     * the editor has replaced is of no further use and must not keep it alive.
     */
    void registerFoldView(javax.swing.text.View view) {
        foldViews.put(view, Boolean.TRUE);
    }

    /**
     * The nearest position outside a folded block, so the caret cannot be parked on an invisible
     * line. Positions that are already visible are returned untouched, which keeps this filter out
     * of the way when nothing is folded.
     */
    private int visibleOffset(int offset) {
        if (foldedStarts.isEmpty() || !foldingEnabled) {
            return offset;
        }
        boolean[] mask = foldMask();
        Element root = bundle.doc.getDefaultRootElement();
        int line = root.getElementIndex(Math.max(0, Math.min(offset, bundle.doc.getLength())));
        if (line < 0 || line >= mask.length || !mask[line]) {
            return offset;
        }
        while (line > 0 && mask[line]) {
            line--;
        }
        return Math.min(bundle.doc.getLength(), root.getElement(line).getEndOffset() - 1);
    }

    /* ------------------------------------------------------------------ */
    /* suggestions                                                         */
    /* ------------------------------------------------------------------ */

    private static final int MAX_SUGGESTIONS = 60;

    private void onInserted(DocumentEvent e) {
        if (suppressSuggest || !suggestOnType) {
            return;
        }
        if (e.getLength() != 1) {
            hideSuggestions();
            return;
        }
        char c;
        try {
            c = bundle.doc.getText(e.getOffset(), 1).charAt(0);
        } catch (BadLocationException ex) {
            hideSuggestions();
            return;
        }
        if (Navigator.isIdentifierChar(c) || c == '.') {
            suggestTimer.restart();
        } else {
            hideSuggestions();
        }
    }

    /** Handles Ctrl+Space: opens the list even for an empty prefix. */
    public void triggerSuggest() {
        showSuggestions(true);
    }

    public boolean suggestionVisible() {
        return suggestPopup != null && suggestPanel != null && suggestPanel.count() > 0;
    }

    public void moveSuggestion(int delta) {
        if (suggestPanel != null) {
            suggestPanel.move(delta);
        }
    }

    private void showSuggestions(boolean manual) {
        if (suggestPopup != null && !manual) {
            // keep the panel where it is while the prefix grows: rebuilding the candidates is
            // enough, moving the popup on every keystroke would make it jitter
            hideSuggestions();
        }
        if ((!suggestOnType && !manual) || bundle.language == null) {
            return;
        }
        String text = text();
        int caret = Math.max(0, Math.min(getCaretPosition(), text.length()));
        int start = caret;
        while (start > 0 && Navigator.isIdentifierChar(text.charAt(start - 1))) {
            start--;
        }
        String prefix = text.substring(start, caret);
        boolean afterDot = start > 0 && text.charAt(start - 1) == '.';
        if (!manual && prefix.isEmpty() && !afterDot) {
            hideSuggestions();
            return;
        }
        if (prefix.length() > 40) {
            hideSuggestions();
            return;
        }
        List<CompletionPopup.Item> items = buildSuggestions(prefix, start, caret);
        if (items.isEmpty()) {
            hideSuggestions();
            return;
        }
        showSuggestions(items);
    }

    private void showSuggestions(List<CompletionPopup.Item> items) {
        if (suggestPanel == null) {
            suggestPanel = new CompletionPopup(theme);
        }
        suggestPanel.setTheme(theme);
        suggestPanel.setItems(items);
        if (suggestPopup != null) {
            suggestPopup.hide();
            suggestPopup = null;
        }
        Rectangle caretRect = rectOf(this, Math.min(getCaretPosition(), bundle.doc.getLength()));
        Point at = new Point(caretRect.x, caretRect.y + caretRect.height);
        SwingUtilities.convertPointToScreen(at, this);
        Dimension size = suggestPanel.getPreferredSize();
        Rectangle screen = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        int x = Math.max(screen.x, Math.min(at.x - 20, screen.x + screen.width - size.width - 8));
        int y = at.y + size.height > screen.y + screen.height ? caretRect.y - size.height : at.y;
        try {
            suggestPopup = PopupFactory.getSharedInstance().getPopup(this, suggestPanel, x, Math.max(screen.y, y));
        } catch (RuntimeException e) {
            // The popup factory refuses to place a popup for a component that is not on screen yet,
            // which can happen when a command opens the list before the window is shown. Typing
            // still works; only the list is missing.
            suggestPopup = null;
            return;
        }
        suggestPopup.show();
    }

    public void hideSuggestions() {
        if (suggestTimer != null) {
            suggestTimer.stop();
        }
        if (suggestPopup != null) {
            suggestPopup.hide();
            suggestPopup = null;
        }
    }

    /** Accepts the highlighted suggestion. Returns false when none is showing. */
    public boolean acceptSuggestion() {
        if (suggestPopup == null || suggestPanel == null) {
            return false;
        }
        CompletionPopup.Item item = suggestPanel.selected();
        hideSuggestions();
        if (item == null) {
            return false;
        }
        int from = Math.max(0, Math.min(item.replaceFrom, bundle.doc.getLength()));
        int to = Math.max(from, Math.min(item.replaceTo, bundle.doc.getLength()));
        String insert = item.insert;
        int caret = item.caretOffset >= 0 ? from + item.caretOffset : from + insert.length();
        suppressSuggest = true;
        bundle.beginCompound();
        try {
            if (to > from) {
                bundle.doc.remove(from, to - from);
            }
            bundle.doc.insertString(from, insert, null);
            setCaretPosition(Math.max(0, Math.min(caret, bundle.doc.getLength())));
        } catch (BadLocationException ignored) {
        } finally {
            bundle.endCompound();
            suppressSuggest = false;
        }
        runHighlight();
        fireState();
        return true;
    }

    private List<CompletionPopup.Item> buildSuggestions(String prefix, int from, int to) {
        List<CompletionPopup.Item> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        String lower = prefix.toLowerCase(Locale.ROOT);
        String indent = indentationOf(caretLine());
        Language lang = bundle.language;

        // Snippets win over everything else: an exact trigger typed out is a snippet request.
        for (Snippets.Snippet snippet : Snippets.matching(lang, prefix)) {
            if (out.size() >= MAX_SUGGESTIONS) {
                break;
            }
            if (!seen.add(snippet.trigger.toLowerCase(Locale.ROOT))) {
                continue;
            }
            int[] caretAt = new int[1];
            String body = Snippets.expand(snippet.body, indent, caretAt);
            out.add(new CompletionPopup.Item(snippet.trigger, snippet.label, "snippet", body, caretAt[0],
                    from, to));
        }

        addCandidates(out, seen, lang.keywords, "keyword", lower, from, to);
        addCandidates(out, seen, lang.control, "control", lower, from, to);
        addCandidates(out, seen, lang.types, "type", lower, from, to);
        addCandidates(out, seen, lang.constants, "constant", lower, from, to);
        addCandidates(out, seen, lang.builtins, "function", lower, from, to);

        for (OutlinePanel.Symbol symbol : OutlinePanel.parse(text(), lang)) {
            if (out.size() >= MAX_SUGGESTIONS) {
                break;
            }
            String name = symbol.name.endsWith("()")
                    ? symbol.name.substring(0, symbol.name.length() - 2) : symbol.name;
            boolean isType = switch (symbol.kind) {
                case "class", "interface", "enum", "record", "struct", "trait", "impl" -> true;
                default -> false;
            };
            if (isType ? name.toLowerCase(Locale.ROOT).startsWith(lower) : !lower.isEmpty()
                    && name.toLowerCase(Locale.ROOT).startsWith(lower)) {
                if (seen.add(name.toLowerCase(Locale.ROOT))) {
                    out.add(new CompletionPopup.Item(name, symbol.kind, isType ? "type" : "function",
                            name, -1, from, to));
                }
            }
        }

        for (String word : documentWords()) {
            if (out.size() >= MAX_SUGGESTIONS) {
                break;
            }
            if (!lower.isEmpty() && !word.toLowerCase(Locale.ROOT).startsWith(lower)) {
                continue;
            }
            if (!seen.add(word.toLowerCase(Locale.ROOT))) {
                continue;
            }
            out.add(new CompletionPopup.Item(word, "", "word", word, -1, from, to));
        }
        return out;
    }

    private void addCandidates(List<CompletionPopup.Item> out, Set<String> seen, Set<String> words,
                               String kind, String lower, int from, int to) {
        for (String word : words) {
            if (out.size() >= MAX_SUGGESTIONS) {
                return;
            }
            if (!lower.isEmpty() && !word.toLowerCase(Locale.ROOT).startsWith(lower)) {
                continue;
            }
            if (seen.add(word.toLowerCase(Locale.ROOT))) {
                out.add(new CompletionPopup.Item(word, kind, kind, word, -1, from, to));
            }
        }
    }

    /** Identifiers already in this buffer, most used first -the local "words" candidate list. */
    private List<String> documentWords() {
        String source = text();
        if (source == wordCacheSource) {
            return wordCache;
        }
        Map<String, Integer> counts = new HashMap<>();
        StringBuilder word = new StringBuilder();
        int limit = Math.min(source.length(), 200_000);
        for (int i = 0; i <= limit; i++) {
            char c = i < limit ? source.charAt(i) : ' ';
            if (Navigator.isIdentifierChar(c)) {
                word.append(c);
                continue;
            }
            if (word.length() >= 2 && word.length() <= 40) {
                counts.merge(word.toString(), 1, Integer::sum);
            }
            word.setLength(0);
        }
        List<Map.Entry<String, Integer>> ranked = new ArrayList<>(counts.entrySet());
        ranked.sort((a, b) -> {
            int byCount = Integer.compare(b.getValue(), a.getValue());
            return byCount != 0 ? byCount : a.getKey().compareTo(b.getKey());
        });
        List<String> words = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : ranked) {
            if (words.size() >= 400) {
                break;
            }
            words.add(entry.getKey());
        }
        wordCacheSource = source;
        wordCache = words;
        return words;
    }

    /* ------------------------------------------------------------------ */
    /* Scrollable                                                          */
    /* ------------------------------------------------------------------ */

    @Override
    public boolean getScrollableTracksViewportWidth() {
        return wrap;
    }

    @Override
    public boolean getScrollableTracksViewportHeight() {
        return false;
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        int height = Math.max(d.height, 10);
        int width = d.width;
        if (!wrap) {
            if (contentWidthDirty) {
                computeContentWidth();
            }
            Insets in = getInsets();
            width = Math.max(width, cachedContentWidth + in.left + in.right + 24);
        }
        // A scrollable view that does not track the viewport is sized to exactly its preferred
        // size, so a short or empty buffer would leave the editor as a small component in the
        // corner: the rest of the pane would reject the caret and the active line highlight would
        // stop at the last character. Asking for at least the viewport keeps the whole editor area
        // usable, which is what VS Code does, and still lets a long line scroll sideways.
        Component host = getParent();
        if (host != null) {
            width = Math.max(width, host.getWidth());
            height = Math.max(height, host.getHeight());
        }
        return new Dimension(width, height);
    }

    private void computeContentWidth() {
        contentWidthDirty = false;
        String text = text();
        FontMetrics fm = getFontMetrics(getFont());
        int max = 0;
        int from = 0;
        int lines = 0;
        while (from <= text.length() && lines < 20000) {
            int nl = text.indexOf('\n', from);
            if (nl < 0) {
                nl = text.length();
            }
            int w = measure(fm, text, from, nl);
            if (w > max) {
                max = w;
            }
            from = nl + 1;
            lines++;
        }
        cachedContentWidth = max;
    }

    private int measure(FontMetrics fm, String text, int from, int to) {
        StringBuilder sb = new StringBuilder(to - from);
        for (int i = from; i < to; i++) {
            char c = text.charAt(i);
            sb.append(c == '\t' ? " ".repeat(Math.max(1, tabSize)) : c);
        }
        return fm.stringWidth(sb.toString());
    }

    /* ------------------------------------------------------------------ */
    /* text helpers                                                        */
    /* ------------------------------------------------------------------ */

    public String text() {
        if (!textCacheValid) {
            textCache = bundle.content();
            textCacheValid = true;
            contentWidthDirty = true;
        }
        return textCache;
    }

    public int lineCount() {
        return bundle.doc.getDefaultRootElement().getElementCount();
    }

    public int caretLine() {
        return bundle.doc.getDefaultRootElement().getElementIndex(getCaretPosition());
    }

    public int caretColumn() {
        Element root = bundle.doc.getDefaultRootElement();
        Element line = root.getElement(root.getElementIndex(getCaretPosition()));
        return getCaretPosition() - line.getStartOffset();
    }

    public int lineStart(int line) {
        return bundle.doc.getDefaultRootElement().getElement(line).getStartOffset();
    }

    /** Zero based line -> offset of the first character. */
    public int offsetOfLine(int line) {
        Element root = bundle.doc.getDefaultRootElement();
        int idx = Math.max(0, Math.min(root.getElementCount() - 1, line));
        return root.getElement(idx).getStartOffset();
    }

    private String lineText(int line) {
        Element root = bundle.doc.getDefaultRootElement();
        if (line < 0 || line >= root.getElementCount()) {
            return "";
        }
        Element el = root.getElement(line);
        int end = Math.min(el.getEndOffset(), bundle.doc.getLength());
        try {
            return bundle.doc.getText(el.getStartOffset(), end - el.getStartOffset());
        } catch (BadLocationException e) {
            return "";
        }
    }

    private String indentUnit() {
        return insertSpaces ? " ".repeat(tabSize) : "\t";
    }

    public String indentationOf(int line) {
        String s = lineText(line);
        int i = 0;
        while (i < s.length() && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) {
            i++;
        }
        return s.substring(0, i);
    }

    private static String leadingWhitespace(String s) {
        int i = 0;
        while (i < s.length() && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) {
            i++;
        }
        return s.substring(0, i);
    }

    /* ------------------------------------------------------------------ */
    /* decorations                                                         */
    /* ------------------------------------------------------------------ */

    private void updateLineHighlight() {
        if (!highlightLine) {
            return;
        }
        Element root = bundle.doc.getDefaultRootElement();
        int caret = getCaretPosition();
        int line = root.getElementIndex(caret);
        Element el = root.getElement(line);
        int from = el.getStartOffset();
        int to = Math.min(el.getEndOffset(), bundle.doc.getLength());
        if (to <= from) {
            if (from < bundle.doc.getLength()) {
                to = from + 1;
            } else {
                removeLineHighlight();
                return;
            }
        }
        if (lineHighlightTag != null && from == lineHighlightFrom && to == lineHighlightTo) {
            return;
        }
        removeLineHighlight();
        try {
            lineHighlightTag = getHighlighter().addHighlight(from, to, linePainter);
            lineHighlightFrom = from;
            lineHighlightTo = to;
        } catch (BadLocationException ignored) {
        }
    }

    private void removeLineHighlight() {
        if (lineHighlightTag != null) {
            getHighlighter().removeHighlight(lineHighlightTag);
            lineHighlightTag = null;
        }
    }

    private void updateBrackets() {
        removeBrackets();
        String text = text();
        int caret = getCaretPosition();
        if (text.isEmpty()) {
            return;
        }
        int[] pair = null;
        int after = caret;
        if (after < text.length()) {
            pair = matchBracket(text, after);
        }
        if (pair == null && caret > 0) {
            pair = matchBracket(text, caret - 1);
        }
        if (pair == null) {
            return;
        }
        try {
            bracketTag1 = getHighlighter().addHighlight(pair[0], pair[0] + 1, bracketPainter);
            bracketTag2 = getHighlighter().addHighlight(pair[1], pair[1] + 1, bracketPainter);
        } catch (BadLocationException ignored) {
        }
    }

    private static final String OPEN = "([{";
    private static final String CLOSE = ")]}";

    /** Returns {openOffset, closeOffset} when the bracket at index matches. */
    private static int[] matchBracket(String text, int index) {
        if (index < 0 || index >= text.length()) {
            return null;
        }
        char c = text.charAt(index);
        int openIdx = OPEN.indexOf(c);
        int closeIdx = CLOSE.indexOf(c);
        if (openIdx >= 0) {
            int depth = 0;
            int limit = Math.min(text.length(), index + 200_000);
            for (int i = index; i < limit; i++) {
                char x = text.charAt(i);
                if (x == c) {
                    depth++;
                } else if (x == CLOSE.charAt(openIdx)) {
                    depth--;
                    if (depth == 0) {
                        return new int[]{index, i};
                    }
                }
            }
            return null;
        }
        if (closeIdx >= 0) {
            int depth = 0;
            int limit = Math.max(0, index - 200_000);
            for (int i = index; i >= limit; i--) {
                char x = text.charAt(i);
                if (x == c) {
                    depth++;
                } else if (x == OPEN.charAt(closeIdx)) {
                    depth--;
                    if (depth == 0) {
                        return new int[]{i, index};
                    }
                }
            }
        }
        return null;
    }

    private void removeBrackets() {
        if (bracketTag1 != null) {
            getHighlighter().removeHighlight(bracketTag1);
            bracketTag1 = null;
        }
        if (bracketTag2 != null) {
            getHighlighter().removeHighlight(bracketTag2);
            bracketTag2 = null;
        }
    }

    private void updateOccurrences() {
        for (Object tag : occurrenceTags) {
            getHighlighter().removeHighlight(tag);
        }
        occurrenceTags.clear();
        if (!showOccurrences) {
            return;
        }
        String text = text();
        if (text.length() > 400_000 || text.isEmpty()) {
            return;
        }
        int start = getSelectionStart();
        int end = getSelectionEnd();
        if (start == end) {
            int[] word = wordAt(text, getCaretPosition());
            if (word == null) {
                return;
            }
            start = word[0];
            end = word[1];
        }
        String needle = text.substring(start, end);
        if (needle.isBlank() || needle.length() > 120 || needle.contains("\n")) {
            return;
        }
        int from = 0;
        int count = 0;
        while (count < 400) {
            int idx = text.indexOf(needle, from);
            if (idx < 0) {
                break;
            }
            if (idx != start) {
                try {
                    occurrenceTags.add(getHighlighter().addHighlight(idx, idx + needle.length(), occurrencePainter));
                } catch (BadLocationException ignored) {
                }
            }
            from = idx + Math.max(1, needle.length());
            count++;
        }
        if (!occurrenceTags.isEmpty()) {
            repaint();
        }
    }

    private static int[] wordAt(String text, int pos) {
        if (pos < 0 || pos > text.length()) {
            return null;
        }
        int a = pos;
        int b = pos;
        while (a > 0 && isWordChar(text.charAt(a - 1))) {
            a--;
        }
        while (b < text.length() && isWordChar(text.charAt(b))) {
            b++;
        }
        if (b - a < 2) {
            return null;
        }
        return new int[]{a, b};
    }

    private static boolean isWordChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_' || c == '$';
    }

    /* ------------------------------------------------------------------ */
    /* whitespace rendering                                                */
    /* ------------------------------------------------------------------ */

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (foldingEnabled && !foldedStarts.isEmpty()) {
            paintFoldMarkers(g);
        }
        if (!renderWhitespace) {
            return;
        }
        Rectangle clip = g.getClipBounds();
        if (clip == null) {
            return;
        }
        String text = text();
        if (text.isEmpty()) {
            return;
        }
        int startPos = viewToModel2D(new Point(0, Math.max(0, clip.y)));
        int endPos = viewToModel2D(new Point(Math.max(1, getWidth()), clip.y + clip.height));
        startPos = Math.max(0, Math.min(startPos, text.length() - 1));
        endPos = Math.max(startPos, Math.min(endPos, text.length() - 1));
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(UI.alpha(theme.gutterFg, 110));
        FontMetrics fm = getFontMetrics(getFont());
        for (int i = startPos; i <= endPos; i++) {
            char c = text.charAt(i);
            if (c != ' ' && c != '\t') {
                continue;
            }
            try {
                Rectangle r = rectOf(this, i);
                if (r == null) {
                    continue;
                }
                if (c == ' ') {
                    g2.fillRect(r.x + r.width / 2 - 1, r.y + r.height / 2 - 1, 2, 2);
                } else {
                    g2.drawLine(r.x + 3, r.y + r.height - 4, r.x + Math.max(4, fm.charWidth(' ')) - 2, r.y + r.height - 4);
                    g2.drawLine(r.x + Math.max(4, fm.charWidth(' ')) - 4, r.y + r.height - 7,
                            r.x + Math.max(4, fm.charWidth(' ')) - 2, r.y + r.height - 4);
                }
            } catch (Exception ignored) {
            }
        }
        g2.dispose();
    }

    /**
     * Draws the small "- marker on every folded line, the same affordance VS Code uses to say
     * that text is there and merely hidden. Without it a collapsed block is indistinguishable from
     * one that was never there.
     */
    private void paintFoldMarkers(Graphics g0) {
        Graphics2D g2 = (Graphics2D) g0.create();
        try {
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            Element root = bundle.doc.getDefaultRootElement();
            FontMetrics fm = getFontMetrics(getFont());
            String dots = "\u2026";
            for (int line : foldedStarts) {
                if (line < 0 || line >= root.getElementCount()) {
                    continue;
                }
                Element el = root.getElement(line);
                int start = el.getStartOffset();
                int end = Math.min(el.getEndOffset(), bundle.doc.getLength());
                if (end <= start) {
                    continue;
                }
                int lastChar = Math.max(start, end - 1);
                Rectangle r = rectOf(this, lastChar);
                if (r == null || r.y + r.height < 0) {
                    continue;
                }
                int w = fm.stringWidth(dots) + 8;
                int h = Math.max(12, r.height - 4);
                int x = r.x + r.width + 4;
                int y = r.y + 2;
                g2.setColor(theme.widgetBg);
                g2.fillRoundRect(x, y, w, h, 5, 5);
                g2.setColor(theme.widgetBorder);
                g2.drawRoundRect(x, y, w, h, 5, 5);
                g2.setColor(theme.gutterFg);
                g2.drawString(dots, x + 4, y + h - fm.getDescent() - 1);
            }
        } finally {
            g2.dispose();
        }
    }

    /* ------------------------------------------------------------------ */
    /* key bindings                                                        */
    /* ------------------------------------------------------------------ */

    private void bind(String stroke, String name, Action action) {
        InputMap im = getInputMap();
        ActionMap am = getActionMap();
        im.put(KeyStroke.getKeyStroke(stroke), name);
        am.put(name, action);
    }

    private void bindChar(char c, String name, Action action) {
        InputMap im = getInputMap();
        ActionMap am = getActionMap();
        im.put(KeyStroke.getKeyStroke(c), name);
        am.put(name, action);
    }

    /**
     * Runs one of the editor's own actions, for the keys this pane takes over only while a
     * suggestion is showing. When nothing is showing the keystroke must behave exactly as it did
     * before, so the action is re-dispatched from the default action map.
     */
    private void fallback(String actionName, ActionEvent cause) {
        Action action = getActionMap().get(actionName);
        if (action != null) {
            action.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, actionName,
                    cause == null ? System.currentTimeMillis() : cause.getWhen(),
                    cause == null ? 0 : cause.getModifiers()));
        }
    }

    private void installKeyBindings() {
        bind("ENTER", "cs-enter", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (acceptSuggestion()) {
                    return;
                }
                smartEnter(false);
            }
        });
        bind("shift ENTER", "cs-enter-above", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                smartEnter(true);
            }
        });
        bind("TAB", "cs-tab", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (acceptSuggestion()) {
                    return;
                }
                if (getSelectionStart() != getSelectionEnd()) {
                    indentSelection(false);
                } else {
                    replaceSelection(indentUnit());
                }
            }
        });
        bind("shift TAB", "cs-shift-tab", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                indentSelection(true);
            }
        });
        bind("UP", "cs-up", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (suggestionVisible()) {
                    moveSuggestion(-1);
                    return;
                }
                fallback("caret-up", e);
            }
        });
        bind("DOWN", "cs-down", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (suggestionVisible()) {
                    moveSuggestion(1);
                    return;
                }
                fallback("caret-down", e);
            }
        });
        bind("ESCAPE", "cs-escape", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (suggestionVisible()) {
                    hideSuggestions();
                }
            }
        });
        bind("ctrl SPACE", "cs-suggest", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                triggerSuggest();
            }
        });
        bind("ctrl SLASH", "cs-comment", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleComment();
            }
        });
        bind("ctrl D", "cs-dup", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                duplicateSelection();
            }
        });
        bind("ctrl shift K", "cs-del-line", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteLines();
            }
        });
        bind("alt UP", "cs-move-up", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveLines(-1);
            }
        });
        bind("alt DOWN", "cs-move-down", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveLines(1);
            }
        });
        bind("shift alt UP", "cs-copy-up", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                copyLines(-1);
            }
        });
        bind("shift alt DOWN", "cs-copy-down", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                copyLines(1);
            }
        });
        bind("BACK_SPACE", "cs-backspace", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!deleteEmptyPair()) {
                    Action def = getActionMap().get("delete-previous");
                    if (def != null) {
                        def.actionPerformed(e);
                    }
                }
            }
        });

        if (autoClose) {
            char[] openers = {'(', '[', '{'};
            char[] closers = {')', ']', '}'};
            for (int i = 0; i < openers.length; i++) {
                final char open = openers[i];
                final char close = closers[i];
                bindChar(open, "cs-open-" + open, new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        insertPair(open, close, true);
                    }
                });
                bindChar(close, "cs-close-" + close, new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        insertPair(open, close, false);
                    }
                });
            }
            char[] quotes = {'"', '\'', '`'};
            for (char q : quotes) {
                bindChar(q, "cs-quote-" + (int) q, new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        insertPair(q, q, true);
                    }
                });
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* editing operations                                                  */
    /* ------------------------------------------------------------------ */

    /** Handles both the wrapping and the "type over the closing bracket" cases. */
    private void insertPair(char open, char close, boolean isOpener) {
        int selStart = getSelectionStart();
        int selEnd = getSelectionEnd();
        String text = text();
        if (!isOpener) {
            if (selStart == selEnd && selStart < text.length() && text.charAt(selStart) == close) {
                setCaretPosition(selStart + 1);
                return;
            }
            replaceSelection(String.valueOf(close));
            return;
        }
        if (selStart != selEnd) {
            String selected = text.substring(selStart, selEnd);
            bundle.beginCompound();
            replaceSelection(open + selected + close);
            bundle.endCompound();
            select(selStart + 1, selEnd + 1);
            return;
        }
        // quotes: don't pair inside a word
        if (open == close && selStart > 0 && selStart < text.length()) {
            char prev = text.charAt(selStart - 1);
            char next = text.charAt(selStart);
            if ((isWordChar(prev) && next != close) || (Character.isLetterOrDigit(prev) && closedQuoteAhead(text, selStart, close))) {
                replaceSelection(String.valueOf(open));
                return;
            }
            if (next == close) {
                setCaretPosition(selStart + 1);
                return;
            }
        }
        if (close == '}' || close == ')' || close == ']') {
            // expand to a block over two lines
            int line = caretLine();
            String indent = indentationOf(line);
            String insertion = open + "\n" + indent + indentUnit() + "\n" + indent + close;
            replaceSelection(insertion);
            int pos = getCaretPosition() - (close + "\n" + indent).length();
            setCaretPosition(pos);
            return;
        }
        replaceSelection(String.valueOf(open) + close);
        setCaretPosition(getCaretPosition() - 1);
    }

    private boolean closedQuoteAhead(String text, int pos, char quote) {
        int i = pos;
        while (i < text.length() && i < pos + 200 && text.charAt(i) != '\n') {
            if (text.charAt(i) == quote) {
                return true;
            }
            i++;
        }
        return false;
    }

    private boolean deleteEmptyPair() {
        if (!autoClose) {
            return false;
        }
        int caret = getCaretPosition();
        if (caret == 0 || caret >= bundle.doc.getLength() || getSelectionStart() != getSelectionEnd()) {
            return false;
        }
        try {
            char prev = bundle.doc.getText(caret - 1, 1).charAt(0);
            char next = bundle.doc.getText(caret, 1).charAt(0);
            if ((prev == '(' && next == ')') || (prev == '[' && next == ']') || (prev == '{' && next == '}')
                    || (prev == '"' && next == '"') || (prev == '\'' && next == '\'') || (prev == '`' && next == '`')) {
                bundle.beginCompound();
                bundle.doc.remove(caret - 1, 2);
                bundle.endCompound();
                return true;
            }
        } catch (BadLocationException ignored) {
        }
        return false;
    }

    private void smartEnter(boolean above) {
        int caret = getCaretPosition();
        int line = caretLine();
        String indent = indentationOf(line);
        String unit = indentUnit();
        String text = text();
        String before = text.substring(lineStart(line), Math.min(caret, text.length()));
        String trimmedBefore = before.stripTrailing();

        boolean opensBlock = trimmedBefore.endsWith("{") || trimmedBefore.endsWith("[")
                || trimmedBefore.endsWith("(");
        if (bundle.language != null && bundle.language.lexer == com.codestudio.core.Language.Lexer.PYTHON
                && trimmedBefore.endsWith(":")) {
            opensBlock = true;
        }
        String inner = opensBlock ? indent + unit : indent;
        if (bundle.language != null && bundle.language.lexer == com.codestudio.core.Language.Lexer.PYTHON) {
            String t = trimmedBefore;
            if (t.startsWith("return") || t.startsWith("break") || t.startsWith("continue")
                    || t.startsWith("pass") || t.startsWith("raise")) {
                inner = indent;
            }
        }

        int lineEnd = Math.min(lineStart(line) + lineText(line).length(), bundle.doc.getLength());
        String rest = caret <= lineEnd ? text.substring(Math.min(caret, text.length()),
                Math.min(lineEnd, text.length())) : "";
        String restTrim = rest.stripLeading();
        boolean closesNext = !restTrim.isEmpty()
                && (restTrim.charAt(0) == '}' || restTrim.charAt(0) == ']' || restTrim.charAt(0) == ')');

        if (above) {
            bundle.beginCompound();
            try {
                bundle.doc.insertString(lineStart(line), "\n" + indent, null);
            } catch (BadLocationException ignored) {
            }
            bundle.endCompound();
            setCaretPosition(lineStart(line) + indent.length());
            return;
        }

        bundle.beginCompound();
        try {
            if (closesNext) {
                String insertion = "\n" + inner + "\n" + indent;
                bundle.doc.insertString(caret, insertion, null);
                setCaretPosition(caret + 1 + inner.length());
            } else {
                String insertion = "\n" + inner;
                bundle.doc.insertString(caret, insertion, null);
                setCaretPosition(caret + insertion.length());
            }
        } catch (BadLocationException ignored) {
        } finally {
            bundle.endCompound();
        }
    }

    public void indentSelection(boolean outdent) {
        int start = getSelectionStart();
        int end = getSelectionEnd();
        Element root = bundle.doc.getDefaultRootElement();
        int first = root.getElementIndex(start);
        int last = root.getElementIndex(Math.max(start, end - 1));
        String unit = indentUnit();
        bundle.beginCompound();
        int delta = 0;
        try {
            for (int line = first; line <= last; line++) {
                Element el = root.getElement(line);
                int ls = el.getStartOffset();
                if (outdent) {
                    int removable = 0;
                    boolean tab = false;
                    try {
                        String s = bundle.doc.getText(ls, Math.min(tabSize, bundle.doc.getLength() - ls));
                        if (!s.isEmpty() && s.charAt(0) == '\t') {
                            tab = true;
                        } else {
                            while (removable < s.length() && removable < tabSize && s.charAt(removable) == ' ') {
                                removable++;
                            }
                        }
                    } catch (BadLocationException ignored) {
                    }
                    int n = tab ? 1 : removable;
                    if (n > 0) {
                        bundle.doc.remove(ls, n);
                        if (line == first) {
                            delta -= n;
                        }
                    }
                } else {
                    bundle.doc.insertString(ls, unit, null);
                    delta += unit.length();
                }
            }
        } catch (BadLocationException ignored) {
        } finally {
            bundle.endCompound();
        }
        if (outdent) {
            select(Math.max(0, start + delta), end);
        } else {
            select(start + unit.length(), end + delta);
        }
    }

    public void toggleComment() {
        String marker = bundle.language == null || bundle.language.lineComments.length == 0
                ? "//" : bundle.language.lineComments[0];
        Element root = bundle.doc.getDefaultRootElement();
        int start = getSelectionStart();
        int end = getSelectionEnd();
        int first = root.getElementIndex(start);
        int last = root.getElementIndex(Math.max(start, end - 1));
        boolean allCommented = true;
        int minIndent = Integer.MAX_VALUE;
        for (int line = first; line <= last; line++) {
            String s = lineText(line);
            if (s.isBlank()) {
                continue;
            }
            String t = s.stripLeading();
            if (!t.startsWith(marker)) {
                allCommented = false;
            }
            minIndent = Math.min(minIndent, s.length() - t.length());
        }
        if (minIndent == Integer.MAX_VALUE) {
            minIndent = 0;
        }
        bundle.beginCompound();
        try {
            if (allCommented) {
                for (int line = first; line <= last; line++) {
                    Element el = root.getElement(line);
                    int ls = el.getStartOffset();
                    String s = lineText(line);
                    int idx = s.indexOf(marker);
                    if (idx >= 0) {
                        int removeLen = marker.length();
                        if (idx + removeLen < s.length() && s.charAt(idx + removeLen) == ' ') {
                            removeLen++;
                        }
                        bundle.doc.remove(ls + idx, removeLen);
                    }
                }
            } else {
                for (int line = first; line <= last; line++) {
                    Element el = root.getElement(line);
                    if (lineText(line).isBlank()) {
                        continue;
                    }
                    bundle.doc.insertString(el.getStartOffset() + Math.min(minIndent, indentLen(lineText(line))),
                            marker + " ", null);
                }
            }
        } catch (BadLocationException ignored) {
        } finally {
            bundle.endCompound();
        }
        select(root.getElement(first).getStartOffset(),
                Math.min(bundle.doc.getLength(),
                        root.getElement(Math.min(last, root.getElementCount() - 1)).getEndOffset()));
        fireState();
    }

    private static int indentLen(String s) {
        int i = 0;
        while (i < s.length() && (s.charAt(i) == ' ' || s.charAt(i) == '\t')) {
            i++;
        }
        return i;
    }

    private void duplicateSelection() {
        int start = getSelectionStart();
        int end = getSelectionEnd();
        Element root = bundle.doc.getDefaultRootElement();
        if (start == end) {
            int line = root.getElementIndex(getCaretPosition());
            Element el = root.getElement(line);
            int from = el.getStartOffset();
            int to = Math.min(el.getEndOffset(), bundle.doc.getLength());
            if (to <= from) {
                return;
            }
            try {
                String s = bundle.doc.getText(from, to - from);
                String ins = s.endsWith("\n") ? s : s + "\n";
                bundle.beginCompound();
                bundle.doc.insertString(to, ins, null);
                bundle.endCompound();
                setCaretPosition(getCaretPosition() + ins.length());
            } catch (BadLocationException ignored) {
            }
            return;
        }
        int first = root.getElementIndex(start);
        int last = root.getElementIndex(Math.max(start, end - 1));
        int from = root.getElement(first).getStartOffset();
        int to = Math.min(root.getElement(last).getEndOffset(), bundle.doc.getLength());
        try {
            String s = bundle.doc.getText(from, to - from);
            String ins = s.endsWith("\n") ? s : s + "\n";
            bundle.beginCompound();
            bundle.doc.insertString(to, ins, null);
            bundle.endCompound();
            setCaretPosition(to + ins.length());
        } catch (BadLocationException ignored) {
        }
    }

    private void deleteLines() {
        Element root = bundle.doc.getDefaultRootElement();
        int start = getSelectionStart();
        int end = getSelectionEnd();
        int first = root.getElementIndex(start);
        int last = root.getElementIndex(Math.max(start, end - 1));
        int from = root.getElement(first).getStartOffset();
        int to = Math.min(root.getElement(last).getEndOffset(), bundle.doc.getLength());
        if (to <= from) {
            return;
        }
        bundle.beginCompound();
        try {
            bundle.doc.remove(from, to - from);
        } catch (BadLocationException ignored) {
        } finally {
            bundle.endCompound();
        }
        setCaretPosition(Math.min(from, bundle.doc.getLength()));
    }

    /** Splits text into lines, keeping a trailing empty entry for a final newline. */
    static List<String> splitLines(String text) {
        List<String> out = new ArrayList<>();
        int from = 0;
        while (true) {
            int nl = text.indexOf('\n', from);
            if (nl < 0) {
                out.add(text.substring(from));
                break;
            }
            out.add(text.substring(from, nl));
            from = nl + 1;
            if (from == text.length()) {
                out.add("");
                break;
            }
        }
        return out;
    }

    private void moveLines(int direction) {
        Element root = bundle.doc.getDefaultRootElement();
        int start = getSelectionStart();
        int end = getSelectionEnd();
        int first = root.getElementIndex(start);
        int last = root.getElementIndex(Math.max(start, end - 1));
        List<String> lines = splitLines(text());
        if (last >= lines.size() - 1 && direction > 0) {
            return;
        }
        if (first == 0 && direction < 0) {
            return;
        }
        if (last < first || first < 0 || last >= lines.size()) {
            return;
        }
        int blockSize = last - first + 1;
        List<String> block = new ArrayList<>(lines.subList(first, first + blockSize));
        int offsetInBlock = start - root.getElement(first).getStartOffset();

        if (direction < 0) {
            String prev = lines.get(first - 1);
            lines.subList(first - 1, first + blockSize).clear();
            lines.addAll(first - 1, block);
            lines.add(first - 1 + blockSize, prev);
        } else {
            String next = lines.get(last + 1);
            lines.subList(first, last + 2).clear();
            lines.add(first, next);
            lines.addAll(first + 1, block);
        }
        bundle.replaceAll(String.join("\n", lines));
        int newLineIndex = direction < 0 ? first - 1 : first + 1;
        int target = offsetOfLine(newLineIndex) + offsetInBlock;
        setCaretPosition(Math.max(0, Math.min(bundle.doc.getLength(), target)));
        if (end > start) {
            moveCaretPosition(Math.max(0, Math.min(bundle.doc.getLength(), target + (end - start))));
        }
    }

    private void copyLines(int direction) {
        Element root = bundle.doc.getDefaultRootElement();
        int line = root.getElementIndex(getCaretPosition());
        List<String> lines = splitLines(text());
        if (line < 0 || line >= lines.size()) {
            return;
        }
        int caretInLine = getCaretPosition() - root.getElement(line).getStartOffset();
        String copy = lines.get(line);
        lines.add(direction < 0 ? line : line + 1, copy);
        bundle.replaceAll(String.join("\n", lines));
        int targetLine = direction < 0 ? line + 1 : line;
        setCaretPosition(Math.min(bundle.doc.getLength(), offsetOfLine(targetLine) + caretInLine));
    }

    /**
     * A deliberately simple "format document": normalises indentation from
     * brace depth and trims trailing whitespace. It is not a language aware
     * formatter but keeps indentation consistent like VS Code's basic mode.
     */
    public void formatDocument() {
        String text = text();
        List<String> lines = splitLines(text);
        boolean py = bundle.language != null && bundle.language.lexer == com.codestudio.core.Language.Lexer.PYTHON;
        String unit = indentUnit();
        StringBuilder sb = new StringBuilder(text.length());
        int depth = 0;
        for (int i = 0; i < lines.size(); i++) {
            String raw = lines.get(i);
            String t = raw.strip();
            boolean last = i == lines.size() - 1;
            if (t.isEmpty()) {
                if (!last) {
                    sb.append('\n');
                } else if (!text.endsWith("\n")) {
                    // nothing
                }
                continue;
            }
            if (py) {
                sb.append(unit.repeat(Math.max(0, Math.min(40, depth)))).append(t);
            } else {
                int lead = 0;
                while (lead < t.length() && (t.charAt(lead) == '}' || t.charAt(lead) == ')'
                        || t.charAt(lead) == ']')) {
                    lead++;
                }
                int useDepth = Math.max(0, depth - lead);
                sb.append(unit.repeat(Math.max(0, Math.min(40, useDepth)))).append(t);
            }
            int opens = count(t, '{') + count(t, '[') + count(t, '(');
            int closes = count(t, '}') + count(t, ']') + count(t, ')');
            depth = Math.max(0, depth + opens - closes);
            if (py && t.endsWith(":")) {
                depth++;
            }
            if (i < lines.size() - 1 || text.endsWith("\n")) {
                sb.append('\n');
            }
        }
        String out = sb.toString();
        if (out.equals(text)) {
            return;
        }
        int caret = getCaretPosition();
        bundle.replaceAll(out);
        setCaretPosition(Math.min(caret, bundle.doc.getLength()));
        fireState();
    }

    private static int count(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == c) {
                n++;
            }
        }
        return n;
    }

    /* ------------------------------------------------------------------ */

    /** Converts a document offset to a component rectangle (never null). */
    static Rectangle rectOf(JTextComponent c, int pos) {
        try {
            Shape s = c.modelToView2D(pos);
            return s == null ? null : s.getBounds();
        } catch (Exception e) {
            return null;
        }
    }

    /** Simple character cell painter used for all editor decorations. */
    private static class CellPainter implements Highlighter.HighlightPainter {
        Color fill;
        Color border;

        CellPainter(Color fill, Color border) {
            this.fill = fill;
            this.border = border;
        }

        @Override
        public void paint(Graphics g, int p0, int p1, Shape bounds, JTextComponent c) {
            Rectangle a = rectOf(c, p0);
            Rectangle b = rectOf(c, Math.max(p0, p1 - 1));
            if (a == null || a.height <= 0) {
                return;
            }
            int width = (b == null ? a.width : b.x + b.width - a.x);
            if (width <= 0) {
                width = 8;
            }
            if (fill != null) {
                g.setColor(fill);
                g.fillRect(a.x, a.y, width, a.height);
            }
            if (border != null) {
                g.setColor(border);
                g.drawRect(a.x, a.y, Math.max(1, width) - 1, a.height - 1);
            }
        }
    }

    /** Full width row highlight for the active line. */
    private static class RowPainter implements Highlighter.HighlightPainter {
        Color color;

        RowPainter(Color color) {
            this.color = color;
        }

        @Override
        public void paint(Graphics g, int p0, int p1, Shape bounds, JTextComponent c) {
            Rectangle a = rectOf(c, p0);
            if (a == null || a.height <= 0) {
                return;
            }
            g.setColor(color);
            g.fillRect(0, a.y, c.getWidth(), a.height);
        }
    }

    public void selectLine(int line) {
        int start = offsetOfLine(line);
        int end = Math.min(bundle.doc.getLength(), start + lineText(line).length());
        setCaretPosition(end);
        moveCaretPosition(start);
        scrollTo(start);
        requestFocusInWindow();
    }

    public void gotoLine(int line, int column) {
        int start = offsetOfLine(line);
        int pos = Math.max(0, Math.min(bundle.doc.getLength(), start + Math.max(0, column)));
        setCaretPosition(pos);
        scrollTo(pos);
        requestFocusInWindow();
    }

    /** Scrolls so that a given offset is roughly centred. */
    public void scrollTo(int pos) {
        try {
            Rectangle r = rectOf(this, pos);
            if (r != null) {
                int h = getParent() != null ? getParent().getHeight() : getHeight();
                scrollRectToVisible(new Rectangle(Math.max(0, r.x - 40), Math.max(0, r.y - h / 2),
                        Math.max(1, r.width), Math.max(1, r.height + h / 2)));
            }
        } catch (Exception ignored) {
        }
    }
}
