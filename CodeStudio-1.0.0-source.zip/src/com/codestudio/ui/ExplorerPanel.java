package com.codestudio.ui;

import com.codestudio.core.DocumentBundle;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.ToolTipManager;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.plaf.basic.BasicTreeUI;

/** The Explorer view: open editors, the workspace file tree and the outline. */
public class ExplorerPanel extends JPanel implements ThemeAware {

    /** Callbacks implemented by the main window. */
    public interface Actions {
        void openFile(File f);

        void openFolder(File dir);

        void notify(String message, boolean error);

        void runInTerminal(File dir);

        void revealInOS(File file);

        void refreshExplorer();

        void closeDocument(File f);

        void requestNewFile(File parentDir);

        void requestNewFolder(File parentDir);
    }

    private final Settings settings;
    private final Workspace workspace;
    private final FileTreeModel model;
    private final JTree tree;
    private final Theme theme;

    private final SectionHeader header;
    private final SectionHeader folderHeader;
    private final JPanel folderBox;
    private final JLabel folderLabel = new JLabel();

    private final SectionHeader openEditorsHeader;
    private final JPanel openEditorsList = new JPanel();
    private final JPanel openEditorsBox;
    private final JScrollPane openEditorsScroll;

    private final SectionHeader outlineHeader;
    private final OutlinePanel outline;
    private final JScrollPane outlineSectionScroll;
    private final JPanel outlineBox;

    private final JScrollPane treeScroll;
    private Actions actions;

    private File activeFile;
    private File rootFile;
    private final Timer watcher;
    private boolean restoring;

    /** Last open-editors snapshot, kept so {@link #retranslate} can rebuild the list. */
    private List<DocumentBundle> lastDocs;
    private DocumentBundle lastActive;

    public ExplorerPanel(Settings settings, Workspace workspace, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.workspace = workspace;
        this.theme = theme;
        this.model = new FileTreeModel(workspace);

        setBackground(theme.sidebarBg);

        /* ---------- header ---------- */
        header = new SectionHeader("Explorer", theme);
        header.addAction("new-file", "New File", () -> requestNewFile(null));
        header.addAction("new-folder", "New Folder", () -> requestNewFolder(null));
        header.addAction("refresh", "Refresh Explorer", this::refreshAll);
        header.addAction("collapse-all", "Collapse Folders", this::collapseAll);

        /* ---------- open editors ---------- */
        openEditorsHeader = new SectionHeader("Open Editors", theme);
        openEditorsList.setLayout(new javax.swing.BoxLayout(openEditorsList, javax.swing.BoxLayout.Y_AXIS));
        openEditorsList.setBackground(theme.sidebarBg);
        openEditorsList.setBorder(BorderFactory.createEmptyBorder(0, 0, 4, 0));
        openEditorsScroll = UI.scroll(openEditorsList, theme);
        openEditorsScroll.getViewport().setBackground(theme.sidebarBg);
        openEditorsScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        openEditorsBox = new JPanel(new BorderLayout());
        openEditorsBox.setOpaque(false);
        openEditorsBox.add(openEditorsScroll, BorderLayout.CENTER);
        openEditorsHeader.addToggleListener(() -> {
            openEditorsBox.setVisible(openEditorsHeader.isExpanded());
            revalidate();
            repaint();
        });

        /* ---------- folder row ---------- */
        folderHeader = new SectionHeader("No Folder", theme);
        folderLabel.setFont(UI.uiBold(11f));
        folderLabel.setForeground(theme.sidebarFg);
        folderHeader.addAction("new-file", "New File", () -> requestNewFile(null));
        folderHeader.addAction("new-folder", "New Folder", () -> requestNewFolder(null));
        folderHeader.addAction("refresh", "Refresh", this::refreshAll);
        folderHeader.addAction("collapse-all", "Collapse All", this::collapseAll);

        folderBox = new JPanel(new BorderLayout());
        folderBox.setOpaque(false);
        folderBox.add(folderHeader, BorderLayout.CENTER);

        /* ---------- tree ---------- */
        tree = new JTree(model);
        tree.setRootVisible(true);
        tree.setShowsRootHandles(false);
        tree.setUI(new FlatTreeUI());
        tree.setBackground(theme.sidebarBg);
        tree.setForeground(theme.sidebarFg);
        tree.setRowHeight(22);
        tree.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));
        tree.setCellRenderer(new Renderer());
        tree.setToggleClickCount(-1);
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        tree.putClientProperty("JTree.lineStyle", "None");
        ToolTipManager.sharedInstance().registerComponent(tree);

        tree.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                maybeShowPopup(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                maybeShowPopup(e);
            }

            private void maybeShowPopup(MouseEvent e) {
                if (!e.isPopupTrigger()) {
                    return;
                }
                TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                if (path != null) {
                    tree.setSelectionPath(path);
                }
                showContextMenu(e.getX(), e.getY(), nodeAt(path));
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() != MouseEvent.BUTTON1) {
                    return;
                }
                TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                if (path == null) {
                    return;
                }
                FileTreeModel.Node node = nodeAt(path);
                if (node == null) {
                    return;
                }
                if (node.isDirectory()) {
                    if (tree.isExpanded(path)) {
                        tree.collapsePath(path);
                    } else {
                        tree.expandPath(path);
                    }
                } else if (actions != null) {
                    actions.openFile(node.file);
                }
            }
        });

        tree.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    FileTreeModel.Node n = nodeAt(tree.getSelectionPath());
                    if (n == null) {
                        return;
                    }
                    if (n.isDirectory()) {
                        TreePath p = tree.getSelectionPath();
                        if (tree.isExpanded(p)) {
                            tree.collapsePath(p);
                        } else {
                            tree.expandPath(p);
                        }
                    } else if (actions != null) {
                        actions.openFile(n.file);
                    }
                } else if (e.getKeyCode() == KeyEvent.VK_DELETE && actions != null) {
                    FileTreeModel.Node n = nodeAt(tree.getSelectionPath());
                    if (n != null) {
                        delete(n);
                    }
                }
            }
        });

        tree.addTreeWillExpandListener(new TreeWillExpandListener() {
            @Override
            public void treeWillExpand(TreeExpansionEvent event) {
                // children load lazily through the model
            }

            @Override
            public void treeWillCollapse(TreeExpansionEvent event) {
                // nothing to release
            }
        });

        treeScroll = UI.scroll(tree, theme);
        treeScroll.getViewport().setBackground(theme.sidebarBg);
        treeScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        /* ---------- outline ---------- */
        outlineHeader = new SectionHeader("Outline", theme);
        outline = new OutlinePanel(theme);
        outlineSectionScroll = UI.scroll(outline, theme);
        outlineSectionScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        outlineBox = new JPanel(new BorderLayout());
        outlineBox.setOpaque(false);
        outlineBox.add(outlineSectionScroll, BorderLayout.CENTER);
        outlineHeader.addToggleListener(() -> {
            outlineBox.setVisible(outlineHeader.isExpanded());
            revalidate();
            repaint();
        });

        JPanel outlineWrap = new JPanel(new BorderLayout());
        outlineWrap.setBackground(theme.sidebarBg);
        outlineWrap.add(outlineHeader, BorderLayout.NORTH);
        outlineWrap.add(outlineBox, BorderLayout.CENTER);
        int outlineHeight = Math.max(80, settings.getInt("workbench.outlineHeight"));
        outlineWrap.setPreferredSize(new Dimension(10, outlineHeight + 26));
        outlineWrap.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, theme.sectionBorder));

        JPanel north = new JPanel();
        north.setLayout(new javax.swing.BoxLayout(north, javax.swing.BoxLayout.Y_AXIS));
        north.setBackground(theme.sidebarBg);
        north.add(header);
        north.add(openEditorsHeader);
        north.add(openEditorsBox);
        north.add(folderBox);
        north.add(sep());

        add(north, BorderLayout.NORTH);
        add(treeScroll, BorderLayout.CENTER);
        add(outlineWrap, BorderLayout.SOUTH);

        watcher = new Timer(2000, e -> pollFileSystem());
        watcher.setRepeats(true);
        watcher.start();

        setRoot(null);
    }

    private JPanel sep() {
        JPanel p = new JPanel();
        p.setBackground(theme.sectionBorder);
        p.setPreferredSize(new Dimension(10, 1));
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        return p;
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    public OutlinePanel outline() {
        return outline;
    }

    public FileTreeModel.Node nodeAt(TreePath path) {
        return path == null || !(path.getLastPathComponent() instanceof FileTreeModel.Node n) ? null : n;
    }

    /* ------------------------------------------------------------------ */
    /* root / refresh                                                      */
    /* ------------------------------------------------------------------ */

    public void setRoot(File dir) {
        this.rootFile = dir;
        model.setRoot(dir);
        if (dir == null) {
            folderHeader.setTitleText("No Folder");
            folderHeader.setToolTipText(null);
            tree.setRootVisible(false);
            tree.setEnabled(false);
            openEditorsHeader.setTitleText("Open Editors");
        } else {
            folderHeader.setTitleText(dir.getName().isEmpty() ? dir.getAbsolutePath() : dir.getName());
            folderHeader.setToolTipText(dir.getAbsolutePath());
            tree.setRootVisible(true);
            tree.setEnabled(true);
            if (!restoring) {
                SwingUtilities.invokeLater(() -> {
                    if (model.rootNode() != null) {
                        tree.expandPath(new TreePath(model.rootNode()));
                    }
                });
            }
        }
        treeScroll.setVisible(dir != null);
        openEditorsBox.setVisible(true);
        revalidate();
        repaint();
    }

    public File root() {
        return rootFile;
    }

    /** Re-reads every directory that has been expanded so far. */
    public void refreshAll() {
        FileTreeModel.Node root = model.rootNode();
        if (root == null) {
            return;
        }
        List<File> expanded = expandedPaths();
        root.children = null;
        model.refresh(root);
        restoreExpanded(expanded);
        tree.repaint();
    }

    public void collapseAll() {
        FileTreeModel.Node root = model.rootNode();
        if (root == null) {
            return;
        }
        for (int i = tree.getRowCount() - 1; i > 0; i--) {
            tree.collapseRow(i);
        }
        tree.expandPath(new TreePath(root));
    }

    private List<File> expandedPaths() {
        List<File> out = new ArrayList<>();
        Enumeration<TreePath> e = tree.getExpandedDescendants(new TreePath(model.getRoot()));
        if (e != null) {
            while (e.hasMoreElements()) {
                FileTreeModel.Node n = nodeAt(e.nextElement());
                if (n != null) {
                    out.add(n.file);
                }
            }
        }
        return out;
    }

    private void restoreExpanded(List<File> dirs) {
        for (File d : dirs) {
            FileTreeModel.Node n = model.find(d);
            if (n != null) {
                tree.expandPath(model.pathOf(n));
            }
        }
    }

    private void pollFileSystem() {
        if (!isShowing() || model.rootNode() == null) {
            return;
        }
        try {
            FileTreeModel.Node root = model.rootNode();
            if (walk(root)) {
                List<File> expanded = expandedPaths();
                restoreExpanded(expanded);
                tree.repaint();
            }
        } catch (Exception ignored) {
            // a directory disappeared while scanning; the next tick will catch up
        }
    }

    /** Returns true when at least one node was refreshed. */
    private boolean walk(FileTreeModel.Node node) {
        if (node == null || !node.isDirectory() || node.children == null) {
            return false;
        }
        long sig = node.signature();
        if (sig != node.stamp) {
            node.stamp = sig;
            model.refresh(node);
            return true;
        }
        for (FileTreeModel.Node child : new ArrayList<>(node.children)) {
            if (walk(child)) {
                return true;
            }
        }
        return false;
    }

    /** Asks the tree to expand down to a file and select it. */
    public void reveal(File file) {
        FileTreeModel.Node n = model.find(file);
        if (n == null) {
            return;
        }
        TreePath path = model.pathOf(n);
        tree.expandPath(path.getParentPath());
        tree.setSelectionPath(path);
        tree.scrollPathToVisible(path);
    }

    public void setActiveFile(File file) {
        this.activeFile = file;
        tree.repaint();
    }

    /* ------------------------------------------------------------------ */
    /* open editors list                                                   */
    /* ------------------------------------------------------------------ */

    public void setOpenEditors(List<DocumentBundle> docs, DocumentBundle active) {
        this.lastDocs = docs;
        this.lastActive = active;
        openEditorsList.removeAll();
        if (docs == null || docs.isEmpty()) {
            JLabel none = new JLabel(Strings.get("No open editors"));
            none.setForeground(UI.alpha(theme.sidebarFg, 150));
            none.setFont(UI.ui(12f));
            none.setBorder(BorderFactory.createEmptyBorder(2, 12, 2, 6));
            openEditorsList.add(none);
        } else {
            for (DocumentBundle b : docs) {
                openEditorsList.add(new EditorRow(b, b == active));
            }
        }
        openEditorsHeader.setTitleText(docs == null || docs.isEmpty()
                ? "Open Editors"
                : Strings.format("Open Editors: {0}", docs.size()));
        openEditorsList.revalidate();
        openEditorsList.repaint();
    }

    /**
     * Re-applies every visible string after a language change. The section headers redo their own
     * title and action tooltips, the outline carries its own filter placeholder, and the open
     * editors rows are rebuilt so their empty-state label and count title are re-rendered.
     */
    public void retranslate() {
        header.retranslate();
        openEditorsHeader.retranslate();
        folderHeader.retranslate();
        outlineHeader.retranslate();
        outline.retranslate();
        // Rebuilding after the header pass also replaces the dynamic "Open Editors: N" title.
        setOpenEditors(lastDocs, lastActive);
        tree.repaint();
        revalidate();
        repaint();
    }

    /** A single row of the OPEN EDITORS list. */
    private class EditorRow extends JPanel {
        private final DocumentBundle bundle;
        private boolean hovering;

        EditorRow(DocumentBundle bundle, boolean active) {
            super(new BorderLayout(5, 0));
            this.bundle = bundle;
            setBackground(active ? theme.listActive : theme.sidebarBg);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(2, 12, 2, 6));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            Color fg = active ? theme.listActiveFg : theme.sidebarFg;
            JLabel label = new JLabel(bundle.name());
            label.setFont(UI.ui(12f));
            label.setForeground(fg);
            label.setIcon(Icons.of("file", 13, badgeColor(bundle)));
            add(label, BorderLayout.CENTER);

            JLabel close = new JLabel();
            close.setPreferredSize(new Dimension(16, 14));
            close.setIcon(Icons.of("close", 12, fg));
            add(close, BorderLayout.EAST);

            boolean dirty = bundle.isDirty();
            if (dirty) {
                close.setIcon(new EditorGroup.DotIcon(fg));
            }
            bundle.addDirtyListener(() -> SwingUtilities.invokeLater(() ->
                    close.setIcon(bundle.isDirty() ? new EditorGroup.DotIcon(
                            isActive() ? theme.listActiveFg : theme.sidebarFg)
                            : Icons.of("close", 12, fg))));

            String tip = bundle.file == null ? Strings.get("Unsaved file") : bundle.file.getAbsolutePath();
            setToolTipText(bundle.isDirty() ? Strings.format("{0}  -  modified", tip) : tip);

            MouseAdapter handler = new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    if (!isActive()) {
                        setBackground(theme.listHover);
                        repaint();
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    if (!isActive()) {
                        setBackground(theme.sidebarBg);
                        repaint();
                    }
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (e.getSource() == close || close.getBounds().contains(e.getPoint())) {
                        if (actions != null) {
                            actions.closeDocument(bundle.file);
                        }
                    } else if (activeFileListener != null) {
                        activeFileListener.open(bundle);
                    }
                }
            };
            addMouseListener(handler);
            label.addMouseListener(handler);
            close.addMouseListener(handler);
        }

        private boolean isActive() {
            return getBackground().equals(theme.listActive);
        }
    }

    /** Hook used by the open-editors rows; the main window sets it. */
    public interface OpenEditorListener {
        void open(DocumentBundle bundle);
    }

    private OpenEditorListener activeFileListener;

    public void setOpenEditorListener(OpenEditorListener l) {
        this.activeFileListener = l;
    }

    private static Color badgeColor(DocumentBundle b) {
        String hex = b.language == null ? "#888888" : b.language.color;
        try {
            return Color.decode(hex);
        } catch (Exception e) {
            return new Color(0x888888);
        }
    }

    /* ------------------------------------------------------------------ */
    /* file operations                                                     */
    /* ------------------------------------------------------------------ */

    private void showContextMenu(int x, int y, FileTreeModel.Node node) {
        if (node == null) {
            return;
        }
        File target = node.file;
        File parentDir = target.isDirectory() ? target : target.getParentFile();

        JPopupMenu menu = new JPopupMenu();
        if (!target.isDirectory()) {
            addItem(menu, Strings.get("Open"), () -> {
                if (actions != null) {
                    actions.openFile(target);
                }
            });
        } else {
            addItem(menu, Strings.get("Open Folder as Workspace"), () -> {
                if (actions != null) {
                    actions.openFolder(target);
                }
            });
        }
        menu.addSeparator();
        addItem(menu, Strings.get("New File..."), () -> requestNewFile(parentDir));
        addItem(menu, Strings.get("New Folder..."), () -> requestNewFolder(parentDir));
        menu.addSeparator();
        addItem(menu, Strings.get("Rename..."), () -> rename(node));
        addItem(menu, Strings.get("Delete"), () -> delete(node));
        menu.addSeparator();
        addItem(menu, Strings.get("Copy Path"), () -> {
            java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(
                    new java.awt.datatransfer.StringSelection(target.getAbsolutePath()), null);
            if (actions != null) {
                actions.notify("Copied: " + target.getAbsolutePath(), false);
            }
        });
        addItem(menu, Strings.get("Copy Relative Path"), () -> {
            String rel = workspace.relative(target);
            java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(
                    new java.awt.datatransfer.StringSelection(rel), null);
            if (actions != null) {
                actions.notify("Copied: " + rel, false);
            }
        });
        menu.addSeparator();
        addItem(menu, Strings.get("Reveal in File Explorer"), () -> {
            if (actions != null) {
                actions.revealInOS(target);
            }
        });
        addItem(menu, Strings.get("Open in Terminal"), () -> {
            if (actions != null) {
                actions.runInTerminal(target.isDirectory() ? target : target.getParentFile());
            }
        });
        menu.addSeparator();
        addItem(menu, Strings.get("Refresh"), this::refreshAll);
        menu.show(tree, x, y);
    }

    private void addItem(JPopupMenu menu, String text, Runnable action) {
        JMenuItem item = new JMenuItem(text);
        item.setFont(UI.ui(12f));
        item.addActionListener(e -> action.run());
        menu.add(item);
    }

    private void requestNewFile(File dir) {
        File parent = resolveParent(dir);
        if (parent == null) {
            return;
        }
        if (actions != null) {
            actions.requestNewFile(parent);
        }
    }

    private void requestNewFolder(File dir) {
        File parent = resolveParent(dir);
        if (parent == null) {
            return;
        }
        if (actions != null) {
            actions.requestNewFolder(parent);
        }
    }

    private File resolveParent(File dir) {
        if (dir != null && dir.isDirectory()) {
            return dir;
        }
        FileTreeModel.Node sel = nodeAt(tree.getSelectionPath());
        if (sel != null) {
            return sel.isDirectory() ? sel.file : sel.file.getParentFile();
        }
        return rootFile;
    }

    /** Creates a file on disk and opens it. Public so the main window can drive it. */
    public void createFile(File dir, String name) {
        if (dir == null || name == null || name.isBlank()) {
            return;
        }
        File f = new File(dir, name.trim());
        try {
            if (f.getParentFile() != null) {
                Files.createDirectories(f.getParentFile().toPath());
            }
            if (f.exists()) {
                if (actions != null) {
                    actions.notify("File already exists: " + f.getName(), true);
                }
                return;
            }
            if (!f.createNewFile()) {
                if (actions != null) {
                    actions.notify("Could not create " + f.getName(), true);
                }
                return;
            }
            refreshAll();
            reveal(f);
            if (actions != null) {
                actions.openFile(f);
            }
        } catch (IOException e) {
            if (actions != null) {
                actions.notify("Could not create " + name + ": " + e.getMessage(), true);
            }
        }
    }

    public void createFolder(File dir, String name) {
        if (dir == null || name == null || name.isBlank()) {
            return;
        }
        File f = new File(dir, name.trim());
        if (f.exists()) {
            if (actions != null) {
                actions.notify("Folder already exists: " + f.getName(), true);
            }
            return;
        }
        if (!f.mkdirs()) {
            if (actions != null) {
                actions.notify("Could not create folder " + f.getName(), true);
            }
            return;
        }
        refreshAll();
        reveal(f);
    }

    private void rename(FileTreeModel.Node node) {
        String current = node.file.getName();
        String name = Dialogs.prompt(this, theme, Strings.get("Rename"),
                Strings.format("New name for \"{0}\":", current), current);
        if (name == null || name.isBlank() || name.equals(current)) {
            return;
        }
        File dest = new File(node.file.getParentFile(), name.trim());
        if (dest.exists()) {
            Dialogs.error(this, theme, Strings.get("Rename failed"),
                    Strings.format("A file named \"{0}\" already exists.", name));
            return;
        }
        boolean ok = node.file.renameTo(dest);
        if (!ok) {
            try {
                Files.move(node.file.toPath(), dest.toPath());
                ok = true;
            } catch (IOException ex) {
                Dialogs.error(this, theme, Strings.get("Rename failed"), String.valueOf(ex.getMessage()));
            }
        }
        if (ok) {
            refreshAll();
            if (actions != null) {
                actions.notify("Renamed to " + dest.getName(), false);
            }
        }
    }

    private void delete(FileTreeModel.Node node) {
        String name = node.file.getName();
        String message = node.isDirectory()
                ? Strings.format("Are you sure you want to delete the folder \"{0}\"?"
                        + "\n\nAll of its contents will be deleted.", name)
                : Strings.format("Are you sure you want to delete the file \"{0}\"?", name);
        int choice = Dialogs.confirm(this, theme, Strings.format("Delete {0}", name), message,
                Strings.get("Delete"), Strings.get("Cancel"));
        if (choice != 0) {
            return;
        }
        boolean ok = Workspace.deleteRecursive(node.file);
        if (ok) {
            refreshAll();
            if (actions != null) {
                actions.notify("Deleted " + node.file.getName(), false);
            }
        } else if (actions != null) {
            actions.notify("Could not delete " + node.file.getName(), true);
        }
    }

    /** Writes the settings of the workspace folder, used by the welcome screen. */
    public static boolean looksLikeProject(File dir) {
        if (dir == null || !dir.isDirectory()) {
            return false;
        }
        String[] markers = {"src", "pom.xml", "build.gradle", "package.json", ".git", "Makefile"};
        for (String m : markers) {
            if (new File(dir, m).exists()) {
                return true;
            }
        }
        return false;
    }

    /* ------------------------------------------------------------------ */
    /* theme                                                               */
    /* ------------------------------------------------------------------ */

    public void setTheme(Theme t) {
        setBackground(t.sidebarBg);
        header.setTheme(t);
        folderHeader.setTheme(t);
        openEditorsHeader.setTheme(t);
        outlineHeader.setTheme(t);
        openEditorsList.setBackground(t.sidebarBg);
        outline.setTheme(t);
        tree.setBackground(t.sidebarBg);
        tree.setForeground(t.sidebarFg);
        tree.setUI(new FlatTreeUI());
        tree.setRowHeight(22);
        tree.setCellRenderer(new Renderer());
        treeScroll.getViewport().setBackground(t.sidebarBg);
        openEditorsScroll.getViewport().setBackground(t.sidebarBg);
        UI.themeScrollBar(treeScroll, t);
        UI.themeScrollBar(openEditorsScroll, t);
        UI.themeScrollBar(outlineSectionScroll, t);
        repaint();
    }

    public void saveLayout(Settings s) {
        // the outline height is fixed in this build; nothing dynamic to persist yet
    }

    /* ------------------------------------------------------------------ */
    /* rendering                                                           */
    /* ------------------------------------------------------------------ */

    private class Renderer extends DefaultTreeCellRenderer {

        Renderer() {
            setBorder(BorderFactory.createEmptyBorder(0, 2, 0, 4));
        }

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded,
                                                      boolean leaf, int row, boolean hasFocus) {
            JLabel c = (JLabel) super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, false);
            c.setFont(UI.ui(12.5f));
            c.setOpaque(true);
            c.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 4));

            boolean active = false;
            if (value instanceof FileTreeModel.Node n) {
                active = activeFile != null && n.file.equals(activeFile) && !n.isDirectory();
                if (n.isDirectory()) {
                    c.setIcon(new FolderIcon(expanded, theme));
                } else {
                    c.setIcon(Icons.of("file", 15, fileColor(n.file)));
                }
                setToolTipText(n.file.getAbsolutePath());
            } else {
                setToolTipText(null);
            }

            Color bg = theme.sidebarBg;
            Color fg = theme.sidebarFg;
            if (selected) {
                bg = hasFocus || tree.isFocusOwner() ? theme.listActive : theme.listSelectionInactive;
                fg = (hasFocus || tree.isFocusOwner()) ? theme.listActiveFg : theme.sidebarFg;
            } else if (active) {
                fg = theme.sidebarFg;
            }
            c.setBackground(bg);
            c.setForeground(fg);
            return c;
        }

        private Color fileColor(File f) {
            com.codestudio.core.Language lang = com.codestudio.core.Language.detect(f.getName());
            String hex = lang == null ? "#888888" : lang.color;
            try {
                return Color.decode(hex);
            } catch (Exception e) {
                return theme.gutterFg;
            }
        }
    }

    /** Simple two-state folder glyph so the tree does not depend on the LAF. */
    private static class FolderIcon implements Icon {
        private final boolean open;
        private final Theme theme;

        FolderIcon(boolean open, Theme theme) {
            this.open = open;
            this.theme = theme;
        }

        @Override
        public int getIconWidth() {
            return 15;
        }

        @Override
        public int getIconHeight() {
            return 15;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color base = theme.dark ? new Color(0xC09553) : new Color(0xDCB67A);
            g2.setColor(base);
            if (open) {
                g2.fillRoundRect(x + 1, y + 4, 13, 9, 2, 2);
                g2.setColor(base.brighter());
                g2.fillRect(x + 1, y + 3, 12, 3);
            } else {
                g2.fillRoundRect(x + 1, y + 3, 13, 10, 2, 2);
                g2.setColor(base.darker());
                g2.drawLine(x + 1, y + 6, x + 13, y + 6);
            }
            g2.dispose();
        }
    }

    /** Chevron instead of the dotted LAF expand control, no row lines. */
    private class FlatTreeUI extends BasicTreeUI {
        @Override
        protected void installDefaults() {
            super.installDefaults();
            setHashColor(theme.sectionBorder);
        }

        @Override
        protected void paintHorizontalLine(Graphics g, javax.swing.JComponent c, int y, int left, int right) {
            // no connector lines
        }

        @Override
        protected void paintVerticalLine(Graphics g, javax.swing.JComponent c, int x, int top, int bottom) {
            // no connector lines
        }

        @Override
        protected void paintExpandControl(Graphics g, Rectangle clipBounds, java.awt.Insets insets, Rectangle bounds,
                                          TreePath path, int row, boolean isExpanded, boolean hasBeenExpanded,
                                          boolean isLeaf) {
            if (isLeaf) {
                return;
            }
            Icon icon = Icons.of(isExpanded ? "chevron-down" : "chevron-right", 14,
                    theme.dark ? new Color(0xCCCCCC) : new Color(0x424242));
            int x = bounds.x - icon.getIconWidth() - 2;
            int y = bounds.y + (bounds.height - icon.getIconHeight()) / 2;
            icon.paintIcon(tree, g, x, y);
        }

        @Override
        protected int getRowX(int row, int depth) {
            return tree.getInsets().left + depth * 12 + 4;
        }
    }

    /** Reads a text file for the search preview without keeping it in memory. */
    static String peek(File f, int maxBytes) throws IOException {
        byte[] all = Files.readAllBytes(f.toPath());
        int len = Math.min(all.length, maxBytes);
        return new String(all, 0, len, StandardCharsets.UTF_8);
    }
}
