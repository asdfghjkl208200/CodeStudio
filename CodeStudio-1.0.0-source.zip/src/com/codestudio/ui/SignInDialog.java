package com.codestudio.ui;

import com.codestudio.core.Account;
import com.codestudio.core.GitHubAuth;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.datatransfer.StringSelection;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URI;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * The one dialog behind every sign-in: a local account checked on this machine, or a GitHub account
 * obtained through the OAuth device flow.
 *
 * <h2>Threading</h2>
 *
 * <p>{@link GitHubAuth} blocks and knows nothing about Swing, so every call into it runs on a daemon
 * thread started here and every result is handed back to the event dispatch thread through
 * {@link SwingUtilities#invokeLater}. Nothing on the EDT ever waits on the network.
 *
 * <h2>What is said about the token, and why</h2>
 *
 * <p>A GitHub token ends up as plain text in {@code ~/.codestudio/accounts.properties} when the user
 * lets it be saved. Reading the Windows credential store (DPAPI) needs native bindings and this
 * project has none, so the dialog says so next to the save option rather than implying a protection
 * that does not exist. The session-only checkbox passes {@code saveToDisk = false} to
 * {@link Account#setToken(String, boolean)}, which keeps the token in memory alone.
 */
public final class SignInDialog extends JDialog {

    /** Which of the two forms the dialog is showing. */
    public enum Mode {
        /** An account created and checked on this machine only. */
        LOCAL,
        /** An account obtained from GitHub. */
        GITHUB
    }

    /** The device flow needs only the profile, so the narrowest scope that returns a login will do. */
    private static final String SCOPE = "read:user";

    /** Layout width for the wrapped explanation and message blocks. */
    private static final int NOTE_WIDTH = 360;
    /** Enough for three wrapped lines of message; fixed so long text is never clipped. */
    private static final int MESSAGE_HEIGHT = 48;

    private final Theme theme;
    private final String clientId;

    private final CardLayout cards = new CardLayout();
    private final JPanel body = new JPanel(cards);

    /* --- local form --- */
    private final JTextField nameField = new JTextField();
    private final JPasswordField passwordField = new JPasswordField();
    private final JPasswordField confirmField = new JPasswordField();
    private final JTextArea localMessage = new JTextArea(" ");
    private final JButton createButton;

    /* --- GitHub form --- */
    private final JPanel notConfiguredNote;
    private final JLabel codeCaption = new JLabel();
    private final JTextField codeField = new JTextField();
    private final JTextField urlField = new JTextField();
    private final JTextArea statusLabel = new JTextArea(" ");
    private final JTextArea githubMessage = new JTextArea(" ");
    private final JCheckBox sessionOnly =
            new JCheckBox(Strings.get("Don't save the token (this session only)"));
    private final JButton signInButton;
    private final JButton cancelButton;
    private final JButton copyOpenButton;

    /** Flipped by Cancel and by closing the window; polled by the device flow. */
    private final AtomicBoolean cancelled = new AtomicBoolean();

    private Mode mode;
    /** True while the device flow is in flight, so a second start cannot race it. */
    private boolean running;
    /** The created or signed-in account, or null when the dialog was cancelled. */
    private Account result;

    private SignInDialog(Component parent, Theme theme, Settings settings, Mode mode) {
        super(windowOf(parent), titleFor(mode), ModalityType.APPLICATION_MODAL);
        this.theme = theme;
        this.clientId = settings.get("account.githubClientId");
        this.mode = mode;

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Let a poll in flight notice, then close; the daemon thread dies with the JVM.
                cancelled.set(true);
                dispose();
            }
        });

        createButton = UI.primaryButton(Strings.get("Add Local Account"), theme, this::createLocal);
        signInButton = UI.primaryButton(Strings.get("Sign in with GitHub"), theme, this::startGitHub);
        cancelButton = UI.smallButton(Strings.get("Cancel"), theme, this::cancel);
        copyOpenButton = UI.smallButton(Strings.get("Copy Code and Open Browser"), theme,
                this::copyAndOpen);
        codeField.setEditable(false);
        codeField.setHorizontalAlignment(JTextField.CENTER);
        codeField.setFont(UI.mono(UI.resolveMono(null), 20f));
        codeField.setBackground(theme.inputBg);
        codeField.setForeground(theme.inputFg);
        codeField.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(6, 6, 6, 6)));
        urlField.setEditable(false);
        urlField.setFont(UI.ui(11.5f));
        urlField.setBackground(theme.panelBg);
        urlField.setForeground(UI.alpha(theme.panelFg, 190));
        urlField.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        message(localMessage);
        message(githubMessage);
        message(statusLabel);

        notConfiguredNote = note(Strings.get("GitHub sign-in is not configured.") + " "
                + Strings.get("To enable it, register an OAuth App on GitHub and paste its client id "
                        + "into the \"account.githubClientId\" setting. No client secret is needed."),
                UI.alpha(theme.panelFg, 170));

        JPanel content = new JPanel(new BorderLayout(0, 10));
        content.setBackground(theme.panelBg);
        content.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

        JPanel local = localCard();
        JPanel github = githubCard();
        body.setOpaque(false);
        body.add(local, "local");
        body.add(github, "github");
        content.add(body, BorderLayout.CENTER);
        setContentPane(content);

        local.add(Box.createVerticalStrut(10));
        local.add(link("Sign in with GitHub instead", () -> setMode(Mode.GITHUB)));
        github.add(Box.createVerticalStrut(10));
        github.add(link("Use a local account instead", () -> setMode(Mode.LOCAL)));

        setMode(mode);
        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    /* ------------------------------------------------------------------ */
    /* entry points                                                        */
    /* ------------------------------------------------------------------ */

    /** Creates a local account. Returns it, or null when the user cancelled or it was rejected. */
    public static Account showLocal(Component parent, Theme theme, Settings settings) {
        SignInDialog d = new SignInDialog(parent, theme, settings, Mode.LOCAL);
        d.setVisible(true);
        return d.result;
    }

    /** Signs in through GitHub. Returns the account, or null when cancelled or refused. */
    public static Account showGitHub(Component parent, Theme theme, Settings settings) {
        SignInDialog d = new SignInDialog(parent, theme, settings, Mode.GITHUB);
        d.setVisible(true);
        return d.result;
    }

    private static Window windowOf(Component parent) {
        if (parent instanceof Window w) {
            return w;
        }
        return parent == null ? null : SwingUtilities.getWindowAncestor(parent);
    }

    private static String titleFor(Mode mode) {
        return Strings.get(mode == Mode.LOCAL ? "Add Local Account" : "Sign in with GitHub");
    }

    private static String subtitleFor(Mode mode) {
        return mode == Mode.LOCAL
                ? Strings.get("The account is checked on this machine only. The password itself is "
                        + "never stored - only a PBKDF2 hash of it.")
                : Strings.get("Connect this app to your GitHub account with a short code.");
    }

    /* ------------------------------------------------------------------ */
    /* the two forms                                                       */
    /* ------------------------------------------------------------------ */

    private JPanel localCard() {
        JPanel p = column();
        p.add(note(subtitleFor(Mode.LOCAL), UI.alpha(theme.panelFg, 190)));
        p.add(Box.createVerticalStrut(10));
        p.add(fieldLabel("User name"));
        p.add(input(nameField));
        p.add(Box.createVerticalStrut(8));
        p.add(fieldLabel("Password"));
        p.add(input(passwordField));
        p.add(Box.createVerticalStrut(8));
        p.add(fieldLabel("Confirm password"));
        p.add(input(confirmField));
        p.add(Box.createVerticalStrut(6));
        p.add(localMessage);
        p.add(Box.createVerticalStrut(6));
        p.add(leftAlign(createButton));
        return p;
    }

    private JPanel githubCard() {
        JPanel p = column();
        p.add(notConfiguredNote);
        p.add(note(subtitleFor(Mode.GITHUB), UI.alpha(theme.panelFg, 190)));
        p.add(Box.createVerticalStrut(10));

        codeCaption.setText(Strings.get("Enter this code on GitHub:"));
        codeCaption.setFont(UI.ui(12.5f));
        codeCaption.setForeground(theme.panelFg);
        codeCaption.setAlignmentX(LEFT_ALIGNMENT);
        p.add(codeCaption);
        p.add(Box.createVerticalStrut(4));

        codeField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        codeField.setAlignmentX(LEFT_ALIGNMENT);
        p.add(codeField);
        p.add(Box.createVerticalStrut(4));
        urlField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));
        urlField.setAlignmentX(LEFT_ALIGNMENT);
        p.add(urlField);
        p.add(Box.createVerticalStrut(8));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        actions.setOpaque(false);
        actions.setAlignmentX(LEFT_ALIGNMENT);
        actions.add(signInButton);
        actions.add(cancelButton);
        actions.add(copyOpenButton);
        p.add(actions);
        p.add(Box.createVerticalStrut(6));

        p.add(githubMessage);
        p.add(statusLabel);
        p.add(Box.createVerticalStrut(6));

        sessionOnly.setFont(UI.ui(12f));
        sessionOnly.setForeground(theme.panelFg);
        sessionOnly.setBackground(theme.panelBg);
        sessionOnly.setFocusPainted(false);
        sessionOnly.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        sessionOnly.setAlignmentX(LEFT_ALIGNMENT);
        p.add(sessionOnly);
        p.add(Box.createVerticalStrut(4));
        p.add(note(Strings.format("The token is written in plain text to {0}. It is not encrypted, "
                + "and it is not stored in the Windows credential store: this is a pure Java "
                + "application and has no access to it.",
                "~/.codestudio/accounts.properties"), UI.alpha(theme.panelFg, 170)));
        return p;
    }

    /* ------------------------------------------------------------------ */
    /* mode switching                                                      */
    /* ------------------------------------------------------------------ */

    private void setMode(Mode m) {
        this.mode = m;
        cards.show(body, m == Mode.LOCAL ? "local" : "github");
        setTitle(titleFor(m));
        applyState();
        pack();
        setLocationRelativeTo(getOwner());
        if (m == Mode.LOCAL) {
            SwingUtilities.invokeLater(nameField::requestFocusInWindow);
        }
    }

    /**
     * Shows what the current state allows: the code row only once a code exists, the GitHub controls
     * only when a client id is configured, Cancel only while polling.
     */
    private void applyState() {
        boolean configured = GitHubAuth.isConfigured(clientId);
        boolean haveCode = codeField.getText() != null && !codeField.getText().isBlank();
        notConfiguredNote.setVisible(!configured);
        codeCaption.setVisible(haveCode);
        codeField.setVisible(haveCode);
        urlField.setVisible(haveCode);
        copyOpenButton.setVisible(haveCode);
        signInButton.setVisible(!running);
        cancelButton.setVisible(running);
        signInButton.setEnabled(configured && !running);
        copyOpenButton.setEnabled(haveCode && !running);
        sessionOnly.setEnabled(configured && !running);
    }

    /* ------------------------------------------------------------------ */
    /* local account                                                       */
    /* ------------------------------------------------------------------ */

    private void createLocal() {
        String name = nameField.getText() == null ? "" : nameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String again = new String(confirmField.getPassword());
        if (name.isEmpty() || password.isEmpty()) {
            showLocalMessage("Enter a user name and a password.", true);
            return;
        }
        if (!password.equals(again)) {
            showLocalMessage("The two passwords do not match.", true);
            return;
        }
        showLocalMessage("Creating the account...", false);
        createButton.setEnabled(false);
        // PBKDF2 with 120k iterations is deliberately slow; keep it off the event dispatch thread.
        Thread t = new Thread(() -> {
            Account created = Account.createLocal(name, password);
            SwingUtilities.invokeLater(() -> {
                createButton.setEnabled(true);
                if (created == null) {
                    showLocalMessage("That name is already taken. Choose another.", true);
                    return;
                }
                result = created;
                dispose();
            });
        }, "account-create");
        t.setDaemon(true);
        t.start();
    }

    private void showLocalMessage(String key, boolean error) {
        localMessage.setForeground(error ? theme.error : UI.alpha(theme.panelFg, 170));
        localMessage.setText(Strings.get(key));
        localMessage.setToolTipText(Strings.get(key));
    }

    /* ------------------------------------------------------------------ */
    /* GitHub device flow                                                  */
    /* ------------------------------------------------------------------ */

    private void startGitHub() {
        if (running) {
            return;
        }
        if (!GitHubAuth.isConfigured(clientId)) {
            githubMessage.setForeground(theme.error);
            githubMessage.setText(Strings.get("GitHub sign-in is not configured."));
            applyState();
            return;
        }
        running = true;
        cancelled.set(false);
        githubMessage.setForeground(UI.alpha(theme.panelFg, 170));
        githubMessage.setText(Strings.get("Requesting a sign-in code from GitHub..."));
        codeField.setText("");
        urlField.setText("");
        statusLabel.setText(" ");
        applyState();

        // Read the checkbox on the EDT, before leaving it; it is a Swing component.
        final boolean saveToDisk = !sessionOnly.isSelected();
        Thread t = new Thread(() -> {
            try {
                GitHubAuth.DeviceCode code = GitHubAuth.requestCode(clientId, SCOPE);
                SwingUtilities.invokeLater(() -> showCode(code));
                String token = GitHubAuth.awaitToken(clientId, code, new GitHubAuth.Progress() {
                    @Override
                    public void status(String message) {
                        SwingUtilities.invokeLater(() -> setStatus(statusText(message), false));
                    }

                    @Override
                    public void waiting(int secondsRemaining) {
                        SwingUtilities.invokeLater(() -> setStatus(
                                Strings.get("Waiting for authorization...") + "   "
                                        + Strings.format("Expires in {0} seconds", secondsRemaining),
                                false));
                    }
                }, cancelled::get);
                SwingUtilities.invokeLater(
                        () -> setStatus(Strings.get("Fetching your GitHub profile..."), false));
                GitHubAuth.User user = GitHubAuth.fetchUser(token);
                SwingUtilities.invokeLater(() -> finish(user, token, saveToDisk));
            } catch (GitHubAuth.AuthException e) {
                String message = e.getMessage();
                SwingUtilities.invokeLater(() -> fail(message));
            } catch (RuntimeException e) {
                String message = e.toString();
                SwingUtilities.invokeLater(() -> fail(message));
            }
        }, "github-signin");
        t.setDaemon(true);
        t.start();
    }

    /** Shows the user code and where to enter it. */
    private void showCode(GitHubAuth.DeviceCode code) {
        githubMessage.setForeground(UI.alpha(theme.panelFg, 170));
        githubMessage.setText(Strings.get("Enter this code on GitHub:"));
        codeField.setText(code.userCode());
        urlField.setText(code.browserUrl());
        urlField.setToolTipText(code.browserUrl());
        applyState();
        copyOpenButton.requestFocusInWindow();
    }

    /** Stores the account and the token, then closes. */
    private void finish(GitHubAuth.User user, String token, boolean saveToDisk) {
        running = false;
        Account account = Account.upsertGitHub(user.login(), user.display(), user.avatarUrl());
        if (account == null) {
            fail("GitHub did not return a usable account.");
            return;
        }
        account.setToken(token, saveToDisk);
        result = account;
        dispose();
    }

    private void fail(String message) {
        running = false;
        // GitHubAuth messages are English source text; prefix() translates the ones the table knows.
        String text = message == null || message.isBlank()
                ? Strings.get("Sign-in failed.")
                : Strings.prefix(message);
        setStatus(text, true);
        applyState();
    }

    private void setStatus(String text, boolean error) {
        statusLabel.setForeground(error ? theme.error : UI.alpha(theme.panelFg, 190));
        statusLabel.setText(text == null || text.isBlank() ? " " : text);
        statusLabel.setToolTipText(statusLabel.getText());
    }

    /**
     * GitHub asks for a back-off with the literal key {@code github.slowdown}; anything else it
     * passes through is already a sentence.
     */
    private static String statusText(String message) {
        if (message == null || message.isBlank()) {
            return " ";
        }
        if ("github.slowdown".equals(message)) {
            return Strings.get("GitHub asked us to slow down; still waiting.");
        }
        return Strings.get(message);
    }

    /** The Cancel control: flips the flag the poll reads, so polling stops promptly. */
    private void cancel() {
        if (!running) {
            dispose();
            return;
        }
        cancelled.set(true);
        setStatus(Strings.get("Authorization cancelled."), false);
        cancelButton.setEnabled(false);
    }

    /** Copies the code and opens the verification page; says so plainly if no browser opens. */
    private void copyAndOpen() {
        String code = codeField.getText() == null ? "" : codeField.getText();
        String url = urlField.getText() == null ? "" : urlField.getText();
        if (code.isBlank()) {
            return;
        }
        try {
            Toolkit.getDefaultToolkit().getSystemClipboard()
                    .setContents(new StringSelection(code), null);
        } catch (RuntimeException e) {
            // A locked or absent clipboard is not worth failing the sign-in over.
        }
        if (url.isBlank() || openBrowser(url)) {
            githubMessage.setForeground(UI.alpha(theme.panelFg, 170));
            githubMessage.setText(Strings.get("Code copied. Enter it on GitHub."));
        } else {
            githubMessage.setForeground(theme.error);
            githubMessage.setText(Strings.format(
                    "Could not open a browser. Open {0} and enter the code yourself.", url));
        }
        githubMessage.setToolTipText(githubMessage.getText());
    }

    /**
     * Opens a URL, degrading quietly to the platform's own launcher when {@link Desktop} is not
     * available (a trimmed JRE, or a desktop environment advertising no browse action).
     */
    private static boolean openBrowser(String url) {
        try {
            if (Desktop.isDesktopSupported()
                    && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(URI.create(url));
                return true;
            }
        } catch (Exception e) {
            // Fall through to the launcher below.
        }
        try {
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            if (os.contains("win")) {
                new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url).start();
            } else if (os.contains("mac")) {
                new ProcessBuilder("open", url).start();
            } else {
                new ProcessBuilder("xdg-open", url).start();
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /* ------------------------------------------------------------------ */
    /* small builders                                                      */
    /* ------------------------------------------------------------------ */

    private static JPanel column() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        return p;
    }

    private static JPanel leftAlign(JButton button) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        p.setOpaque(false);
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.add(button);
        return p;
    }

    private JLabel fieldLabel(String key) {
        JLabel l = new JLabel(Strings.get(key));
        l.setFont(UI.ui(11.5f));
        l.setForeground(UI.alpha(theme.panelFg, 190));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JTextField input(JTextField field) {
        field.setFont(UI.ui(12.5f));
        field.setBackground(theme.inputBg);
        field.setForeground(theme.inputFg);
        field.setCaretColor(theme.inputFg);
        field.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        field.setAlignmentX(LEFT_ALIGNMENT);
        return field;
    }

    /** A message line: wrapping, transparent, and a fixed size so text is never clipped. */
    private void message(JTextArea area) {
        area.setEditable(false);
        area.setOpaque(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(UI.ui(11.5f));
        area.setForeground(theme.error);
        area.setBorder(null);
        area.setFocusable(false);
        area.setAlignmentX(LEFT_ALIGNMENT);
        area.setPreferredSize(new Dimension(NOTE_WIDTH, MESSAGE_HEIGHT));
        area.setMaximumSize(new Dimension(NOTE_WIDTH, MESSAGE_HEIGHT));
    }

    /**
     * A wrapped block of explanation text at a fixed width. The height is measured by laying the
     * area out at that width first: a {@link JTextArea} reports one row's height until something
     * tells it how wide it will really be.
     */
    private JPanel note(String text, Color foreground) {
        JTextArea area = new JTextArea(text);
        area.setEditable(false);
        area.setOpaque(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFocusable(false);
        area.setFont(UI.ui(11.5f));
        area.setForeground(foreground);
        area.setBorder(BorderFactory.createEmptyBorder(0, 0, 4, 0));
        area.setSize(NOTE_WIDTH, Short.MAX_VALUE);
        int height = area.getPreferredSize().height;
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.setPreferredSize(new Dimension(NOTE_WIDTH, height));
        p.setMaximumSize(new Dimension(NOTE_WIDTH, height));
        p.add(area, BorderLayout.CENTER);
        return p;
    }

    private JButton link(String textKey, Runnable action) {
        JButton b = UI.smallButton(Strings.get(textKey), theme, action);
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.setForeground(theme.accent);
        return b;
    }
}
