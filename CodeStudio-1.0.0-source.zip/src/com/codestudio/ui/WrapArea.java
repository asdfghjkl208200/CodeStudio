package com.codestudio.ui;

import java.awt.Dimension;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.BorderFactory;

/**
 * A read-only, selectable block of word-wrapped text that reports the height it needs <i>at the
 * width it was actually given</i>.
 *
 * <p>A plain {@code JTextArea} cannot do this. Its preferred size is the size of its content laid
 * out on <em>one line</em>, so a caller that puts it in a vertical box and lets it fill the width
 * gets a component one line tall with the remaining text clipped away. Measuring at the current
 * width fixes that, and {@link #getMaximumSize} then keeps a box layout from stretching the block
 * vertically to fill its container.
 *
 * <p>The resize listener is load-bearing rather than a nicety. The height is only right once the
 * component has been given a width, and a component whose width changes without its own invalidation
 * keeps the height it measured at the old width — which is the difference between a paragraph
 * showing in full and showing its first line and a half. Nothing else in the layout system will ask
 * it to think again.
 */
public class WrapArea extends javax.swing.JTextArea {

    public WrapArea(String text) {
        super(text == null ? "" : text);
        setEditable(false);
        setOpaque(false);
        setLineWrap(true);
        setWrapStyleWord(true);
        setFocusable(true);
        setBorder(BorderFactory.createEmptyBorder());
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                revalidate();
            }
        });
    }

    @Override
    public Dimension getPreferredSize() {
        int w = getWidth();
        if (w <= 0) {
            return super.getPreferredSize();
        }
        setSize(w, Short.MAX_VALUE);
        return new Dimension(w, super.getPreferredSize().height);
    }

    @Override
    public Dimension getMaximumSize() {
        return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
    }
}
