package com.codestudio.ui;

import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import javax.swing.text.AbstractDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.ParagraphView;
import javax.swing.text.Position;
import javax.swing.text.StyledEditorKit;
import javax.swing.text.ViewFactory;

/**
 * A {@link StyledEditorKit} that knows about folded lines.
 *
 * <p>Folding is a view-level idea, not a document one: the text stays in the buffer, offsets stay
 * valid, and only the paragraphs inside a folded region report no height. Everything else that
 * walks the document - the highlighter, find and replace, the problem parser, saving - keeps seeing
 * the whole file, which is what should happen.
 *
 * <p>Hidden-ness is asked for while a paragraph measures and paints, never remembered in the view,
 * so toggling a fold only has to tell the affected views that their preference changed. That leaves
 * the document, the caret and the editor's key maps alone, which rebuilding the view tree would not.
 */
public final class FoldEditorKit extends StyledEditorKit {

    private static final long serialVersionUID = 1L;

    private final transient CodeTextPane editor;
    private final transient ViewFactory delegate;

    public FoldEditorKit(CodeTextPane editor) {
        this.editor = editor;
        this.delegate = new StyledEditorKit().getViewFactory();
    }

    @Override
    public ViewFactory getViewFactory() {
        return element -> {
            if (element != null && AbstractDocument.ParagraphElementName.equals(element.getName())) {
                FoldParagraph view = new FoldParagraph(element, editor);
                editor.registerFoldView(view);
                return view;
            }
            return delegate.create(element);
        };
    }

    /** A paragraph that takes no vertical space and paints nothing while its line is folded. */
    static final class FoldParagraph extends ParagraphView {

        private final CodeTextPane editor;

        FoldParagraph(Element element, CodeTextPane editor) {
            super(element);
            this.editor = editor;
        }

        private boolean hidden() {
            return editor.isLineHidden(line());
        }

        /** The paragraph's index in the document, which is its line number. */
        private int line() {
            Element element = getElement();
            Element parent = element == null ? null : element.getParentElement();
            if (parent == null) {
                return -1;
            }
            return parent.getElementIndex(element.getStartOffset());
        }

        @Override
        public float getPreferredSpan(int axis) {
            if (axis == Y_AXIS && hidden()) {
                return 0;
            }
            return super.getPreferredSpan(axis);
        }

        @Override
        public float getMinimumSpan(int axis) {
            if (axis == Y_AXIS && hidden()) {
                return 0;
            }
            return super.getMinimumSpan(axis);
        }

        @Override
        public float getMaximumSpan(int axis) {
            if (axis == Y_AXIS && hidden()) {
                return 0;
            }
            return super.getMaximumSpan(axis);
        }

        @Override
        public void paint(Graphics g, Shape allocation) {
            if (hidden()) {
                return;
            }
            super.paint(g, allocation);
        }

        /**
         * A hidden paragraph has no rectangle of its own. Answering with the allocation's origin
         * keeps a stray model-to-view call - a gutter line number, an occurrence highlight - from
         * drawing the text back in at some remembered position.
         */
        @Override
        public Shape modelToView(int pos, Shape allocation, Position.Bias bias)
                throws BadLocationException {
            if (hidden()) {
                Rectangle2D bounds = allocation.getBounds2D();
                return new Rectangle2D.Double(bounds.getX(), bounds.getY(), 0, 0);
            }
            return super.modelToView(pos, allocation, bias);
        }
    }
}
