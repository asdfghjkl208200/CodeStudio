package com.codestudio.ui;

/**
 * A view that changes appearance depending on whether it is the one currently shown.
 *
 * <p>Only the source control view needed this — it polls a repository while visible and stops when
 * hidden — and {@link SideBar} used to test for that one class by name. The container now asks, so
 * any view may opt in.
 */
public interface ActiveAware {

    /** Called when this view becomes, or stops being, the visible one. */
    void setActive(boolean active);
}
