package com.codestudio.ui;

import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** The narrow icon strip on the far left of the workbench. */
public class ActivityBar extends JPanel {

    public interface Listener {
        void activitySelected(String viewId);

        void activityRepeated(String viewId);

        void extensionsRequested();

        void accountsRequested();

        void notificationsRequested();
    }

    /** Icon-strip items that live in the top group, in order. */
    private static final String[][] TOP_ITEMS = {
        {"explorer", "files", "Explorer (Ctrl+Shift+E)"},
        {"search", "search", "Search (Ctrl+Shift+F)"},
        {"scm", "source-control", "Source Control (Ctrl+Shift+G)"},
        {"run", "run", "Run and Debug (Ctrl+Shift+D)"},
        {"extensions", "extensions", "Extensions"},
    };

    private final Map<String, Item> items = new LinkedHashMap<>();
    private final List<Listener> listeners = new ArrayList<>();
    private final JPanel top = new JPanel();
    private final JPanel bottom = new JPanel();
    /** The stretchy gap at the end of {@link #top}; plugin items are inserted just before it. */
    private final java.awt.Component topGlue = Box.createVerticalGlue();
    private Theme theme;
    private String active = "explorer";

    public ActivityBar(Theme theme) {
        super(new BorderLayout());
        this.theme = theme;
        setBackground(theme.activityBg);
        setPreferredSize(new Dimension(48, 100));

        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(theme.activityBg);
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.setBackground(theme.activityBg);

        for (String[] spec : TOP_ITEMS) {
            Item item = new Item(spec[0], spec[1], spec[2]);
            items.put(spec[0], item);
            top.add(item);
        }
        top.add(topGlue);
        add(top, BorderLayout.CENTER);

        JPanel footer = new JPanel();
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        footer.setBackground(theme.activityBg);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));

        // Footer reads: accounts, small gap, settings.
        Item accountsItem = new Item("accounts", "person", "Accounts");
        items.put("accounts", accountsItem);
        footer.add(accountsItem);

        JPanel spacers = new JPanel();
        spacers.setOpaque(false);
        spacers.setPreferredSize(new Dimension(48, 6));
        footer.add(spacers);

        Item settingsItem = new Item("settings", "settings", "Settings (Ctrl+,)");
        items.put("settings", settingsItem);
        footer.add(settingsItem);

        bottom.add(footer, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
    }

    public void addListener(Listener l) {
        listeners.add(l);
    }

    /** Re-applies the tooltip of every item after a language change. */
    public void retranslate() {
        for (Item item : items.values()) {
            item.applyTooltip();
        }
    }

    public void setActive(String viewId) {
        if (viewId == null || viewId.equals(active)) {
            refresh();
            return;
        }
        this.active = viewId;
        refresh();
    }

    public String activeView() {
        return active;
    }

    /**
     * Adds an item to the top group, after the built-in items and before the stretchy glue. Used by
     * plugins to contribute an entry point; the tooltip is looked up by {@code tooltipKey} on every
     * language change.
     *
     * <p>A null {@code icon} draws a neutral placeholder. An icon that is supplied is painted
     * verbatim — the plugin owns its colours, so it is never recoloured by the theme.
     */
    public void addItem(String id, javax.swing.Icon icon, String tooltipKey) {
        if (id == null) {
            return;
        }
        Item previous = items.remove(id);
        if (previous != null) {
            java.awt.Container parent = previous.getParent();
            if (parent != null) {
                parent.remove(previous);
            }
        }
        Item item = new Item(id, icon, tooltipKey);
        items.put(id, item);
        int index = top.getComponentZOrder(topGlue);
        top.add(item, index < 0 ? top.getComponentCount() : index);
        item.setActive(id.equals(active));
        top.revalidate();
        top.repaint();
    }

    /**
     * Removes an item contributed by a plugin.
     *
     * @return whether an item with this id existed.
     */
    public boolean removeItem(String id) {
        if (id == null) {
            return false;
        }
        Item item = items.remove(id);
        if (item == null) {
            return false;
        }
        java.awt.Container parent = item.getParent();
        if (parent != null) {
            parent.remove(item);
            parent.revalidate();
            parent.repaint();
        }
        if (id.equals(active)) {
            active = "";
            refresh();
        }
        return true;
    }

    /** Sets the number shown in the item's badge; 0 hides it. Works for plugin items too. */
    public void setBadge(String viewId, int count) {
        Item item = items.get(viewId);
        if (item != null) {
            item.badge = Math.max(0, count);
            item.repaint();
        }
    }

    private void refresh() {
        for (Map.Entry<String, Item> e : items.entrySet()) {
            e.getValue().setActive(e.getKey().equals(active));
        }
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.activityBg);
        top.setBackground(t.activityBg);
        bottom.setBackground(t.activityBg);
        for (Item item : items.values()) {
            item.setTheme(t);
        }
        repaint();
        for (java.awt.Component c : getComponents()) {
            c.setBackground(t.activityBg);
        }
    }

    /** One icon in the strip. */
    private class Item extends JPanel {
        private final String id;
        /** Name resolved through {@link Icons}; null when an explicit icon was supplied. */
        private final String iconName;
        /** Plugin-supplied icon, painted verbatim. Null means "resolve {@link #iconName}". */
        private final javax.swing.Icon explicitIcon;
        /** Untranslated tooltip, kept so {@link #applyTooltip} can redo it after a language change. */
        private final String tooltipKey;
        private boolean selected;
        private boolean hovering;
        private int badge;

        Item(String id, String iconName, String tooltipKey) {
            this(id, iconName, null, tooltipKey);
        }

        /** An item contributed by a plugin; a null icon draws a neutral placeholder. */
        Item(String id, javax.swing.Icon icon, String tooltipKey) {
            this(id, null, icon, tooltipKey);
        }

        private Item(String id, String iconName, javax.swing.Icon explicitIcon, String tooltipKey) {
            super(new BorderLayout());
            this.id = id;
            this.iconName = iconName;
            this.explicitIcon = explicitIcon;
            this.tooltipKey = tooltipKey;
            setBackground(theme.activityBg);
            setPreferredSize(new Dimension(48, 48));
            setMaximumSize(new Dimension(48, 48));
            setMinimumSize(new Dimension(48, 48));
            setToolTipText(Strings.get(tooltipKey));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            JLabel icon = new JLabel();
            icon.setHorizontalAlignment(JLabel.CENTER);
            add(icon, BorderLayout.CENTER);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    fire();
                }
            });
        }

        void setTheme(Theme t) {
            setBackground(t.activityBg);
            repaint();
        }

        void applyTooltip() {
            setToolTipText(Strings.get(tooltipKey));
        }

        private void fire() {
            if ("settings".equals(id)) {
                for (Listener l : new ArrayList<>(listeners)) {
                    l.activitySelected("settings");
                }
                return;
            }
            if ("accounts".equals(id)) {
                for (Listener l : new ArrayList<>(listeners)) {
                    l.accountsRequested();
                }
                return;
            }
            boolean repeat = id.equals(active);
            for (Listener l : new ArrayList<>(listeners)) {
                if (repeat) {
                    l.activityRepeated(id);
                } else {
                    l.activitySelected(id);
                }
            }
        }

        void setActive(boolean value) {
            this.selected = value;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(theme.activityBg);
                g.fillRect(0, 0, getWidth(), getHeight());

                Color fg = selected ? theme.activityActiveFg
                        : (hovering ? theme.activityFg : theme.activityInactiveFg);
                if (selected) {
                    g.setColor(theme.activityActiveFg);
                    g.fillRect(0, 0, 2, getHeight());
                }
                paintIcon(g, fg);

                if (badge > 0) {
                    String text = badge > 99 ? "99+" : String.valueOf(badge);
                    g.setFont(UI.uiBold(9.5f));
                    int w = Math.max(15, g.getFontMetrics().stringWidth(text) + 7);
                    int bx = getWidth() - w - 4;
                    int by = getHeight() - 18;
                    g.setColor(theme.accent);
                    g.fillRoundRect(bx, by, w, 14, 8, 8);
                    g.setColor(Color.WHITE);
                    int tw = g.getFontMetrics().stringWidth(text);
                    g.drawString(text, bx + (w - tw) / 2, by + 11);
                }
            } finally {
                g.dispose();
            }
        }

        private void paintIcon(Graphics2D g, Color fg) {
            javax.swing.Icon icon = explicitIcon;
            if (icon == null) {
                // A plugin icon is painted as given; only a named one follows the theme colour.
                icon = iconName != null ? Icons.of(iconName, 24, fg) : placeholder(fg);
            }
            int x = (getWidth() - icon.getIconWidth()) / 2;
            int y = (getHeight() - icon.getIconHeight()) / 2;
            icon.paintIcon(this, g, x, y);
        }
    }

    /** Neutral stand-in for a plugin item registered without an icon. */
    private static javax.swing.Icon placeholder(Color fg) {
        return new javax.swing.Icon() {
            @Override
            public int getIconWidth() {
                return 24;
            }

            @Override
            public int getIconHeight() {
                return 24;
            }

            @Override
            public void paintIcon(java.awt.Component c, Graphics g0, int x, int y) {
                Graphics2D g = (Graphics2D) g0.create();
                try {
                    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
                    g.setColor(fg);
                    g.setStroke(new java.awt.BasicStroke(1.6f));
                    g.drawRoundRect(x + 4, y + 4, 16, 16, 6, 6);
                    g.fillOval(x + 10, y + 10, 4, 4);
                } finally {
                    g.dispose();
                }
            }
        };
    }
}
