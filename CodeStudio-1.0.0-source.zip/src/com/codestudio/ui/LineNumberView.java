package com.codestudio.ui;

import com.codestudio.core.Breakpoints;
import com.codestudio.core.Theme;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Element;

/** Gutter with line numbers, shown as the row header of the editor scroll pane. */
public class LineNumberView extends JComponent implements DocumentListener, CaretListener {

    /** Width of the click target that toggles a breakpoint. */
    private static final int BREAKPOINT_WIDTH = 20;
    /** Width of the click target that folds the block starting on a line. */
    private static final int FOLD_WIDTH = 16;

    private final CodeTextPane text;
    private Theme theme;
    private int lineCount = 1;
    private int activeLine = -1;
    private int hoverLine = -1;

    public LineNumberView(CodeTextPane text, Theme theme) {
        this.text = text;
        this.theme = theme;
        setOpaque(true);
        setBackground(theme.editorBg);
        text.getDocument().addDocumentListener(this);
        text.addCaretListener(this);
        // Fold state lives in the editor, and the chevron column has to follow it.
        text.addStateListener(this::repaint);
        Breakpoints.addListener(this::repaint);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int line = lineAtY(e.getY());
                if (line < 0 || e.getClickCount() != 1) {
                    return;
                }
                if (SwingUtilities.isLeftMouseButton(e) && e.getX() < BREAKPOINT_WIDTH) {
                    Breakpoints.toggle(text.bundle().file, line);
                    return;
                }
                if (SwingUtilities.isLeftMouseButton(e) && e.getX() >= getWidth() - FOLD_WIDTH
                        && text.toggleFold(line)) {
                    repaint();
                    return;
                }
                // select the whole line, like VS Code's gutter click
                text.selectLine(line);
                text.requestFocusInWindow();
            }
        });
        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int line = lineAtY(e.getY());
                boolean overFold = e.getX() >= getWidth() - FOLD_WIDTH && text.canFold(line);
                setCursor(java.awt.Cursor.getPredefinedCursor(
                        e.getX() < BREAKPOINT_WIDTH || overFold
                                ? java.awt.Cursor.HAND_CURSOR : java.awt.Cursor.DEFAULT_CURSOR));
                if (line != hoverLine) {
                    hoverLine = overFold ? line : -1;
                    repaint();
                }
            }
        });
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.editorBg);
        repaint();
    }

    private int lineAtY(int y) {
        Element root = text.getDocument().getDefaultRootElement();
        Rectangle clip = new Rectangle(0, y, 1, 1);
        int offset = text.viewToModel2D(new Point2D.Double(0, y));
        if (offset < 0) {
            return -1;
        }
        int line = root.getElementIndex(Math.min(offset, Math.max(0, text.getDocument().getLength())));
        return Math.max(0, Math.min(root.getElementCount() - 1, line));
    }

    @Override
    public Dimension getPreferredSize() {
        FontMetrics fm = getFontMetrics(getFont());
        int digits = Math.max(3, String.valueOf(Math.max(1, lineCount)).length());
        int width = fm.charWidth('0') * digits + 34 + (text.isFoldingEnabled() ? FOLD_WIDTH : 0);
        int height = text.getPreferredSize().height;
        return new Dimension(width, Math.max(height, 10));
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        try {
            g.setColor(theme.editorBg);
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setFont(getFont());

            Rectangle clip = g.getClipBounds();
            if (clip == null) {
                return;
            }
            Element root = text.getDocument().getDefaultRootElement();
            int len = text.getDocument().getLength();

            int startOffset = text.viewToModel2D(new Point2D.Double(0, Math.max(0, clip.y)));
            startOffset = Math.max(0, Math.min(startOffset, len));
            int endOffset = text.viewToModel2D(new Point2D.Double(0, clip.y + clip.height));
            endOffset = Math.max(0, Math.min(endOffset, len));

            int first = root.getElementIndex(startOffset);
            int last = root.getElementIndex(endOffset);
            FontMetrics fm = g.getFontMetrics();
            int currentLine = text.caretLine();

            for (int line = first; line <= last; line++) {
                Element el = root.getElement(line);
                // A folded line has no row of its own; drawing its number would stack every hidden
                // number on the line that hides them.
                if (text.isLineHidden(line)) {
                    continue;
                }
                Rectangle r = CodeTextPane.rectOf(text, el.getStartOffset());
                if (r == null || r.height <= 0) {
                    continue;
                }
                String label = String.valueOf(line + 1);
                int x = getWidth() - fm.stringWidth(label) - 10 - (text.isFoldingEnabled() ? FOLD_WIDTH : 0);
                int y = r.y + r.height - fm.getDescent() - 1;
                if (line == currentLine) {
                    g.setColor(theme.gutterActiveFg);
                } else {
                    g.setColor(theme.gutterFg);
                }
                g.drawString(label, x, y);

                Breakpoints.Point bp = Breakpoints.find(text.bundle().file, line);
                if (bp != null) {
                    int size = Math.max(7, Math.min(11, r.height - 5));
                    int cx = (BREAKPOINT_WIDTH - size) / 2;
                    int cy = r.y + (r.height - size) / 2;
                    g.setColor(bp.enabled ? new Color(0xE51400) : new Color(0x7A7A7A));
                    g.fillOval(cx, cy, size, size);
                }
            }
            if (text.isFoldingEnabled()) {
                paintFoldChevrons(g, root, first, last);
            }
        } finally {
            g.dispose();
        }
    }

    /**
     * The chevron that opens and closes a block, in a column of its own to the right of the
     * numbers. Only lines that start a block get one, so the column is a map of what can be folded.
     */
    private void paintFoldChevrons(Graphics g, Element root, int first, int last) {
        java.util.Set<Integer> folded = text.foldedLines();
        for (int line = first; line <= last; line++) {
            if (!text.canFold(line)) {
                continue;
            }
            Rectangle r = CodeTextPane.rectOf(text, root.getElement(line).getStartOffset());
            if (r == null || r.height <= 0) {
                continue;
            }
            boolean isFolded = folded.contains(line);
            java.awt.Color c = isFolded || line == hoverLine
                    ? theme.gutterActiveFg : LineNumberView.dim(theme.gutterFg);
            int size = 12;
            int x = getWidth() - FOLD_WIDTH + (FOLD_WIDTH - size) / 2;
            int y = r.y + (r.height - size) / 2;
            Icons.of(isFolded ? "chevron-right" : "chevron-down", size, c).paintIcon(this, g, x, y);
        }
    }

    /* ---------------- listeners ---------------- */

    private void refresh() {
        int count = text.getDocument().getDefaultRootElement().getElementCount();
        if (count != lineCount) {
            lineCount = count;
            revalidate();
            getParent();
        }
        repaint();
    }

    @Override
    public void insertUpdate(DocumentEvent e) {
        refresh();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        refresh();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        repaint();
    }

    @Override
    public void caretUpdate(CaretEvent e) {
        repaint();
    }

    /** Width used by the editor when hiding the gutter. */
    public void hideNumbers() {
        setPreferredSize(new Dimension(0, 0));
    }

    public static Color dim(Color c) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), 120);
    }
}
