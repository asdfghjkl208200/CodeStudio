package com.codestudio.ui;

import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;

/** Themed replacements for the standard modal dialogs. */
public final class Dialogs {

    private Dialogs() {
    }

    private static JPanel messagePanel(String message, int width) {
        JTextArea area = new JTextArea(message);
        area.setEditable(false);
        area.setOpaque(false);
        area.setFont(UI.ui(12.5f));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setColumns(width);
        area.setBorder(BorderFactory.createEmptyBorder());
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.add(area, BorderLayout.CENTER);
        return p;
    }

    public static int confirm(Component parent, Theme theme, String title, String message, String... options) {
        Object[] opts = options;
        return JOptionPane.showOptionDialog(parent, messagePanel(message, 36), title,
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opts, opts[0]);
    }

    public static void info(Component parent, Theme theme, String title, String message) {
        JOptionPane.showMessageDialog(parent, messagePanel(message, 40), title, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(Component parent, Theme theme, String title, String message) {
        JOptionPane.showMessageDialog(parent, messagePanel(message, 46), title, JOptionPane.ERROR_MESSAGE);
    }

    /** Returns the entered text, or null when cancelled. */
    public static String prompt(Component parent, Theme theme, String title, String message, String initial) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setOpaque(false);
        if (message != null && !message.isBlank()) {
            JLabel label = new JLabel(message);
            label.setForeground(theme.panelFg);
            label.setFont(UI.ui(12.5f));
            panel.add(label, BorderLayout.NORTH);
        }
        JTextField field = new JTextField(initial == null ? "" : initial, 26);
        field.setBackground(theme.inputBg);
        field.setForeground(theme.inputFg);
        field.setCaretColor(theme.inputFg);
        field.setFont(UI.ui(12.5f));
        field.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.accent),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)));
        panel.add(field, BorderLayout.CENTER);

        Object[] options = {Strings.get("OK"), Strings.get("Cancel")};
        int result = JOptionPane.showOptionDialog(parent, panel, title, JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
        if (result != 0) {
            return null;
        }
        return field.getText();
    }

    /**
     * A password variant of {@link #prompt}: same shape, same cancel convention — the entered
     * password, or null when cancelled.
     *
     * <p>When {@code confirm} is true a second field is shown and the dialog refuses to accept a
     * mismatch: it says so and asks again rather than returning a password the user did not mean to
     * type. The fields are {@link JPasswordField}s, which {@link Theme} already styles through
     * {@code PasswordField.background} and {@code PasswordField.foreground} in the look and feel, so
     * no extra colour handling is needed here.
     *
     * <p>This is a general dialog primitive rather than part of any one form; a caller wanting
     * inline validation should build its own panel.
     */
    public static String promptPassword(Component parent, Theme theme, String title, String message,
                                        boolean confirm) {
        while (true) {
            JPanel panel = new JPanel(new BorderLayout(0, 6));
            panel.setOpaque(false);
            if (message != null && !message.isBlank()) {
                JLabel label = new JLabel(message);
                label.setForeground(theme.panelFg);
                label.setFont(UI.ui(12.5f));
                panel.add(label, BorderLayout.NORTH);
            }
            JPasswordField field = passwordField(theme);
            JPanel fields = new JPanel(new java.awt.GridLayout(confirm ? 2 : 1, 1, 0, 4));
            fields.setOpaque(false);
            fields.add(field);
            JPasswordField again = null;
            if (confirm) {
                again = passwordField(theme);
                fields.add(again);
            }
            panel.add(fields, BorderLayout.CENTER);

            Object[] options = {Strings.get("OK"), Strings.get("Cancel")};
            int result = JOptionPane.showOptionDialog(parent, panel, title, JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
            if (result != 0) {
                return null;
            }
            String value = new String(field.getPassword());
            if (!confirm) {
                return value;
            }
            if (value.equals(new String(again.getPassword()))) {
                return value;
            }
            error(parent, theme, title, Strings.get("The two passwords do not match."));
        }
    }

    private static JPasswordField passwordField(Theme theme) {
        JPasswordField field = new JPasswordField(26);
        field.setFont(UI.ui(12.5f));
        field.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.accent),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)));
        return field;
    }

    public static java.io.File chooseFile(Component parent, Theme theme, boolean save,
                                          String defaultName, java.io.File startDir) {
        javax.swing.JFileChooser chooser = new javax.swing.JFileChooser();
        chooser.setDialogType(save ? javax.swing.JFileChooser.SAVE_DIALOG : javax.swing.JFileChooser.OPEN_DIALOG);
        chooser.setFileSelectionMode(javax.swing.JFileChooser.FILES_AND_DIRECTORIES);
        if (startDir != null && startDir.isDirectory()) {
            chooser.setCurrentDirectory(startDir);
        }
        if (defaultName != null) {
            chooser.setSelectedFile(new java.io.File(defaultName));
        }
        applyChooserDefaults(chooser);
        int result = save ? chooser.showSaveDialog(parent) : chooser.showOpenDialog(parent);
        if (result != javax.swing.JFileChooser.APPROVE_OPTION) {
            return null;
        }
        return chooser.getSelectedFile();
    }

    public static java.io.File chooseDirectory(Component parent, Theme theme, java.io.File startDir) {
        javax.swing.JFileChooser chooser = new javax.swing.JFileChooser();
        chooser.setFileSelectionMode(javax.swing.JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle(Strings.get("Select Folder"));
        if (startDir != null && startDir.isDirectory()) {
            chooser.setCurrentDirectory(startDir);
        }
        applyChooserDefaults(chooser);
        int result = chooser.showOpenDialog(parent);
        if (result != javax.swing.JFileChooser.APPROVE_OPTION) {
            return null;
        }
        return chooser.getSelectedFile();
    }

    private static void applyChooserDefaults(javax.swing.JFileChooser chooser) {
        chooser.setPreferredSize(new Dimension(720, 480));
    }

    /** Simple scrollable text viewer used for the "About" and shortcut pages. */
    public static void textDialog(Component parent, Theme theme, String title, String text, int width, int height) {
        JTextArea area = new JTextArea(text);
        area.setEditable(false);
        area.setFont(UI.mono(UI.resolveMono(null), 12.5f));
        area.setBackground(theme.editorBg);
        area.setForeground(theme.editorFg);
        area.setCaretColor(theme.editorFg);
        area.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(width, height));
        sp.setBorder(BorderFactory.createLineBorder(theme.panelBorder));
        JOptionPane.showMessageDialog(parent, sp, title, JOptionPane.PLAIN_MESSAGE);
    }

    public static Font defaultFont() {
        return UIManager.getFont("Label.font");
    }
}
