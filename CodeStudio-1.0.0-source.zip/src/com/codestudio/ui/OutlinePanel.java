package com.codestudio.ui;

import com.codestudio.core.Language;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Document symbol outline, derived with lightweight pattern matching. */
public class OutlinePanel extends JPanel {

    public interface Navigator {
        void goTo(int line, int column);
    }

    public static class Symbol {
        public final String name;
        public final String kind;
        public final int line;
        public final int depth;

        public Symbol(String name, String kind, int line, int depth) {
            this.name = name;
            this.kind = kind;
            this.line = line;
            this.depth = depth;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    private static final Pattern JAVA_TYPE = Pattern.compile(
            "^\\s*(?:@\\w+(?:\\([^)]*\\))?\\s*)*(?:public|private|protected|static|final|abstract|sealed|non-sealed|strictfp|\\s)*\\s*"
                    + "(class|interface|enum|record|@interface)\\s+(\\w+)");
    private static final Pattern JAVA_MEMBER = Pattern.compile(
            "^\\s*(?:@\\w+(?:\\([^)]*\\))?\\s*)*(?:public|private|protected|static|final|abstract|synchronized|native|default|\\s)+"
                    + "[\\w<>\\[\\],.\\s?]+\\s+(\\w+)\\s*\\(([^;]*)$");
    private static final Pattern PY_DEF = Pattern.compile("^\\s*(?:async\\s+)?def\\s+(\\w+)\\s*\\(");
    private static final Pattern PY_CLASS = Pattern.compile("^\\s*class\\s+(\\w+)\\s*[:(]");
    private static final Pattern JS_FUNC = Pattern.compile("^\\s*(?:export\\s+)?(?:async\\s+)?function\\s+(\\w+)\\s*\\(");
    private static final Pattern JS_CLASS = Pattern.compile("^\\s*(?:export\\s+)?(?:abstract\\s+)?class\\s+(\\w+)");
    private static final Pattern JS_VAR = Pattern.compile(
            "^\\s*(?:export\\s+)?(?:const|let|var)\\s+(\\w+)\\s*=\\s*(?:async\\s*)?(?:\\(|function)");
    private static final Pattern GO_FUNC = Pattern.compile("^\\s*func\\s+(?:\\([^)]*\\)\\s*)?(\\w+)\\s*\\(");
    private static final Pattern GO_TYPE = Pattern.compile("^\\s*type\\s+(\\w+)\\s+(struct|interface)");
    private static final Pattern RS_FN = Pattern.compile("^\\s*(?:pub\\s+)?(?:async\\s+)?fn\\s+(\\w+)");
    private static final Pattern RS_TYPE = Pattern.compile("^\\s*(?:pub\\s+)?(struct|enum|trait|impl)\\s+(\\w+)");
    private static final Pattern C_FUNC = Pattern.compile("^\\s*(?:[\\w*&:<>,\\[\\]\\s]+?)\\s+(\\w+)\\s*\\(([^;]*)\\)\\s*\\{?\\s*$");
    private static final Pattern CSS_RULE = Pattern.compile("^([.#]?[\\w\\-.#: >,\\[\\]=\\*]+)\\s*\\{");
    private static final Pattern MD_HEADING = Pattern.compile("^(#{1,6})\\s+(.*)");

    private final DefaultListModel<Symbol> model = new DefaultListModel<>();
    private final JList<Symbol> list = new JList<>(model);
    private final JTextField filter = new JTextField();
    private final JLabel empty = new JLabel(Strings.get("No symbols found"));
    private final List<Symbol> all = new ArrayList<>();
    private final JScrollPane scrollPane;
    private Theme theme;
    private Navigator navigator;
    private Language language;

    public OutlinePanel(Theme theme) {
        super(new BorderLayout());
        this.theme = theme;
        setBackground(theme.sidebarBg);

        filter.setBackground(theme.inputBg);
        filter.setForeground(theme.inputFg);
        filter.setCaretColor(theme.inputFg);
        filter.setFont(UI.ui(12f));
        filter.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(3, 4, 3, 4),
                BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                        BorderFactory.createEmptyBorder(3, 6, 3, 6))));
        filter.putClientProperty("JTextField.placeholderText", Strings.get("Filter symbols"));
        filter.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                applyFilter();
            }
        });

        list.setBackground(theme.sidebarBg);
        list.setForeground(theme.sidebarFg);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setCellRenderer(new Renderer());
        list.setFixedCellHeight(20);
        list.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int idx = list.locationToIndex(e.getPoint());
                if (idx < 0) {
                    return;
                }
                Symbol s = model.get(idx);
                if (navigator != null) {
                    navigator.goTo(s.line, 0);
                }
            }
        });
        list.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(filter, BorderLayout.CENTER);

        empty.setForeground(UI.alpha(theme.sidebarFg, 140));
        empty.setFont(UI.ui(12f));
        empty.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        empty.setVisible(false);

        scrollPane = UI.scroll(list, theme);
        scrollPane.getViewport().setBackground(theme.sidebarBg);

        add(top, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(empty, BorderLayout.SOUTH);
    }

    public void setNavigator(Navigator n) {
        this.navigator = n;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.sidebarBg);
        filter.setBackground(t.inputBg);
        filter.setForeground(t.inputFg);
        filter.setCaretColor(t.inputFg);
        list.setBackground(t.sidebarBg);
        list.setForeground(t.sidebarFg);
        empty.setForeground(UI.alpha(t.sidebarFg, 140));
        scrollPane.getViewport().setBackground(t.sidebarBg);
        UI.themeScrollBar(scrollPane, t);
        repaint();
    }

    /** Rebuilds the outline for a document. */
    public void update(String text, Language lang) {
        this.language = lang;
        all.clear();
        all.addAll(parse(text, lang));
        applyFilter();
    }

    private void applyFilter() {
        String q = filter.getText().trim().toLowerCase(java.util.Locale.ROOT);
        model.clear();
        for (Symbol s : all) {
            if (q.isEmpty() || s.name.toLowerCase(java.util.Locale.ROOT).contains(q)) {
                model.addElement(s);
            }
        }
        empty.setVisible(model.isEmpty());
        empty.setText(filter.getText().isBlank()
                ? Strings.get("No symbols found")
                : Strings.get("No matching symbols"));
    }

    /**
     * Re-applies every visible string after a language change. The filter placeholder lives in a
     * client property that Swing reads once when the field is first painted, so it is written
     * again explicitly; the empty-state label is refreshed by re-running the filter.
     */
    public void retranslate() {
        filter.putClientProperty("JTextField.placeholderText", Strings.get("Filter symbols"));
        applyFilter();
        list.repaint();
    }

    /* ------------------------------------------------------------------ */

    public static List<Symbol> parse(String text, Language lang) {
        List<Symbol> out = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return out;
        }
        String id = lang == null ? "plaintext" : lang.id;
        String[] lines = text.split("\n", -1);
        int braceDepth = 0;
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String trimmed = line.strip();
            if (trimmed.isEmpty()) {
                continue;
            }
            int indent = line.length() - line.stripLeading().length();
            int depth = switch (id) {
                case "python", "ruby", "yaml" -> indent / 4;
                default -> braceDepth;
            };
            Matcher m;
            switch (id) {
                case "java", "kotlin", "csharp", "c", "cpp" -> {
                    if ((m = JAVA_TYPE.matcher(line)).find()) {
                        out.add(new Symbol(m.group(2), m.group(1), i, depth));
                    } else if ((m = JAVA_MEMBER.matcher(line)).find()) {
                        String name = m.group(1);
                        if (!isKeyword(name)) {
                            out.add(new Symbol(name + "()", "method", i, Math.max(0, depth)));
                        }
                    }
                }
                case "javascript", "typescript" -> {
                    if ((m = JS_CLASS.matcher(line)).find()) {
                        out.add(new Symbol(m.group(1), "class", i, depth));
                    } else if ((m = JS_FUNC.matcher(line)).find()) {
                        out.add(new Symbol(m.group(1) + "()", "function", i, depth));
                    } else if ((m = JS_VAR.matcher(line)).find()) {
                        out.add(new Symbol(m.group(1) + "()", "function", i, depth));
                    }
                }
                case "python" -> {
                    if ((m = PY_CLASS.matcher(line)).find()) {
                        out.add(new Symbol(m.group(1), "class", i, depth));
                    } else if ((m = PY_DEF.matcher(line)).find()) {
                        out.add(new Symbol(m.group(1) + "()", "function", i, depth));
                    }
                }
                case "go" -> {
                    if ((m = GO_TYPE.matcher(line)).find()) {
                        out.add(new Symbol(m.group(1), m.group(2), i, depth));
                    } else if ((m = GO_FUNC.matcher(line)).find()) {
                        out.add(new Symbol(m.group(1) + "()", "function", i, depth));
                    }
                }
                case "rust" -> {
                    if ((m = RS_TYPE.matcher(line)).find()) {
                        out.add(new Symbol(m.group(2), m.group(1), i, depth));
                    } else if ((m = RS_FN.matcher(line)).find()) {
                        out.add(new Symbol(m.group(1) + "()", "function", i, depth));
                    }
                }
                case "css", "scss", "less" -> {
                    if ((m = CSS_RULE.matcher(line)).find() && !trimmed.startsWith("@")) {
                        out.add(new Symbol(m.group(1).strip(), "rule", i, depth));
                    }
                }
                case "markdown" -> {
                    if ((m = MD_HEADING.matcher(line)).find()) {
                        out.add(new Symbol(m.group(2).strip(), "heading", i, m.group(1).length() - 1));
                    }
                }
                default -> {
                    if ((m = C_FUNC.matcher(line)).find() && !isKeyword(m.group(1))) {
                        out.add(new Symbol(m.group(1) + "()", "function", i, depth));
                    }
                }
            }
            braceDepth += count(line, '{') - count(line, '}');
            if (braceDepth < 0) {
                braceDepth = 0;
            }
        }
        return out;
    }

    private static boolean isKeyword(String s) {
        return switch (s) {
            case "if", "for", "while", "switch", "catch", "return", "else", "do", "try", "new", "synchronized" -> true;
            default -> false;
        };
    }

    private static int count(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == c) {
                n++;
            }
        }
        return n;
    }

    /* ------------------------------------------------------------------ */

    private class Renderer implements ListCellRenderer<Symbol> {
        private final JPanel panel = new JPanel(new BorderLayout(4, 0));
        private final JLabel label = new JLabel();

        Renderer() {
            panel.setOpaque(true);
            panel.setBorder(BorderFactory.createEmptyBorder(1, 4, 1, 6));
            label.setFont(UI.ui(12f));
            panel.add(label, BorderLayout.CENTER);
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends Symbol> list, Symbol value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            panel.setBackground(isSelected ? theme.listActive : theme.sidebarBg);
            Color fg = isSelected ? theme.listActiveFg : theme.sidebarFg;
            label.setForeground(fg);
            label.setText(value.name);
            label.setIcon(Icons.of(iconFor(value.kind), 14, isSelected ? fg : colorFor(value.kind)));
            int indent = Math.min(6, value.depth) * 12;
            label.setBorder(BorderFactory.createEmptyBorder(0, indent, 0, 0));
            panel.setToolTipText(Strings.format("{0}  (line {1})", value.name, value.line + 1));
            return panel;
        }

        private String iconFor(String kind) {
            return switch (kind) {
                case "class", "interface", "enum", "record", "struct", "trait", "impl" -> "folder-tree";
                case "method", "function" -> "run";
                case "heading" -> "file";
                case "rule" -> "theme";
                default -> "file";
            };
        }

        private Color colorFor(String kind) {
            return switch (kind) {
                case "class", "interface", "enum", "record", "struct", "trait" -> theme.synType;
                case "method", "function" -> theme.synFunction;
                default -> theme.gutterFg;
            };
        }
    }

    /** Preferred height used when embedded as a collapsible sidebar section. */
    public Dimension preferredOutlineHeight() {
        return new Dimension(10, 200);
    }
}
