package com.codestudio.ui;

import com.codestudio.core.Account;
import com.codestudio.core.GitHubAuth;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * The Accounts view: every account on this machine, which one is signed in, and the actions that
 * add, switch, remove or sign out of one.
 *
 * <p>Structured like {@link GitPanel} — a {@link SectionHeader} with actions, a scrollable list, and
 * actions at the foot. Account state itself lives in {@link Account}; this view only reads it and
 * calls its methods.
 *
 * <p>Switching the account here does not by itself change what the editor has open. The window owns
 * that per-account session, so a switch is reported through {@link Listener} and {@code MainWindow}
 * decides what to restore.
 */
public class AccountsPanel extends JPanel implements ThemeAware {

    /**
     * Told when something happened that the host window has to act on.
     *
     * <p>Both callbacks arrive on the event dispatch thread.
     */
    public interface Listener {

        /** The signed-in account changed: restore that account's session. Null means signed out. */
        void accountSwitched(Account account);

        /** Accounts were added, removed, or their stored tokens changed: the list was rebuilt. */
        void accountsChanged();
    }

    /** Height of the footer message: three wrapped lines at any supported sidebar width. */
    private static final int HINT_HEIGHT = 46;

    private final Settings settings;
    private Theme theme;
    private final List<Listener> listeners = new ArrayList<>();

    private final SectionHeader header;
    private final JButton headerGitHub;
    private final JPanel list = UI.column();
    private final JScrollPane scroll;
    private final JTextArea hint = new JTextArea(" ");
    private final JButton addButton;
    private final JButton githubButton;

    /** The last message shown in the footer, kept untranslated so retranslate() can redo it. */
    private String hintText = " ";
    private boolean hintError;
    /** The current account id as of the last rebuild, so a refresh can tell whether it moved. */
    private String lastCurrentId;

    public AccountsPanel(Settings settings, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.theme = theme;
        setBackground(theme.sidebarBg);

        header = new SectionHeader("Accounts", theme);
        header.addAction("person", "Add Local Account", this::addLocal);
        headerGitHub = header.addAction("link", "Sign in with GitHub", this::signInGitHub);
        header.addAction("refresh", "Refresh", this::refresh);

        list.setBackground(theme.sidebarBg);
        list.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        scroll = UI.scroll(list, theme);
        scroll.getViewport().setBackground(theme.sidebarBg);
        scroll.getVerticalScrollBar().setUnitIncrement(18);

        addButton = UI.smallButton(Strings.get("Add Local Account"), theme, this::addLocal);
        githubButton = UI.smallButton(Strings.get("Sign in with GitHub"), theme, this::signInGitHub);
        addButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        githubButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(theme.sidebarBg);
        top.add(header);
        JPanel sep = new JPanel();
        sep.setBackground(theme.sectionBorder);
        sep.setPreferredSize(new Dimension(10, 1));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        top.add(sep);

        hint.setEditable(false);
        hint.setOpaque(false);
        hint.setLineWrap(true);
        hint.setWrapStyleWord(true);
        hint.setFocusable(false);
        hint.setFont(UI.ui(11.5f));
        hint.setForeground(UI.alpha(theme.sidebarFg, 180));
        hint.setBorder(BorderFactory.createEmptyBorder(6, 10, 2, 8));
        hint.setAlignmentX(LEFT_ALIGNMENT);
        hint.setPreferredSize(new Dimension(160, HINT_HEIGHT));
        hint.setMaximumSize(new Dimension(Integer.MAX_VALUE, HINT_HEIGHT));

        // One button per line: the sidebar can be narrow, and a row of two would be clipped.
        JPanel buttons = new JPanel();
        buttons.setLayout(new BoxLayout(buttons, BoxLayout.Y_AXIS));
        buttons.setOpaque(false);
        buttons.setAlignmentX(LEFT_ALIGNMENT);
        buttons.setBorder(BorderFactory.createEmptyBorder(4, 8, 8, 8));
        for (JButton b : new JButton[]{addButton, githubButton}) {
            b.setAlignmentX(LEFT_ALIGNMENT);
            buttons.add(b);
            buttons.add(Box.createVerticalStrut(4));
        }

        JPanel footer = new JPanel();
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        footer.setBackground(theme.sidebarBg);
        footer.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, theme.sectionBorder));
        footer.add(hint);
        footer.add(buttons);

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(footer, BorderLayout.SOUTH);

        rebuild();
    }

    /* ------------------------------------------------------------------ */
    /* host hooks                                                          */
    /* ------------------------------------------------------------------ */

    public void addListener(Listener listener) {
        if (listener != null) {
            listeners.add(listener);
        }
    }

    public void removeListener(Listener listener) {
        listeners.remove(listener);
    }

    @Override
    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.sidebarBg);
        header.setTheme(t);
        scroll.getViewport().setBackground(t.sidebarBg);
        UI.themeScrollBar(scroll, t);
        hint.setForeground(hintError ? t.error : UI.alpha(t.sidebarFg, 180));
        repaint();
        // Every note, row and footer control is rebuilt with the new colours.
        rebuild();
    }

    /**
     * Re-reads every label through {@link Strings} after a language change and rebuilds the list, so
     * the section title, its tooltips, the rows, the empty state and the footer all follow.
     */
    @Override
    public void retranslate() {
        header.retranslate();
        addButton.setText(Strings.get("Add Local Account"));
        githubButton.setText(Strings.get("Sign in with GitHub"));
        renderHint();
        rebuild();
    }

    /* ------------------------------------------------------------------ */
    /* the list                                                            */
    /* ------------------------------------------------------------------ */

    /** Rebuilds the rows from {@link Account#all()}. Call after any change to the accounts. */
    public final void rebuild() {
        list.removeAll();
        List<Account> accounts = Account.all();
        Account current = Account.current();
        lastCurrentId = current == null ? null : current.id;

        if (!GitHubAuth.isConfigured(settings.get("account.githubClientId"))) {
            list.add(new Note(Strings.get("GitHub sign-in is not configured.") + " "
                    + Strings.get("To enable it, register an OAuth App on GitHub and paste its "
                            + "client id into the \"account.githubClientId\" setting. No client "
                            + "secret is needed."),
                    UI.alpha(theme.sidebarFg, 170), 8, 10, 4, 10));
        }
        if (accounts.isEmpty()) {
            list.add(emptyState());
        } else {
            for (Account a : accounts) {
                list.add(row(a, current != null && current.id.equals(a.id)));
            }
        }
        list.add(new Note(Strings.format("Accounts are stored in {0}.",
                "~/.codestudio/accounts.properties"), UI.alpha(theme.sidebarFg, 150), 8, 10, 8, 10));

        applyConfiguredState();
        list.revalidate();
        list.repaint();
    }

    /** Enables or disables the GitHub affordances, and explains why when they are off. */
    private void applyConfiguredState() {
        boolean configured = GitHubAuth.isConfigured(settings.get("account.githubClientId"));
        String explanation = Strings.get("GitHub sign-in is not configured.") + " "
                + Strings.get("To enable it, register an OAuth App on GitHub and paste its client id "
                        + "into the \"account.githubClientId\" setting. No client secret is needed.");
        headerGitHub.setEnabled(configured);
        githubButton.setEnabled(configured);
        headerGitHub.setToolTipText(configured ? Strings.get("Sign in with GitHub") : explanation);
        githubButton.setToolTipText(configured ? Strings.get("Sign in with GitHub") : explanation);
        // A FlatButton paints its own icon, so a disabled one has to be dimmed by hand.
        headerGitHub.setIcon(Icons.of("link", 14,
                configured ? theme.sidebarFg : UI.alpha(theme.sidebarFg, 110)));
    }

    private JComponent emptyState() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(theme.sidebarBg);
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 6, 10));
        p.setAlignmentX(LEFT_ALIGNMENT);

        JLabel title = new JLabel(Strings.get("No accounts yet"));
        title.setFont(UI.uiBold(12.5f));
        title.setForeground(theme.sidebarFg);
        title.setAlignmentX(LEFT_ALIGNMENT);
        p.add(title);
        p.add(Box.createVerticalStrut(4));
        p.add(new Note(Strings.get("Add a local account checked on this machine, or sign in with "
                + "GitHub."), UI.alpha(theme.sidebarFg, 180), 0, 0, 8, 0));

        for (JButton b : new JButton[]{
                UI.smallButton(Strings.get("Add Local Account"), theme, this::addLocal),
                UI.smallButton(Strings.get("Sign in with GitHub"), theme, this::signInGitHub)}) {
            b.setAlignmentX(LEFT_ALIGNMENT);
            p.add(b);
            p.add(Box.createVerticalStrut(4));
        }
        return p;
    }

    /** One account: name, kind, whether it is the current one, and what can be done to it. */
    private JComponent row(Account a, boolean isCurrent) {
        JPanel p = new JPanel(new BorderLayout(8, 0));
        p.setBackground(theme.sidebarBg);
        p.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.setToolTipText(a.id);

        JLabel icon = new JLabel(Icons.of(a.isGitHub() ? "link" : "person", 15,
                isCurrent ? theme.accent : UI.alpha(theme.sidebarFg, 190)));
        p.add(icon, BorderLayout.WEST);

        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.setOpaque(false);
        // Left, like everything stacked in it. A box layout aligns a child by comparing its
        // alignment to the container's, and two different values put the child somewhere in the
        // middle rather than flush against the start.
        text.setAlignmentX(LEFT_ALIGNMENT);

        JPanel nameRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        nameRow.setOpaque(false);
        nameRow.setAlignmentX(LEFT_ALIGNMENT);
        JLabel name = new JLabel(nameOf(a));
        name.setFont(isCurrent ? UI.uiBold(12.5f) : UI.ui(12.5f));
        name.setForeground(theme.sidebarFg);
        nameRow.add(name);
        nameRow.add(badge(Strings.get(a.isGitHub() ? "GitHub account" : "Local account")));
        if (isCurrent) {
            nameRow.add(badge(Strings.get("Signed in")));
        }
        text.add(nameRow);

        if (a.isGitHub() && a.hasToken() && !a.tokenSaved()) {
            JPanel stateRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
            stateRow.setOpaque(false);
            stateRow.add(badge(Strings.get("not saved to disk")));
            text.add(stateRow);
        }

        // One button per line: the sidebar can be narrow, and FlowLayout would clip a second one.
        JPanel actions = new JPanel();
        actions.setLayout(new BoxLayout(actions, BoxLayout.Y_AXIS));
        actions.setOpaque(false);
        actions.setAlignmentX(LEFT_ALIGNMENT);
        if (isCurrent) {
            actions.add(rowButton("Sign Out", this::signOut));
        } else {
            actions.add(rowButton("Switch to this Account", () -> switchTo(a)));
        }
        if (a.isGitHub() && a.hasToken()) {
            actions.add(rowButton("Clear Stored Token", () -> clearToken(a)));
        }
        actions.add(rowButton("Remove Account", () -> removeAccount(a)));
        text.add(actions);

        p.add(text, BorderLayout.CENTER);
        UI.hoverHighlight(p, theme.sidebarBg, theme.listHover);
        return p;
    }

    private JLabel badge(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UI.ui(10f));
        l.setOpaque(true);
        l.setBackground(theme.badgeBg);
        l.setForeground(theme.badgeFg);
        l.setBorder(BorderFactory.createEmptyBorder(1, 5, 1, 5));
        return l;
    }

    private JButton rowButton(String key, Runnable action) {
        JButton b = UI.smallButton(Strings.get(key), theme, action);
        b.setFont(UI.ui(11f));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setAlignmentX(LEFT_ALIGNMENT);
        return b;
    }

    /* ------------------------------------------------------------------ */
    /* actions                                                             */
    /* ------------------------------------------------------------------ */

    private void addLocal() {
        adopt(SignInDialog.showLocal(this, theme, settings));
    }

    private void signInGitHub() {
        if (!GitHubAuth.isConfigured(settings.get("account.githubClientId"))) {
            warn("GitHub sign-in is not configured.");
            return;
        }
        adopt(SignInDialog.showGitHub(this, theme, settings));
    }

    /** Signs in to an account that was just created, and tells the window to switch its session. */
    private void adopt(Account account) {
        if (account == null) {
            return;
        }
        Account.setCurrent(account.id);
        rebuild();
        fireAccountsChanged();
        fireAccountSwitched(account);
        info(account.isGitHub()
                ? Strings.format("Signed in with GitHub as {0}", nameOf(account))
                : Strings.format("Signed in as {0}", nameOf(account)));
    }

    private void switchTo(Account account) {
        Account.setCurrent(account.id);
        rebuild();
        fireAccountSwitched(account);
        info("Account switched");
    }

    private void signOut() {
        Account.setCurrent(null);
        rebuild();
        fireAccountSwitched(null);
        info("Signed out");
    }

    private void clearToken(Account account) {
        int choice = Dialogs.confirm(this, theme, Strings.get("Clear Stored Token"),
                Strings.format("Clear the saved GitHub token for \"{0}\"? You will need to sign in "
                        + "again.", nameOf(account)),
                Strings.get("Clear Stored Token"), Strings.get("Cancel"));
        if (choice != 0) {
            return;
        }
        account.clearToken();
        rebuild();
        fireAccountsChanged();
        info("Stored token cleared.");
    }

    private void removeAccount(Account account) {
        boolean wasCurrent = account.id.equals(lastCurrentId);
        int choice = Dialogs.confirm(this, theme, Strings.get("Remove Account"),
                Strings.get("Remove this account?"),
                Strings.get("Remove Account"), Strings.get("Cancel"));
        if (choice != 0) {
            return;
        }
        try {
            Account.remove(account.id);
        } catch (RuntimeException e) {
            warn("Could not remove the account: " + e.getMessage());
            return;
        }
        rebuild();
        fireAccountsChanged();
        if (wasCurrent) {
            fireAccountSwitched(Account.current());
        }
        info(Strings.format("Removed {0}.", nameOf(account)));
    }

    /** Re-reads the file, for when it was edited by hand. */
    private void refresh() {
        String before = lastCurrentId;
        Account.reload();
        rebuild();
        fireAccountsChanged();
        Account current = Account.current();
        String now = current == null ? null : current.id;
        if (!Objects.equals(before, now)) {
            fireAccountSwitched(current);
        }
    }

    /* ------------------------------------------------------------------ */
    /* messages and notification                                           */
    /* ------------------------------------------------------------------ */

    private void info(String text) {
        setHint(text, false);
    }

    private void warn(String text) {
        setHint(text, true);
    }

    private void setHint(String text, boolean error) {
        hintText = text == null || text.isBlank() ? " " : text;
        hintError = error;
        renderHint();
    }

    /** Renders the footer message; rendering is where translation happens. */
    private void renderHint() {
        hint.setForeground(hintError ? theme.error : UI.alpha(theme.sidebarFg, 180));
        hint.setText(Strings.prefix(hintText));
    }

    private void fireAccountSwitched(Account account) {
        for (Listener l : new ArrayList<>(listeners)) {
            try {
                l.accountSwitched(account);
            } catch (RuntimeException e) {
                warn("An account listener failed: " + e);
            }
        }
    }

    private void fireAccountsChanged() {
        for (Listener l : new ArrayList<>(listeners)) {
            try {
                l.accountsChanged();
            } catch (RuntimeException e) {
                warn("An account listener failed: " + e);
            }
        }
    }

    /** The display name, falling back to the login and then to the raw id. */
    private static String nameOf(Account a) {
        if (a.displayName != null && !a.displayName.isBlank()) {
            return a.displayName;
        }
        if (a.login != null && !a.login.isBlank()) {
            return a.login;
        }
        return a.id;
    }

    /* ------------------------------------------------------------------ */
    /* the wrapped note                                                    */
    /* ------------------------------------------------------------------ */

    /**
     * A block of wrapped text that re-measures itself whenever the sidebar is resized, so the text
     * is never clipped: a {@link JTextArea} reports one row's height until something tells it how
     * wide it really is, and the sidebar width is not known until it is laid out.
     */
    private class Note extends JPanel {

        Note(String text, Color foreground, int top, int left, int bottom, int right) {
            super(new BorderLayout());
            setOpaque(false);
            setAlignmentX(LEFT_ALIGNMENT);
            WrapArea area = new WrapArea(text);
            area.setFocusable(false);
            area.setFont(UI.ui(11.5f));
            area.setForeground(foreground);
            area.setBorder(BorderFactory.createEmptyBorder(top, left, bottom, right));
            add(area, BorderLayout.CENTER);
        }
    }
}
