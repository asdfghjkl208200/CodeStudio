package com.codestudio.ui;

import com.codestudio.core.Problems;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** The bottom panel with the Problems, Output, Debug Console and Terminal views. */
public class PanelArea extends JPanel {

    public static final String PROBLEMS = "problems";
    public static final String OUTPUT = "output";
    public static final String DEBUG = "debug";
    public static final String TERMINAL = "terminal";

    public interface Actions {
        void closePanel();

        void toggleMaximized();

        void notify(String message, boolean error);
    }

    private final Settings settings;
    private Theme theme;
    private Actions actions;

    private final CardLayout cards = new CardLayout();
    private final JPanel host = new JPanel(cards);
    private final JPanel tabStrip = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
    private final Map<String, ViewTab> tabs = new LinkedHashMap<>();
    /** Action buttons paired with their untranslated tooltip, so {@link #retranslate} can redo them. */
    private final Map<javax.swing.JButton, String> actionTooltips = new LinkedHashMap<>();

    private final ProblemsView problemsView;
    private final OutputView outputView;
    private final OutputView debugView;
    private final TerminalPanel terminalPanel;

    private String current = PROBLEMS;
    private boolean maximized;
    private int errors;
    private int warnings;

    public PanelArea(Settings settings, Workspace workspace, Problems problems, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.theme = theme;

        setBackground(theme.panelBg);
        host.setBackground(theme.panelBg);
        tabStrip.setBackground(theme.panelBg);
        tabStrip.setBorder(BorderFactory.createEmptyBorder(2, 4, 0, 4));

        problemsView = new ProblemsView(problems, workspace, theme);
        outputView = new OutputView(settings, theme);
        debugView = new OutputView(settings, theme);
        terminalPanel = new TerminalPanel(settings, theme, workspace.getRoot());

        host.add(problemsView, PROBLEMS);
        host.add(outputView, OUTPUT);
        host.add(debugView, DEBUG);
        host.add(terminalPanel, TERMINAL);

        addTab(PROBLEMS, "Problems");
        addTab(OUTPUT, "Output");
        addTab(DEBUG, "Debug Console");
        addTab(TERMINAL, "Terminal");

        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(theme.panelBg);
        bar.add(tabStrip, BorderLayout.WEST);

        JPanel right = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 2, 0));
        right.setBackground(theme.panelBg);
        right.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 4));
        right.add(actionButton("clear", "Clear", this::clearCurrent));
        right.add(actionButton("layout", "Maximize Panel", () -> {
            maximized = !maximized;
            if (actions != null) {
                actions.toggleMaximized();
            }
        }));
        right.add(actionButton("close", "Close Panel", () -> {
            if (actions != null) {
                actions.closePanel();
            }
        }));
        bar.add(right, BorderLayout.EAST);

        add(bar, BorderLayout.NORTH);
        add(host, BorderLayout.CENTER);

        show(PROBLEMS);
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    private void addTab(String id, String title) {
        ViewTab tab = new ViewTab(id, title);
        tabs.put(id, tab);
        tabStrip.add(tab);
    }

    /** Toolbar button that remembers its untranslated tooltip. */
    private javax.swing.JButton actionButton(String icon, String tooltip, Runnable action) {
        javax.swing.JButton b = UI.iconButton(Icons.of(icon, 14, theme.panelFg), Strings.get(tooltip), theme, action);
        actionTooltips.put(b, tooltip);
        return b;
    }

    /**
     * Re-applies the tab labels and toolbar tooltips after a language change, and lets each docked
     * view redo its own chrome.
     */
    public void retranslate() {
        for (ViewTab tab : tabs.values()) {
            tab.retranslate();
        }
        for (Map.Entry<javax.swing.JButton, String> e : actionTooltips.entrySet()) {
            e.getKey().setToolTipText(Strings.get(e.getValue()));
        }
        problemsView.retranslate();
        outputView.retranslate();
        debugView.retranslate();
        terminalPanel.retranslate();
        revalidate();
        repaint();
    }

    public void show(String id) {
        if (id == null || !tabs.containsKey(id)) {
            return;
        }
        current = id;
        cards.show(host, id);
        for (Map.Entry<String, ViewTab> e : tabs.entrySet()) {
            e.getValue().setSelected(e.getKey().equals(id));
        }
        if (TERMINAL.equals(id)) {
            terminalPanel.ensureTerminal(null);
        }
        revalidate();
        repaint();
    }

    public String currentView() {
        return current;
    }

    public ProblemsView problems() {
        return problemsView;
    }

    public OutputView output() {
        return outputView;
    }

    public OutputView debugConsole() {
        return debugView;
    }

    public TerminalPanel terminals() {
        return terminalPanel;
    }

    /** Updates the counters shown next to the Problems tab. */
    public void setProblemCounts(int errors, int warnings) {
        this.errors = errors;
        this.warnings = warnings;
        ViewTab tab = tabs.get(PROBLEMS);
        if (tab != null) {
            tab.refresh();
        }
    }

    private void clearCurrent() {
        switch (current) {
            case PROBLEMS -> problemsView.clearAll();
            case OUTPUT -> outputView.clear();
            case DEBUG -> debugView.clear();
            case TERMINAL -> terminalPanel.clearCurrent();
            default -> {
                // nothing to clear
            }
        }
    }

    public boolean isMaximized() {
        return maximized;
    }

    public void setMaximized(boolean value) {
        this.maximized = value;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.panelBg);
        host.setBackground(t.panelBg);
        tabStrip.setBackground(t.panelBg);
        problemsView.setTheme(t);
        outputView.setTheme(t);
        debugView.setTheme(t);
        terminalPanel.setTheme(t);
        for (ViewTab tab : tabs.values()) {
            tab.refresh();
        }
        repaint();
    }

    /** One tab of the panel: uppercase label plus optional error / warning badge. */
    private class ViewTab extends JPanel {
        private final String id;
        /** The untranslated tab label, kept so {@link #retranslate} can look it up again. */
        private final String title;
        private final JLabel label = new JLabel();
        private boolean selected;
        private boolean hovering;

        ViewTab(String id, String title) {
            super(new BorderLayout(4, 0));
            this.id = id;
            this.title = title;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(4, 9, 4, 9));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            label.setText(Strings.get(title).toUpperCase());
            label.setFont(UI.ui(11f));
            add(label, BorderLayout.CENTER);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (e.getButton() == MouseEvent.BUTTON2 && TERMINAL.equals(ViewTab.this.id)) {
                        terminalPanel.newTerminal();
                        return;
                    }
                    PanelArea.this.show(ViewTab.this.id);
                }
            });
        }

        void setSelected(boolean value) {
            this.selected = value;
            refresh();
        }

        void refresh() {
            label.setForeground(selected ? theme.panelFg : UI.alpha(theme.panelFg, 150));
            repaint();
        }

        void retranslate() {
            label.setText(Strings.get(title).toUpperCase());
            refresh();
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            d.width = Math.max(74, d.width + badgeWidth());
            return d;
        }

        private int badgeWidth() {
            if (!PROBLEMS.equals(id)) {
                return 0;
            }
            return (errors > 0 ? 26 : 0) + (warnings > 0 ? 26 : 0);
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (selected) {
                    g.setColor(UI.mix(theme.panelBg, theme.panelFg, 0.08f));
                    g.fillRoundRect(0, 0, getWidth(), getHeight(), 5, 5);
                } else if (hovering) {
                    g.setColor(UI.mix(theme.panelBg, theme.panelFg, 0.04f));
                    g.fillRoundRect(0, 0, getWidth(), getHeight(), 5, 5);
                }
                if (PROBLEMS.equals(id) && (errors > 0 || warnings > 0)) {
                    g.setFont(UI.uiBold(10.5f));
                    int x = getWidth() - 8;
                    if (warnings > 0) {
                        String text = String.valueOf(warnings);
                        int w = g.getFontMetrics().stringWidth(text);
                        g.setColor(theme.warning);
                        g.drawString(text, x - w, getHeight() / 2 + 4);
                        x -= w + 8;
                    }
                    if (errors > 0) {
                        String text = String.valueOf(errors);
                        int w = g.getFontMetrics().stringWidth(text);
                        g.setColor(theme.error);
                        g.drawString(text, x - w, getHeight() / 2 + 4);
                    }
                }
            } finally {
                g.dispose();
            }
            super.paintComponent(g0);
        }
    }

    /** Colour used for the maximized panel border. */
    Color borderColor() {
        return theme.dark ? new Color(0x1B1B1B) : new Color(0xDCDCDC);
    }

    public void setWorkingDirectory(File dir) {
        terminalPanel.setWorkingDirectory(dir);
    }
}
