package com.codestudio.ui;

import com.codestudio.core.Problems;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;

/** The Problems panel: diagnostics collected from compiler and program output. */
public class ProblemsView extends JPanel {

    public interface Actions {
        void openAt(File file, int line, int column);

        void notify(String message, boolean error);

        void revealInOS(File file);
    }

    private final Problems problems;
    private final Workspace workspace;
    private Theme theme;
    private Actions actions;

    private final Model model = new Model();
    private final JTable table = new JTable(model);
    private final TableRowSorter<Model> sorter = new TableRowSorter<>(model);
    private final JCheckBox errors = new JCheckBox(Strings.get("Errors"), true);
    private final JCheckBox warnings = new JCheckBox(Strings.get("Warnings"), true);
    private final JCheckBox infos = new JCheckBox(Strings.get("Info"), true);
    private final JTextField filter = new JTextField();
    private final JLabel empty = new JLabel(Strings.get("No problems have been detected in the workspace."));
    private final JScrollPane scroll;
    private javax.swing.JButton clearButton;

    public ProblemsView(Problems problems, Workspace workspace, Theme theme) {
        super(new BorderLayout());
        this.problems = problems;
        this.workspace = workspace;
        this.theme = theme;
        setBackground(theme.panelBg);

        table.setBackground(theme.panelBg);
        table.setForeground(theme.panelFg);
        table.setFont(UI.ui(12.5f));
        table.setRowHeight(22);
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(false);
        table.setGridColor(theme.panelBorder);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFillsViewportHeight(true);
        table.setRowSorter(sorter);
        table.setDefaultRenderer(Object.class, new CellRenderer());
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setBackground(theme.panelBg);
        table.getTableHeader().setForeground(UI.alpha(theme.panelFg, 180));
        table.getTableHeader().setFont(UI.ui(11.5f));
        table.getTableHeader().setPreferredSize(new Dimension(10, 22));
        JTableHeader header = table.getTableHeader();
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, theme.panelBorder));

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popup(e);
                    return;
                }
                if (e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1) {
                    openSelected();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popup(e);
                }
            }
        });

        scroll = UI.scroll(table, theme);
        scroll.getViewport().setBackground(theme.panelBg);
        scroll.setColumnHeaderView(table.getTableHeader());

        /* ---------- toolbar ---------- */
        JPanel bar = new JPanel(new BorderLayout(6, 0));
        bar.setBackground(theme.panelBg);
        bar.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));

        JPanel toggles = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 8, 0));
        toggles.setBackground(theme.panelBg);
        for (JCheckBox box : new JCheckBox[]{errors, warnings, infos}) {
            box.setBackground(theme.panelBg);
            box.setForeground(UI.alpha(theme.panelFg, 200));
            box.setFont(UI.ui(11.5f));
            box.setFocusPainted(false);
            box.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            box.addActionListener(e -> applyFilter());
            toggles.add(box);
        }
        bar.add(toggles, BorderLayout.WEST);

        filter.setFont(UI.ui(12f));
        filter.setBackground(theme.inputBg);
        filter.setForeground(theme.inputFg);
        filter.setCaretColor(theme.inputFg);
        filter.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(2, 6, 2, 6)));
        filter.putClientProperty("JTextField.placeholderText", Strings.get("Filter problems"));
        filter.setPreferredSize(new Dimension(220, 24));
        filter.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                applyFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                applyFilter();
            }
        });
        JPanel right = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 6, 0));
        right.setBackground(theme.panelBg);
        right.add(filter);
        clearButton = UI.smallButton(Strings.get("Clear"), theme, this::clear);
        right.add(clearButton);
        bar.add(right, BorderLayout.EAST);

        empty.setFont(UI.ui(13f));
        empty.setForeground(UI.alpha(theme.panelFg, 140));
        empty.setHorizontalAlignment(SwingConstants.CENTER);

        add(bar, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(empty, BorderLayout.SOUTH);

        problems.addListener(this::refresh);
        refresh();
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.panelBg);
        table.setBackground(t.panelBg);
        table.setForeground(t.panelFg);
        table.setGridColor(t.panelBorder);
        table.getTableHeader().setBackground(t.panelBg);
        table.getTableHeader().setForeground(UI.alpha(t.panelFg, 180));
        table.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, t.panelBorder));
        table.setDefaultRenderer(Object.class, new CellRenderer());
        filter.setBackground(t.inputBg);
        filter.setForeground(t.inputFg);
        filter.setCaretColor(t.inputFg);
        filter.setBorder(BorderFactory.createCompoundBorder(UI.line(t.inputBorder),
                BorderFactory.createEmptyBorder(2, 6, 2, 6)));
        scroll.getViewport().setBackground(t.panelBg);
        UI.themeScrollBar(scroll, t);
        empty.setForeground(UI.alpha(t.panelFg, 140));
        repaint();
    }

    /** Reloads the table from the shared problem list. */
    public final void refresh() {
        model.setRows(problems.all());
        applyFilter();
        boolean any = !problems.isEmpty();
        empty.setText(any ? " " : Strings.get("No problems have been detected in the workspace."));
        empty.setVisible(!any);
        revalidate();
        repaint();
    }

    /**
     * Re-applies the column headers, the toolbar toggles and the empty state after a language
     * change. Re-reading a string twice is harmless, so this can be called at any time.
     */
    public void retranslate() {
        errors.setText(Strings.get("Errors"));
        warnings.setText(Strings.get("Warnings"));
        infos.setText(Strings.get("Info"));
        if (clearButton != null) {
            clearButton.setText(Strings.get("Clear"));
        }
        // The placeholder lives in a client property Swing reads when the field is first painted,
        // so it has to be written again explicitly.
        filter.putClientProperty("JTextField.placeholderText", Strings.get("Filter problems"));
        // JTable caches the header values when the model is attached, so write them back by hand.
        int columns = Math.min(model.getColumnCount(), table.getColumnModel().getColumnCount());
        for (int i = 0; i < columns; i++) {
            table.getColumnModel().getColumn(i).setHeaderValue(model.getColumnName(i));
        }
        table.getTableHeader().resizeAndRepaint();
        refresh();
    }

    private void applyFilter() {
        List<RowFilter<Model, Integer>> filters = new ArrayList<>();
        final List<Problems.Severity> allowed = new ArrayList<>();
        if (errors.isSelected()) {
            allowed.add(Problems.Severity.ERROR);
        }
        if (warnings.isSelected()) {
            allowed.add(Problems.Severity.WARNING);
        }
        if (infos.isSelected()) {
            allowed.add(Problems.Severity.INFO);
        }
        filters.add(new RowFilter<>() {
            @Override
            public boolean include(Entry<? extends Model, ? extends Integer> entry) {
                return allowed.contains(model.severityAt(entry.getIdentifier()));
            }
        });
        String text = filter.getText().trim().toLowerCase(java.util.Locale.ROOT);
        if (!text.isEmpty()) {
            filters.add(new RowFilter<>() {
                @Override
                public boolean include(Entry<? extends Model, ? extends Integer> entry) {
                    String haystack = model.searchText(entry.getIdentifier());
                    return haystack.contains(text);
                }
            });
        }
        sorter.setRowFilter(filters.isEmpty() ? null : RowFilter.andFilter(filters));
    }

    private void clear() {
        problems.clear();
    }

    public void clearAll() {
        clear();
    }

    private Problems.Problem selected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            return null;
        }
        return model.problemAt(table.convertRowIndexToModel(row));
    }

    private void openSelected() {
        Problems.Problem p = selected();
        if (p == null || actions == null) {
            return;
        }
        if (p.file == null) {
            actions.notify("This problem has no file associated with it", true);
            return;
        }
        actions.openAt(p.file, p.line, p.column);
    }

    private void popup(MouseEvent e) {
        int row = table.rowAtPoint(e.getPoint());
        if (row >= 0) {
            table.setRowSelectionInterval(row, row);
        }
        Problems.Problem p = selected();
        if (p == null) {
            return;
        }
        JPopupMenu menu = new JPopupMenu();
        addItem(menu, "Go to Problem", this::openSelected);
        addItem(menu, "Copy Message", () -> java.awt.Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new java.awt.datatransfer.StringSelection(p.message), null));
        addItem(menu, "Copy", () -> java.awt.Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new java.awt.datatransfer.StringSelection(p.toString()), null));
        if (p.file != null) {
            addItem(menu, "Reveal in File Explorer", () -> {
                if (actions != null) {
                    actions.revealInOS(p.file);
                }
            });
        }
        menu.addSeparator();
        addItem(menu, "Clear All", this::clear);
        menu.show(table, e.getX(), e.getY());
    }

    private void addItem(JPopupMenu menu, String text, Runnable action) {
        JMenuItem item = new JMenuItem(Strings.get(text));
        item.setFont(UI.ui(12f));
        item.addActionListener(e -> action.run());
        menu.add(item);
    }

    /* ------------------------------------------------------------------ */

    /** Table model over the shared problem list. */
    private static class Model extends AbstractTableModel {
        private static final String[] COLUMNS = {"", "Message", "File", "Line"};
        private List<Problems.Problem> rows = new ArrayList<>();

        void setRows(List<Problems.Problem> list) {
            rows = list;
            fireTableDataChanged();
        }

        Problems.Problem problemAt(int index) {
            return index >= 0 && index < rows.size() ? rows.get(index) : null;
        }

        Problems.Severity severityAt(int index) {
            Problems.Problem p = problemAt(index);
            return p == null ? Problems.Severity.INFO : p.severity;
        }

        String searchText(int index) {
            Problems.Problem p = problemAt(index);
            if (p == null) {
                return "";
            }
            return (p.message + " " + (p.file == null ? "" : p.file.getName())).toLowerCase(java.util.Locale.ROOT);
        }

        @Override
        public int getRowCount() {
            return rows.size();
        }

        @Override
        public int getColumnCount() {
            return COLUMNS.length;
        }

        @Override
        public String getColumnName(int column) {
            return Strings.get(COLUMNS[column]);
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            Problems.Problem p = rows.get(rowIndex);
            return switch (columnIndex) {
                case 0 -> p.severity;
                case 1 -> p.message;
                case 2 -> p.file == null ? "" : p.file.getName();
                case 3 -> p.line + 1;
                default -> "";
            };
        }
    }

    /** Renders the severity icon, the message and the file name. */
    private class CellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            JLabel c = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, false, row, column);
            c.setFont(column == 1 ? UI.ui(12.5f) : UI.ui(11.5f));
            c.setOpaque(true);
            c.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
            Color bg = isSelected ? (table.isFocusOwner() ? theme.listActive : theme.listSelectionInactive)
                    : theme.panelBg;
            c.setBackground(bg);
            c.setForeground(isSelected && table.isFocusOwner() ? theme.listActiveFg : theme.panelFg);

            if (column == 0) {
                Problems.Severity sev = value instanceof Problems.Severity s ? s : Problems.Severity.INFO;
                c.setText("");
                c.setHorizontalAlignment(SwingConstants.CENTER);
                c.setIcon(new SeverityIcon(sev));
            } else if (column == 2) {
                c.setForeground(isSelected && table.isFocusOwner()
                        ? theme.listActiveFg : UI.alpha(theme.panelFg, 170));
            } else if (column == 3) {
                c.setHorizontalAlignment(SwingConstants.RIGHT);
                c.setForeground(isSelected && table.isFocusOwner()
                        ? theme.listActiveFg : UI.alpha(theme.panelFg, 170));
            } else {
                c.setIcon(null);
                c.setHorizontalAlignment(SwingConstants.LEFT);
                c.setToolTipText(String.valueOf(value));
            }
            return c;
        }
    }

    /** Small round glyph for the severity column. */
    private class SeverityIcon implements javax.swing.Icon {
        private final Problems.Severity severity;

        SeverityIcon(Problems.Severity severity) {
            this.severity = severity;
        }

        @Override
        public int getIconWidth() {
            return 16;
        }

        @Override
        public int getIconHeight() {
            return 16;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color color = switch (severity) {
                case ERROR -> theme.error;
                case WARNING -> theme.warning;
                case INFO -> theme.info;
            };
            g2.setColor(color);
            if (severity == Problems.Severity.INFO) {
                g2.fillOval(x + 3, y + 3, 10, 10);
                g2.setColor(theme.panelBg);
                g2.setFont(UI.uiBold(9f));
                g2.drawString("i", x + 6, y + 11);
            } else {
                int[] xs = {x + 8, x + 2, x + 14};
                int[] ys = {y + 2, y + 14, y + 14};
                g2.fillPolygon(xs, ys, 3);
                g2.setColor(theme.panelBg);
                g2.setFont(UI.uiBold(9f));
                g2.drawString("!", x + 6, y + 13);
            }
            g2.dispose();
        }
    }
}
