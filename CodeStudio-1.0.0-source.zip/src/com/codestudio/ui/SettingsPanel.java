package com.codestudio.ui;

import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** The Settings view: an editable list built from {@link Settings#DEFAULTS}. */
public class SettingsPanel extends JPanel implements ThemeAware {

    public interface Actions {
        void notify(String message, boolean error);

        void openSettingsFile();

        void resetSettings();
    }

    /** Human readable name for a settings group. */
    private static final Map<String, String> GROUPS = new LinkedHashMap<>();

    static {
        GROUPS.put("workbench", "Workbench");
        GROUPS.put("editor", "Text Editor");
        GROUPS.put("files", "Files");
        GROUPS.put("terminal", "Terminal");
        GROUPS.put("window", "Window");
        GROUPS.put("workspace", "Workspace");
    }

    /** Keys rendered as a drop down instead of a text field. */
    private static final Map<String, String[]> ENUMS = new LinkedHashMap<>();

    static {
        ENUMS.put("workbench.colorTheme", new String[]{"dark", "light"});
        ENUMS.put("workbench.language", new String[]{"system", "en", "zh"});
        ENUMS.put("editor.autoSave", new String[]{"off", "afterDelay", "onFocusChange"});
        ENUMS.put("files.eol", new String[]{"auto", "LF", "CRLF"});
        ENUMS.put("workbench.activityView", new String[]{"explorer", "search", "scm", "run", "settings"});
    }

    /**
     * Display text for a drop down value. The stored value stays the raw token — only the rendering
     * changes — so "zh" shows as 简体中文 while the settings file keeps "zh".
     */
    private static String enumLabel(String key, String value) {
        switch (key) {
            case "workbench.language":
                return Strings.modeLabel(value);
            case "workbench.colorTheme":
                return Theme.displayName(value);
            case "editor.autoSave":
                return switch (value) {
                    case "afterDelay" -> Strings.get("after a delay");
                    case "onFocusChange" -> Strings.get("on focus change");
                    default -> Strings.get("off");
                };
            case "files.eol":
                return "auto".equals(value) ? Strings.get("auto") : value;
            default:
                return value;
        }
    }

    private final Settings settings;
    private Theme theme;
    private Actions actions;

    private final JTextField search = new JTextField();
    private final JPanel list = new JPanel();
    private final JScrollPane scroll;
    private final List<Row> rows = new ArrayList<>();
    private SectionHeader header;
    private boolean rebuilding;

    public SettingsPanel(Settings settings, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.theme = theme;
        setBackground(theme.sidebarBg);

        search.setFont(UI.ui(12.5f));
        search.setBackground(theme.inputBg);
        search.setForeground(theme.inputFg);
        search.setCaretColor(theme.inputFg);
        search.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        search.putClientProperty("JTextField.placeholderText", Strings.get("Search settings"));
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                filter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                filter();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                filter();
            }
        });

        header = new SectionHeader("Settings", theme);
        header.addAction("edit", "Open settings.properties", () -> {
            if (actions != null) {
                actions.openSettingsFile();
            }
        });
        header.addAction("refresh", "Reset to Defaults", () -> {
            if (actions != null) {
                actions.resetSettings();
            }
        });

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(theme.sidebarBg);
        top.add(header, BorderLayout.NORTH);
        JPanel pad = new JPanel(new BorderLayout());
        pad.setBackground(theme.sidebarBg);
        pad.setBorder(BorderFactory.createEmptyBorder(4, 8, 6, 8));
        pad.add(search, BorderLayout.CENTER);
        top.add(pad, BorderLayout.CENTER);

        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        list.setBackground(theme.sidebarBg);
        list.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));

        scroll = UI.scroll(list, theme);
        scroll.getViewport().setBackground(theme.sidebarBg);
        scroll.getVerticalScrollBar().setUnitIncrement(18);

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        rebuild();
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.sidebarBg);
        search.setBackground(t.inputBg);
        search.setForeground(t.inputFg);
        search.setCaretColor(t.inputFg);
        search.setBorder(BorderFactory.createCompoundBorder(UI.line(t.inputBorder),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        scroll.getViewport().setBackground(t.sidebarBg);
        UI.themeScrollBar(scroll, t);
        rebuild();
    }

    /** Rebuilds every row; also used after a theme change. */
    public final void rebuild() {
        rebuilding = true;
        list.removeAll();
        rows.clear();

        String currentGroup = null;
        for (Map.Entry<String, String> e : Settings.DEFAULTS.entrySet()) {
            String key = e.getKey();
            String group = key.contains(".") ? key.substring(0, key.indexOf('.')) : "general";
            if (!group.equals(currentGroup)) {
                if (currentGroup != null) {
                    list.add(Box.createVerticalStrut(8));
                }
                currentGroup = group;
                list.add(groupLabel(GROUPS.getOrDefault(group, capitalize(group))));
            }
            Row row = new Row(key, e.getValue());
            rows.add(row);
            list.add(row);
        }
        list.add(Box.createVerticalStrut(10));
        list.add(helpNote());
        rebuilding = false;
        filter();
        list.revalidate();
        list.repaint();
    }

    /**
     * Re-applies every visible string after a language change. The placeholder is set through a
     * client property, which Swing reads once when the field is first painted, so it has to be
     * written again explicitly rather than picked up from the rebuild.
     */
    public void retranslate() {
        search.putClientProperty("JTextField.placeholderText", Strings.get("Search settings"));
        header.retranslate();
        rebuild();
    }

    private JComponent groupLabel(String text) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(theme.sidebarBg);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, theme.sectionBorder),
                BorderFactory.createEmptyBorder(6, 10, 5, 8)));
        JLabel l = new JLabel(Strings.get(text).toUpperCase());
        l.setFont(UI.uiBold(11f));
        l.setForeground(theme.sectionHeader);
        p.add(l, BorderLayout.WEST);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.putClientProperty("settings.group", Boolean.TRUE);
        return p;
    }

    private JComponent helpNote() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(theme.sidebarBg);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, theme.sectionBorder),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        String note = Strings.format(
                "Settings are stored in {0} and applied immediately.",
                "<b>~/.codestudio/settings.properties</b>");
        JLabel l = new JLabel("<html>" + note + "</html>");
        l.setFont(UI.ui(11.5f));
        l.setForeground(UI.alpha(theme.sidebarFg, 170));
        p.add(l, BorderLayout.CENTER);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        p.setAlignmentX(LEFT_ALIGNMENT);
        return p;
    }

    private static String capitalize(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private void filter() {
        String q = search.getText().trim().toLowerCase(java.util.Locale.ROOT);
        for (int i = 0; i < list.getComponentCount(); i++) {
            Component c = list.getComponent(i);
            if (!(c instanceof Row row)) {
                if (c instanceof JComponent jc && Boolean.TRUE.equals(jc.getClientProperty("settings.group"))) {
                    jc.setVisible(q.isEmpty());
                }
                continue;
            }
            row.setVisible(q.isEmpty()
                    || row.key.toLowerCase(java.util.Locale.ROOT).contains(q)
                    || row.description().toLowerCase(java.util.Locale.ROOT).contains(q));
        }
        list.revalidate();
        list.repaint();
    }

    /* ------------------------------------------------------------------ */

    /** A single editable setting. */
    private class Row extends JPanel {
        final String key;
        final String label;
        private final JLabel nameLabel = new JLabel();
        private JComponent editor;

        Row(String key, String defaultValue) {
            super(new BorderLayout(6, 0));
            this.key = key;
            this.label = key.substring(key.indexOf('.') + 1);
            setBackground(theme.sidebarBg);
            setBorder(BorderFactory.createEmptyBorder(3, 10, 3, 10));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            setAlignmentX(LEFT_ALIGNMENT);

            nameLabel.setText(label);
            nameLabel.setFont(UI.ui(12.5f));
            nameLabel.setForeground(theme.sidebarFg);
            nameLabel.setToolTipText(key);
            add(nameLabel, BorderLayout.WEST);

            editor = buildEditor(defaultValue);
            add(editor, BorderLayout.EAST);
        }

        String description() {
            return key;
        }

        private JComponent buildEditor(String defaultValue) {
            String value = settings.get(key);
            String[] options = ENUMS.get(key);
            if (options != null) {
                JComboBox<String> combo = new JComboBox<>(options);
                // Items stay the raw stored tokens; only the rendering is translated.
                combo.setRenderer(new DefaultListCellRenderer() {
                    @Override
                    public Component getListCellRendererComponent(javax.swing.JList<?> source,
                            Object item, int index, boolean selected, boolean focus) {
                        Object shown = item == null ? null : enumLabel(key, String.valueOf(item));
                        return super.getListCellRendererComponent(source, shown, index, selected, focus);
                    }
                });
                combo.setSelectedItem(value);
                combo.setFont(UI.ui(12f));
                combo.setBackground(theme.inputBg);
                combo.setForeground(theme.inputFg);
                combo.setFocusable(false);
                combo.setPreferredSize(new Dimension(140, 24));
                combo.addActionListener(e -> {
                    if (!rebuilding && combo.getSelectedItem() != null) {
                        apply(String.valueOf(combo.getSelectedItem()));
                    }
                });
                return combo;
            }
            if (isBoolean(defaultValue, value)) {
                JCheckBox box = new JCheckBox();
                box.setSelected("true".equalsIgnoreCase(value));
                box.setBackground(theme.sidebarBg);
                box.setFocusPainted(false);
                box.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                box.addActionListener(e -> {
                    if (!rebuilding) {
                        apply(String.valueOf(box.isSelected()));
                    }
                });
                JPanel wrap = new JPanel(new BorderLayout());
                wrap.setBackground(theme.sidebarBg);
                wrap.add(box, BorderLayout.EAST);
                return wrap;
            }
            if (isNumeric(defaultValue)) {
                int min = key.contains("zoomLevel") ? -10 : 0;
                int max = key.contains("zoomLevel") ? 10 : 1_000_000;
                int current = Math.max(min, Math.min(max, settings.getInt(key)));
                JSpinner spin = new JSpinner(new SpinnerNumberModel(current, min, max, 1));
                spin.setFont(UI.ui(12f));
                spin.setPreferredSize(new Dimension(90, 24));
                ((JSpinner.DefaultEditor) spin.getEditor()).getTextField().setBackground(theme.inputBg);
                ((JSpinner.DefaultEditor) spin.getEditor()).getTextField().setForeground(theme.inputFg);
                spin.addChangeListener(e -> {
                    if (!rebuilding) {
                        apply(String.valueOf(spin.getValue()));
                    }
                });
                return spin;
            }
            JTextField field = new JTextField(value, 18);
            field.setFont(UI.mono(UI.resolveMono(null), 12f));
            field.setBackground(theme.inputBg);
            field.setForeground(theme.inputFg);
            field.setCaretColor(theme.inputFg);
            field.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                    BorderFactory.createEmptyBorder(2, 5, 2, 5)));
            field.setPreferredSize(new Dimension(190, 24));
            field.addFocusListener(new FocusAdapter() {
                @Override
                public void focusLost(FocusEvent e) {
                    apply(field.getText());
                }
            });
            field.addActionListener(e -> apply(field.getText()));
            return field;
        }

        private boolean isBoolean(String def, String value) {
            return "true".equalsIgnoreCase(def) || "false".equalsIgnoreCase(def)
                    || "true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value);
        }

        private boolean isNumeric(String def) {
            if (def == null || def.isBlank() || label.equals("x") || label.equals("y")) {
                return false;
            }
            for (int i = 0; i < def.length(); i++) {
                if (!Character.isDigit(def.charAt(i)) && def.charAt(i) != '-') {
                    return false;
                }
            }
            return true;
        }

        private void apply(String value) {
            settings.set(key, value);
            nameLabel.setForeground(theme.accent);
            javax.swing.Timer t = new javax.swing.Timer(600, e -> nameLabel.setForeground(theme.sidebarFg));
            t.setRepeats(false);
            t.start();
        }
    }

    /** Exposed so the main window can steer the search box from the command palette. */
    public void focusSearch(String text) {
        search.setText(text == null ? "" : text);
        search.requestFocusInWindow();
    }
}
