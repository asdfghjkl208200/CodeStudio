package com.codestudio.ui;

import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 * Toast stack installed as the window glass pane. Points outside a toast fall
 * through to the content pane because {@link #contains(Point)} is overridden.
 */
public class Notifications extends JPanel {

    public enum Level {
        INFO, WARNING, ERROR
    }

    private static final int MARGIN = 14;
    private static final int GAP = 8;
    private static final int MAX_WIDTH = 340;
    private static final int MAX_VISIBLE = 4;

    private Theme theme;
    private final List<Toast> toasts = new ArrayList<>();
    private final List<String> history = new ArrayList<>();

    public Notifications(Theme theme) {
        super(null);
        this.theme = theme;
        setOpaque(false);
        setFocusable(false);
    }

    /** Re-themes the stack and every visible toast. */
    public void setTheme(Theme t) {
        this.theme = t;
        for (Toast toast : toasts) {
            toast.applyTheme(t);
        }
        revalidate();
        repaint();
    }

    public void info(String message) {
        show(message, Level.INFO);
    }

    public void warn(String message) {
        show(message, Level.WARNING);
    }

    public void error(String message) {
        show(message, Level.ERROR);
    }

    public void show(String message, boolean error) {
        show(message, error ? Level.ERROR : Level.INFO);
    }

    /** Adds a toast; the oldest one is dropped when the stack is full. */
    public void show(String message, Level level) {
        if (message == null || message.isBlank()) {
            return;
        }
        if (!SwingUtilities.isEventDispatchThread()) {
            SwingUtilities.invokeLater(() -> show(message, level));
            return;
        }
        synchronized (history) {
            history.add(0, message);
            while (history.size() > 50) {
                history.remove(history.size() - 1);
            }
        }
        Toast toast = new Toast(message, level, theme);
        toasts.add(toast);
        add(toast);
        while (toasts.size() > MAX_VISIBLE) {
            removeToast(toasts.get(0));
        }
        layoutToasts();
        toast.slideIn();
        revalidate();
        repaint();
    }

    /**
     * Re-applies the stack's own text after a language change. The toasts only ever carry messages
     * that {@code MainWindow.notify} has already translated, and the "Notifications" heading and
     * "No notifications yet." empty state are owned by {@code MainWindow.showNotifications}, so this
     * class has no literal of its own to redo. The method exists so the window can treat every panel
     * uniformly.
     */
    public void retranslate() {
        // Every string shown here arrives pre-translated; nothing of our own to re-apply.
        revalidate();
        repaint();
    }

    public List<String> history() {
        synchronized (history) {
            return new ArrayList<>(history);
        }
    }

    public void clearAll() {
        for (Toast toast : new ArrayList<>(toasts)) {
            removeToast(toast);
        }
        toasts.clear();
        revalidate();
        repaint();
    }

    private void removeToast(Toast toast) {
        toasts.remove(toast);
        remove(toast);
        layoutToasts();
        revalidate();
        repaint();
    }

    /** Stacks the toasts upward from the bottom right corner. */
    private void layoutToasts() {
        int y = getHeight() - MARGIN;
        for (int i = toasts.size() - 1; i >= 0; i--) {
            Toast toast = toasts.get(i);
            Dimension d = toast.getPreferredSize();
            int w = Math.min(MAX_WIDTH, d.width);
            int h = d.height;
            toast.setBounds(getWidth() - w - MARGIN, y - h, w, h);
            y -= h + GAP;
        }
    }

    @Override
    public void doLayout() {
        layoutToasts();
    }

    /** Mouse events outside a toast are forwarded to the window content. */
    @Override
    public boolean contains(int x, int y) {
        for (Toast toast : toasts) {
            if (toast.getBounds().contains(x, y)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean contains(Point p) {
        return p != null && contains(p.x, p.y);
    }

    /** A single toast card. */
    private class Toast extends JPanel {
        private final JLabel message = new JLabel();
        private final JLabel close = new JLabel();
        private Level level;
        private Theme t;
        private boolean hovering;
        private int slideOffset;

        Toast(String text, Level level, Theme t) {
            super(new BorderLayout(8, 0));
            this.level = level;
            setLayout(new BorderLayout(8, 0));
            setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 8));
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            message.setText("<html><body style='width:" + (MAX_WIDTH - 90) + "px'>" + UI.esc(text) + "</body></html>");
            message.setFont(UI.ui(12.5f));
            add(message, BorderLayout.CENTER);

            close.setIcon(Icons.of("close", 12, theme.panelFg));
            close.setPreferredSize(new Dimension(16, 16));
            close.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            close.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    e.consume();
                    removeToast(Toast.this);
                }
            });
            add(close, BorderLayout.EAST);

            applyTheme(t);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    removeToast(Toast.this);
                }
            });

            int delay = level == Level.ERROR ? 9000 : (level == Level.WARNING ? 7000 : 5000);
            Timer timer = new Timer(delay, e -> fadeOut());
            timer.setRepeats(false);
            timer.start();
        }

        void applyTheme(Theme t) {
            this.t = t;
            message.setForeground(t.panelFg);
            close.setIcon(Icons.of("close", 12, UI.alpha(t.panelFg, 190)));
            repaint();
        }

        /** Animates the card in from the right edge; the offset is applied while painting. */
        void slideIn() {
            slideOffset = 42;
            Timer timer = new Timer(12, null);
            timer.addActionListener(e -> {
                slideOffset = Math.max(0, slideOffset - 5);
                repaint();
                if (slideOffset == 0) {
                    ((Timer) e.getSource()).stop();
                }
            });
            timer.start();
        }

        private void fadeOut() {
            if (hovering) {
                Timer again = new Timer(1200, e -> fadeOut());
                again.setRepeats(false);
                again.start();
                return;
            }
            removeToast(this);
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.translate(slideOffset, 0);
                g.setColor(t.widgetBg);
                g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                g.setColor(hovering ? UI.mix(t.widgetBorder, t.panelFg, 0.2f) : t.widgetBorder);
                g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);

                Color bar = switch (level) {
                    case ERROR -> t.error;
                    case WARNING -> t.warning;
                    case INFO -> t.accent;
                };
                g.setColor(bar);
                g.fillRoundRect(1, 1, 3, getHeight() - 3, 3, 3);
            } finally {
                g.dispose();
            }
            super.paintComponent(g0);
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            d.width = Math.min(MAX_WIDTH, Math.max(240, d.width));
            return d;
        }
    }
}
