package com.codestudio.ui;

import com.codestudio.core.DocumentBundle;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.SyntaxHighlighter;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;

/**
 * One editor: breadcrumbs, the code area with gutter and minimap, plus the
 * find/replace widget.
 */
public class EditorPanel extends JPanel {

    /** Callbacks the editor needs from the workbench. */
    public interface Actions {
        void runFile(DocumentBundle bundle);

        void splitEditor();

        void showEditorMenu(java.awt.Component invoker, DocumentBundle bundle);

        void notify(String message);
    }

    private final DocumentBundle bundle;
    private final Settings settings;
    private final Workspace workspace;
    private final SyntaxHighlighter highlighter;
    private final Actions actions;

    private final CodeTextPane editor;
    private final LineNumberView gutter;
    private final Minimap minimap;
    private final FindReplaceBar findBar;
    private final JScrollPane scroll;
    private final JPanel north;
    private final JPanel breadcrumbs;
    /** The breadcrumb's text label; kept as a field so it can be filled while the bar is built. */
    private JLabel breadcrumbPath;
    private JButton runButton;
    private JButton splitButton;
    private JButton moreButton;
    private final JPanel editorArea;
    private boolean minimapShown;
    private Theme theme;

    public EditorPanel(DocumentBundle bundle, Settings settings, Workspace workspace,
                       SyntaxHighlighter highlighter, Theme theme, Actions actions) {
        super(new BorderLayout());
        this.bundle = bundle;
        this.settings = settings;
        this.workspace = workspace;
        this.highlighter = highlighter;
        this.theme = theme;
        this.actions = actions;

        setBackground(theme.editorBg);
        setOpaque(true);

        editor = new CodeTextPane(bundle, settings, highlighter, theme);
        gutter = new LineNumberView(editor, theme);
        minimap = new Minimap(editor, theme);
        findBar = new FindReplaceBar(editor, theme);
        findBar.setVisible(false);

        scroll = UI.scroll(editor, theme);
        scroll.setBackground(theme.editorBg);
        scroll.getViewport().setBackground(theme.editorBg);
        scroll.getVerticalScrollBar().setBlockIncrement(60);
        applyLineNumbers();

        editorArea = new JPanel(new BorderLayout());
        editorArea.setBackground(theme.editorBg);
        editorArea.add(scroll, BorderLayout.CENTER);
        applyMinimap();

        breadcrumbs = buildBreadcrumbs();

        north = new JPanel();
        north.setLayout(new BoxLayout(north, BoxLayout.Y_AXIS));
        north.setOpaque(true);
        north.setBackground(theme.editorBg);
        north.add(breadcrumbs);
        north.add(findBar);

        add(north, BorderLayout.NORTH);
        add(editorArea, BorderLayout.CENTER);

        bundle.addDirtyListener(this::updateBreadcrumbTitle);
    }

    /* ------------------------------------------------------------------ */

    private JPanel buildBreadcrumbs() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(theme.editorBg);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, theme.editorBg),
                BorderFactory.createEmptyBorder(3, 8, 3, 4)));

        JLabel path = new JLabel();
        breadcrumbPath = path;
        path.setFont(UI.ui(11.5f));
        path.setForeground(UI.alpha(theme.editorFg, 190));
        bar.add(path, BorderLayout.CENTER);
        bar.putClientProperty("pathLabel", path);

        JPanel tools = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        tools.setOpaque(false);
        runButton = UI.iconButton(Icons.of("run", 14, UI.alpha(theme.editorFg, 190)), Strings.get("Run File"),
                theme, () -> actions.runFile(bundle));
        splitButton = UI.iconButton(Icons.of("split", 14, UI.alpha(theme.editorFg, 190)),
                Strings.get("Split Editor"), theme, () -> actions.splitEditor());
        moreButton = UI.iconButton(Icons.of("ellipsis", 14, UI.alpha(theme.editorFg, 190)),
                Strings.get("More Actions..."), theme, () -> actions.showEditorMenu(tools, bundle));
        tools.add(runButton);
        tools.add(splitButton);
        tools.add(moreButton);
        bar.add(tools, BorderLayout.EAST);

        bar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                bar.setBackground(theme.editorBg);
            }
        });
        updateBreadcrumbTitle();
        return bar;
    }

    private void updateBreadcrumbTitle() {
        JLabel path = breadcrumbPath;
        if (path == null) {
            return;
        }
        String text;
        if (bundle.file == null) {
            text = Strings.format("{0}  (unsaved)", bundle.name());
        } else {
            String rel = workspace.relative(bundle.file);
            String[] parts = rel.split("[\\\\/]");
            StringBuilder sb = new StringBuilder("<html><body style='font-family:Segoe UI;font-size:11px'>");
            String sep = "<span style='color:" + UI.hex(UI.alpha(theme.editorFg, 120)) + "'> &rsaquo; </span>";
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) {
                    sb.append(sep);
                }
                String color = i == parts.length - 1
                        ? UI.hex(theme.editorFg) : UI.hex(UI.alpha(theme.editorFg, 190));
                sb.append("<span style='color:").append(color).append("'>").append(UI.esc(parts[i]))
                        .append("</span>");
            }
            sb.append("</body></html>");
            text = sb.toString();
        }
        path.setText(text);
        path.setToolTipText(bundle.file == null ? Strings.get("Unsaved file") : bundle.file.getAbsolutePath());
    }

    private void applyLineNumbers() {
        boolean show = settings.getBool("editor.lineNumbers");
        scroll.setRowHeaderView(show ? gutter : null);
        if (show) {
            scroll.setCorner(JScrollPane.UPPER_LEFT_CORNER, new JPanel() {
                {
                    setBackground(theme.editorBg);
                    setOpaque(true);
                }

                @Override
                public Dimension getPreferredSize() {
                    return new Dimension(gutter.getPreferredSize().width, 6);
                }
            });
        }
    }

    private void applyMinimap() {
        boolean show = settings.getBool("editor.minimap");
        if (show && !minimapShown) {
            editorArea.add(minimap, BorderLayout.EAST);
            minimapShown = true;
        } else if (!show && minimapShown) {
            editorArea.remove(minimap);
            minimapShown = false;
        }
        editorArea.revalidate();
        editorArea.repaint();
    }

    /* ------------------------------------------------------------------ */

    public CodeTextPane editor() {
        return editor;
    }

    public DocumentBundle bundle() {
        return bundle;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.editorBg);
        editorArea.setBackground(t.editorBg);
        north.setBackground(t.editorBg);
        breadcrumbs.setBackground(t.editorBg);
        scroll.getViewport().setBackground(t.editorBg);
        UI.themeScrollBar(scroll, t);
        editor.applyTheme(t);
        gutter.setTheme(t);
        minimap.setTheme(t);
        findBar.setTheme(t);
        updateBreadcrumbTitle();
        repaint();
    }

    /**
     * Re-applies every visible string after a language change: the breadcrumb and its tooltip, the
     * chrome buttons' tooltips and the find/replace widget. Called by
     * {@link EditorGroup#retranslate()}.
     */
    public void retranslate() {
        runButton.setToolTipText(Strings.get("Run File"));
        splitButton.setToolTipText(Strings.get("Split Editor"));
        moreButton.setToolTipText(Strings.get("More Actions..."));
        updateBreadcrumbTitle();
        findBar.retranslate();
    }

    public void refreshPrefs() {
        editor.readPrefs();
        editor.applyFont();
        applyLineNumbers();
        applyMinimap();
        minimap.invalidateBuffer();
        editor.runHighlight();
        updateBreadcrumbTitle();
    }

    public void openFind(boolean replace) {
        findBar.setVisible(true);
        north.revalidate();
        north.repaint();
        findBar.open(replace);
    }

    public void closeFind() {
        if (findBar.isVisible()) {
            findBar.setVisible(false);
            north.revalidate();
            north.repaint();
            editor.requestFocusInWindow();
        }
    }

    public boolean isFindVisible() {
        return findBar.isVisible();
    }

    public Minimap minimap() {
        return minimap;
    }

    public JScrollPane scrollPane() {
        return scroll;
    }

    /** Focuses the code area and restores the caret. */
    public void activate() {
        SwingUtilities.invokeLater(() -> {
            editor.setCaretPosition(Math.min(bundle.caret, editor.getDocument().getLength()));
            editor.requestFocusInWindow();
            editor.refreshDecorations();
        });
    }

    public void saveCaret() {
        bundle.caret = editor.getCaretPosition();
        bundle.selectionEnd = editor.getSelectionEnd();
    }

    public void syncAfterExternalChange() {
        editor.runHighlight();
        minimap.invalidateBuffer();
        gutter.revalidate();
        gutter.repaint();
        updateBreadcrumbTitle();
    }

    public void dispose() {
        findBar.close();
        editor.hideSuggestions();
        editor.getHighlighter().removeAllHighlights();
    }

    public JViewport viewport() {
        return scroll.getViewport();
    }
}
