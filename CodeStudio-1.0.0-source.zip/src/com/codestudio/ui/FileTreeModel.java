package com.codestudio.ui;

import com.codestudio.core.Workspace;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

/** Lazily loaded file system tree used by the Explorer view. */
public class FileTreeModel implements TreeModel {

    /** A directory or file node; children are read the first time they are needed. */
    public static class Node {
        public final File file;
        public final Node parent;
        public List<Node> children;
        public long stamp = -1;

        public Node(File file, Node parent) {
            this.file = file;
            this.parent = parent;
        }

        public boolean isDirectory() {
            return file.isDirectory();
        }

        public boolean isRoot() {
            return parent == null;
        }

        public List<Node> children(Workspace workspace) {
            if (!isDirectory()) {
                return List.of();
            }
            if (children == null) {
                children = load(workspace);
                stamp = signature();
            }
            return children;
        }

        public long signature() {
            if (!file.isDirectory()) {
                return file.lastModified();
            }
            String[] names = file.list();
            long h = file.lastModified();
            if (names != null) {
                for (String n : names) {
                    h = h * 31 + n.hashCode();
                }
            }
            return h;
        }

        private List<Node> load(Workspace workspace) {
            File[] files = file.listFiles();
            List<Node> out = new ArrayList<>();
            if (files == null) {
                return out;
            }
            Set<String> excluded = workspace == null ? Set.of() : workspace.excludedDirs();
            Arrays.sort(files, (a, b) -> {
                if (a.isDirectory() != b.isDirectory()) {
                    return a.isDirectory() ? -1 : 1;
                }
                return a.getName().compareToIgnoreCase(b.getName());
            });
            for (File f : files) {
                String name = f.getName();
                if (name.startsWith(".") && f.isDirectory() && !name.equals(".github")) {
                    continue;
                }
                if (f.isDirectory() && excluded.contains(name.toLowerCase(Locale.ROOT))) {
                    continue;
                }
                out.add(new Node(f, this));
            }
            return out;
        }

        @Override
        public String toString() {
            return file.getName();
        }
    }

    private Node root;
    private final Workspace workspace;
    private final List<TreeModelListener> listeners = new ArrayList<>();

    public FileTreeModel(Workspace workspace) {
        this.workspace = workspace;
    }

    public void setRoot(File dir) {
        root = dir == null ? null : new Node(dir, null);
        for (TreeModelListener l : new ArrayList<>(listeners)) {
            l.treeStructureChanged(new javax.swing.event.TreeModelEvent(this,
                    new TreePath(root == null ? new Object[]{""} : new Object[]{root})));
        }
    }

    public Node rootNode() {
        return root;
    }

    public Workspace workspace() {
        return workspace;
    }

    /** Re-reads the children of a node from disk. */
    public void refresh(Node node) {
        if (node == null) {
            return;
        }
        node.children = null;
        TreePath path = pathOf(node);
        for (TreeModelListener l : new ArrayList<>(listeners)) {
            l.treeStructureChanged(new javax.swing.event.TreeModelEvent(this, path));
        }
    }

    public TreePath pathOf(Node node) {
        List<Node> chain = new ArrayList<>();
        Node n = node;
        while (n != null) {
            chain.add(0, n);
            n = n.parent;
        }
        return new TreePath(chain.toArray());
    }

    /** Finds the node for a file by walking down from the root. */
    public Node find(File target) {
        if (root == null || target == null) {
            return null;
        }
        try {
            File abs = target.getCanonicalFile();
            if (!abs.getAbsolutePath().startsWith(root.file.getAbsoluteFile().getAbsolutePath())) {
                return null;
            }
            String rel = root.file.getAbsoluteFile().toURI().relativize(abs.toURI()).getPath();
            Node cur = root;
            for (String part : rel.split("/")) {
                if (part.isEmpty()) {
                    continue;
                }
                Node next = null;
                for (Node child : cur.children(workspace)) {
                    if (child.file.getName().equals(part)) {
                        next = child;
                        break;
                    }
                }
                if (next == null) {
                    return null;
                }
                cur = next;
            }
            return cur;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Object getRoot() {
        return root;
    }

    @Override
    public Object getChild(Object parent, int index) {
        List<Node> kids = ((Node) parent).children(workspace);
        return index >= 0 && index < kids.size() ? kids.get(index) : null;
    }

    @Override
    public int getChildCount(Object parent) {
        return ((Node) parent).children(workspace).size();
    }

    @Override
    public boolean isLeaf(Object node) {
        return !((Node) node).isDirectory();
    }

    @Override
    public void valueForPathChanged(TreePath path, Object newValue) {
        // read-only model
    }

    @Override
    public int getIndexOfChild(Object parent, Object child) {
        List<Node> kids = ((Node) parent).children(workspace);
        return kids.indexOf(child);
    }

    @Override
    public void addTreeModelListener(TreeModelListener l) {
        listeners.add(l);
    }

    @Override
    public void removeTreeModelListener(TreeModelListener l) {
        listeners.remove(l);
    }
}
