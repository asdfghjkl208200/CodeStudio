package com.codestudio.ui;

import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.ToolTipManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/** "Search" view: search and replace across every file in the workspace folder. */
public class SearchPanel extends JPanel implements ThemeAware {

    public interface Actions {
        void openAt(File file, int line, int column, int length);

        void notify(String message, boolean error);

        /** Called after files were modified on disk so open editors can reload. */
        void filesChanged(List<File> files);

        void revealInOS(File file);
    }

    /** One match inside a file. */
    public static class Match {
        public final int line;
        public final int column;
        public final int length;
        public final String preview;

        Match(int line, int column, int length, String preview) {
            this.line = line;
            this.column = column;
            this.length = length;
            this.preview = preview;
        }
    }

    /** All matches found inside a single file. */
    public static class FileResult {
        public final File file;
        public final List<Match> matches = new ArrayList<>();

        FileResult(File file) {
            this.file = file;
        }

        @Override
        public String toString() {
            return file.getName();
        }
    }

    private static final int MAX_RESULTS = 3000;
    private static final long MAX_FILE_BYTES = 4L * 1024 * 1024;

    private final Workspace workspace;
    private Theme theme;
    private Actions actions;

    private final JTextField query = new JTextField();
    private final JTextField replace = new JTextField();
    private final JTextField includes = new JTextField();
    private final JTextField excludes = new JTextField();
    private final JLabel status = new JLabel(" ");
    private final JLabel empty = new JLabel(" ");

    private final Toggle caseToggle = new Toggle("Aa", "Match Case");
    private final Toggle wordToggle = new Toggle("ab", "Match Whole Word");
    private final Toggle regexToggle = new Toggle(".*", "Use Regular Expression");

    private final JPanel replaceRow = new JPanel(new BorderLayout(4, 0));
    private final JPanel detailsBox = new JPanel(new GridLayout(0, 1, 0, 3));
    /** Labels built from a fixed key, so {@link #retranslate} can re-apply their text. */
    private final Map<JLabel, String> translatedLabels = new LinkedHashMap<>();
    private JButton replaceAllButton;
    private JButton toggleDetailsButton;

    private final DefaultMutableTreeNode root = new DefaultMutableTreeNode("root");
    private final DefaultTreeModel model = new DefaultTreeModel(root);
    private final JTree tree = new JTree(model);
    private final JScrollPane treeScroll;

    private SwingWorker<List<FileResult>, Void> worker;
    private List<FileResult> lastResults = new ArrayList<>();
    private boolean includeIgnored;

    public SearchPanel(Workspace workspace, Theme theme) {
        super(new BorderLayout());
        this.workspace = workspace;
        this.theme = theme;
        setBackground(theme.sidebarBg);

        /* ---------- query rows ---------- */
        query.putClientProperty("JTextField.placeholderText", Strings.get("Search"));
        JPanel form = new JPanel(new BorderLayout(0, 3));
        form.setBackground(theme.sidebarBg);
        form.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));

        form.add(fieldRow(query, false, true), BorderLayout.NORTH);
        replaceRow.add(fieldRow(replace, true, false), BorderLayout.NORTH);
        replaceRow.setBackground(theme.sidebarBg);
        replaceRow.setVisible(false);
        form.add(replaceRow, BorderLayout.CENTER);

        detailsBox.setBackground(theme.sidebarBg);
        detailsBox.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));
        detailsBox.add(labeled("files to include", includes));
        detailsBox.add(labeled("files to exclude", excludes));
        detailsBox.setVisible(false);

        JPanel south = new JPanel(new BorderLayout());
        south.setBackground(theme.sidebarBg);
        south.add(detailsBox, BorderLayout.NORTH);

        status.setFont(UI.ui(11.5f));
        status.setForeground(theme.sidebarFg);
        status.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 8));
        south.add(status, BorderLayout.SOUTH);
        form.add(south, BorderLayout.SOUTH);

        /* ---------- tree ---------- */
        tree.setRootVisible(false);
        tree.setShowsRootHandles(true);
        tree.setRowHeight(20);
        tree.setBackground(theme.sidebarBg);
        tree.setForeground(theme.sidebarFg);
        tree.setCellRenderer(new Renderer());
        tree.setToggleClickCount(-1);
        ToolTipManager.sharedInstance().registerComponent(tree);
        tree.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popup(e);
                    return;
                }
                if (e.getClickCount() == 1 && e.getButton() == MouseEvent.BUTTON1) {
                    activate(pathAt(e));
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popup(e);
                }
            }
        });
        tree.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    activate(tree.getSelectionPath());
                }
            }
        });
        treeScroll = UI.scroll(tree, theme);
        treeScroll.getViewport().setBackground(theme.sidebarBg);

        empty.setFont(UI.ui(12f));
        empty.setForeground(UI.alpha(theme.sidebarFg, 150));
        empty.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 6));

        add(form, BorderLayout.NORTH);
        add(treeScroll, BorderLayout.CENTER);
        add(empty, BorderLayout.SOUTH);

        wire();
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    private void wire() {
        query.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                scheduleSearch();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                scheduleSearch();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                scheduleSearch();
            }
        });
        query.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    runSearch();
                } else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    close();
                }
            }
        });
        for (JTextField f : new JTextField[]{includes, excludes}) {
            f.addActionListener(e -> runSearch());
        }
        replace.addActionListener(e -> replaceAll());
        caseToggle.addActionListener(e -> runSearch());
        wordToggle.addActionListener(e -> runSearch());
        regexToggle.addActionListener(e -> runSearch());
    }

    private final javax.swing.Timer debounce = new javax.swing.Timer(320, e -> runSearch());

    private void scheduleSearch() {
        debounce.setRepeats(false);
        debounce.restart();
        if (query.getText().isEmpty()) {
            clearResults();
        }
    }

    /** Whether the panel is currently the visible sidebar view. */
    public void focusSearch() {
        query.requestFocusInWindow();
        query.selectAll();
    }

    public void toggleReplace() {
        boolean show = !replaceRow.isVisible();
        replaceRow.setVisible(show);
        detailsBox.setVisible(show);
        revalidate();
        repaint();
        if (show) {
            replace.requestFocusInWindow();
        }
    }

    public void close() {
        if (worker != null) {
            worker.cancel(true);
        }
        clearResults();
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.sidebarBg);
        tree.setBackground(t.sidebarBg);
        tree.setForeground(t.sidebarFg);
        tree.setCellRenderer(new Renderer());
        treeScroll.getViewport().setBackground(t.sidebarBg);
        UI.themeScrollBar(treeScroll, t);
        for (JTextField f : new JTextField[]{query, replace, includes, excludes}) {
            f.setBackground(t.inputBg);
            f.setForeground(t.inputFg);
            f.setCaretColor(t.inputFg);
            f.setBorder(BorderFactory.createCompoundBorder(UI.line(t.inputBorder),
                    BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        }
        status.setForeground(t.sidebarFg);
        empty.setForeground(UI.alpha(t.sidebarFg, 150));
        caseToggle.setTheme(t);
        wordToggle.setTheme(t);
        regexToggle.setTheme(t);
        tree.repaint();
        repaint();
    }

    /**
     * Re-applies every visible string after a language change. Swing reads the placeholder client
     * property once, so it is written again here; the result tree is re-rendered because its cell
     * text is drawn by {@link Renderer}.
     */
    public void retranslate() {
        query.putClientProperty("JTextField.placeholderText", Strings.get("Search"));
        for (Map.Entry<JLabel, String> e : translatedLabels.entrySet()) {
            e.getKey().setText(Strings.get(e.getValue()));
        }
        caseToggle.retranslate();
        wordToggle.retranslate();
        regexToggle.retranslate();
        if (replaceAllButton != null) {
            replaceAllButton.setToolTipText(Strings.get("Replace All"));
        }
        if (toggleDetailsButton != null) {
            toggleDetailsButton.setToolTipText(Strings.get("Toggle Details"));
        }
        tree.setCellRenderer(new Renderer());
        applySummary();
        tree.repaint();
        repaint();
    }

    /* ------------------------------------------------------------------ */

    private JPanel fieldRow(JTextField field, boolean showReplaceButton, boolean showToggles) {
        field.setBackground(theme.inputBg);
        field.setForeground(theme.inputFg);
        field.setCaretColor(theme.inputFg);
        field.setFont(UI.ui(12.5f));
        field.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));

        JPanel row = new JPanel(new BorderLayout(3, 0));
        row.setBackground(theme.sidebarBg);
        row.add(field, BorderLayout.CENTER);

        JPanel right = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 2, 0));
        right.setBackground(theme.sidebarBg);
        if (showToggles) {
            right.add(caseToggle);
            right.add(wordToggle);
            right.add(regexToggle);
        }
        if (showReplaceButton) {
            replaceAllButton = UI.iconButton(Icons.of("replace", 14, theme.sidebarFg),
                    Strings.get("Replace All"), theme, this::replaceAll);
            right.add(replaceAllButton);
            toggleDetailsButton = UI.iconButton(Icons.of("ellipsis", 14, theme.sidebarFg),
                    Strings.get("Toggle Details"), theme, this::toggleReplace);
            right.add(toggleDetailsButton);
        }
        row.add(right, BorderLayout.EAST);
        return row;
    }

    private JPanel labeled(String text, JTextField field) {
        JPanel p = new JPanel(new BorderLayout(0, 2));
        p.setBackground(theme.sidebarBg);
        JLabel l = new JLabel(Strings.get(text));
        translatedLabels.put(l, text);
        l.setFont(UI.ui(11f));
        l.setForeground(UI.alpha(theme.sidebarFg, 190));
        p.add(l, BorderLayout.NORTH);
        field.setBackground(theme.inputBg);
        field.setForeground(theme.inputFg);
        field.setCaretColor(theme.inputFg);
        field.setFont(UI.ui(12f));
        field.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    /** Small square toggle used for the Aa / ab / .* options. */
    private class Toggle extends JToggleButton {
        private Theme t;
        private final String tooltipKey;

        Toggle(String text, String tooltip) {
            super(text);
            this.t = theme;
            this.tooltipKey = tooltip;
            setFont(UI.mono(UI.resolveMono(null), 11.5f));
            setToolTipText(Strings.get(tooltip));
            setFocusPainted(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setOpaque(false);
            setPreferredSize(new Dimension(24, 22));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        void setTheme(Theme t) {
            this.t = t;
            repaint();
        }

        /** Re-applies the tooltip after a language change. */
        void retranslate() {
            setToolTipText(Strings.get(tooltipKey));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (isSelected()) {
                g2.setColor(t.listActive);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 5, 5);
            } else if (getModel().isRollover()) {
                g2.setColor(t.hover);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 5, 5);
            }
            g2.dispose();
            setForeground(isSelected() ? t.listActiveFg : UI.alpha(t.sidebarFg, 200));
            super.paintComponent(g);
        }
    }

    /* ------------------------------------------------------------------ */
    /* searching                                                           */
    /* ------------------------------------------------------------------ */

    private Pattern buildPattern(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        int flags = Pattern.MULTILINE;
        if (!caseToggle.isSelected()) {
            flags |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
        }
        String body = regexToggle.isSelected() ? text : Pattern.quote(text);
        if (wordToggle.isSelected()) {
            body = "\\b" + body + "\\b";
        }
        try {
            return Pattern.compile(body, flags);
        } catch (PatternSyntaxException e) {
            status.setText(Strings.get("Invalid pattern: ") + e.getDescription());
            status.setForeground(theme.error);
            return null;
        }
    }

    /** Runs a search over the whole workspace folder on a background thread. */
    public void runSearch() {
        debounce.stop();
        String text = query.getText();
        if (text == null || text.isEmpty()) {
            clearResults();
            return;
        }
        Pattern pattern = buildPattern(text);
        if (pattern == null) {
            return;
        }
        if (worker != null && !worker.isDone()) {
            worker.cancel(true);
        }
        File rootDir = workspace.getRoot();
        if (rootDir == null) {
            status.setText(Strings.get("Open a folder to search across files"));
            status.setForeground(theme.warning);
            return;
        }
        status.setText(Strings.get("Searching..."));
        status.setForeground(theme.sidebarFg);

        Pattern includePat = compileGlob(includes.getText());
        Pattern excludePat = compileGlob(excludes.getText());
        List<File> candidates = workspace.indexFiles();
        String queryText = text;

        worker = new SwingWorker<>() {
            @Override
            protected List<FileResult> doInBackground() {
                List<FileResult> results = new ArrayList<>();
                int total = 0;
                for (File f : candidates) {
                    if (isCancelled() || total >= MAX_RESULTS) {
                        break;
                    }
                    if (!includeIgnored && !workspace.isProbablyText(f)) {
                        continue;
                    }
                    String rel = workspace.relative(f);
                    if (includePat != null && !includePat.matcher(rel).matches()) {
                        continue;
                    }
                    if (excludePat != null && excludePat.matcher(rel).matches()) {
                        continue;
                    }
                    try {
                        if (f.length() > MAX_FILE_BYTES) {
                            continue;
                        }
                        byte[] bytes = Files.readAllBytes(f.toPath());
                        String content = new String(bytes, StandardCharsets.UTF_8);
                        if (content.indexOf('\0') >= 0) {
                            continue;
                        }
                        FileResult fr = searchFile(f, content, pattern, MAX_RESULTS - total);
                        if (fr != null && !fr.matches.isEmpty()) {
                            results.add(fr);
                            total += fr.matches.size();
                        }
                    } catch (Exception ignored) {
                        // unreadable file: skip
                    }
                }
                return results;
            }

            @Override
            protected void done() {
                if (isCancelled()) {
                    return;
                }
                try {
                    showResults(get(), queryText);
                } catch (Exception e) {
                    status.setText(Strings.get("Search failed: ") + e.getMessage());
                    status.setForeground(theme.error);
                }
            }
        };
        worker.execute();
    }

    private static FileResult searchFile(File file, String content, Pattern pattern, int budget) {
        FileResult fr = new FileResult(file);
        Matcher m = pattern.matcher(content);
        int lineStart = 0;
        int line = 0;
        int guard = 0;
        while (m.find() && fr.matches.size() < budget && guard++ < 100000) {
            int start = m.start();
            while (lineStart <= start) {
                int nl = content.indexOf('\n', lineStart);
                if (nl < 0 || nl >= start) {
                    break;
                }
                lineStart = nl + 1;
                line++;
            }
            int nl = content.indexOf('\n', start);
            int end = nl < 0 ? content.length() : nl;
            String raw = content.substring(lineStart, Math.min(end, lineStart + 400)).strip();
            fr.matches.add(new Match(line, start - lineStart, Math.max(1, m.end() - start), raw));
        }
        return fr;
    }

    private void showResults(List<FileResult> results, String queryText) {
        lastResults = results;
        root.removeAllChildren();
        for (FileResult fr : results) {
            DefaultMutableTreeNode fileNode = new DefaultMutableTreeNode(fr);
            for (Match m : fr.matches) {
                fileNode.add(new DefaultMutableTreeNode(m));
            }
            root.add(fileNode);
        }
        model.reload();
        for (int i = 0; i < tree.getRowCount(); i++) {
            tree.expandRow(i);
        }
        tree.setSelectionRow(-1);
        applySummary();
    }

    /**
     * Re-applies the status line and the empty-state label from {@link #lastResults}. Kept
     * separate so {@link #retranslate} can refresh both without running a new search.
     */
    private void applySummary() {
        String text = query.getText();
        if (text == null || text.isEmpty()) {
            status.setText(" ");
            empty.setText(" ");
            empty.setVisible(false);
            return;
        }
        int total = lastResults.stream().mapToInt(f -> f.matches.size()).sum();
        status.setForeground(theme.sidebarFg);
        if (total == 0) {
            status.setText(Strings.get("No results found"));
            empty.setText(Strings.get("No results found in the workspace"));
            empty.setVisible(true);
        } else {
            String summary = Strings.format("{0} results in {1} files", total, lastResults.size());
            status.setText(total >= MAX_RESULTS
                    ? summary + " " + Strings.get("(limit reached)") : summary);
            empty.setText(" ");
            empty.setVisible(false);
        }
    }

    private void clearResults() {
        lastResults = new ArrayList<>();
        root.removeAllChildren();
        model.reload();
        status.setText(" ");
        empty.setText(" ");
        empty.setVisible(false);
    }

    private TreePath pathAt(MouseEvent e) {
        return tree.getPathForLocation(e.getX(), e.getY());
    }

    private void activate(TreePath path) {
        if (path == null) {
            return;
        }
        Object last = path.getLastPathComponent();
        if (!(last instanceof DefaultMutableTreeNode n)) {
            return;
        }
        Object user = n.getUserObject();
        if (user instanceof Match m && n.getParent() instanceof DefaultMutableTreeNode p
                && p.getUserObject() instanceof FileResult fr) {
            if (actions != null) {
                actions.openAt(fr.file, m.line, m.column, m.length);
            }
        } else if (user instanceof FileResult fr && actions != null) {
            actions.openAt(fr.file, fr.matches.isEmpty() ? 0 : fr.matches.get(0).line,
                    fr.matches.isEmpty() ? 0 : fr.matches.get(0).column, 0);
        }
    }

    /* ------------------------------------------------------------------ */
    /* replacing                                                           */
    /* ------------------------------------------------------------------ */

    public void replaceAll() {
        String text = query.getText();
        if (text == null || text.isEmpty()) {
            return;
        }
        String replacement = replace.getText();
        Pattern pattern = buildPattern(text);
        if (pattern == null) {
            return;
        }
        List<FileResult> targets = lastResults;
        if (targets.isEmpty()) {
            runSearch();
            targets = lastResults;
        }
        final List<FileResult> snapshot = new ArrayList<>(targets);
        if (snapshot.isEmpty()) {
            if (actions != null) {
                actions.notify("Nothing to replace", false);
            }
            return;
        }
        int files = snapshot.size();
        int count = snapshot.stream().mapToInt(f -> f.matches.size()).sum();
        int choice = Dialogs.confirm(this, theme, Strings.get("Replace in Files"),
                Strings.format("Replace {0} occurrences across {1} files?"
                        + "\n\nThis overwrites the files on disk.", count, files),
                Strings.get("Replace"), Strings.get("Cancel"));
        if (choice != 0) {
            return;
        }

        List<File> changed = new ArrayList<>();
        String replacementText = regexToggle.isSelected()
                ? replacement : Matcher.quoteReplacement(replacement);
        int replaced = 0;
        for (FileResult fr : snapshot) {
            try {
                byte[] bytes = Files.readAllBytes(fr.file.toPath());
                String content = new String(bytes, StandardCharsets.UTF_8);
                Matcher m = pattern.matcher(content);
                String updated = m.replaceAll(replacementText);
                if (!updated.equals(content)) {
                    Files.write(fr.file.toPath(), updated.getBytes(StandardCharsets.UTF_8));
                    changed.add(fr.file);
                    replaced += fr.matches.size();
                }
            } catch (Exception e) {
                if (actions != null) {
                    actions.notify(Strings.get("Could not write ") + fr.file.getName()
                            + ": " + e.getMessage(), true);
                }
            }
        }
        if (actions != null) {
            actions.filesChanged(changed);
            actions.notify(Strings.format("Replaced {0} occurrences in {1} files",
                    replaced, changed.size()), false);
        }
        runSearch();
    }

    public void replaceInFile(FileResult fr, String replacement) {
        // used by the per-file context menu action
        String text = query.getText();
        if (text == null || text.isEmpty()) {
            return;
        }
        Pattern pattern = buildPattern(text);
        if (pattern == null) {
            return;
        }
        try {
            byte[] bytes = Files.readAllBytes(fr.file.toPath());
            String content = new String(bytes, StandardCharsets.UTF_8);
            String rep = regexToggle.isSelected() ? replacement : Matcher.quoteReplacement(replacement);
            String updated = pattern.matcher(content).replaceAll(rep);
            if (!updated.equals(content)) {
                Files.write(fr.file.toPath(), updated.getBytes(StandardCharsets.UTF_8));
                if (actions != null) {
                    actions.filesChanged(List.of(fr.file));
                    actions.notify(Strings.get("Replaced in ") + fr.file.getName(), false);
                }
            }
        } catch (Exception e) {
            if (actions != null) {
                actions.notify(Strings.get("Could not write ") + fr.file.getName(), true);
            }
        }
        runSearch();
    }

    private void popup(MouseEvent e) {
        TreePath path = tree.getPathForLocation(e.getX(), e.getY());
        if (path == null) {
            return;
        }
        tree.setSelectionPath(path);
        DefaultMutableTreeNode n = (DefaultMutableTreeNode) path.getLastPathComponent();
        JPopupMenu menu = new JPopupMenu();
        if (n.getUserObject() instanceof FileResult fr) {
            JMenuItem replaceItem = new JMenuItem(Strings.get("Replace All in File"));
            replaceItem.setFont(UI.ui(12f));
            replaceItem.addActionListener(a -> replaceInFile(fr, replace.getText()));
            menu.add(replaceItem);
            JMenuItem copyPath = new JMenuItem(Strings.get("Copy Path"));
            copyPath.setFont(UI.ui(12f));
            copyPath.addActionListener(a -> java.awt.Toolkit.getDefaultToolkit().getSystemClipboard()
                    .setContents(new java.awt.datatransfer.StringSelection(fr.file.getAbsolutePath()), null));
            menu.add(copyPath);
            JMenuItem reveal = new JMenuItem(Strings.get("Reveal in File Explorer"));
            reveal.setFont(UI.ui(12f));
            reveal.addActionListener(a -> {
                if (actions != null) {
                    actions.revealInOS(fr.file);
                }
            });
            menu.add(reveal);
        } else if (n.getUserObject() instanceof Match) {
            JMenuItem open = new JMenuItem(Strings.get("Open Match"));
            open.setFont(UI.ui(12f));
            open.addActionListener(a -> activate(path));
            menu.add(open);
        }
        menu.show(tree, e.getX(), e.getY());
    }

    /* ------------------------------------------------------------------ */

    /** Translates a comma separated list of globs into a matcher regex. */
    static Pattern compileGlob(String spec) {
        if (spec == null || spec.isBlank()) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        String[] parts = spec.split(",");
        for (int i = 0; i < parts.length; i++) {
            String g = parts[i].trim();
            if (g.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append('|');
            }
            sb.append('(').append(globToRegex(g)).append(')');
        }
        if (sb.length() == 0) {
            return null;
        }
        try {
            return Pattern.compile(sb.toString(), Pattern.CASE_INSENSITIVE);
        } catch (PatternSyntaxException e) {
            return null;
        }
    }

    private static String globToRegex(String glob) {
        StringBuilder sb = new StringBuilder("^");
        boolean hasSlash = glob.indexOf('/') >= 0 || glob.indexOf('\\') >= 0;
        if (!hasSlash && !glob.startsWith("*")) {
            sb.append("(?:.*[/\\\\])?");
        }
        for (int i = 0; i < glob.length(); i++) {
            char c = glob.charAt(i);
            switch (c) {
                case '*' -> {
                    if (i + 1 < glob.length() && glob.charAt(i + 1) == '*') {
                        sb.append(".*");
                        i++;
                    } else {
                        sb.append("[^/\\\\]*");
                    }
                }
                case '?' -> sb.append("[^/\\\\]");
                case '.', '(', ')', '+', '|', '^', '$', '@', '%', '{', '}', '[', ']', '\\' -> sb.append('\\').append(c);
                default -> sb.append(c);
            }
        }
        sb.append('$');
        return sb.toString();
    }

    public boolean includeIgnoredFiles() {
        return includeIgnored;
    }

    public void setIncludeIgnored(boolean value) {
        this.includeIgnored = value;
    }

    public void clear() {
        query.setText("");
        replace.setText("");
        clearResults();
    }

    public JTextField queryField() {
        return query;
    }

    /* ------------------------------------------------------------------ */

    private class Renderer extends DefaultTreeCellRenderer {

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded,
                                                      boolean leaf, int row, boolean hasFocus) {
            Object user = value instanceof DefaultMutableTreeNode n ? n.getUserObject() : null;
            JLabel c = (JLabel) super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, false);
            c.setFont(UI.ui(12.5f));
            c.setOpaque(true);
            c.setBorder(BorderFactory.createEmptyBorder(1, 2, 1, 4));
            setToolTipText(null);

            if (user instanceof FileResult fr) {
                String rel = workspace.relative(fr.file);
                c.setText(rel + "  (" + fr.matches.size() + ")");
                c.setIcon(Icons.of("file", 14, fileColor(fr.file)));
                setToolTipText(fr.file.getAbsolutePath());
            } else if (user instanceof Match m) {
                c.setText(m.preview.length() > 90 ? m.preview.substring(0, 90) + "..." : m.preview);
                c.setIcon(null);
                c.setFont(UI.mono(UI.resolveMono(null), 12f));
                setToolTipText(Strings.format("<html><b>Line {0}</b><br>{1}</html>",
                        m.line + 1, UI.esc(m.preview)));
            } else {
                c.setText(String.valueOf(value));
                c.setIcon(null);
            }

            Color bg = theme.sidebarBg;
            Color fg = theme.sidebarFg;
            if (selected) {
                if (tree.isFocusOwner()) {
                    bg = theme.listActive;
                    fg = theme.listActiveFg;
                } else {
                    bg = theme.listSelectionInactive;
                }
            }
            c.setBackground(bg);
            c.setForeground(fg);
            return c;
        }

        private Color fileColor(File f) {
            com.codestudio.core.Language lang = com.codestudio.core.Language.detect(f.getName());
            try {
                return Color.decode(lang == null ? "#888888" : lang.color);
            } catch (Exception e) {
                return theme.gutterFg;
            }
        }
    }

    public void setStatusText(String text) {
        status.setText(text == null || text.isBlank() ? " " : text);
        status.setForeground(theme.sidebarFg);
        repaint();
    }
}
