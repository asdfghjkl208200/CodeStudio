package com.codestudio.ui;

import com.codestudio.core.Theme;

/**
 * A view that can restyle itself when the colour theme changes and re-render its text when the
 * language changes.
 *
 * <p>{@link SideBar} used to walk an {@code instanceof} chain over its six built-in views, which
 * meant a seventh view — a plugin's — could never receive a theme. The container now asks the view
 * instead of testing its type, so any view that implements this is themed, including contributed
 * ones.
 */
public interface ThemeAware {

    /** Re-applies colors. Called on theme change and when the view is first added. */
    void setTheme(Theme theme);

    /**
     * Re-applies text after a language change. The default does nothing, which is right for a view
     * whose text is rebuilt from its model on every update.
     */
    default void retranslate() {
    }
}
