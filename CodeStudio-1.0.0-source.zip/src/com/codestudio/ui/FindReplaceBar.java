package com.codestudio.ui;

import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Highlighter;
import javax.swing.text.JTextComponent;

/** The in-editor find / replace widget (Ctrl+F). */
public class FindReplaceBar extends JPanel {

    private final CodeTextPane editor;
    private Theme theme;

    private final JTextField findField = new JTextField(22);
    private final JTextField replaceField = new JTextField(22);
    private final JLabel status = new JLabel("");
    private final JCheckBox caseBox = new JCheckBox("Aa");
    private final JCheckBox wordBox = new JCheckBox("ab");
    private final JCheckBox regexBox = new JCheckBox(".*");

    /** Buttons kept as fields so {@link #retranslate()} can redo their tooltips and labels. */
    private JButton replaceToggle;
    private JButton prevButton;
    private JButton nextButton;
    private JButton closeButton;
    private JButton replaceButton;
    private JButton replaceAllButton;

    private final JPanel replaceRow = new JPanel(new BorderLayout());
    private final List<Object> matchTags = new ArrayList<>();
    private final List<int[]> matches = new ArrayList<>();
    private int currentMatch = -1;

    private final MatchPainter matchPainter;
    private final MatchPainter currentPainter;

    public FindReplaceBar(CodeTextPane editor, Theme theme) {
        this.editor = editor;
        this.theme = theme;
        this.matchPainter = new MatchPainter(UI.alpha(theme.accent, 60), null);
        this.currentPainter = new MatchPainter(UI.alpha(theme.warning, 120), theme.warning);

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(theme.widgetBg);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, theme.panelBorder),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));

        add(buildFindRow());
        add(replaceRow);
        replaceRow.setOpaque(false);
        replaceRow.add(buildReplaceRow(), BorderLayout.CENTER);
        replaceRow.setVisible(false);

        installFieldKeys(findField);
        installFieldKeys(replaceField);
        findField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                refreshMatches();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                refreshMatches();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                refreshMatches();
            }
        });
        for (JCheckBox box : new JCheckBox[]{caseBox, wordBox, regexBox}) {
            box.setOpaque(false);
            box.setForeground(theme.sidebarFg);
            box.setFont(UI.ui(11f));
            box.addActionListener(e -> refreshMatches());
        }
        caseBox.setToolTipText(Strings.get("Match Case"));
        wordBox.setToolTipText(Strings.get("Match Whole Word"));
        regexBox.setToolTipText(Strings.get("Use Regular Expression"));
        status.setForeground(theme.inputPlaceholder);
        status.setFont(UI.ui(11f));
    }

    private JPanel buildFindRow() {
        JPanel row = new JPanel(new BorderLayout(4, 0));
        row.setOpaque(false);
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        left.setOpaque(false);

        replaceToggle = UI.iconButton(Icons.of("chevron-right", 14, theme.sidebarFg),
                Strings.get("Toggle Replace"), theme, () -> {
                    boolean visible = !replaceRow.isVisible();
                    replaceRow.setVisible(visible);
                    revalidate();
                    repaint();
                });
        replaceToggle.setPreferredSize(new Dimension(20, 24));
        left.add(replaceToggle);
        findField.putClientProperty("JTextField.placeholderText", Strings.get("Find"));
        findField.setBackground(theme.inputBg);
        findField.setForeground(theme.inputFg);
        findField.setCaretColor(theme.inputFg);
        findField.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        findField.setFont(UI.ui(12.5f));
        left.add(findField);
        left.add(caseBox);
        left.add(wordBox);
        left.add(regexBox);
        left.add(status);
        row.add(left, BorderLayout.CENTER);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 2, 0));
        right.setOpaque(false);
        prevButton = UI.iconButton(Icons.of("chevron-up", 14, theme.sidebarFg),
                Strings.get("Previous Match (Shift+Enter)"), theme, () -> findNext(-1));
        nextButton = UI.iconButton(Icons.of("chevron-down", 14, theme.sidebarFg),
                Strings.get("Next Match (Enter)"), theme, () -> findNext(1));
        closeButton = UI.iconButton(Icons.of("close", 14, theme.sidebarFg),
                Strings.get("Close (Esc)"), theme, this::close);
        right.add(prevButton);
        right.add(nextButton);
        right.add(closeButton);
        row.add(right, BorderLayout.EAST);
        return row;
    }

    private JPanel buildReplaceRow() {
        JPanel row = new JPanel(new BorderLayout(4, 0));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        left.setOpaque(false);
        left.add(Box.createHorizontalStrut(20));
        replaceField.putClientProperty("JTextField.placeholderText", Strings.get("Replace"));
        replaceField.setBackground(theme.inputBg);
        replaceField.setForeground(theme.inputFg);
        replaceField.setCaretColor(theme.inputFg);
        replaceField.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        replaceField.setFont(UI.ui(12.5f));
        left.add(replaceField);
        row.add(left, BorderLayout.CENTER);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        right.setOpaque(false);
        replaceButton = UI.smallButton(Strings.get("Replace"), theme, this::replaceCurrent);
        replaceAllButton = UI.smallButton(Strings.get("Replace All"), theme, this::replaceAll);
        right.add(replaceButton);
        right.add(replaceAllButton);
        row.add(right, BorderLayout.EAST);
        return row;
    }

    private void installFieldKeys(JTextField field) {
        field.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "close");
        field.getActionMap().put("close", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                close();
            }
        });
        field.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "next");
        field.getActionMap().put("next", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findNext(1);
            }
        });
        field.getInputMap(JComponent.WHEN_FOCUSED)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, KeyEvent.SHIFT_DOWN_MASK), "prev");
        field.getActionMap().put("prev", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findNext(-1);
            }
        });
        field.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0), "next");
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.widgetBg);
        matchPainter.fill = UI.alpha(t.accent, 60);
        currentPainter.fill = UI.alpha(t.warning, 130);
        currentPainter.border = t.warning;
        applyThemeColors();
        repaint();
    }

    private void applyThemeColors() {
        findField.setBackground(theme.inputBg);
        findField.setForeground(theme.inputFg);
        findField.setCaretColor(theme.inputFg);
        findField.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        replaceField.setBackground(theme.inputBg);
        replaceField.setForeground(theme.inputFg);
        replaceField.setCaretColor(theme.inputFg);
        replaceField.setBorder(BorderFactory.createCompoundBorder(UI.line(theme.inputBorder),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        for (JCheckBox box : new JCheckBox[]{caseBox, wordBox, regexBox}) {
            box.setForeground(theme.sidebarFg);
        }
        status.setForeground(theme.inputPlaceholder);
    }

    /**
     * Re-applies every visible string after a language change. The two field placeholders go
     * through a client property that Swing reads once, so they are written again explicitly here
     * rather than picked up from construction, and the dynamic match counter is recomputed from
     * its {@link Strings#format} template.
     */
    public void retranslate() {
        replaceToggle.setToolTipText(Strings.get("Toggle Replace"));
        prevButton.setToolTipText(Strings.get("Previous Match (Shift+Enter)"));
        nextButton.setToolTipText(Strings.get("Next Match (Enter)"));
        closeButton.setToolTipText(Strings.get("Close (Esc)"));
        caseBox.setToolTipText(Strings.get("Match Case"));
        wordBox.setToolTipText(Strings.get("Match Whole Word"));
        regexBox.setToolTipText(Strings.get("Use Regular Expression"));
        replaceButton.setText(Strings.get("Replace"));
        replaceAllButton.setText(Strings.get("Replace All"));
        findField.putClientProperty("JTextField.placeholderText", Strings.get("Find"));
        replaceField.putClientProperty("JTextField.placeholderText", Strings.get("Replace"));
        if (isVisible()) {
            refreshMatches();
        }
    }

    /* ------------------------------------------------------------------ */

    public void open(boolean withReplace) {
        replaceRow.setVisible(withReplace);
        String selected = editor.getSelectedText();
        if (selected != null && !selected.contains("\n") && selected.length() < 200) {
            findField.setText(selected);
        }
        refreshMatches();
        revalidate();
        repaint();
        javax.swing.SwingUtilities.invokeLater(() -> {
            findField.requestFocusInWindow();
            findField.selectAll();
        });
    }

    public void close() {
        clearHighlights();
        editor.requestFocusInWindow();
        // hiding is the host's job
        java.awt.Container parent = getParent();
        if (parent != null) {
            setVisible(false);
            parent.revalidate();
            parent.repaint();
        }
    }

    public boolean isReplaceVisible() {
        return replaceRow.isVisible();
    }

    /* ---------------- searching ---------------- */

    private static final int MAX_MATCHES = 2000;

    private Pattern buildPattern() {
        String q = findField.getText();
        if (q.isEmpty()) {
            return null;
        }
        int flags = 0;
        if (!caseBox.isSelected()) {
            flags |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
        }
        try {
            String expr = regexBox.isSelected() ? q : Pattern.quote(q);
            return Pattern.compile(expr, flags);
        } catch (PatternSyntaxException e) {
            return null;
        }
    }

    private void refreshMatches() {
        clearHighlights();
        matches.clear();
        currentMatch = -1;
        Pattern p = buildPattern();
        if (p == null) {
            status.setText(findField.getText().isEmpty() ? "" : Strings.get("Bad regex"));
            return;
        }
        String text = editor.text();
        Matcher m = p.matcher(text);
        while (m.find() && matches.size() < MAX_MATCHES) {
            int len = m.end() - m.start();
            if (len == 0) {
                break;
            }
            if (wordBox.isSelected() && !isWholeWord(text, m.start(), m.end())) {
                continue;
            }
            matches.add(new int[]{m.start(), len});
        }
        for (int[] match : matches) {
            try {
                matchTags.add(editor.getHighlighter().addHighlight(match[0], match[0] + match[1], matchPainter));
            } catch (BadLocationException ignored) {
            }
        }
        status.setText(matches.isEmpty() ? Strings.get("No results")
                : Strings.format("of {0}", matches.size()));
        if (!matches.isEmpty()) {
            selectNearest(editor.getCaretPosition());
        }
    }

    private static boolean isWholeWord(String text, int start, int end) {
        boolean left = start == 0 || !Character.isLetterOrDigit(text.charAt(start - 1));
        boolean right = end >= text.length() || !Character.isLetterOrDigit(text.charAt(end));
        return left && right;
    }

    private void clearHighlights() {
        for (Object tag : matchTags) {
            editor.getHighlighter().removeHighlight(tag);
        }
        matchTags.clear();
    }

    private void selectNearest(int caret) {
        int best = 0;
        for (int i = 0; i < matches.size(); i++) {
            if (matches.get(i)[0] >= caret) {
                best = i;
                break;
            }
        }
        highlightCurrent(best, false);
    }

    private void highlightCurrent(int index, boolean moveCaret) {
        if (matches.isEmpty()) {
            return;
        }
        if (currentMatch >= 0 && currentMatch < matches.size()) {
            try {
                editor.getHighlighter().removeHighlight(currentTag);
            } catch (Exception ignored) {
            }
        }
        currentMatch = ((index % matches.size()) + matches.size()) % matches.size();
        int[] match = matches.get(currentMatch);
        try {
            currentTag = editor.getHighlighter().addHighlight(match[0], match[0] + match[1], currentPainter);
        } catch (BadLocationException ignored) {
        }
        status.setText(Strings.format("{0} of {1}", currentMatch + 1, matches.size()));
        if (moveCaret) {
            editor.select(match[0], match[0] + match[1]);
            editor.scrollTo(match[0]);
        }
    }

    private Object currentTag;

    private void findNext(int direction) {
        if (matches.isEmpty()) {
            refreshMatches();
            if (matches.isEmpty()) {
                return;
            }
        }
        highlightCurrent(currentMatch + direction, true);
        editor.requestFocusInWindow();
    }

    private void replaceCurrent() {
        if (currentMatch < 0 || currentMatch >= matches.size()) {
            findNext(1);
            return;
        }
        int[] match = matches.get(currentMatch);
        String replacement = replaceField.getText();
        try {
            editor.bundle().beginCompound();
            editor.getDocument().remove(match[0], match[1]);
            editor.getDocument().insertString(match[0], replacement, null);
            editor.bundle().endCompound();
        } catch (BadLocationException ignored) {
        }
        refreshMatches();
        if (!matches.isEmpty()) {
            highlightCurrent(Math.min(currentMatch, matches.size() - 1), true);
        }
    }

    private void replaceAll() {
        Pattern p = buildPattern();
        if (p == null) {
            return;
        }
        String text = editor.text();
        Matcher m = p.matcher(text);
        StringBuilder sb = new StringBuilder();
        int count = 0;
        while (m.find()) {
            if (wordBox.isSelected() && !isWholeWord(text, m.start(), m.end())) {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group()));
                continue;
            }
            count++;
            String rep = regexBox.isSelected() ? replaceField.getText()
                    : Matcher.quoteReplacement(replaceField.getText());
            m.appendReplacement(sb, rep);
        }
        m.appendTail(sb);
        if (count == 0) {
            return;
        }
        editor.bundle().replaceAll(sb.toString());
        refreshMatches();
        status.setText(Strings.format("{0} replaced", count));
        editor.requestFocusInWindow();
    }

    /* ------------------------------------------------------------------ */

    private static class MatchPainter implements Highlighter.HighlightPainter {
        Color fill;
        Color border;

        MatchPainter(Color fill, Color border) {
            this.fill = fill;
            this.border = border;
        }

        @Override
        public void paint(Graphics g, int p0, int p1, Shape bounds, JTextComponent c) {
            Rectangle a = CodeTextPane.rectOf(c, p0);
            Rectangle b = CodeTextPane.rectOf(c, Math.max(p0, p1 - 1));
            if (a == null) {
                return;
            }
            int w = (b == null ? a.width : b.x + b.width - a.x);
            if (fill != null) {
                g.setColor(fill);
                g.fillRect(a.x, a.y, Math.max(2, w), a.height);
            }
            if (border != null) {
                g.setColor(border);
                g.drawRect(a.x, a.y, Math.max(2, w) - 1, a.height - 1);
            }
        }
    }
}
