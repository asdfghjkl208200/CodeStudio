package com.codestudio.ui;

import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/** A stack of terminals with its own tab strip, like the VS Code terminal view. */
public class TerminalPanel extends JPanel {

    public interface Actions {
        void notify(String message, boolean error);
    }

    private final Settings settings;
    private Theme theme;
    private Actions actions;

    private final CardLayout cards = new CardLayout();
    private final JPanel host = new JPanel(cards);
    private final JPanel tabStrip = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
    private final List<TerminalView> terminals = new ArrayList<>();
    private final Map<TerminalView, Tab> tabs = new LinkedHashMap<>();
    /** Action buttons paired with their untranslated tooltip, so {@link #retranslate} can redo them. */
    private final Map<javax.swing.JButton, String> actionTooltips = new LinkedHashMap<>();
    private final JLabel hint = new JLabel(" ");
    private File workingDirectory;

    public TerminalPanel(Settings settings, Theme theme, File workingDirectory) {
        super(new BorderLayout());
        this.settings = settings;
        this.theme = theme;
        this.workingDirectory = workingDirectory;

        setBackground(theme.panelBg);
        host.setBackground(theme.panelBg);
        tabStrip.setBackground(theme.panelBg);
        tabStrip.setBorder(BorderFactory.createEmptyBorder(2, 4, 0, 4));

        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(theme.panelBg);
        bar.add(tabStrip, BorderLayout.WEST);

        JPanel right = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 2, 0));
        right.setBackground(theme.panelBg);
        right.add(actionButton("plus", "New Terminal", this::newTerminal));
        right.add(actionButton("trash", "Kill Terminal", this::killCurrent));
        right.add(actionButton("close", "Clear", this::clearCurrent));
        bar.add(right, BorderLayout.EAST);

        add(bar, BorderLayout.NORTH);
        add(host, BorderLayout.CENTER);
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    /** Toolbar button that remembers its untranslated tooltip. */
    private javax.swing.JButton actionButton(String icon, String tooltip, Runnable action) {
        javax.swing.JButton b = UI.iconButton(Icons.of(icon, 14, theme.panelFg), Strings.get(tooltip), theme, action);
        actionTooltips.put(b, tooltip);
        return b;
    }

    /** Re-applies the toolbar and tab tooltips after a language change. */
    public void retranslate() {
        for (Map.Entry<javax.swing.JButton, String> e : actionTooltips.entrySet()) {
            e.getKey().setToolTipText(Strings.get(e.getValue()));
        }
        for (Tab tab : tabs.values()) {
            tab.refresh();
        }
        repaint();
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.panelBg);
        host.setBackground(t.panelBg);
        tabStrip.setBackground(t.panelBg);
        for (TerminalView v : terminals) {
            v.setTheme(t);
        }
        for (Tab tab : tabs.values()) {
            tab.refresh();
        }
        repaint();
    }

    /** Creates a terminal in the given directory (or the workspace root). */
    public TerminalView newTerminal() {
        return newTerminal(workingDirectory);
    }

    public TerminalView newTerminal(File directory) {
        if (directory == null) {
            directory = workingDirectory;
        }
        TerminalView view = new TerminalView(settings, theme, directory);
        view.setOnExit(() -> javax.swing.SwingUtilities.invokeLater(() -> {
            Tab tab = tabs.get(view);
            if (tab != null) {
                tab.refresh();
            }
        }));
        terminals.add(view);
        host.add(view, view.title());
        Tab tab = new Tab(view);
        tabs.put(view, tab);
        tabStrip.add(tab);
        select(view);
        revalidate();
        repaint();
        return view;
    }

    public void select(TerminalView view) {
        if (!terminals.contains(view)) {
            return;
        }
        cards.show(host, view.title());
        for (Map.Entry<TerminalView, Tab> e : tabs.entrySet()) {
            e.getValue().setSelected(e.getKey() == view);
        }
        view.focusInput();
    }

    public TerminalView current() {
        for (Map.Entry<TerminalView, Tab> e : tabs.entrySet()) {
            if (e.getValue().selected) {
                return e.getKey();
            }
        }
        return terminals.isEmpty() ? null : terminals.get(terminals.size() - 1);
    }

    /** Ensures at least one terminal exists and focuses it. */
    public TerminalView ensureTerminal(File directory) {
        if (terminals.isEmpty()) {
            return newTerminal(directory);
        }
        TerminalView v = current();
        if (v != null) {
            select(v);
        }
        return v;
    }

    public void closeTerminal(TerminalView view) {
        if (!terminals.contains(view)) {
            return;
        }
        view.kill();
        int index = terminals.indexOf(view);
        terminals.remove(view);
        host.remove(view);
        Tab tab = tabs.remove(view);
        if (tab != null) {
            tabStrip.remove(tab);
        }
        if (terminals.isEmpty()) {
            newTerminal();
            return;
        }
        select(terminals.get(Math.min(index, terminals.size() - 1)));
        revalidate();
        repaint();
    }

    public void killCurrent() {
        TerminalView v = current();
        if (v != null) {
            closeTerminal(v);
        }
    }

    public void clearCurrent() {
        TerminalView v = current();
        if (v != null) {
            v.clear();
        }
    }

    public void disposeAll() {
        for (TerminalView v : new ArrayList<>(terminals)) {
            v.kill();
        }
    }

    public void setWorkingDirectory(File dir) {
        this.workingDirectory = dir;
    }

    /** A terminal tab in the strip. */
    private class Tab extends JPanel {
        private final TerminalView view;
        private final JLabel label = new JLabel();
        private boolean selected;
        private boolean hovering;

        Tab(TerminalView view) {
            super(new BorderLayout(4, 0));
            this.view = view;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            label.setText(view.title());
            label.setFont(UI.ui(11.5f));
            label.setHorizontalAlignment(SwingConstants.CENTER);
            add(label, BorderLayout.CENTER);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (e.getButton() == MouseEvent.BUTTON1) {
                        select(view);
                    } else if (e.getButton() == MouseEvent.BUTTON2) {
                        closeTerminal(view);
                    }
                }
            });
        }

        void setSelected(boolean value) {
            this.selected = value;
            refresh();
        }

        void refresh() {
            if (selected) {
                label.setForeground(theme.panelFg);
                setToolTipText(Strings.get("Active terminal"));
            } else {
                label.setForeground(UI.alpha(theme.panelFg, 160));
                setToolTipText(Strings.get("Click to focus this terminal"));
            }
            repaint();
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            d.width = Math.max(78, d.width);
            return d;
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (selected) {
                    g.setColor(theme.editorBg);
                    g.fillRoundRect(0, 0, getWidth(), getHeight(), 4, 4);
                } else if (hovering) {
                    g.setColor(theme.hover);
                    g.fillRoundRect(0, 0, getWidth(), getHeight(), 4, 4);
                }
                if (selected) {
                    g.setColor(theme.accent);
                    g.fillRect(2, getHeight() - 2, getWidth() - 4, 2);
                }
            } finally {
                g.dispose();
            }
            super.paintComponent(g0);
        }
    }
}
