package com.codestudio.ui;

import com.codestudio.core.Breakpoints;
import com.codestudio.core.Runner;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

/** The Run and Debug view: launch configurations, breakpoints and the toolchain. */
public class RunPanel extends JPanel implements ThemeAware {

    public interface Actions {
        void runActiveFile(boolean debug);

        void runFile(File file, boolean debug);

        void stopRun();

        void openAt(File file, int line);

        void notify(String message, boolean error);
    }

    private final Settings settings;
    private final Runner runner;
    private Theme theme;
    private Actions actions;

    private final JPanel body = new JPanel();
    private final JScrollPane scroll;
    private final JLabel stopLabel = new JLabel(" ");
    private final SectionHeader header;
    private final SectionHeader breakpointHeader;
    private final SectionHeader configHeader;
    private final JPanel breakpointList = new JPanel();
    private final JPanel configList = new JPanel();
    private JButton debugButton;
    private JButton runButton;
    /** Last state passed to {@link #setRunState}, so {@link #retranslate} can redo the label. */
    private boolean running;
    private String runningWhat = "";

    public RunPanel(Settings settings, Runner runner, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.runner = runner;
        this.theme = theme;
        setBackground(theme.sidebarBg);

        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(theme.sidebarBg);

        header = new SectionHeader("Run and Debug", theme);
        header.addAction("refresh", "Refresh Configurations", this::rebuild);
        header.addAction("stop", "Stop", () -> {
            if (actions != null) {
                actions.stopRun();
            }
        });

        JPanel buttons = new JPanel(new BorderLayout(4, 4));
        buttons.setBackground(theme.sidebarBg);
        buttons.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        debugButton = UI.primaryButton(Strings.get("Run and Debug"), theme, () -> {
            if (actions != null) {
                actions.runActiveFile(true);
            }
        });
        buttons.add(debugButton, BorderLayout.NORTH);
        runButton = UI.smallButton(Strings.get("Run Without Debugging"), theme, () -> {
            if (actions != null) {
                actions.runActiveFile(false);
            }
        });
        buttons.add(runButton, BorderLayout.SOUTH);
        buttons.setMaximumSize(new Dimension(Integer.MAX_VALUE, 76));
        buttons.setAlignmentX(LEFT_ALIGNMENT);

        stopLabel.setFont(UI.ui(11.5f));
        stopLabel.setForeground(UI.alpha(theme.sidebarFg, 170));
        stopLabel.setBorder(BorderFactory.createEmptyBorder(2, 12, 8, 10));
        stopLabel.setAlignmentX(LEFT_ALIGNMENT);

        configHeader = new SectionHeader("Launch Configurations", theme);
        configList.setLayout(new BoxLayout(configList, BoxLayout.Y_AXIS));
        configList.setBackground(theme.sidebarBg);
        configHeader.addToggleListener(() -> {
            configList.setVisible(configHeader.isExpanded());
            revalidate();
        });

        breakpointHeader = new SectionHeader("Breakpoints", theme);
        breakpointHeader.addAction("trash", "Remove All", Breakpoints::clear);
        breakpointList.setLayout(new BoxLayout(breakpointList, BoxLayout.Y_AXIS));
        breakpointList.setBackground(theme.sidebarBg);
        breakpointHeader.addToggleListener(() -> {
            breakpointList.setVisible(breakpointHeader.isExpanded());
            revalidate();
        });

        body.add(header);
        body.add(buttons);
        body.add(stopLabel);
        body.add(configHeader);
        body.add(configList);
        body.add(Box.createVerticalStrut(4));
        body.add(breakpointHeader);
        body.add(breakpointList);
        body.add(Box.createVerticalGlue());

        scroll = UI.scroll(body, theme);
        scroll.getViewport().setBackground(theme.sidebarBg);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);

        Breakpoints.addListener(() -> SwingUtilities.invokeLater(this::refreshBreakpoints));
        rebuild();
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.sidebarBg);
        body.setBackground(t.sidebarBg);
        configList.setBackground(t.sidebarBg);
        breakpointList.setBackground(t.sidebarBg);
        scroll.getViewport().setBackground(t.sidebarBg);
        UI.themeScrollBar(scroll, t);
        stopLabel.setForeground(UI.alpha(t.sidebarFg, 170));
        rebuild();
    }

    /** Recomputes the launch configurations and the breakpoint list. */
    public final void rebuild() {
        configList.removeAll();
        List<Runner.Config> configs = new ArrayList<>();
        try {
            configs = runner.discover();
        } catch (Exception ignored) {
            // an unreadable workspace must not break the view
        }
        if (configs.isEmpty()) {
            JLabel none = new JLabel(Strings.get("No runnable files found in this folder."));
            none.setFont(UI.ui(12f));
            none.setForeground(UI.alpha(theme.sidebarFg, 150));
            none.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 8));
            none.setAlignmentX(LEFT_ALIGNMENT);
            configList.add(none);
        } else {
            for (Runner.Config c : configs) {
                configList.add(new ConfigRow(c));
            }
        }
        configHeader.setTitleText(Strings.format("Launch Configurations: {0}", configs.size()));

        refreshBreakpoints();
        revalidate();
        repaint();
    }

    private void refreshBreakpoints() {
        breakpointList.removeAll();
        List<Breakpoints.Point> points = Breakpoints.all();
        if (points.isEmpty()) {
            JLabel none = new JLabel(Strings.get("No breakpoints. Click the left gutter of a file to add one."));
            none.setFont(UI.ui(12f));
            none.setForeground(UI.alpha(theme.sidebarFg, 150));
            none.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 8));
            none.setAlignmentX(LEFT_ALIGNMENT);
            breakpointList.add(none);
        } else {
            for (Breakpoints.Point p : points) {
                breakpointList.add(new BreakpointRow(p));
            }
        }
        breakpointHeader.setTitleText(Strings.format("Breakpoints: {0}", points.size()));
        breakpointList.revalidate();
        breakpointList.repaint();
    }

    /** Shows what the run button is currently doing. */
    public void setRunState(boolean running, String what) {
        this.running = running;
        this.runningWhat = what == null ? "" : what;
        stopLabel.setText(running ? Strings.format("Running {0}...", runningWhat) : " ");
        stopLabel.setForeground(running ? theme.accent : UI.alpha(theme.sidebarFg, 170));
    }

    /** Toolchain summary appended to the view. */
    public void showToolchainText() {
        StringBuilder sb = new StringBuilder();
        for (String[] tool : Runner.toolchain()) {
            sb.append(tool[0]).append(": ").append(tool[1]).append('\n');
        }
        String text = sb.length() == 0
                ? Strings.get("No language toolchains were found on PATH.") : sb.toString();
        Dialogs.textDialog(this, theme, Strings.get("Detected Toolchain"), text, 620, 340);
    }

    /**
     * Re-applies every visible string after a language change: the section headers redo their own
     * titles and action tooltips, and rebuilding the two lists refreshes the empty-state labels,
     * the per-row tooltips and the header counts.
     */
    public void retranslate() {
        header.retranslate();
        configHeader.retranslate();
        breakpointHeader.retranslate();
        if (debugButton != null) {
            debugButton.setText(Strings.get("Run and Debug"));
        }
        if (runButton != null) {
            runButton.setText(Strings.get("Run Without Debugging"));
        }
        setRunState(running, runningWhat);
        rebuild();
    }

    /* ------------------------------------------------------------------ */

    private class ConfigRow extends JPanel {
        private boolean hovering;

        ConfigRow(Runner.Config config) {
            super(new BorderLayout(6, 0));
            setBackground(theme.sidebarBg);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(3, 12, 3, 8));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
            setAlignmentX(LEFT_ALIGNMENT);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            JLabel label = new JLabel(config.name);
            label.setFont(UI.ui(12.5f));
            label.setForeground(theme.sidebarFg);
            label.setIcon(Icons.of("run", 14, theme.dark ? new Color(0x73C991) : new Color(0x16825D)));
            add(label, BorderLayout.CENTER);

            JLabel kind = new JLabel(config.kind);
            kind.setFont(UI.ui(10.5f));
            kind.setForeground(UI.alpha(theme.sidebarFg, 140));
            add(kind, BorderLayout.EAST);

            setToolTipText(config.file.getAbsolutePath());
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (actions == null) {
                        return;
                    }
                    if (e.getClickCount() >= 2 || e.isControlDown()) {
                        actions.runFile(config.file, false);
                    } else {
                        actions.openAt(config.file, 0);
                    }
                }
            });
        }

        @Override
        protected void paintComponent(java.awt.Graphics g0) {
            java.awt.Graphics2D g = (java.awt.Graphics2D) g0.create();
            g.setColor(hovering ? theme.hover : theme.sidebarBg);
            g.fillRect(0, 0, getWidth(), getHeight());
            g.dispose();
            super.paintComponent(g0);
        }
    }

    private class BreakpointRow extends JPanel {
        private boolean hovering;

        BreakpointRow(Breakpoints.Point point) {
            super(new BorderLayout(6, 0));
            setBackground(theme.sidebarBg);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(2, 10, 2, 6));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
            setAlignmentX(LEFT_ALIGNMENT);

            JCheckBox box = new JCheckBox();
            box.setSelected(point.enabled);
            box.setBackground(theme.sidebarBg);
            box.setFocusPainted(false);
            box.setToolTipText(Strings.get("Enable or disable this breakpoint"));
            box.addActionListener(e -> Breakpoints.setEnabled(point, box.isSelected()));
            add(box, BorderLayout.WEST);

            String name = point.file == null ? "?" : point.file.getName();
            JLabel label = new JLabel(name + "  :  " + (point.line + 1));
            label.setFont(UI.ui(12.5f));
            label.setForeground(theme.sidebarFg);
            label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            label.setToolTipText(point.file == null ? "" : point.file.getAbsolutePath());
            add(label, BorderLayout.CENTER);

            JLabel remove = new JLabel();
            remove.setIcon(Icons.of("close", 12, theme.sidebarFg));
            remove.setPreferredSize(new Dimension(16, 14));
            remove.setToolTipText(Strings.get("Remove breakpoint"));
            remove.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    Breakpoints.remove(point);
                }
            });
            add(remove, BorderLayout.EAST);

            MouseAdapter open = new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    if (e.getSource() != remove && actions != null && point.file != null) {
                        actions.openAt(point.file, point.line);
                    }
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }
            };
            addMouseListener(open);
            label.addMouseListener(open);
        }

        @Override
        protected void paintComponent(java.awt.Graphics g0) {
            java.awt.Graphics2D g = (java.awt.Graphics2D) g0.create();
            g.setColor(hovering ? theme.hover : theme.sidebarBg);
            g.fillRect(0, 0, getWidth(), getHeight());
            g.dispose();
            super.paintComponent(g0);
        }
    }

    /** Component used by the sidebar to scroll a view to the top after a switch. */
    public void scrollToTop() {
        scroll.getVerticalScrollBar().setValue(0);
    }

    public Component content() {
        return body;
    }
}
