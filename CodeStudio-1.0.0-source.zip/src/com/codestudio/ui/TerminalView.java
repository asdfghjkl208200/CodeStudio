package com.codestudio.ui;

import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/** A line oriented shell that talks to {@code cmd.exe} / {@code bash} through pipes. */
public class TerminalView extends JPanel {

    private static final java.util.regex.Pattern ANSI =
            java.util.regex.Pattern.compile("\u001B\\[[;?\\d]*[ -/]*[@-~]");

    private final Settings settings;
    private Theme theme;

    private final JTextPane output = new JTextPane();
    private final JTextField input = new JTextField();
    private final JLabel prompt = new JLabel();
    private final JScrollPane scroll;

    private Process process;
    private BufferedWriter stdin;
    private Thread reader;
    private final List<String> history = new ArrayList<>();
    private int historyIndex = -1;
    private File cwd;
    private boolean alive;
    private Runnable onExit;
    private final String title;

    private static int counter = 1;

    public TerminalView(Settings settings, Theme theme, File workingDirectory) {
        super(new BorderLayout());
        this.settings = settings;
        this.theme = theme;
        this.cwd = workingDirectory;
        this.title = "Terminal " + counter++;

        output.setEditable(false);
        output.setFont(UI.mono(settings.get("editor.fontFamily"), settings.getInt("terminal.fontSize")));
        output.setBackground(theme.panelBg);
        output.setForeground(theme.panelFg);
        output.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));

        scroll = UI.scroll(output, theme);
        scroll.getViewport().setBackground(theme.panelBg);
        scroll.setBorder(null);

        prompt.setFont(UI.mono(settings.get("editor.fontFamily"), settings.getInt("terminal.fontSize")));
        prompt.setForeground(theme.dark ? new Color(0x4EC9B0) : new Color(0x267F99));
        prompt.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 4));

        input.setFont(UI.mono(settings.get("editor.fontFamily"), settings.getInt("terminal.fontSize")));
        input.setBackground(theme.panelBg);
        input.setForeground(theme.panelFg);
        input.setCaretColor(theme.editorFg);
        input.setBorder(BorderFactory.createEmptyBorder(2, 0, 4, 8));
        input.addActionListener(e -> submit());
        input.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    historyStep(-1);
                    e.consume();
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    historyStep(1);
                    e.consume();
                } else if (e.getKeyCode() == KeyEvent.VK_C && e.isControlDown()) {
                    input.setText("");
                    e.consume();
                }
            }
        });

        JPanel inputRow = new JPanel(new BorderLayout());
        inputRow.setBackground(theme.panelBg);
        inputRow.add(prompt, BorderLayout.WEST);
        inputRow.add(input, BorderLayout.CENTER);

        add(scroll, BorderLayout.CENTER);
        add(inputRow, BorderLayout.SOUTH);

        start();
    }

    public String title() {
        return title;
    }

    public void setOnExit(Runnable r) {
        this.onExit = r;
    }

    /** Launches the shell process. */
    public final void start() {
        String configured = settings.get("terminal.shell");
        List<String> cmd = new ArrayList<>();
        if (configured != null && !configured.isBlank()) {
            for (String part : configured.trim().split("\\s+")) {
                cmd.add(part);
            }
        } else if (com.codestudio.core.Runner.isWindows()) {
            cmd.add(System.getenv("COMSPEC") == null ? "cmd.exe" : System.getenv("COMSPEC"));
            cmd.add("/Q");
            cmd.add("/K");
            cmd.add("chcp 65001 >nul");
        } else {
            String shell = System.getenv("SHELL");
            cmd.add(shell == null || shell.isBlank() ? "bash" : shell);
            cmd.add("-i");
        }

        ProcessBuilder pb = new ProcessBuilder(cmd);
        if (cwd != null && cwd.isDirectory()) {
            pb.directory(cwd);
        }
        pb.redirectErrorStream(true);
        pb.environment().put("PYTHONIOENCODING", "utf-8");
        pb.environment().put("LANG", "en_US.UTF-8");

        try {
            process = pb.start();
        } catch (IOException e) {
            append(Strings.format("Could not start {0}: {1}", String.join(" ", cmd), e.getMessage()) + "\n", true);
            append(Strings.get("Set the \"terminal.shell\" setting to a valid shell command.") + "\n", true);
            alive = false;
            input.setEnabled(false);
            return;
        }
        Charset cs = StandardCharsets.UTF_8;
        stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), cs));
        alive = true;
        updatePrompt();

        reader = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(process.getInputStream(), cs))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String text = ANSI.matcher(line).replaceAll("");
                    if (text.contains("chcp 65001")) {
                        continue;
                    }
                    post(text + "\n", false);
                }
            } catch (IOException ignored) {
                // the process ended
            } finally {
                post("\n" + Strings.get("[process exited]") + "\n", false);
                SwingUtilities.invokeLater(() -> {
                    alive = false;
                    input.setEnabled(false);
                    if (onExit != null) {
                        onExit.run();
                    }
                });
            }
        }, "terminal-reader");
        reader.setDaemon(true);
        reader.start();
    }

    private void updatePrompt() {
        String path = cwd == null ? "~" : cwd.getAbsolutePath();
        if (cwd != null && cwd.getName() != null && !cwd.getName().isEmpty()) {
            path = cwd.getName();
        }
        prompt.setText(path + " >");
    }

    /** Sends the typed line to the shell. */
    private void submit() {
        String text = input.getText();
        input.setText("");
        if (text == null) {
            return;
        }
        if (!text.isBlank()) {
            history.remove(text);
            history.add(text);
            if (history.size() > 200) {
                history.remove(0);
            }
            historyIndex = -1;
        }
        append(shortPrompt() + " " + text + "\n", false);

        String trimmed = text.trim();
        if (trimmed.equals("clear") || trimmed.equals("cls")) {
            clear();
            trackCd(trimmed);
            return;
        }
        trackCd(trimmed);
        if (!alive) {
            append(Strings.get("The terminal process has exited. Press Restart to open a new one.") + "\n", true);
            return;
        }
        try {
            stdin.write(text);
            stdin.newLine();
            stdin.flush();
        } catch (IOException e) {
            append(Strings.format("Could not write to the shell: {0}", e.getMessage()) + "\n", true);
        }
    }

    /** Tracks "cd" so the prompt label keeps up with the shell. */
    private void trackCd(String command) {
        if (!command.startsWith("cd")) {
            return;
        }
        String rest = command.substring(2).trim();
        if (rest.isEmpty()) {
            File home = new File(System.getProperty("user.home"));
            cwd = home;
            updatePrompt();
            return;
        }
        rest = rest.replace("\"", "");
        File next = new File(rest).isAbsolute() ? new File(rest) : new File(cwd == null ? new File(".") : cwd, rest);
        try {
            next = next.getCanonicalFile();
        } catch (IOException ignored) {
            // keep the unresolved path
        }
        if (next.isDirectory()) {
            cwd = next;
            updatePrompt();
        }
    }

    private String shortPrompt() {
        return cwd == null ? "~" : cwd.getName();
    }

    private void historyStep(int direction) {
        if (history.isEmpty()) {
            return;
        }
        if (historyIndex == -1) {
            historyIndex = history.size();
        }
        historyIndex = Math.max(0, Math.min(history.size() - 1, historyIndex + direction));
        input.setText(history.get(historyIndex));
        input.selectAll();
    }

    /* ------------------------------------------------------------------ */

    private void post(String text, boolean stderr) {
        SwingUtilities.invokeLater(() -> append(text, stderr));
    }

    private void append(String text, boolean stderr) {
        StyledDocument doc = output.getStyledDocument();
        SimpleAttributeSet attrs = new SimpleAttributeSet();
        StyleConstants.setForeground(attrs, stderr ? theme.error : theme.panelFg);
        StyleConstants.setFontFamily(attrs, settings.get("editor.fontFamily"));
        StyleConstants.setFontSize(attrs, settings.getInt("terminal.fontSize"));
        try {
            doc.insertString(doc.getLength(), text, attrs);
        } catch (BadLocationException ignored) {
            // nothing sensible to do here
        }
        if (doc.getLength() > 400_000) {
            try {
                doc.remove(0, doc.getLength() - 200_000);
            } catch (BadLocationException ignored) {
                // ignore
            }
        }
        scrollToEnd();
    }

    private void scrollToEnd() {
        JScrollBar bar = scroll.getVerticalScrollBar();
        SwingUtilities.invokeLater(() -> bar.setValue(bar.getMaximum()));
    }

    public void clear() {
        output.setText("");
    }

    public void restart() {
        kill();
        output.setText("");
        input.setEnabled(true);
        start();
        input.requestFocusInWindow();
    }

    /** Terminates the shell process. */
    public void kill() {
        alive = false;
        Process p = process;
        if (p != null) {
            try {
                p.descendants().forEach(ProcessHandle::destroyForcibly);
            } catch (Exception ignored) {
                // best effort
            }
            p.destroyForcibly();
        }
    }

    public boolean isAlive() {
        return alive && process != null && process.isAlive();
    }

    public void focusInput() {
        input.requestFocusInWindow();
    }

    /** Runs a command as if the user typed it. */
    public void runCommand(String command) {
        input.setText(command);
        submit();
    }

    public void setTheme(Theme t) {
        this.theme = t;
        output.setBackground(t.panelBg);
        output.setForeground(t.panelFg);
        prompt.setForeground(t.dark ? new Color(0x4EC9B0) : new Color(0x267F99));
        input.setBackground(t.panelBg);
        input.setForeground(t.panelFg);
        input.setCaretColor(t.editorFg);
        scroll.getViewport().setBackground(t.panelBg);
        UI.themeScrollBar(scroll, t);
        repaint();
    }

    public Dimension preferredSizeHint() {
        return new Dimension(600, 200);
    }
}
