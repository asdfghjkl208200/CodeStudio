package com.codestudio.ui;

import com.codestudio.core.Language;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** The status bar along the bottom edge of the window. */
public class StatusBar extends JPanel {

    public interface Actions {
        void showProblems();

        void showLanguagePicker();

        void showEncodingPicker();

        void showEolPicker();

        void showIndentPicker();

        void showBranchPicker();

        void toggleTheme();

        void showNotifications();

        void showTerminal();

        void showAccounts();
    }

    private final Theme theme;
    private Actions actions;

    private final JPanel left = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
    private final JPanel right = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 0, 0));

    private final Item branch;
    private final Item problems;
    private final Item position;
    private final Item indentation;
    private final Item encoding;
    private final Item eol;
    private final Item language;
    private final Item themeItem;
    private final Item bell;
    private final Item account;

    /** Segments contributed by plugins, in the order they were added. */
    private final java.util.List<Item> pluginItems = new java.util.ArrayList<>();
    private final java.util.Map<String, Item> pluginItemsById = new java.util.LinkedHashMap<>();

    private int errors;
    private int warnings;
    private String transientMessage;
    /** The signed-in account's name, or null when nobody is signed in. */
    private String accountName;

    // The state behind each segment, kept so retranslate() can rebuild its text.
    private int caretLine = 1;
    private int caretColumn = 1;
    private int caretSelection;
    private int indentSize = 4;
    private boolean indentSpaces = true;
    private String encodingName;
    private String eolValue = "LF";
    private Language currentLanguage;

    public StatusBar(Theme theme) {
        super(new BorderLayout());
        this.theme = theme;
        setBackground(theme.statusBg);
        setPreferredSize(new Dimension(10, 24));

        left.setOpaque(false);
        right.setOpaque(false);

        branch = new Item("sync", "main", "Click to switch branch", () -> act(a -> a.showBranchPicker()));
        problems = new Item("error", "0  0", "No problems detected", () -> act(a -> a.showProblems()));
        position = new Item(null, Strings.format("Ln {0}, Col {1}", 1, 1), "Go to line",
                () -> act(a -> a.showProblems()));
        indentation = new Item(null, Strings.format("Spaces: {0}", 4), "Select indentation",
                () -> act(a -> a.showIndentPicker()));
        encoding = new Item(null, "UTF-8", "Select encoding", () -> act(a -> a.showEncodingPicker()));
        eol = new Item(null, "LF", "Select end of line sequence", () -> act(a -> a.showEolPicker()));
        language = new Item(null, Strings.languageName("plaintext", "Plain Text"), "Select language mode",
                () -> act(a -> a.showLanguagePicker()));
        themeItem = new Item("theme", "", "Switch color theme", () -> act(a -> a.toggleTheme()));
        bell = new Item("bell", "", "Notifications", () -> act(a -> a.showNotifications()));
        account = new Item("person", Strings.get("Accounts"), "Accounts",
                () -> act(a -> a.showAccounts()));

        left.add(account);
        left.add(branch);
        left.add(problems);
        right.add(position);
        right.add(indentation);
        right.add(encoding);
        right.add(eol);
        right.add(language);
        right.add(themeItem);
        right.add(bell);

        add(left, BorderLayout.WEST);
        add(right, BorderLayout.EAST);
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    private void act(java.util.function.Consumer<Actions> consumer) {
        if (actions != null) {
            consumer.accept(actions);
        }
    }

    /** Untranslated branch text, kept so {@link #retranslate} can redo it after a language change. */
    private String branchText = "No repository";

    public void setBranch(String text) {
        branchText = text == null || text.isBlank() ? "No repository" : text;
        if (transientMessage == null) {
            branch.setText(Strings.get(branchText));
        }
    }

    public void setProblems(int errors, int warnings) {
        this.errors = errors;
        this.warnings = warnings;
        if (errors == 0 && warnings == 0) {
            problems.setText("0  0");
            problems.setIcon("error");
        } else {
            problems.setText(errors + "  " + warnings);
            problems.setIcon(errors > 0 ? "error" : "warning");
            problems.setColors(errors > 0 ? theme.error : theme.warning, Color.WHITE);
        }
        problems.setToolTipText(Strings.format("{0} errors, {1} warnings", errors, warnings));
    }

    public void setCaret(int line, int column, int selectionLength) {
        caretLine = line;
        caretColumn = column;
        caretSelection = selectionLength;
        if (selectionLength > 0) {
            position.setText(Strings.format("Ln {0}, Col {1} ({2} selected)", line, column, selectionLength));
        } else {
            position.setText(Strings.format("Ln {0}, Col {1}", line, column));
        }
    }

    public void setIndentation(int size, boolean spaces) {
        indentSize = size;
        indentSpaces = spaces;
        indentation.setText(Strings.format(spaces ? "Spaces: {0}" : "Tab Size: {0}", size));
    }

    public void setEncoding(String name) {
        encodingName = name;
        encoding.setText(name == null ? "UTF-8" : name);
    }

    public void setEol(String value) {
        eolValue = value;
        eol.setText(value == null ? "LF" : value);
    }

    public void setLanguage(Language lang) {
        currentLanguage = lang;
        language.setText(lang == null
                ? Strings.languageName("plaintext", "Plain Text")
                : Strings.languageName(lang.id, lang.name));
    }

    /**
     * Sets the account segment. A null or blank name means nobody is signed in, and the segment
     * falls back to the generic label rather than disappearing — the entry point to accounts has to
     * stay reachable precisely when there is no account yet.
     */
    public void setAccount(String name) {
        accountName = name == null || name.isBlank() ? null : name;
        account.setText(accountName == null ? Strings.get("Accounts") : accountName);
    }

    /**
     * Adds a segment contributed by a plugin.
     *
     * <p>The text is shown exactly as the plugin supplied it. A plugin's own words are not in the
     * translation table, and guessing at a translation for text we do not own would be worse than
     * showing it as written.
     */
    public void addPluginItem(String id, String text, Runnable onClick) {
        if (id == null || id.isBlank() || pluginItemsById.containsKey(id)) {
            return;
        }
        Item item = new Item(null, text == null ? "" : text, "",
                onClick == null ? () -> { } : onClick);
        pluginItemsById.put(id, item);
        pluginItems.add(item);
        left.add(item);
        left.revalidate();
        left.repaint();
    }

    /** Removes a plugin's segment. False when no such segment was present. */
    public boolean removePluginItem(String id) {
        Item item = pluginItemsById.remove(id);
        if (item == null) {
            return false;
        }
        pluginItems.remove(item);
        left.remove(item);
        left.revalidate();
        left.repaint();
        return true;
    }

    /** Shows a short lived message on the left of the bar. */
    public void setMessage(String text, int millis) {
        if (text == null || text.isBlank()) {
            return;
        }
        transientMessage = text;
        branch.setText(Strings.get(text));
        branch.setIcon(null);
        javax.swing.Timer t = new javax.swing.Timer(Math.max(1500, millis), e -> {
            transientMessage = null;
            branch.setText(Strings.get(branchText));
            branch.setIcon("sync");
        });
        t.setRepeats(false);
        t.start();
        repaint();
    }

    /**
     * Re-applies every segment after a language change: the tooltips, the static text of each
     * segment rebuilt from the state it was last given, and whichever text the branch segment is
     * currently showing. Safe to call at any time — text that is already translated passes through
     * unchanged.
     */
    public void retranslate() {
        for (Item item : segments()) {
            item.applyTooltip();
        }
        setCaret(caretLine, caretColumn, caretSelection);
        setIndentation(indentSize, indentSpaces);
        setEncoding(encodingName);
        setEol(eolValue);
        setLanguage(currentLanguage);
        setProblems(errors, warnings);
        setAccount(accountName);
        branch.setText(Strings.get(transientMessage == null ? branchText : transientMessage));
        repaint();
    }

    /** Every segment, including contributed ones, so theming and retranslation cover them too. */
    private java.util.List<Item> segments() {
        java.util.List<Item> all = new java.util.ArrayList<>(
                java.util.List.of(branch, problems, position, indentation, encoding, eol,
                        language, themeItem, bell, account));
        all.addAll(pluginItems);
        return all;
    }

    public boolean hasTransientMessage() {
        return transientMessage != null;
    }

    public void setTheme(Theme t) {
        setBackground(t.statusBg);
        for (Item item : segments()) {
            item.setColors(null, t.statusFg);
        }
        setProblems(errors, warnings);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        g.setColor(theme.statusBg);
        g.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(g);
    }

    /** A clickable segment of the status bar. */
    private class Item extends JPanel {
        private final JLabel label = new JLabel();
        private final Runnable action;
        /** Untranslated tooltip, kept so {@link #applyTooltip} can redo it after a language change. */
        private final String tooltipKey;
        private boolean hovering;
        private Color customFg;
        private Color customBg;
        private String iconName;

        Item(String iconName, String text, String tooltipKey, Runnable action) {
            super(new BorderLayout(4, 0));
            this.iconName = iconName;
            this.action = action;
            this.tooltipKey = tooltipKey;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(0, 7, 0, 7));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setToolTipText(Strings.get(tooltipKey));
            label.setText(text);
            label.setFont(UI.ui(11.5f));
            label.setForeground(theme.statusFg);
            add(label, BorderLayout.CENTER);
            refreshIcon();
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    Item.this.action.run();
                }
            });
        }

        void setText(String text) {
            label.setText(text);
        }

        void setIcon(String name) {
            this.iconName = name;
            refreshIcon();
        }

        void applyTooltip() {
            setToolTipText(Strings.get(tooltipKey));
        }

        void setColors(Color fg, Color bg) {
            this.customFg = fg;
            this.customBg = bg;
            label.setForeground(fg == null ? theme.statusFg : fg);
            repaint();
        }

        private void refreshIcon() {
            label.setIcon(iconName == null ? null
                    : Icons.of(iconName, 13, customFg == null ? theme.statusFg : customFg));
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (hovering || customBg != null && hovering) {
                    g.setColor(theme.statusHover);
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            } finally {
                g.dispose();
            }
            super.paintComponent(g0);
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            d.height = 24;
            return d;
        }
    }
}
