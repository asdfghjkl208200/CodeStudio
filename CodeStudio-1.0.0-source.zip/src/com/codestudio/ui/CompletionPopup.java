package com.codestudio.ui;

import com.codestudio.core.Theme;
import com.codestudio.core.Strings;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;

/**
 * The suggestion list shown under the caret.
 *
 * <p>A plain panel rather than a window: it is installed through Swing's popup factory, so it
 * layers above the editor without stealing focus. That is what keeps the keys in the editor -
 * {@link CodeTextPane} sees the arrow keys while the list is up and moves the selection itself.
 */
public class CompletionPopup extends JPanel {

    /** One suggestion. */
    public static class Item {
        /** Text drawn in the list and inserted on accept. */
        public final String label;
        /** Short kind hint on the right, e.g. "snippet". */
        public final String detail;
        /** "keyword", "snippet", "symbol", "word" -picks the icon. */
        public final String kind;
        /** What accepting the item inserts. Equals the label except for snippets. */
        public final String insert;
        /** Caret offset inside {@link #insert}, or -1 for "at the end". */
        public final int caretOffset;
        /** The typed prefix this item completes, used to decide what to replace. */
        public final int replaceFrom;
        public final int replaceTo;

        public Item(String label, String detail, String kind, String insert, int caretOffset,
                    int replaceFrom, int replaceTo) {
            this.label = label;
            this.detail = detail;
            this.kind = kind;
            this.insert = insert == null ? label : insert;
            this.caretOffset = caretOffset;
            this.replaceFrom = replaceFrom;
            this.replaceTo = replaceTo;
        }
    }

    private static final int ROW_HEIGHT = 21;
    private static final int MAX_ROWS = 12;
    private static final int WIDTH = 380;

    private final DefaultListModel<Item> model = new DefaultListModel<>();
    private final JList<Item> list = new JList<>(model);
    private final JScrollPane scroll;
    private final Renderer renderer = new Renderer();
    private Theme theme;

    public CompletionPopup(Theme theme) {
        super(new BorderLayout());
        this.theme = theme;

        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setFixedCellHeight(ROW_HEIGHT);
        list.setCellRenderer(renderer);
        list.setFocusable(false);
        list.setSelectionBackground(theme.listActive);
        list.setSelectionForeground(theme.listActiveFg);
        list.setBackground(theme.widgetBg);
        list.setForeground(theme.panelFg);

        scroll = new JScrollPane(list);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(theme.widgetBg);
        scroll.getVerticalScrollBar().setUI(new UI.FlatScrollBarUI(theme));

        setLayout(new BorderLayout());
        setBackground(theme.widgetBg);
        setBorder(BorderFactory.createLineBorder(theme.widgetBorder));
        add(scroll, BorderLayout.CENTER);
    }

    public void setTheme(Theme t) {
        this.theme = t;
        renderer.applyTheme(t);
        setBackground(t.widgetBg);
        setBorder(BorderFactory.createLineBorder(t.widgetBorder));
        list.setBackground(t.widgetBg);
        list.setForeground(t.panelFg);
        list.setSelectionBackground(t.listActive);
        list.setSelectionForeground(t.listActiveFg);
        scroll.getViewport().setBackground(t.widgetBg);
        scroll.getVerticalScrollBar().setUI(new UI.FlatScrollBarUI(t));
        repaint();
    }

    public void setItems(java.util.List<Item> items) {
        model.clear();
        for (Item item : items) {
            model.addElement(item);
        }
        if (!items.isEmpty()) {
            list.setSelectedIndex(0);
            list.ensureIndexIsVisible(0);
        }
        revalidate();
    }

    public int count() {
        return model.size();
    }

    public Item selected() {
        return list.getSelectedValue();
    }

    public void move(int delta) {
        int size = model.size();
        if (size == 0) {
            return;
        }
        int index = Math.floorMod(list.getSelectedIndex() + delta, size);
        list.setSelectedIndex(index);
        list.ensureIndexIsVisible(index);
    }

    public void select(int index) {
        if (index >= 0 && index < model.size()) {
            list.setSelectedIndex(index);
            list.ensureIndexIsVisible(index);
        }
    }

    @Override
    public Dimension getPreferredSize() {
        int rows = Math.max(1, Math.min(MAX_ROWS, model.size()));
        return new Dimension(WIDTH, rows * ROW_HEIGHT + 2);
    }

    @Override
    public Dimension getMaximumSize() {
        return getPreferredSize();
    }

    /* ------------------------------------------------------------------ */

    private class Renderer implements ListCellRenderer<Item> {
        private final JPanel row = new JPanel(new BorderLayout(6, 0));
        private final JLabel label = new JLabel();
        private final JLabel detail = new JLabel();

        Renderer() {
            row.setOpaque(true);
            row.setBorder(BorderFactory.createEmptyBorder(1, 6, 1, 8));
            label.setFont(UI.ui(12.5f));
            detail.setFont(UI.ui(10.5f));
            detail.setHorizontalAlignment(JLabel.RIGHT);
            row.add(label, BorderLayout.CENTER);
            row.add(detail, BorderLayout.EAST);
        }

        void applyTheme(Theme t) {
            row.setBackground(t.widgetBg);
            label.setForeground(t.panelFg);
            detail.setForeground(UI.alpha(t.panelFg, 140));
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends Item> list, Item value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            row.setBackground(isSelected ? theme.listActive : theme.widgetBg);
            Color fg = isSelected ? theme.listActiveFg : theme.panelFg;
            label.setForeground(fg);
            label.setText(value.label);
            label.setIcon(Icons.of(iconFor(value.kind), 13, isSelected ? fg : colorFor(value.kind)));
            detail.setForeground(isSelected ? UI.alpha(theme.listActiveFg, 200) : UI.alpha(theme.panelFg, 140));
            // The detail is a kind name for most items and a snippet's own description for the rest,
            // so it goes through the table: a known kind is translated, anything else stays as is.
            detail.setText(value.detail == null ? "" : Strings.get(value.detail));
            return row;
        }

        private String iconFor(String kind) {
            return switch (kind == null ? "" : kind) {
                case "snippet" -> "quote";
                case "keyword", "control" -> "keyboard";
                case "type" -> "folder-tree";
                case "function", "method" -> "run";
                case "constant" -> "star";
                default -> "edit";
            };
        }

        private Color colorFor(String kind) {
            return switch (kind == null ? "" : kind) {
                case "snippet" -> theme.synConstant;
                case "keyword", "control" -> theme.synKeyword;
                case "type" -> theme.synType;
                case "function", "method" -> theme.synFunction;
                case "constant" -> theme.synConstant;
                default -> theme.synVar;
            };
        }
    }
}
