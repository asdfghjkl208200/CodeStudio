package com.codestudio.ui;

import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/** The "Get Started" page shown when nothing is open. */
public class WelcomePanel extends JPanel implements ThemeAware {

    /** Below this width the Start and Recent columns are stacked instead of placed side by side. */
    private static final int TWO_COLUMN_MIN = 620;

    public interface Actions {
        void newFile();

        void openFile();

        void openFolder();

        void openPath(String path);

        void cloneRepository();

        void showShortcuts();

        void showAbout();

        void openSettings();

        void toggleTheme();

        /** Opens the accounts view. Declared with a default body so existing callers keep compiling. */
        default void showAccounts() {
        }
    }

    private final Settings settings;
    private Theme theme;
    private Actions actions;
    private final JPanel body = new JPanel();
    private final JScrollPane scroll;

    public WelcomePanel(Settings settings, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.theme = theme;
        setBackground(theme.panelBg);

        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(theme.panelBg);
        body.setBorder(BorderFactory.createEmptyBorder(28, 40, 32, 40));

        scroll = UI.scroll(body, theme);
        scroll.getViewport().setBackground(theme.panelBg);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scroll, BorderLayout.CENTER);
        // Rebuild when the width crosses the one-column/two-column line; the panel has to be laid
        // out once before it knows how much room it has, and again if the sidebar is dragged.
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                if (twoColumns() != laidOutAsTwoColumns) {
                    rebuild();
                }
            }
        });
        rebuild();
    }

    /** Which of the two shapes the current body was built in, so a resize only rebuilds on a change. */
    private boolean laidOutAsTwoColumns;

    public void setActions(Actions a) {
        this.actions = a;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.panelBg);
        body.setBackground(t.panelBg);
        scroll.getViewport().setBackground(t.panelBg);
        UI.themeScrollBar(scroll, t);
        rebuild();
    }

    /** Refreshes the recent lists; called whenever the view becomes visible. */
    public final void rebuild() {
        laidOutAsTwoColumns = twoColumns();
        body.removeAll();

        JLabel title = new JLabel(Strings.get("CodeStudio"));
        title.setFont(UI.ui(26f));
        title.setForeground(theme.editorFg);
        title.setAlignmentX(LEFT_ALIGNMENT);
        body.add(title);

        // Wrapped rather than a label: the sentence is longer than the sidebar is wide, and a label
        // would cut it off mid-clause instead of continuing on the next line.
        WrapArea subtitle = new WrapArea(Strings.get(
                "A Java workbench for editing, searching, running and versioning your code."));
        subtitle.setFont(UI.ui(13f));
        subtitle.setForeground(UI.alpha(theme.editorFg, 170));
        subtitle.setAlignmentX(LEFT_ALIGNMENT);
        subtitle.setBorder(BorderFactory.createEmptyBorder(4, 0, 22, 0));
        body.add(subtitle);

        body.add(columns());
        body.add(Box.createVerticalGlue());

        body.revalidate();
        body.repaint();
    }

    /**
     * Re-applies every string after a language change. The body is rebuilt outright, which re-reads
     * the title, the subtitle, both column headings and every action row, and picks the recent
     * folder list up again at the same time.
     */
    public void retranslate() {
        rebuild();
    }

    /**
     * The Start and Recent columns, side by side when there is room for both and stacked when there
     * is not.
     *
     * <p>The page is shown in the sidebar, which is 260 pixels wide by default — less than half of
     * what two columns and their gap need. Laid out side by side there, both columns were cut off
     * mid-sentence and the Recent list was off the edge entirely, so the width decides the shape
     * rather than an assumption about how much room the page has.
     */
    private JPanel columns() {
        JPanel grid;
        if (twoColumns()) {
            grid = new JPanel(new java.awt.GridLayout(1, 2, 48, 0));
            grid.add(leftColumn());
            grid.add(rightColumn());
        } else {
            grid = new JPanel();
            grid.setLayout(new BoxLayout(grid, BoxLayout.Y_AXIS));
            grid.add(leftColumn());
            grid.add(Box.createVerticalStrut(26));
            grid.add(rightColumn());
        }
        grid.setBackground(theme.panelBg);
        grid.setAlignmentX(LEFT_ALIGNMENT);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 420));
        return grid;
    }

    /** True when the panel is wide enough for the two-column layout. */
    private boolean twoColumns() {
        int width = getWidth();
        if (width <= 0 && getParent() != null) {
            width = getParent().getWidth();
        }
        return width >= TWO_COLUMN_MIN;
    }

    private JPanel leftColumn() {
        JPanel col = column("Start");
        col.add(action(Strings.get("New File..."), "Ctrl+N", this::actNewFile));
        col.add(action(Strings.get("Open File..."), "Ctrl+O", this::actOpenFile));
        col.add(action(Strings.get("Open Folder..."), "Ctrl+K Ctrl+O", this::actOpenFolder));
        col.add(action(Strings.get("Clone Git Repository..."), null, () -> {
            if (actions != null) {
                actions.cloneRepository();
            }
        }));
        col.add(action(Strings.get("Show All Commands"), "Ctrl+Shift+P", () -> {
            if (actions != null) {
                actions.showShortcuts();
            }
        }));
        col.add(action(Strings.get("Accounts"), null, () -> {
            if (actions != null) {
                actions.showAccounts();
            }
        }));
        return col;
    }

    private JPanel rightColumn() {
        JPanel col = column("Recent");
        List<String> folders = settings.getRecentFolders();
        if (folders.isEmpty()) {
            JLabel none = new JLabel(Strings.get("No recent folders yet"));
            none.setFont(UI.ui(12.5f));
            none.setForeground(UI.alpha(theme.editorFg, 130));
            none.setBorder(BorderFactory.createEmptyBorder(2, 0, 6, 0));
            col.add(none);
        } else {
            int shown = 0;
            for (String path : folders) {
                if (shown++ >= 6) {
                    break;
                }
                File dir = new File(path);
                String name = dir.getName().isEmpty() ? path : dir.getName();
                col.add(action(name, shorten(path), () -> actOpenPath(path)));
            }
        }
        col.add(Box.createVerticalStrut(10));
        JLabel helpTitle = new JLabel(Strings.get("Help"));
        helpTitle.setFont(UI.uiBold(12.5f));
        helpTitle.setForeground(theme.editorFg);
        helpTitle.setBorder(BorderFactory.createEmptyBorder(8, 0, 4, 0));
        col.add(helpTitle);
        col.add(action(Strings.get("Keyboard Shortcuts"), "Ctrl+K Ctrl+S", () -> {
            if (actions != null) {
                actions.showShortcuts();
            }
        }));
        col.add(action(Strings.get("Settings"), "Ctrl+,", () -> {
            if (actions != null) {
                actions.openSettings();
            }
        }));
        col.add(action(Strings.get("Switch Theme"), null, () -> {
            if (actions != null) {
                actions.toggleTheme();
            }
        }));
        col.add(action(Strings.get("About CodeStudio"), null, () -> {
            if (actions != null) {
                actions.showAbout();
            }
        }));
        return col;
    }

    private JPanel column(String heading) {
        JPanel col = new JPanel();
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.setBackground(theme.panelBg);
        JLabel h = new JLabel(Strings.get(heading));
        h.setFont(UI.uiBold(15f));
        h.setForeground(theme.editorFg);
        h.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        h.setAlignmentX(LEFT_ALIGNMENT);
        col.add(h);
        return col;
    }

    private static String shorten(String path) {
        if (path.length() <= 46) {
            return path;
        }
        return "..." + path.substring(path.length() - 43);
    }

    private void actNewFile() {
        if (actions != null) {
            actions.newFile();
        }
    }

    private void actOpenFile() {
        if (actions != null) {
            actions.openFile();
        }
    }

    private void actOpenFolder() {
        if (actions != null) {
            actions.openFolder();
        }
    }

    private void actOpenPath(String path) {
        if (actions != null) {
            actions.openPath(path);
        }
    }

    /** A clickable link row. */
    private class Link extends JPanel {
        private final String text;
        private final String hint;
        private final Runnable action;
        private boolean hovering;

        Link(String text, String hint, Runnable action) {
            super(new BorderLayout(8, 0));
            this.text = text;
            this.hint = hint;
            this.action = action;
            setBackground(theme.panelBg);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
            setAlignmentX(LEFT_ALIGNMENT);
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            if (hint != null) {
                JLabel h = new JLabel(hint);
                h.setFont(UI.ui(11.5f));
                h.setForeground(UI.alpha(theme.editorFg, 120));
                add(h, BorderLayout.EAST);
            }
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    repaint();
                }

                @Override
                public void mouseClicked(MouseEvent e) {
                    Link.this.action.run();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g.setColor(theme.panelBg);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setFont(UI.ui(13f));
                Color color = hovering ? theme.accent : theme.info;
                g.setColor(color);
                g.drawString(text, 0, 16);
                java.awt.FontMetrics fm = g.getFontMetrics();
                int w = fm.stringWidth(text);
                if (hovering) {
                    g.drawLine(0, 19, w, 19);
                }
            } finally {
                g.dispose();
            }
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            d.height = 24;
            return d;
        }
    }

    private Link action(String text, String hint, Runnable action) {
        return new Link(text, hint, action);
    }

    /** Font used for the section headings so dialogs can reuse it. */
    static Font headingFont() {
        return UI.uiBold(15f);
    }
}
