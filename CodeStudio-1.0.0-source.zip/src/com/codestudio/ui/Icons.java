package com.codestudio.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.util.HashMap;
import java.util.Map;
import javax.swing.Icon;

/**
 * Hand drawn vector icons (16x16 design grid) so the IDE needs no image
 * resources and every icon can follow the active theme color.
 */
public final class Icons {

    private static final Map<String, Icon> CACHE = new HashMap<>();
    public static final int GRID = 16;

    private Icons() {
    }

    public static Icon of(String name, int size, Color color) {
        String key = name + '|' + size + '|' + color.getRGB();
        Icon icon = CACHE.get(key);
        if (icon == null) {
            icon = new VectorIcon(name, size, color);
            CACHE.put(key, icon);
        }
        return icon;
    }

    public static Icon of(String name, Color color) {
        return of(name, 16, color);
    }

    private static final class VectorIcon implements Icon {
        private final String name;
        private final int size;
        private final Color color;

        VectorIcon(String name, int size, Color color) {
            this.name = name;
            this.size = size;
            this.color = color;
        }

        @Override
        public int getIconWidth() {
            return size;
        }

        @Override
        public int getIconHeight() {
            return size;
        }

        @Override
        public void paintIcon(Component c, Graphics g0, int x, int y) {
            Graphics2D g = (Graphics2D) g0.create();
            try {
                g.translate(x, y);
                g.scale(size / (double) GRID, size / (double) GRID);
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
                g.setColor(color);
                g.setStroke(new BasicStroke(1.35f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                draw(g, name);
            } finally {
                g.dispose();
            }
        }
    }

    private static void draw(Graphics2D g, String name) {
        switch (name) {
            case "chevron-right" -> line(g, 6, 3.5, 11, 8, 6, 12.5);
            case "chevron-down" -> line(g, 3.5, 6, 8, 10.5, 12.5, 6);
            case "chevron-up" -> line(g, 3.5, 10, 8, 5.5, 12.5, 10);
            case "arrow-right" -> {
                line(g, 3, 8, 12.5, 8);
                line(g, 9, 4.5, 12.5, 8, 9, 11.5);
            }
            case "arrow-left" -> {
                line(g, 13, 8, 3.5, 8);
                line(g, 7, 4.5, 3.5, 8, 7, 11.5);
            }
            case "close" -> {
                line(g, 4, 4, 12, 12);
                line(g, 12, 4, 4, 12);
            }
            case "plus" -> {
                line(g, 8, 3, 8, 13);
                line(g, 3, 8, 13, 8);
            }
            case "minus" -> line(g, 3, 8, 13, 8);
            case "check" -> line(g, 3.5, 8.5, 6.5, 11.5, 12.5, 4.5);
            case "file" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(3.5, 1.5);
                p.lineTo(9, 1.5);
                p.lineTo(12.5, 5);
                p.lineTo(12.5, 14.5);
                p.lineTo(3.5, 14.5);
                p.closePath();
                g.draw(p);
                line(g, 9, 1.5, 9, 5, 12.5, 5);
            }
            case "folder" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(1.5, 3.5);
                p.lineTo(6, 3.5);
                p.lineTo(7.5, 5.5);
                p.lineTo(14.5, 5.5);
                p.lineTo(14.5, 13);
                p.lineTo(1.5, 13);
                p.closePath();
                g.draw(p);
            }
            case "folder-open" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(1.5, 3.5);
                p.lineTo(6, 3.5);
                p.lineTo(7.5, 5.5);
                p.lineTo(13, 5.5);
                p.lineTo(13, 7);
                g.draw(p);
                Path2D q = new Path2D.Double();
                q.moveTo(1.5, 12.5);
                q.lineTo(3.5, 7);
                q.lineTo(15, 7);
                q.lineTo(13, 12.5);
                q.closePath();
                g.draw(q);
            }
            case "files" -> {
                g.draw(new RoundRectangle2D.Double(5.5, 1.5, 9, 11, 2, 2));
                g.draw(new RoundRectangle2D.Double(1.5, 4.5, 9, 10, 2, 2));
            }
            case "search" -> {
                g.draw(new Ellipse2D.Double(2.5, 2.5, 8.5, 8.5));
                line(g, 9.5, 9.5, 13.5, 13.5);
            }
            case "replace" -> {
                g.draw(new RoundRectangle2D.Double(1.5, 2.5, 8, 6, 2, 2));
                g.draw(new RoundRectangle2D.Double(6.5, 7.5, 8, 6, 2, 2));
            }
            case "source-control" -> {
                g.draw(new Ellipse2D.Double(2, 1.5, 4, 4));
                g.draw(new Ellipse2D.Double(2, 10.5, 4, 4));
                g.draw(new Ellipse2D.Double(10, 6, 4, 4));
                line(g, 4, 5.5, 4, 10.5);
                Path2D p = new Path2D.Double();
                p.moveTo(6, 12.5);
                p.curveTo(9, 12.5, 9, 10.5, 10, 9.5);
                g.draw(p);
            }
            case "git-branch" -> {
                g.draw(new Ellipse2D.Double(2, 10.5, 4, 4));
                g.draw(new Ellipse2D.Double(10, 1.5, 4, 4));
                g.draw(new Ellipse2D.Double(4, 1.5, 4, 4));
                line(g, 4, 5.5, 4, 10.5);
                line(g, 12, 5.5, 12, 8);
                line(g, 4, 8, 12, 8);
            }
            case "run" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(4, 2.5);
                p.lineTo(13.5, 8);
                p.lineTo(4, 13.5);
                p.closePath();
                g.fill(p);
            }
            case "stop" -> g.fill(new RoundRectangle2D.Double(3.5, 3.5, 9, 9, 1.5, 1.5));
            case "debug" -> {
                g.draw(new Ellipse2D.Double(3.5, 3.5, 9, 10));
                line(g, 8, 3.5, 8, 1.5);
                line(g, 2.5, 6, 3.5, 7);
                line(g, 13.5, 6, 12.5, 7);
                line(g, 2.5, 11, 3.5, 10);
                line(g, 13.5, 11, 12.5, 10);
            }
            case "extensions" -> {
                g.draw(new RoundRectangle2D.Double(2, 2, 5, 5, 1, 1));
                g.draw(new RoundRectangle2D.Double(9, 2, 5, 5, 1, 1));
                g.draw(new RoundRectangle2D.Double(2, 9, 5, 5, 1, 1));
                g.draw(new RoundRectangle2D.Double(9, 9, 5, 5, 1, 1));
            }
            case "settings" -> {
                g.draw(new Ellipse2D.Double(5, 5, 6, 6));
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI * i / 4.0;
                    double cx = 8 + Math.cos(a) * 5.2;
                    double cy = 8 + Math.sin(a) * 5.2;
                    double ex = 8 + Math.cos(a) * 6.8;
                    double ey = 8 + Math.sin(a) * 6.8;
                    g.draw(new java.awt.geom.Line2D.Double(cx, cy, ex, ey));
                }
            }
            case "terminal" -> {
                g.draw(new RoundRectangle2D.Double(1.5, 2.5, 13, 11, 2, 2));
                line(g, 4.5, 6, 6.5, 8, 4.5, 10);
                line(g, 8.5, 10.5, 11.5, 10.5);
            }
            case "new-file" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(2.5, 1.5);
                p.lineTo(8, 1.5);
                p.lineTo(11.5, 5);
                p.lineTo(11.5, 14.5);
                p.lineTo(2.5, 14.5);
                p.closePath();
                g.draw(p);
                line(g, 8, 1.5, 8, 5, 11.5, 5);
                line(g, 13, 8, 13, 13);
                line(g, 10.5, 10.5, 15.5, 10.5);
            }
            case "new-folder" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(1.5, 3.5);
                p.lineTo(5, 3.5);
                p.lineTo(6.5, 5.5);
                p.lineTo(11, 5.5);
                p.lineTo(11, 13);
                p.lineTo(1.5, 13);
                p.closePath();
                g.draw(p);
                line(g, 13, 8, 13, 14);
                line(g, 10, 11, 16, 11);
            }
            case "open-folder" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(1.5, 3.5);
                p.lineTo(6, 3.5);
                p.lineTo(7.5, 5.5);
                p.lineTo(14.5, 5.5);
                p.lineTo(14.5, 13);
                p.lineTo(1.5, 13);
                p.closePath();
                g.draw(p);
                line(g, 8, 11.5, 8, 7.5);
                line(g, 6, 9.3, 8, 7.3, 10, 9.3);
            }
            case "refresh" -> {
                g.draw(new Arc2D.Double(2.5, 2.5, 11, 11, 60, 250, Arc2D.OPEN));
                line(g, 11.5, 1.5, 11.8, 5.2);
                line(g, 11.5, 1.5, 8, 2.2);
            }
            case "collapse-all" -> {
                line(g, 3, 4, 13, 4);
                line(g, 6, 7.5, 10, 7.5);
                line(g, 3, 12, 6.5, 8.5, 10, 12);
            }
            case "ellipsis" -> {
                g.fill(new Ellipse2D.Double(2.5, 6.8, 2.4, 2.4));
                g.fill(new Ellipse2D.Double(6.8, 6.8, 2.4, 2.4));
                g.fill(new Ellipse2D.Double(11.1, 6.8, 2.4, 2.4));
            }
            case "split" -> {
                g.draw(new RoundRectangle2D.Double(1.5, 2.5, 13, 11, 1.5, 1.5));
                line(g, 8, 3, 8, 13);
            }
            case "layout" -> {
                g.draw(new RoundRectangle2D.Double(1.5, 2.5, 13, 11, 1.5, 1.5));
                line(g, 5.5, 3, 5.5, 13);
            }
            case "panel" -> {
                g.draw(new RoundRectangle2D.Double(1.5, 2.5, 13, 11, 1.5, 1.5));
                line(g, 2, 10, 14, 10);
            }
            case "sidebar" -> {
                g.draw(new RoundRectangle2D.Double(1.5, 2.5, 13, 11, 1.5, 1.5));
                line(g, 6.5, 3, 6.5, 13);
            }
            case "error" -> {
                g.fill(new Ellipse2D.Double(1.5, 1.5, 13, 13));
                g.setColor(Color.WHITE);
                g.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                line(g, 5.5, 5.5, 10.5, 10.5);
                line(g, 10.5, 5.5, 5.5, 10.5);
            }
            case "warning" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(8, 1.5);
                p.lineTo(15, 14);
                p.lineTo(1, 14);
                p.closePath();
                g.fill(p);
                g.setColor(Color.WHITE);
                g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                line(g, 8, 6, 8, 10);
                g.fill(new Ellipse2D.Double(7.2, 11.4, 1.6, 1.6));
            }
            case "info" -> {
                g.draw(new Ellipse2D.Double(1.5, 1.5, 13, 13));
                line(g, 8, 7, 8, 11.5);
                g.fill(new Ellipse2D.Double(7.2, 4.2, 1.6, 1.6));
            }
            case "bell" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(3.5, 11.5);
                p.lineTo(3.5, 7.5);
                p.curveTo(3.5, 3.5, 12.5, 3.5, 12.5, 7.5);
                p.lineTo(12.5, 11.5);
                g.draw(p);
                line(g, 2, 11.5, 14, 11.5);
                line(g, 6.5, 13.5, 9.5, 13.5);
            }
            case "save" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(2.5, 2.5);
                p.lineTo(11, 2.5);
                p.lineTo(13.5, 5);
                p.lineTo(13.5, 13.5);
                p.lineTo(2.5, 13.5);
                p.closePath();
                g.draw(p);
                g.draw(new java.awt.geom.Rectangle2D.Double(5, 2.5, 6, 4.5));
                g.draw(new java.awt.geom.Rectangle2D.Double(5, 9, 6, 4.5));
            }
            case "history" -> {
                g.draw(new Arc2D.Double(2.5, 2.5, 11, 11, 70, 250, Arc2D.OPEN));
                line(g, 8, 5, 8, 8.5, 10.5, 10);
            }
            case "keyboard" -> {
                g.draw(new RoundRectangle2D.Double(1, 4.5, 14, 8, 1.5, 1.5));
                line(g, 4, 7.5, 4, 7.5);
                line(g, 8, 7.5, 8, 7.5);
                line(g, 12, 7.5, 12, 7.5);
                line(g, 5, 10, 11, 10);
            }
            case "trash" -> {
                line(g, 2.5, 4, 13.5, 4);
                Path2D p = new Path2D.Double();
                p.moveTo(4, 4);
                p.lineTo(5, 14);
                p.lineTo(11, 14);
                p.lineTo(12, 4);
                g.draw(p);
                line(g, 6, 2.5, 10, 2.5);
            }
            case "edit" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(2.5, 13.5);
                p.lineTo(3.5, 10);
                p.lineTo(11, 2.5);
                p.lineTo(13.5, 5);
                p.lineTo(6, 12.5);
                p.closePath();
                g.draw(p);
            }
            case "word-wrap" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(2.5, 4.5);
                p.lineTo(13.5, 4.5);
                g.draw(p);
                g.draw(new java.awt.geom.Line2D.Double(2.5, 8, 9.5, 8));
                g.draw(new Arc2D.Double(7.5, 6, 5.5, 5.5, 0, 180, Arc2D.OPEN));
                g.draw(new java.awt.geom.Line2D.Double(2.5, 11.5, 6.5, 11.5));
                line(g, 11, 10, 13, 11.5, 11, 13);
            }
            case "zoom-in" -> {
                g.draw(new Ellipse2D.Double(2.5, 2.5, 9, 9));
                line(g, 10, 10, 13.5, 13.5);
                line(g, 7, 5, 7, 9);
                line(g, 5, 7, 9, 7);
            }
            case "zoom-out" -> {
                g.draw(new Ellipse2D.Double(2.5, 2.5, 9, 9));
                line(g, 10, 10, 13.5, 13.5);
                line(g, 5, 7, 9, 7);
            }
            case "theme" -> {
                g.draw(new Ellipse2D.Double(2, 2, 12, 12));
                Path2D p = new Path2D.Double();
                p.append(new Ellipse2D.Double(2, 2, 12, 12), false);
                g.fill(new Arc2D.Double(2, 2, 12, 12, 90, 180, Arc2D.PIE));
            }
            case "filter" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(2, 3);
                p.lineTo(14, 3);
                p.lineTo(9.5, 8.5);
                p.lineTo(9.5, 13.5);
                p.lineTo(6.5, 11.5);
                p.lineTo(6.5, 8.5);
                p.closePath();
                g.draw(p);
            }
            case "case-sensitive" -> {
                g.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12));
                g.drawString("Aa", 1, 12);
            }
            case "regex" -> {
                g.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 12));
                g.drawString(".*", 2, 12);
            }
            case "whole-word" -> {
                g.setFont(new java.awt.Font("Consolas", java.awt.Font.BOLD, 11));
                g.drawString("ab", 1, 11);
                line(g, 1, 12.5, 13, 12.5);
                line(g, 1, 2.5, 13, 2.5);
            }
            case "clear" -> {
                g.draw(new Ellipse2D.Double(1.5, 1.5, 13, 13));
                line(g, 5, 5, 11, 11);
                line(g, 11, 5, 5, 11);
            }
            case "sync" -> {
                g.draw(new Arc2D.Double(2.5, 2.5, 11, 11, 40, 140, Arc2D.OPEN));
                g.draw(new Arc2D.Double(2.5, 2.5, 11, 11, 220, 140, Arc2D.OPEN));
                line(g, 10.5, 1.8, 12.5, 4.5, 9.5, 5);
                line(g, 5.5, 14.2, 3.5, 11.5, 6.5, 11);
            }
            case "indent" -> {
                line(g, 6, 3, 14, 3);
                line(g, 6, 8, 14, 8);
                line(g, 6, 13, 14, 13);
                line(g, 2, 6, 5, 8, 2, 10);
            }
            case "quote" -> {
                g.setFont(new java.awt.Font("Georgia", java.awt.Font.BOLD, 14));
                g.drawString("\"", 2, 12);
            }
            case "person" -> {
                g.draw(new Ellipse2D.Double(5.5, 2.5, 5, 5));
                Path2D p = new Path2D.Double();
                p.moveTo(2.5, 14);
                p.curveTo(2.5, 9.5, 13.5, 9.5, 13.5, 14);
                g.draw(p);
            }
            case "link" -> {
                g.draw(new Arc2D.Double(1.5, 5, 8, 8, 90, 180, Arc2D.OPEN));
                g.draw(new Arc2D.Double(6.5, 5, 8, 8, 270, 180, Arc2D.OPEN));
                line(g, 5.5, 8, 10.5, 8);
            }
            case "lock" -> {
                g.draw(new RoundRectangle2D.Double(3.5, 7, 9, 7, 1.5, 1.5));
                g.draw(new Arc2D.Double(5, 2.5, 6, 7, 0, 180, Arc2D.OPEN));
            }
            case "eye" -> {
                Path2D p = new Path2D.Double();
                p.moveTo(1.5, 8);
                p.curveTo(5, 2.5, 11, 2.5, 14.5, 8);
                p.curveTo(11, 13.5, 5, 13.5, 1.5, 8);
                g.draw(p);
                g.draw(new Ellipse2D.Double(6, 6, 4, 4));
            }
            case "star" -> {
                Path2D p = new Path2D.Double();
                double cx = 8, cy = 8.5, r1 = 6.5, r2 = 2.8;
                for (int i = 0; i < 10; i++) {
                    double r = (i % 2 == 0) ? r1 : r2;
                    double a = -Math.PI / 2 + i * Math.PI / 5;
                    double px = cx + Math.cos(a) * r;
                    double py = cy + Math.sin(a) * r;
                    if (i == 0) {
                        p.moveTo(px, py);
                    } else {
                        p.lineTo(px, py);
                    }
                }
                p.closePath();
                g.draw(p);
            }
            case "folder-tree" -> {
                g.draw(new java.awt.geom.Rectangle2D.Double(1.5, 1.5, 5, 4));
                g.draw(new java.awt.geom.Rectangle2D.Double(9.5, 6, 5, 4));
                g.draw(new java.awt.geom.Rectangle2D.Double(9.5, 11, 5, 4));
                line(g, 4, 5.5, 4, 13, 9.5, 13);
                line(g, 4, 8, 9.5, 8);
            }
            default -> {
                g.draw(new java.awt.geom.Rectangle2D.Double(2.5, 2.5, 11, 11));
            }
        }
    }

    /** Draws a polyline through the given coordinate pairs. */
    private static void line(Graphics2D g, double... pts) {
        Path2D p = new Path2D.Double();
        p.moveTo(pts[0], pts[1]);
        for (int i = 2; i + 1 < pts.length; i += 2) {
            p.lineTo(pts[i], pts[i + 1]);
        }
        g.draw(p);
    }
}
