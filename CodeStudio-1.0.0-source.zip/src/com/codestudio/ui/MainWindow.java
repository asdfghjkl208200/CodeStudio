package com.codestudio.ui;

import com.codestudio.core.Account;
import com.codestudio.core.Breakpoints;
import com.codestudio.core.DocumentBundle;
import com.codestudio.core.Git;
import com.codestudio.core.Language;
import com.codestudio.core.Navigator;
import com.codestudio.core.Problems;
import com.codestudio.core.Runner;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.SyntaxHighlighter;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import com.codestudio.core.plugin.PluginManager;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.KeyboardFocusManager;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSplitPane;
import javax.swing.KeyStroke;
import javax.swing.MenuSelectionManager;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 * The workbench: menu bar, activity bar, sidebar, editor groups, panel area,
 * status bar, toasts and every command the IDE exposes.
 */
public class MainWindow extends JFrame implements
        EditorPanel.Actions, EditorGroup.Listener,
        ExplorerPanel.Actions, SearchPanel.Actions, GitPanel.Actions, RunPanel.Actions,
        SettingsPanel.Actions, WelcomePanel.Actions, StatusBar.Actions, PanelArea.Actions,
        ActivityBar.Listener, ProblemsView.Actions, OutlinePanel.Navigator,
        QuickOpen.Provider, TerminalPanel.Actions, PluginManager.WorkspaceAware {

    public static final String VERSION = "1.0.0";

    /**
     * What CodeStudio is, in English.
     *
     * <p>Deliberately not in the translation table. Everything else in the interface follows
     * {@code workbench.language}, but this paragraph is the program's own description: it is meant
     * to read the same in every language, and to be quotable as is (the project README opens with
     * it). The one-line summary it replaced is still available in the table if a localized version
     * is wanted back.
     */
    public static final String DESCRIPTION =
            "CodeStudio is a desktop code editor and IDE for Windows, macOS and Linux, written in plain "
                    + "Java with the Swing toolkit and no third-party libraries at all; a plain JDK 17 or newer "
                    + "is enough to build and run it. Its aim is the everyday feature set of Visual Studio Code: "
                    + "a tabbed editor with split views, syntax highlighting for 31 languages, code folding, "
                    + "suggestions and snippets, find and replace, project-wide search, an outline, a file "
                    + "explorer, an integrated terminal, Git integration, running and problem reporting, and "
                    + "workspace-wide go to definition, find all references and rename. The interface is "
                    + "available in English and Simplified Chinese and switched at runtime; plugins can "
                    + "contribute commands, themes, languages, sidebar views and status items; and every local "
                    + "account keeps its own workspace and open files.";

    private static final String[] ENCODINGS = {"UTF-8", "UTF-16", "GBK", "GB18030", "ISO-8859-1", "windows-1252", "US-ASCII"};

    private final Settings settings;
    private final Workspace workspace;
    private final Problems problems = new Problems();
    private final Problems.Parser problemParser = new Problems.Parser();
    private final SyntaxHighlighter highlighter;
    private final Runner runner;
    private Theme theme;

    private final ActivityBar activityBar;
    private final SideBar sideBar;
    private final ExplorerPanel explorer;
    private final SearchPanel search;
    private final GitPanel git;
    private final RunPanel runPanel;
    private final SettingsPanel settingsPanel;
    private final WelcomePanel welcome;
    private final PanelArea panelArea;
    private final StatusBar statusBar;
    private final Notifications notifications;
    private final PluginManager plugins = new PluginManager();
    private final AccountsPanel accounts;
    private final ExtensionsPanel extensionsPanel;
    /** Ids of what plugins contributed, so a reload can withdraw exactly those and no more. */
    private final List<String> installedViewIds = new ArrayList<>();
    private final List<String> installedStatusIds = new ArrayList<>();

    private final JPanel editorArea = new JPanel(new BorderLayout());
    private final List<EditorGroup> groups = new ArrayList<>();
    private final Set<CodeTextPane> autoSaveHooked = Collections.newSetFromMap(new IdentityHashMap<>());
    private final JSplitPane horizontal;
    private JSplitPane vertical;

    private QuickOpen quickOpen;
    private JSplitPane editorSplit;
    private int activeGroupIndex;
    private boolean panelVisible;
    private boolean maximizedPanel;
    private int sidebarWidth;
    private int panelHeight;
    private int problemCursor;

    /* --- Zen Mode remembers what it hid so leaving it restores the same workbench --- */
    private boolean zenMode;
    private boolean zenSideBar;
    private boolean zenPanel;
    private boolean zenMaximized;
    private JMenuBar menuBar;
    /** Set by Ctrl+K, consumed by the next key: the second half of a two stroke shortcut. */
    private long chordK;

    private final Timer outlineTimer = new Timer(300, e -> refreshOutline());
    private final Timer autoSaveTimer = new Timer(1500, e -> saveAll());
    private final Timer gitTimer = new Timer(5000, e -> refreshGitInfo());
    private final Timer filesTimer = new Timer(15000, e -> checkExternalChanges());

    public MainWindow(Settings settings) {
        super("CodeStudio");
        this.settings = settings;
        // Resolve the language before a single component is built, so the first paint is already
        // in the right language rather than being translated a frame later.
        Strings.setLanguage(settings.get("workbench.language"));
        this.workspace = new Workspace(settings);
        this.theme = Theme.get(settings.get("workbench.colorTheme"));
        this.highlighter = new SyntaxHighlighter(theme);
        this.runner = new Runner(workspace);

        theme.applyToUIManager();

        activityBar = new ActivityBar(theme);
        sideBar = new SideBar(settings, theme);
        explorer = new ExplorerPanel(settings, workspace, theme);
        search = new SearchPanel(workspace, theme);
        git = new GitPanel(settings, workspace, theme);
        runPanel = new RunPanel(settings, runner, theme);
        settingsPanel = new SettingsPanel(settings, theme);
        welcome = new WelcomePanel(settings, theme);
        panelArea = new PanelArea(settings, workspace, problems, theme);
        statusBar = new StatusBar(theme);
        notifications = new Notifications(theme);
        accounts = new AccountsPanel(settings, theme);
        extensionsPanel = new ExtensionsPanel(plugins, theme);

        editorArea.setBackground(theme.editorBg);
        createGroup();

        sideBar.addView("explorer", explorer);
        sideBar.addView("search", search);
        sideBar.addView("scm", git);
        sideBar.addView("run", runPanel);
        sideBar.addView("settings", settingsPanel);
        sideBar.addView("welcome", welcome);
        sideBar.addView("accounts", accounts);
        sideBar.addView("extensions", extensionsPanel);

        explorer.setActions(this);
        explorer.setOpenEditorListener(this::openDocument);
        explorer.outline().setNavigator(this);
        search.setActions(this);
        git.setActions(this);
        runPanel.setActions(this);
        settingsPanel.setActions(this);
        welcome.setActions(this);
        statusBar.setActions(this);
        panelArea.setActions(this);
        panelArea.problems().setActions(this);
        panelArea.terminals().setActions(this);
        extensionsPanel.setActions(new ExtensionsPanel.Actions() {
            @Override
            public void notify(String message, boolean error) {
                MainWindow.this.notify(message, error);
            }

            @Override
            public void pluginsChanged() {
                reloadPlugins();
            }
        });
        accounts.addListener(new AccountsPanel.Listener() {
            @Override
            public void accountSwitched(Account account) {
                switchAccountSession(account);
            }

            @Override
            public void accountsChanged() {
                refreshAccount();
            }
        });
        activityBar.addListener(this);

        // After the panels exist, so a contributed view has somewhere to go, and before the menu
        // bar is built, so the Plugins menu already lists what was contributed.
        installPlugins();

        horizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sideBar, editorArea);
        horizontal.setBorder(null);
        horizontal.setDividerSize(5);
        horizontal.setContinuousLayout(true);
        horizontal.setResizeWeight(0);

        horizontal.setRightComponent(buildRightSide());

        menuBar = buildMenuBar();
        setJMenuBar(menuBar);
        setContentPane(buildContent());
        setGlassPane(notifications);
        notifications.setVisible(true);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        outlineTimer.setRepeats(false);
        autoSaveTimer.setRepeats(false);

        wireListeners();
        installGlobalKeys();
        restoreWindow();
        restoreSession();
        // After restoreSession, so the status bar shows the account the session was restored for
        // rather than the label it was constructed with.
        refreshAccount();
        applyVisibility();
        // The first editor group has to be attached here: every other path that puts a group into
        // the editor area goes through applyEditorLayout, and without this call a freshly started
        // workbench shows neither tabs nor text until the editor is split.
        applyEditorLayout();
    }

    /* ------------------------------------------------------------------ */
    /* construction                                                        */
    /* ------------------------------------------------------------------ */

    /**
     * Loads plugins and folds what they contribute into the workbench.
     *
     * <p>A plugin that throws is reported and otherwise ignored; {@link PluginManager} contains the
     * failure, so there is nothing to recover from here.
     */
    private void installPlugins() {
        plugins.setHost(new PluginManager.Host() {
            @Override
            public void showMessage(String pluginId, String message) {
                // Qualified: inside this anonymous class an unqualified notify() would resolve to
                // Object.notify(), which takes no arguments.
                MainWindow.this.notify(message, false);
            }

            @Override
            public void showError(String pluginId, String message, Throwable cause) {
                MainWindow.this.notify(pluginId + ": " + message, true);
                // The trace goes to the output view as well: a notification fades, and this is the
                // only record of why a plugin misbehaved.
                journal(pluginId, message);
                for (Throwable t = cause; t != null; t = t.getCause()) {
                    journal(pluginId, "  " + t);
                    for (StackTraceElement frame : t.getStackTrace()) {
                        journal(pluginId, "      at " + frame);
                    }
                }
            }

            @Override
            public void log(String pluginId, String message) {
                journal(pluginId, message);
            }
        });
        plugins.reload();

        for (PluginManager.View view : plugins.views()) {
            sideBar.addView(view.id(), view.component());
            // A contributed view is styled like a built-in one when it says how.
            if (view.component() instanceof ThemeAware aware) {
                aware.setTheme(theme);
            }
            activityBar.addItem(view.id(), view.icon(), view.title());
            installedViewIds.add(view.id());
        }
        for (PluginManager.StatusItem item : plugins.statusItems()) {
            statusBar.addPluginItem(item.id(), item.text(), item.onClick());
            installedStatusIds.add(item.id());
        }
        // The panel is built early in the constructor, before this runs, so its first refresh saw an
        // empty plugin list. Refresh here — the one place the set of loaded plugins changes — rather
        // than in reloadPlugins(), which would leave the start-up path showing nothing installed.
        if (extensionsPanel != null) {
            extensionsPanel.refresh();
        }
    }

    /** Writes one line to the output view, tagged with the plugin that produced it. */
    private void journal(String pluginId, String message) {
        panelArea.output().appendLine(OutputView.CODESTUDIO, "[" + pluginId + "] " + message);
    }

    /**
     * Withdraws everything plugins contributed and loads them again.
     *
     * <p>Withdrawal has to be explicit: a plugin that has been disabled or removed must lose its
     * view, its activity bar icon and its status segment, and {@link PluginManager} cannot do that
     * because those live in the UI.
     */
    private void reloadPlugins() {
        for (String id : installedViewIds) {
            activityBar.removeItem(id);
            sideBar.removeView(id);
        }
        for (String id : installedStatusIds) {
            statusBar.removePluginItem(id);
        }
        installedViewIds.clear();
        installedStatusIds.clear();

        installPlugins();
        menuBar = buildMenuBar();
        if (!zenMode) {
            setJMenuBar(menuBar);
        }
        notify("Plugins reloaded", false);
    }

    @Override
    public java.nio.file.Path workspaceRoot() {
        return workspace.getRoot() == null ? null : workspace.getRoot().toPath();
    }

    /* ------------------------------------------------------------------ */
    /* accounts                                                            */
    /* ------------------------------------------------------------------ */

    /** The settings that make up one account's session, swapped as a group on a switch. */
    private static final String[] SESSION_KEYS = {
        "files.lastFolder", "workspace.openFiles", "workspace.activeFile"
    };

    /**
     * Which account the live session keys currently belong to, or null when signed out.
     *
     * <p>Needed because the keys themselves are shared: {@code files.lastFolder} always means "the
     * folder that is open", and only this field says whose folder that is.
     */
    private String sessionAccountKey;

    /** Points the status bar at the signed-in account, or back at the generic label. */
    private void refreshAccount() {
        Account current = Account.current();
        statusBar.setAccount(current == null ? null : current.displayName);
    }

    /**
     * Hands the workbench over to another account: the open folder, the open files, and which of
     * them had focus all change with it, so signing in as somebody else does not show them the
     * previous account's tabs.
     *
     * <p>The outgoing session is parked under {@code session.<account>.<setting>} and swapped back
     * in on return. Signing out (a null account) parks it too and starts from an empty workbench.
     *
     * <p>Unsaved work is not silently discarded: {@link #closeAllEditors()} asks about modified
     * buffers first, and if the user cancels, neither half of the swap has happened yet and the
     * account is left as it was.
     */
    private void switchAccountSession(Account account) {
        String next = account == null ? null : account.sessionKey();
        if (java.util.Objects.equals(next, sessionAccountKey)) {
            refreshAccount();
            return;
        }
        saveAll();
        if (!workspace.dirtyDocuments().isEmpty()) {
            // Every prompt has now been shown. Anything still modified is something the user
            // declined to save, so the switch stops here with the account unchanged.
            return;
        }
        if (sessionAccountKey != null) {
            for (String key : SESSION_KEYS) {
                settings.set(sessionKey(sessionAccountKey, key), settings.get(key));
            }
        }
        sessionAccountKey = next;

        closeAllEditors();
        for (String key : SESSION_KEYS) {
            settings.set(key, next == null ? "" : settings.get(sessionKey(next, key), ""));
        }
        restoreSessionState();
        refreshAccount();
        notify(account == null
                ? "Signed out. This workbench is now empty."
                : Strings.format("Signed in as {0}", account.displayName), false);
    }

    private static String sessionKey(String accountKey, String key) {
        return "session." + accountKey + "." + key;
    }

    /** Opens the accounts view, from the status bar segment or the activity bar. */
    @Override
    public void showAccounts() {
        showView("accounts");
    }

    private JPanel buildContent() {
        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(theme.editorBg);
        content.add(activityBar, BorderLayout.WEST);
        content.add(horizontal, BorderLayout.CENTER);
        content.add(statusBar, BorderLayout.SOUTH);
        return content;
    }

    private JPanel buildRightSide() {
        JPanel host = new JPanel(new BorderLayout());
        host.setBackground(theme.editorBg);
        vertical = new JSplitPane(JSplitPane.VERTICAL_SPLIT, editorArea, panelArea);
        vertical.setBorder(null);
        vertical.setDividerSize(5);
        vertical.setContinuousLayout(true);
        vertical.setResizeWeight(1);
        host.add(vertical, BorderLayout.CENTER);
        return host;
    }

    private EditorGroup createGroup() {
        final EditorGroup group = new EditorGroup(settings, workspace, highlighter, theme, this);
        group.addListener(() -> {
            if (group == currentGroup()) {
                activeEditorChanged();
            } else {
                syncExplorerEditors();
            }
        });
        groups.add(group);
        return group;
    }

    private EditorGroup currentGroup() {
        if (activeGroupIndex < 0 || activeGroupIndex >= groups.size()) {
            activeGroupIndex = 0;
        }
        return groups.get(activeGroupIndex);
    }

    private void wireListeners() {
        problems.addListener(() -> SwingUtilities.invokeLater(() -> {
            panelArea.setProblemCounts(problems.errorCount(), problems.warningCount());
            statusBar.setProblems(problems.errorCount(), problems.warningCount());
            panelArea.problems().refresh();
        }));

        workspace.addListener(() -> SwingUtilities.invokeLater(() -> {
            explorer.setRoot(workspace.getRoot());
            panelArea.setWorkingDirectory(workspace.getRoot());
            runPanel.rebuild();
            refreshGitInfo();
            updateTitle();
        }));

        settings.addListener(this::onSettingsChanged);

        gitTimer.setInitialDelay(1500);
        gitTimer.start();
        filesTimer.setInitialDelay(20000);
        filesTimer.start();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exit();
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
                if ("onFocusChange".equals(settings.get("editor.autoSave"))) {
                    autoSaveNow();
                }
            }
        });
    }

    /** Focus follows the editor group the caret lives in. */
    private void installFocusTracking() {
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addPropertyChangeListener("focusOwner", e -> {
            Component c = e.getNewValue() instanceof Component ? (Component) e.getNewValue() : null;
            if (c == null) {
                return;
            }
            for (int i = 0; i < groups.size(); i++) {
                if (SwingUtilities.isDescendingFrom(c, groups.get(i)) && activeGroupIndex != i) {
                    activeGroupIndex = i;
                    activeEditorChanged();
                    return;
                }
            }
        });
    }

    private void installGlobalKeys() {
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(e -> {
            if (e.getID() != KeyEvent.KEY_PRESSED || !isActive()) {
                return false;
            }
            if (quickOpen != null && quickOpen.isVisible()) {
                return false;
            }
            if (MenuSelectionManager.defaultManager().getSelectedPath().length > 0) {
                return false;
            }
            return handleGlobalKey(e);
        });
    }

    private boolean handleGlobalKey(KeyEvent e) {
        int mods = e.getModifiersEx();
        boolean ctrl = (mods & KeyEvent.CTRL_DOWN_MASK) != 0;
        boolean shift = (mods & KeyEvent.SHIFT_DOWN_MASK) != 0;
        boolean alt = (mods & KeyEvent.ALT_DOWN_MASK) != 0;
        // A pending Ctrl+K turns the next key into the second half of a chord. The window is
        // short so a stray Ctrl+K does not swallow an unrelated keystroke much later.
        if (chordK != 0 && System.currentTimeMillis() - chordK < 1500) {
            chordK = 0;
            if (e.getKeyCode() == KeyEvent.VK_Z && !ctrl && !alt && !shift) {
                toggleZenMode();
                return true;
            }
            if (ctrl && !alt) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_0 -> {
                        foldAllActive();
                        return true;
                    }
                    case KeyEvent.VK_J -> {
                        unfoldAllActive();
                        return true;
                    }
                    default -> {
                        return false;
                    }
                }
            }
            return false;
        }
        chordK = 0;
        if (!ctrl) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_F5 -> {
                    if (shift) {
                        stopRun();
                    } else {
                        runActiveFile(!alt);
                    }
                    return true;
                }
                case KeyEvent.VK_F8 -> {
                    goToProblem(shift ? -1 : 1);
                    return true;
                }
                case KeyEvent.VK_F2 -> {
                    renameSymbol();
                    return true;
                }
                case KeyEvent.VK_F12 -> {
                    if (shift) {
                        findAllReferences();
                    } else {
                        goToDefinition();
                    }
                    return true;
                }
                case KeyEvent.VK_F11 -> {
                    toggleFullScreen();
                    return true;
                }
                case KeyEvent.VK_Z -> {
                    if (alt && !shift) {
                        toggleWordWrap();
                        return true;
                    }
                    return false;
                }
                default -> {
                    return false;
                }
            }
        }
        if (ctrl && alt) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_O -> openFolderDialog();
                case KeyEvent.VK_S -> saveAll();
                case KeyEvent.VK_W -> closeAllEditors();
                default -> {
                    return false;
                }
            }
            return true;
        }
        if (!ctrl) {
            return false;
        }
        switch (e.getKeyCode()) {
            case KeyEvent.VK_K -> {
                if (!shift && !alt) {
                    chordK = System.currentTimeMillis();
                    return true;
                }
                return false;
            }
            case KeyEvent.VK_OPEN_BRACKET -> {
                if (shift) {
                    foldActive();
                } else {
                    activeText(p -> p.indentSelection(true));
                }
            }
            case KeyEvent.VK_CLOSE_BRACKET -> {
                if (shift) {
                    unfoldActive();
                } else {
                    activeText(p -> p.indentSelection(false));
                }
            }
            case KeyEvent.VK_N -> {
                if (shift) {
                    newFileFromPalette();
                } else {
                    newFile();
                }
            }
            case KeyEvent.VK_O -> {
                if (shift) {
                    openQuick(QuickOpen.MODE_SYMBOL);
                } else {
                    openFileDialog();
                }
            }
            case KeyEvent.VK_P -> {
                if (shift) {
                    openQuick(QuickOpen.MODE_COMMAND);
                } else {
                    openQuick(QuickOpen.MODE_FILE);
                }
            }
            case KeyEvent.VK_S -> {
                if (shift) {
                    saveActiveAs();
                } else if (!alt) {
                    saveActive();
                } else {
                    return false;
                }
            }
            case KeyEvent.VK_W -> {
                if (shift) {
                    return false;
                }
                closeActiveEditor();
            }
            case KeyEvent.VK_F -> {
                if (shift) {
                    showView("search");
                } else {
                    openFind(false);
                }
            }
            case KeyEvent.VK_H -> openFind(true);
            case KeyEvent.VK_G -> {
                if (shift) {
                    showView("scm");
                } else {
                    openQuick(QuickOpen.MODE_LINE);
                }
            }
            case KeyEvent.VK_E -> {
                if (shift) {
                    showView("explorer");
                } else {
                    return false;
                }
            }
            case KeyEvent.VK_D -> {
                if (shift) {
                    showView("run");
                } else {
                    return false;
                }
            }
            case KeyEvent.VK_X -> {
                if (shift) {
                    extensionsRequested();
                } else {
                    return false;
                }
            }
            case KeyEvent.VK_F5 -> runActiveFile(false);
            case KeyEvent.VK_M -> {
                if (shift) {
                    showProblems();
                } else {
                    return false;
                }
            }
            case KeyEvent.VK_B -> toggleSideBar();
            case KeyEvent.VK_J -> togglePanel();
            case KeyEvent.VK_U -> {
                if (shift) {
                    showPanelView(PanelArea.OUTPUT);
                } else {
                    return false;
                }
            }
            case KeyEvent.VK_COMMA -> openSettings();
            case KeyEvent.VK_I -> {
                if (shift) {
                    formatActive();
                } else {
                    return false;
                }
            }
            case KeyEvent.VK_Z -> {
                if (!alt) {
                    return false;
                }
                toggleWordWrap();
            }
            case KeyEvent.VK_BACK_QUOTE -> toggleTerminal();
            case KeyEvent.VK_EQUALS, KeyEvent.VK_PLUS, KeyEvent.VK_ADD -> zoom(1);
            case KeyEvent.VK_MINUS, KeyEvent.VK_SUBTRACT -> zoom(-1);
            case KeyEvent.VK_0 -> zoom(0);
            case KeyEvent.VK_TAB -> {
                if (!shift) {
                    return false;
                }
                nextEditor(-1);
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /* menu bar                                                            */
    /* ------------------------------------------------------------------ */

    private JMenuBar buildMenuBar() {
        JMenuBar bar = new JMenuBar();
        bar.setBackground(theme.titleBg);
        bar.setBorder(null);

        JMenu file = menu("File");
        file.add(item("New Text File", "ctrl N", this::newFile));
        file.add(item("New File...", "", this::newFileFromPalette));
        file.add(item("Open File...", "ctrl O", this::openFileDialog));
        file.add(item("Open Folder...", "ctrl alt O", this::openFolderDialog));
        JMenu recent = menu("Open Recent");
        file.add(recent);
        recent.addMenuListener(new javax.swing.event.MenuListener() {
            @Override
            public void menuSelected(javax.swing.event.MenuEvent e) {
                recent.removeAll();
                List<String> folders = settings.getRecentFolders();
                if (folders.isEmpty()) {
                    JMenuItem none = new JMenuItem("No recent folders");
                    none.setEnabled(false);
                    recent.add(none);
                    return;
                }
                for (String path : folders) {
                    recent.add(item(new File(path).getName(), "", () -> openFolder(new File(path))));
                }
            }

            @Override
            public void menuDeselected(javax.swing.event.MenuEvent e) {
            }

            @Override
            public void menuCanceled(javax.swing.event.MenuEvent e) {
            }
        });
        file.addSeparator();
        file.add(item("Save", "ctrl S", this::saveActive));
        file.add(item("Save As...", "ctrl shift S", this::saveActiveAs));
        file.add(item("Save All", "ctrl alt S", this::saveAll));
        JCheckBoxMenuItem auto = new JCheckBoxMenuItem("Auto Save");
        auto.setSelected(!"off".equals(settings.get("editor.autoSave")));
        auto.addActionListener(e -> settings.set("editor.autoSave", auto.isSelected() ? "afterDelay" : "off"));
        file.add(auto);
        file.addSeparator();
        file.add(item("Settings", "ctrl COMMA", this::openSettings));
        file.add(item("Keyboard Shortcuts", "", this::showShortcuts));
        file.addSeparator();
        file.add(item("Close Editor", "ctrl W", this::closeActiveEditor));
        file.add(item("Close All Editors", "ctrl alt W", this::closeAllEditors));
        file.addSeparator();
        file.add(item("Exit", "alt F4", this::exit));

        JMenu edit = menu("Edit");
        edit.add(undoItem());
        edit.add(redoItem());
        edit.addSeparator();
        edit.add(item("Cut", "ctrl X", () -> textAction("cut")));
        edit.add(item("Copy", "ctrl C", () -> textAction("copy")));
        edit.add(item("Paste", "ctrl V", () -> textAction("paste")));
        edit.addSeparator();
        edit.add(item("Find", "ctrl F", () -> openFind(false)));
        edit.add(item("Replace", "ctrl H", () -> openFind(true)));
        edit.add(item("Find in Files", "ctrl shift F", () -> showView("search")));
        edit.addSeparator();
        edit.add(item("Toggle Line Comment", "ctrl SLASH", () -> activeText(CodeTextPane::toggleComment)));
        edit.add(item("Format Document", "ctrl shift I", this::formatActive));
        edit.add(item("Indent", "TAB", () -> activeText(p -> p.indentSelection(false))));
        edit.add(item("Outdent", "shift TAB", () -> activeText(p -> p.indentSelection(true))));
        edit.addSeparator();
        edit.add(item("Fold", "ctrl shift OPEN_BRACKET", this::foldActive));
        edit.add(item("Unfold", "ctrl shift CLOSE_BRACKET", this::unfoldActive));
        edit.add(item("Toggle Fold", "", this::toggleFoldActive));
        // Two stroke shortcuts have no accelerator form a menu can show; they are listed in the
        // Keyboard Shortcuts help instead.
        edit.add(item("Fold All", "", this::foldAllActive));
        edit.add(item("Unfold All", "", this::unfoldAllActive));
        edit.addSeparator();
        edit.add(item("Rename Symbol", "F2", this::renameSymbol));

        JMenu selection = menu("Selection");
        selection.add(item("Select All", "ctrl A", () -> activeText(CodeTextPane::selectAll)));
        selection.add(item("Select Current Line", "", () -> activeText(p -> p.selectLine(p.caretLine()))));
        selection.add(item("Expand Line Selection", "ctrl L", () -> activeText(p -> p.selectLine(p.caretLine()))));

        JMenu view = menu("View");
        view.add(item("Command Palette...", "ctrl shift P", () -> openQuick(QuickOpen.MODE_COMMAND)));
        view.add(item("Open View...", "", () -> openQuick(QuickOpen.MODE_HELP)));
        view.addSeparator();
        view.add(item("Explorer", "ctrl shift E", () -> showView("explorer")));
        view.add(item("Search", "ctrl shift F", () -> showView("search")));
        view.add(item("Source Control", "ctrl shift G", () -> showView("scm")));
        view.add(item("Run and Debug", "ctrl shift D", () -> showView("run")));
        view.add(item("Extensions", "", () -> showView("extensions")));
        view.add(item("Accounts", "", this::showAccounts));
        view.add(item("Settings", "ctrl COMMA", this::openSettings));
        view.addSeparator();
        view.add(item("Problems", "ctrl shift M", this::showProblems));
        view.add(item("Output", "ctrl shift U", () -> showPanelView(PanelArea.OUTPUT)));
        view.add(item("Debug Console", "", () -> showPanelView(PanelArea.DEBUG)));
        view.add(item("Terminal", "ctrl BACK_QUOTE", this::toggleTerminal));
        view.addSeparator();
        view.add(item("Toggle Primary Side Bar", "ctrl B", this::toggleSideBar));
        view.add(item("Toggle Panel", "ctrl J", this::togglePanel));
        view.add(item("Toggle Maximized Panel", "", this::toggleMaximizedPanel));
        view.add(item("Full Screen", "F11", this::toggleFullScreen));
        view.add(item("Toggle Zen Mode", "", this::toggleZenMode));
        view.addSeparator();
        JCheckBoxMenuItem wrap = new JCheckBoxMenuItem("Word Wrap");
        wrap.setSelected(settings.getBool("editor.wordWrap"));
        wrap.addActionListener(e -> toggleWordWrap());
        view.add(wrap);
        JCheckBoxMenuItem minimap = new JCheckBoxMenuItem("Minimap");
        minimap.setSelected(settings.getBool("editor.minimap"));
        minimap.addActionListener(e -> {
            settings.set("editor.minimap", String.valueOf(minimap.isSelected()));
        });
        view.add(minimap);
        view.addSeparator();
        view.add(item("Zoom In", "ctrl EQUALS", () -> zoom(1)));
        view.add(item("Zoom Out", "ctrl MINUS", () -> zoom(-1)));
        view.add(item("Reset Zoom", "ctrl 0", () -> zoom(0)));
        view.addSeparator();
        view.add(item("Color Theme", "", this::toggleTheme));
        view.add(item("Split Editor", "", this::splitEditor));
        view.add(item("Unsplit Editor", "", this::unsplitEditor));

        JMenu go = menu("Go");
        go.add(item("Go to Definition", "F12", this::goToDefinition));
        go.add(item("Find All References", "shift F12", this::findAllReferences));
        go.addSeparator();
        go.add(item("Go to File...", "ctrl P", () -> openQuick(QuickOpen.MODE_FILE)));
        go.add(item("Go to Symbol in Editor...", "ctrl shift O", () -> openQuick(QuickOpen.MODE_SYMBOL)));
        go.add(item("Go to Line/Column...", "ctrl G", () -> openQuick(QuickOpen.MODE_LINE)));
        go.addSeparator();
        go.add(item("Next Problem", "F8", () -> goToProblem(1)));
        go.add(item("Previous Problem", "shift F8", () -> goToProblem(-1)));
        go.addSeparator();
        go.add(item("Next Editor", "ctrl TAB", () -> nextEditor(1)));
        go.add(item("Previous Editor", "ctrl shift TAB", () -> nextEditor(-1)));

        JMenu run = menu("Run");
        run.add(item("Start Debugging", "F5", () -> runActiveFile(true)));
        run.add(item("Run Without Debugging", "ctrl F5", () -> runActiveFile(false)));
        run.add(item("Stop", "shift F5", this::stopRun));
        run.addSeparator();
        run.add(item("Show Run and Debug", "ctrl shift D", () -> showView("run")));
        run.add(item("Remove All Breakpoints", "", Breakpoints::clear));
        run.add(item("Detected Toolchain", "", () -> runPanel.showToolchainText()));

        JMenu terminal = menu("Terminal");
        terminal.add(item("New Terminal", "ctrl shift BACK_QUOTE", () -> panelArea.terminals().newTerminal()));
        terminal.add(item("New Terminal in Workspace Folder", "", () -> panelArea.terminals().newTerminal(workspace.getRoot())));
        terminal.addSeparator();
        terminal.add(item("Kill Terminal", "", () -> panelArea.terminals().killCurrent()));
        terminal.add(item("Clear Terminal", "", () -> panelArea.terminals().clearCurrent()));
        terminal.add(item("Run Active File in Terminal", "", this::runInTerminal));

        JMenu pluginsMenu = buildPluginsMenu();

        JMenu accountsMenu = menu("Accounts");
        accountsMenu.add(item("Manage Accounts", "", this::showAccounts));
        JMenuItem signOut = item("Sign Out", "", this::signOut);
        // Nothing to sign out of yet: shown greyed rather than hidden, so the entry point is
        // discoverable before an account exists.
        signOut.setEnabled(Account.current() != null);
        accountsMenu.add(signOut);
        accountsMenu.addSeparator();
        accountsMenu.add(item("Add Local Account...", "", () -> showAccounts()));
        accountsMenu.add(item("Sign in with GitHub...", "", () -> showAccounts()));

        JMenu help = menu("Help");
        help.add(item("Welcome", "", () -> showView("welcome")));
        help.add(item("Keyboard Shortcuts", "", this::showShortcuts));
        help.add(item("Documentation", "", () -> showAbout()));
        help.addSeparator();
        help.add(item("About CodeStudio", "", this::showAbout));

        bar.add(file);
        bar.add(edit);
        bar.add(selection);
        bar.add(view);
        bar.add(go);
        bar.add(run);
        bar.add(terminal);
        bar.add(accountsMenu);
        bar.add(pluginsMenu);
        bar.add(help);
        return bar;
    }

    /**
     * The Plugins menu: one item per contributed command, then the management entries.
     *
     * <p>Rebuilt whenever plugins are reloaded, so a command that has just been loaded appears
     * without a restart. The category is prefixed to the title because a menu has no group headers
     * to separate two plugins that both contribute a command called "Format".
     */
    private JMenu buildPluginsMenu() {
        JMenu pluginsMenu = menu("Plugins");

        List<PluginManager.Command> contributed = plugins.commands();
        for (PluginManager.Command command : contributed) {
            // Not looked up in the translation table: a plugin authors its own words, and inventing
            // a translation for text we do not own would be worse than showing it as written.
            pluginsMenu.add(item(command.category() + ": " + command.title(),
                    command.keybinding(), command.action()));
        }
        if (!contributed.isEmpty()) {
            pluginsMenu.addSeparator();
        }

        pluginsMenu.add(item("Manage Extensions", "", () -> showView("extensions")));
        pluginsMenu.add(item("Reload Plugins", "", this::reloadPlugins));
        pluginsMenu.add(item("Open Plugins Folder", "", this::openPluginsFolder));
        return pluginsMenu;
    }

    /** Signs out of the current account and hands the workbench back to an empty session. */
    private void signOut() {
        if (Account.current() == null) {
            return;
        }
        Account.setCurrent(null);
        accounts.rebuild();
        switchAccountSession(null);
    }

    /** Opens the plugins directory in the desktop file manager, creating it if it is not there yet. */
    private void openPluginsFolder() {
        try {
            java.nio.file.Path dir = plugins.directory();
            java.nio.file.Files.createDirectories(dir);
            java.awt.Desktop.getDesktop().open(dir.toFile());
        } catch (Exception e) {
            notify("Could not open the plugins folder: " + e.getMessage(), true);
        }
    }

    private JMenu menu(String text) {
        JMenu m = new JMenu(Strings.get(text));
        m.setFont(UI.ui(12.5f));
        m.setForeground(theme.titleFg);
        return m;
    }

    private JMenuItem item(String text, String accelerator, Runnable action) {
        JMenuItem mi = new JMenuItem(Strings.get(text));
        mi.setFont(UI.ui(12.5f));
        mi.setForeground(theme.panelFg);
        mi.setBackground(theme.widgetBg);
        if (accelerator != null && !accelerator.isBlank()) {
            KeyStroke stroke = stroke(accelerator);
            if (stroke != null) {
                mi.setAccelerator(stroke);
            }
        }
        mi.addActionListener(e -> action.run());
        return mi;
    }

    /** Parses an accelerator, tolerating unknown key names instead of failing the build. */
    private static KeyStroke stroke(String text) {
        try {
            return KeyStroke.getKeyStroke(text);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private JMenuItem undoItem() {
        JMenuItem mi = item("Undo", "ctrl Z", () -> {
            EditorPanel p = activeEditor();
            if (p != null && p.bundle().undo.canUndo()) {
                p.bundle().undo.undo();
            }
        });
        return mi;
    }

    private JMenuItem redoItem() {
        return item("Redo", "ctrl Y", () -> {
            EditorPanel p = activeEditor();
            if (p != null && p.bundle().undo.canRedo()) {
                p.bundle().undo.redo();
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* EditorPanel.Actions                                                 */
    /* ------------------------------------------------------------------ */

    @Override
    public void runFile(DocumentBundle bundle) {
        if (bundle == null || bundle.file == null) {
            notify("Save the file before running it", true);
            return;
        }
        runFile(bundle.file, false);
    }

    @Override
    public void splitEditor() {
        if (groups.size() >= 2) {
            setActiveGroup(1 - activeGroupIndex);
            return;
        }
        EditorGroup second = createGroup();
        List<DocumentBundle> open = new ArrayList<>(workspace.documents());
        EditorPanel current = currentGroup().active();
        for (DocumentBundle b : open) {
            if (current != null && b == current.bundle()) {
                continue;
            }
            second.open(b);
            break;
        }
        applyEditorLayout();
        setActiveGroup(1);
        notify("Editor split. Documents live in one group at a time.", false);
    }

    public void unsplitEditor() {
        if (groups.size() < 2) {
            return;
        }
        EditorGroup second = groups.get(1);
        EditorGroup first = groups.get(0);
        for (EditorPanel p : new ArrayList<>(second.editors())) {
            DocumentBundle b = p.bundle();
            second.release(p);
            first.open(b);
        }
        groups.remove(second);
        applyEditorLayout();
        setActiveGroup(0);
    }

    @Override
    public void showEditorMenu(Component invoker, DocumentBundle bundle) {
        EditorPanel panel = findPanel(bundle);
        EditorGroup group = groupOf(panel);
        JPopupMenu menu = new JPopupMenu();
        menu.setBackground(theme.widgetBg);
        addMenuItem(menu, "Save", () -> saveBundle(bundle));
        addMenuItem(menu, "Save As...", () -> SavePrompt.saveAs(this, bundle, settings, this));
        addMenuItem(menu, "Close", () -> {
            if (panel != null && group != null) {
                group.close(panel);
            }
        });
        addMenuItem(menu, "Close Others", () -> {
            if (panel != null && group != null) {
                group.closeOthers(panel);
            }
        });
        addMenuItem(menu, "Close Saved", () -> {
            if (group != null) {
                group.closeSaved();
            }
        });
        addMenuItem(menu, "Close All", () -> {
            if (group != null) {
                group.closeAll();
            }
        });
        menu.addSeparator();
        addMenuItem(menu, "Run File", () -> runFile(bundle));
        addMenuItem(menu, "Split Editor", this::splitEditor);
        menu.addSeparator();
        addMenuItem(menu, "Fold", () -> {
            if (panel != null && !panel.editor().foldAtCaret()) {
                notify("Nothing to fold on this line", true);
            }
        });
        addMenuItem(menu, "Unfold", () -> {
            if (panel != null) {
                panel.editor().unfoldAtCaret();
            }
        });
        addMenuItem(menu, "Toggle Fold", () -> {
            if (panel != null && !panel.editor().toggleFoldAtCaret()) {
                notify("Nothing to fold on this line", true);
            }
        });
        addMenuItem(menu, "Fold All", this::foldAllActive);
        addMenuItem(menu, "Unfold All", this::unfoldAllActive);
        menu.addSeparator();
        addMenuItem(menu, "Rename Symbol", this::renameSymbol);
        menu.addSeparator();
        addMenuItem(menu, "Copy Path", () -> {
            if (bundle.file != null) {
                copyToClipboard(bundle.file.getAbsolutePath());
            }
        });
        addMenuItem(menu, "Copy Relative Path", () -> {
            if (bundle.file != null) {
                copyToClipboard(workspace.relative(bundle.file));
            }
        });
        addMenuItem(menu, "Reveal in File Explorer", () -> {
            if (bundle.file != null) {
                revealInOS(bundle.file);
            }
        });
        menu.show(invoker, 0, invoker.getHeight());
    }

    private void addMenuItem(JPopupMenu menu, String text, Runnable action) {
        JMenuItem item = new JMenuItem(text);
        item.setFont(UI.ui(12.5f));
        item.setForeground(theme.panelFg);
        item.setBackground(theme.widgetBg);
        item.addActionListener(e -> SwingUtilities.invokeLater(action));
        menu.add(item);
    }

    /**
     * Shows a notification. The message is translated here so the many {@code notify("...")} call
     * sites need no change. {@link Strings#prefix} rather than {@code get} because these messages
     * are frequently assembled by concatenation — {@code notify("Deleted " + name)} — and the
     * assembled text is not itself a key.
     */
    @Override
    public void notify(String message) {
        String text = Strings.prefix(message);
        notifications.info(text);
        statusBar.setMessage(text, 3000);
    }

    /* ------------------------------------------------------------------ */
    /* ExplorerPanel.Actions                                               */
    /* ------------------------------------------------------------------ */

    @Override
    public void openFolder() {
        openFolderDialog();
    }

    @Override
    public void openFile() {
        openFileDialog();
    }

    @Override
    public void openFile(File f) {
        if (f == null) {
            return;
        }
        if (f.isDirectory()) {
            openFolder(f);
            return;
        }
        try {
            openDocument(workspace.open(f));
        } catch (IOException e) {
            notify("Could not open " + f.getName() + ": " + e.getMessage(), true);
        }
    }

    @Override
    public void openFolder(File dir) {
        if (dir == null || !dir.isDirectory()) {
            return;
        }
        workspace.setRoot(dir);
        showView("explorer");
        sideBar.setSideBarVisible(true);
        notify("Opened folder " + dir.getName(), false);
    }

    @Override
    public void notify(String message, boolean error) {
        String text = Strings.prefix(message);
        notifications.show(text, error);
        statusBar.setMessage(text, error ? 5000 : 3000);
    }

    @Override
    public void runInTerminal(File dir) {
        panelArea.show(PanelArea.TERMINAL);
        setPanelVisible(true);
        panelArea.terminals().newTerminal(dir);
    }

    @Override
    public void revealInOS(File file) {
        if (file == null || !file.exists()) {
            notify("Path no longer exists", true);
            return;
        }
        try {
            if (Runner.isWindows()) {
                if (file.isDirectory()) {
                    new ProcessBuilder("explorer.exe", file.getAbsolutePath()).start();
                } else {
                    new ProcessBuilder("explorer.exe", "/select," + file.getAbsolutePath()).start();
                }
            } else if (System.getProperty("os.name", "").toLowerCase().contains("mac")) {
                new ProcessBuilder("open", file.isDirectory() ? file.getAbsolutePath() : file.getParent()).start();
            } else {
                new ProcessBuilder("xdg-open", file.isDirectory() ? file.getAbsolutePath() : file.getParent()).start();
            }
        } catch (IOException e) {
            notify("Could not open the file manager: " + e.getMessage(), true);
        }
    }

    @Override
    public void refreshExplorer() {
        explorer.refreshAll();
        workspace.invalidateIndex();
        search.setStatusText("Workspace index refreshed");
    }

    @Override
    public void closeDocument(File f) {
        DocumentBundle b = workspace.get(f);
        if (b == null) {
            return;
        }
        for (EditorGroup g : groups) {
            EditorPanel p = g.find(b);
            if (p != null) {
                g.close(p);
                return;
            }
        }
        workspace.close(b);
    }

    @Override
    public void requestNewFile(File parentDir) {
        String name = Dialogs.prompt(this, theme, "New File", "Name of the new file:", "");
        if (name != null && !name.isBlank()) {
            explorer.createFile(parentDir != null ? parentDir : workspace.getRoot(), name);
        }
    }

    @Override
    public void requestNewFolder(File parentDir) {
        String name = Dialogs.prompt(this, theme, "New Folder", "Name of the new folder:", "");
        if (name != null && !name.isBlank()) {
            explorer.createFolder(parentDir != null ? parentDir : workspace.getRoot(), name);
        }
    }

    /* ------------------------------------------------------------------ */
    /* SearchPanel.Actions                                                 */
    /* ------------------------------------------------------------------ */

    @Override
    public void openAt(File file, int line, int column, int length) {
        try {
            DocumentBundle b = workspace.open(file);
            EditorPanel panel = openDocument(b);
            if (panel != null) {
                SwingUtilities.invokeLater(() -> {
                    CodeTextPane text = panel.editor();
                    text.gotoLine(line, column);
                    if (length > 0 && column + length <= text.lineCount()) {
                        int start = text.offsetOfLine(line) + column;
                        text.select(Math.min(start, text.getDocument().getLength()),
                                Math.min(start + length, text.getDocument().getLength()));
                    }
                });
            }
        } catch (IOException e) {
            notify("Could not open " + file.getName() + ": " + e.getMessage(), true);
        }
    }

    @Override
    public void filesChanged(List<File> files) {
        for (File f : files) {
            DocumentBundle b = workspace.get(f);
            if (b == null) {
                continue;
            }
            for (EditorGroup g : groups) {
                EditorPanel p = g.find(b);
                if (p != null) {
                    p.syncAfterExternalChange();
                }
            }
        }
        if (!files.isEmpty()) {
            explorer.refreshAll();
            git.refreshAsync(true);
        }
    }

    /* ------------------------------------------------------------------ */
    /* GitPanel.Actions                                                    */
    /* ------------------------------------------------------------------ */

    @Override
    public void openDiff(File file, boolean staged) {
        File root = Git.findRoot(workspace.getRoot());
        if (root == null || file == null) {
            return;
        }
        String patch = Git.diff(root, file, staged);
        String title = "Diff: " + file.getName() + (staged ? " (staged)" : "");
        Dialogs.textDialog(this, theme, title, patch.isBlank() ? "(no changes)" : patch, 900, 620);
    }

    /* ------------------------------------------------------------------ */
    /* RunPanel.Actions                                                    */
    /* ------------------------------------------------------------------ */

    @Override
    public void runActiveFile(boolean debug) {
        EditorPanel panel = activeEditor();
        if (panel == null) {
            notify("Open a file to run it", true);
            return;
        }
        DocumentBundle b = panel.bundle();
        if (!saveBundle(b)) {
            return;
        }
        if (b.file == null) {
            notify("This buffer has no file on disk", true);
            return;
        }
        runFile(b.file, debug);
    }

    @Override
    public void runFile(File file, boolean debug) {
        if (file == null) {
            return;
        }
        if (runner.isRunning()) {
            notify("A program is already running. Stop it first.", true);
            return;
        }
        Runner.Plan plan = runner.planFor(file, debug);
        if (!plan.isValid()) {
            notify(plan.problem == null ? "Cannot run " + file.getName() : plan.problem, true);
            return;
        }
        problems.clear();
        problemParser.reset();
        panelArea.output().showChannel(OutputView.TASKS);
        if (debug) {
            panelArea.debugConsole().showChannel(OutputView.DEBUG);
        }
        panelArea.show(debug ? PanelArea.DEBUG : PanelArea.OUTPUT);
        setPanelVisible(true);
        runPanel.setRunState(true, plan.name);
        OutputView console = debug ? panelArea.debugConsole() : panelArea.output();
        console.appendLine(debug ? OutputView.DEBUG : OutputView.TASKS, "> " + plan.name);
        runner.setListener(new Runner.Listener() {
            @Override
            public void onStarted(String commandLine, File dir) {
                SwingUtilities.invokeLater(() -> runPanel.setRunState(true, plan.name));
            }

            @Override
            public void onOutput(String line, boolean stderr) {
                console.appendLine(debug ? OutputView.DEBUG : OutputView.TASKS, line);
                Problems.Problem problem = problemParser.parse(line, plan.file.getParentFile());
                if (problem != null) {
                    problems.add(problem);
                }
            }

            @Override
            public void onFinished(int exitCode, long millis, boolean stopped) {
                String status = stopped ? "stopped" : "exit code " + exitCode;
                console.appendLine(debug ? OutputView.DEBUG : OutputView.TASKS,
                        "-- " + plan.name + " finished (" + status + ") in " + millis + " ms");
                SwingUtilities.invokeLater(() -> {
                    runPanel.setRunState(false, plan.name);
                    MainWindow.this.notify(plan.name + " finished: " + status, exitCode != 0 && !stopped);
                });
                refreshGitInfo();
            }
        });
        runner.start(plan);
    }

    @Override
    public void stopRun() {
        if (!runner.isRunning()) {
            notify("Nothing is running", false);
            return;
        }
        runner.stop();
        notify("Stopped", false);
    }

    @Override
    public void openAt(File file, int line) {
        openAt(file, line, 0, 0);
    }

    @Override
    public void openAt(File file, int line, int column) {
        openAt(file, line, column, 0);
    }

    /* ------------------------------------------------------------------ */
    /* Settings / Welcome / Status bar / Panel actions                     */
    /* ------------------------------------------------------------------ */

    @Override
    public void openSettingsFile() {
        File dir = Settings.DIR.toFile();
        if (!dir.exists() && !dir.mkdirs()) {
            notify("Could not create " + dir, true);
            return;
        }
        openFile(new File(dir, "settings.properties"));
    }

    @Override
    public void resetSettings() {
        int choice = Dialogs.confirm(this, theme, "Reset Settings",
                "Reset every setting to its default value?", "Reset", "Cancel");
        if (choice != 0) {
            return;
        }
        for (var e : Settings.DEFAULTS.entrySet()) {
            settings.set(e.getKey(), e.getValue());
        }
        settings.saveNow();
        settingsPanel.rebuild();
        notify("Settings reset to defaults", false);
    }

    @Override
    public void newFile() {
        openDocument(workspace.openUntitled(Language.plain()));
    }

    private void newFileFromPalette() {
        String name = Dialogs.prompt(this, theme, "New File",
                "Path of the new file (relative to the open folder):", "untitled.txt");
        if (name == null || name.isBlank()) {
            return;
        }
        File root = workspace.getRoot();
        if (root == null) {
            notify("Open a folder first", true);
            return;
        }
        explorer.createFile(root, name);
    }

    private void openFileDialog() {
        File f = Dialogs.chooseFile(this, theme, false, null, workspace.getRoot());
        if (f != null) {
            openFile(f);
        }
    }

    private void openFolderDialog() {
        File dir = Dialogs.chooseDirectory(this, theme, workspace.getRoot());
        if (dir != null) {
            openFolder(dir);
        }
    }

    @Override
    public void openPath(String path) {
        if (path == null || path.isBlank()) {
            return;
        }
        File f = new File(path);
        if (f.isDirectory()) {
            openFolder(f);
        } else if (f.isFile()) {
            openFile(f);
        } else {
            notify("Path not found: " + path, true);
        }
    }

    @Override
    public void cloneRepository() {
        String url = Dialogs.prompt(this, theme, "Clone Git Repository",
                "Repository URL (https://... or git@...):", "");
        if (url == null || url.isBlank()) {
            return;
        }
        File parent = Dialogs.chooseDirectory(this, theme, workspace.getRoot());
        if (parent == null) {
            return;
        }
        panelArea.show(PanelArea.TERMINAL);
        setPanelVisible(true);
        TerminalView tv = panelArea.terminals().newTerminal(parent);
        tv.runCommand("git clone " + url.trim());
        notify("Cloning into " + parent.getName() + "...", false);
    }

    @Override
    public void showShortcuts() {
        Dialogs.textDialog(this, theme, "Keyboard Shortcuts", shortcutsText(), 720, 560);
    }

    @Override
    public void showAbout() {
        Dialogs.info(this, theme, "About CodeStudio", aboutText());
    }

    /**
     * The text of the About box. Split out of {@link #showAbout()} so the self test can check it
     * without opening a modal dialog.
     */
    public String aboutText() {
        StringBuilder sb = new StringBuilder();
        sb.append("CodeStudio ").append(VERSION).append("\n\n")
                .append(DESCRIPTION).append('\n')
                .append(Strings.format("Language: {0}", Strings.modeLabel(Strings.current())))
                .append('\n')
                .append(Strings.format("{0} plugin(s) loaded, {1} command(s) contributed.",
                        plugins.plugins().size(), plugins.commands().size()))
                .append('\n');
        Account current = Account.current();
        if (current != null) {
            sb.append(Strings.format("Signed in as {0}.", current.displayName)).append('\n');
        }
        sb.append('\n')
                .append("Java ").append(System.getProperty("java.version"))
                .append("  -  ").append(System.getProperty("os.name")).append(' ')
                .append(System.getProperty("os.arch"))
                .append('\n').append(Strings.get("Settings file: ")).append(settings.file());
        return sb.toString();
    }

    @Override
    public void openSettings() {
        showView("settings");
        settingsPanel.rebuild();
    }

    @Override
    public void toggleTheme() {
        Theme next = Theme.other(theme);
        settings.set("workbench.colorTheme", next.dark ? "dark" : "light");
        applyTheme(next);
    }

    @Override
    public void showProblems() {
        panelArea.show(PanelArea.PROBLEMS);
        setPanelVisible(true);
    }

    @Override
    public void showLanguagePicker() {
        EditorPanel p = activeEditor();
        if (p == null) {
            notify("No active editor", true);
            return;
        }
        List<Language> all = Language.all();
        String[] names = new String[all.size()];
        int selected = 0;
        for (int i = 0; i < all.size(); i++) {
            names[i] = Strings.languageName(all.get(i).id, all.get(i).name);
            if (all.get(i).id.equals(p.bundle().language == null ? "" : p.bundle().language.id)) {
                selected = i;
            }
        }
        pickFromList(names, selected, index -> {
            Language lang = all.get(index);
            p.bundle().language = lang;
            p.editor().setLanguage(lang);
            p.syncAfterExternalChange();
            updateActiveEditor();
        });
    }

    @Override
    public void showEncodingPicker() {
        EditorPanel p = activeEditor();
        if (p == null) {
            return;
        }
        int selected = 0;
        for (int i = 0; i < ENCODINGS.length; i++) {
            if (ENCODINGS[i].equalsIgnoreCase(p.bundle().encoding)) {
                selected = i;
            }
        }
        pickFromList(ENCODINGS, selected, index -> {
            DocumentBundle b = p.bundle();
            String enc = ENCODINGS[index];
            if (b.file != null) {
                try {
                    byte[] bytes = Files.readAllBytes(b.file.toPath());
                    b.reload(new String(bytes, Charset.forName(enc)));
                    b.encoding = enc;
                    p.syncAfterExternalChange();
                } catch (Exception e) {
                    notify("Could not reopen with " + enc + ": " + e.getMessage(), true);
                    return;
                }
            } else {
                b.encoding = enc;
            }
            updateActiveEditor();
            notify("Encoding set to " + enc, false);
        });
    }

    @Override
    public void showEolPicker() {
        EditorPanel p = activeEditor();
        if (p == null) {
            return;
        }
        String[] options = {"\n", "\r\n"};
        pickFromList(new String[]{"LF", "CRLF"}, p.bundle().eol.equals("\r\n") ? 1 : 0, index -> {
            p.bundle().eol = options[index];
            updateActiveEditor();
        });
    }

    @Override
    public void showIndentPicker() {
        String[] labels = new String[6];
        for (int i = 0; i < 6; i++) {
            labels[i] = "Spaces: " + (i + 2);
        }
        int size = Math.max(2, Math.min(7, settings.getInt("editor.tabSize")));
        pickFromList(labels, size - 2, index -> {
            settings.set("editor.tabSize", String.valueOf(index + 2));
            settings.set("editor.insertSpaces", "true");
            updateActiveEditor();
        });
    }

    @Override
    public void showBranchPicker() {
        File root = Git.findRoot(workspace.getRoot());
        if (root == null) {
            notify("This folder is not a Git repository", true);
            return;
        }
        List<String> branches = Git.branches(root);
        if (branches.isEmpty()) {
            notify("No branches found", true);
            return;
        }
        String[] items = new String[branches.size() + 1];
        for (int i = 0; i < branches.size(); i++) {
            items[i] = branches.get(i);
        }
        items[branches.size()] = "Create Branch...";
        pickFromList(items, 0, index -> {
            if (index == branches.size()) {
                String name = Dialogs.prompt(this, theme, "Create Branch", "Name of the new branch:", "");
                if (name != null && !name.isBlank()) {
                    String out = Git.run(root, "checkout", "-b", name.trim());
                    notify(out.isBlank() ? "Switched to a new branch " + name : out, !out.isBlank());
                    git.refreshAsync(true);
                    refreshGitInfo();
                }
                return;
            }
            String out = Git.run(root, "checkout", branches.get(index));
            notify(out.isBlank() ? "Switched to " + branches.get(index) : out, !out.isBlank());
            git.refreshAsync(true);
            refreshGitInfo();
        });
    }

    @Override
    public void showNotifications() {
        List<String> history = notifications.history();
        StringBuilder sb = new StringBuilder();
        for (String line : history) {
            sb.append("- ").append(line).append('\n');
        }
        Dialogs.textDialog(this, theme, Strings.get("Notifications"),
                sb.length() == 0 ? Strings.get("No notifications yet.") : sb.toString(), 520, 360);
    }

    @Override
    public void showTerminal() {
        toggleTerminal();
    }

    @Override
    public void closePanel() {
        setPanelVisible(false);
    }

    @Override
    public void toggleMaximized() {
        toggleMaximizedPanel();
    }

    /* ------------------------------------------------------------------ */
    /* ActivityBar.Listener                                                */
    /* ------------------------------------------------------------------ */

    @Override
    public void activitySelected(String viewId) {
        if (sideBar.isVisible() && viewId.equals(sideBar.currentView())) {
            setSideBarVisible(false);
            return;
        }
        showView(viewId);
    }

    @Override
    public void activityRepeated(String viewId) {
        if (sideBar.isVisible() && viewId.equals(sideBar.currentView())) {
            setSideBarVisible(false);
        } else {
            showView(viewId);
        }
    }

    @Override
    public void extensionsRequested() {
        showView("extensions");
    }

    @Override
    public void accountsRequested() {
        showView("accounts");
    }

    @Override
    public void notificationsRequested() {
        showNotifications();
    }

    /* ------------------------------------------------------------------ */
    /* OutlinePanel.Navigator                                              */
    /* ------------------------------------------------------------------ */

    @Override
    public void goTo(int line, int column) {
        EditorPanel p = activeEditor();
        if (p != null) {
            p.activate();
            p.editor().gotoLine(line, column);
        }
    }

    /* ------------------------------------------------------------------ */
    /* QuickOpen.Provider                                                  */
    /* ------------------------------------------------------------------ */

    @Override
    public List<QuickOpen.Command> commands() {
        List<QuickOpen.Command> list = new ArrayList<>();
        add(list, "File", "New Text File", "Ctrl+N", this::newFile);
        add(list, "File", "New File...", "", this::newFileFromPalette);
        add(list, "File", "Open File...", "Ctrl+O", this::openFileDialog);
        add(list, "File", "Open Folder...", "Ctrl+Alt+O", this::openFolderDialog);
        add(list, "File", "Save", "Ctrl+S", this::saveActive);
        add(list, "File", "Save As...", "Ctrl+Shift+S", this::saveActiveAs);
        add(list, "File", "Save All", "Ctrl+Alt+S", this::saveAll);
        add(list, "File", "Toggle Auto Save", "", () -> settings.set("editor.autoSave",
                "off".equals(settings.get("editor.autoSave")) ? "afterDelay" : "off"));
        add(list, "File", "Close Editor", "Ctrl+W", this::closeActiveEditor);
        add(list, "File", "Close All Editors", "Ctrl+Alt+W", this::closeAllEditors);
        add(list, "File", "Reveal Active File in Explorer", "", this::revealActiveInExplorer);
        add(list, "File", "Refresh Explorer", "", this::refreshExplorer);

        add(list, "Edit", "Undo", "Ctrl+Z", () -> {
            EditorPanel p = activeEditor();
            if (p != null && p.bundle().undo.canUndo()) {
                p.bundle().undo.undo();
            }
        });
        add(list, "Edit", "Redo", "Ctrl+Y", () -> {
            EditorPanel p = activeEditor();
            if (p != null && p.bundle().undo.canRedo()) {
                p.bundle().undo.redo();
            }
        });
        add(list, "Edit", "Find", "Ctrl+F", () -> openFind(false));
        add(list, "Edit", "Replace", "Ctrl+H", () -> openFind(true));
        add(list, "Edit", "Find in Files", "Ctrl+Shift+F", () -> showView("search"));
        add(list, "Edit", "Toggle Line Comment", "Ctrl+/", () -> activeText(CodeTextPane::toggleComment));
        add(list, "Edit", "Format Document", "Ctrl+Shift+I", this::formatActive);
        add(list, "Edit", "Trigger Suggest", "Ctrl+Space", () -> activeText(CodeTextPane::triggerSuggest));
        add(list, "Edit", "Toggle Fold", "Ctrl+Shift+[", this::toggleFoldActive);
        add(list, "Edit", "Fold", "", this::foldActive);
        add(list, "Edit", "Unfold", "", this::unfoldActive);
        add(list, "Edit", "Fold All", "Ctrl+K Ctrl+0", this::foldAllActive);
        add(list, "Edit", "Unfold All", "Ctrl+K Ctrl+J", this::unfoldAllActive);
        add(list, "Edit", "Rename Symbol", "F2", this::renameSymbol);

        add(list, "View", "Show All Commands", "Ctrl+Shift+P", () -> openQuick(QuickOpen.MODE_COMMAND));
        add(list, "View", "Go to File...", "Ctrl+P", () -> openQuick(QuickOpen.MODE_FILE));
        add(list, "View", "Go to Symbol in Editor...", "Ctrl+Shift+O", () -> openQuick(QuickOpen.MODE_SYMBOL));
        add(list, "View", "Go to Line/Column...", "Ctrl+G", () -> openQuick(QuickOpen.MODE_LINE));
        add(list, "View", "Show Explorer", "Ctrl+Shift+E", () -> showView("explorer"));
        add(list, "View", "Show Search", "Ctrl+Shift+F", () -> showView("search"));
        add(list, "View", "Show Source Control", "Ctrl+Shift+G", () -> showView("scm"));
        add(list, "View", "Show Run and Debug", "Ctrl+Shift+D", () -> showView("run"));
        add(list, "View", "Show Problems", "Ctrl+Shift+M", this::showProblems);
        add(list, "View", "Show Output", "Ctrl+Shift+U", () -> showPanelView(PanelArea.OUTPUT));
        add(list, "View", "Show Debug Console", "", () -> showPanelView(PanelArea.DEBUG));
        add(list, "View", "Toggle Terminal", "Ctrl+`", this::toggleTerminal);
        add(list, "View", "Toggle Primary Side Bar", "Ctrl+B", this::toggleSideBar);
        add(list, "View", "Toggle Panel", "Ctrl+J", this::togglePanel);
        add(list, "View", "Toggle Maximized Panel", "", this::toggleMaximizedPanel);
        add(list, "View", "Toggle Word Wrap", "Alt+Z", this::toggleWordWrap);
        add(list, "View", "Toggle Full Screen", "F11", this::toggleFullScreen);
        add(list, "View", "Toggle Zen Mode", "Ctrl+K Z", this::toggleZenMode);
        add(list, "View", "Zoom In", "Ctrl+=", () -> zoom(1));
        add(list, "View", "Zoom Out", "Ctrl+-", () -> zoom(-1));
        add(list, "View", "Reset Zoom", "Ctrl+0", () -> zoom(0));
        add(list, "View", "Split Editor", "", this::splitEditor);
        add(list, "View", "Unsplit Editor", "", this::unsplitEditor);
        add(list, "Preferences", "Open Settings", "Ctrl+,", this::openSettings);
        add(list, "Preferences", "Open Settings (JSON)", "", this::openSettingsFile);
        add(list, "Preferences", "Reset Settings", "", this::resetSettings);
        add(list, "Preferences", "Color Theme", "", this::toggleTheme);
        add(list, "Preferences", "Keyboard Shortcuts", "", this::showShortcuts);

        add(list, "Go", "Next Problem", "F8", () -> goToProblem(1));
        add(list, "Go", "Previous Problem", "Shift+F8", () -> goToProblem(-1));
        add(list, "Go", "Go to Definition", "F12", this::goToDefinition);
        add(list, "Go", "Find All References", "Shift+F12", this::findAllReferences);
        add(list, "Go", "Next Editor", "Ctrl+Tab", () -> nextEditor(1));
        add(list, "Go", "Previous Editor", "Ctrl+Shift+Tab", () -> nextEditor(-1));

        add(list, "Run", "Start Debugging", "F5", () -> runActiveFile(true));
        add(list, "Run", "Run Without Debugging", "Ctrl+F5", () -> runActiveFile(false));
        add(list, "Run", "Stop", "Shift+F5", this::stopRun);
        add(list, "Run", "Detected Toolchain", "", () -> runPanel.showToolchainText());
        add(list, "Run", "Remove All Breakpoints", "", Breakpoints::clear);

        add(list, "Terminal", "Create New Terminal", "Ctrl+Shift+`", () -> panelArea.terminals().newTerminal());
        add(list, "Terminal", "Kill Terminal", "", () -> panelArea.terminals().killCurrent());
        add(list, "Terminal", "Clear Terminal", "", () -> panelArea.terminals().clearCurrent());
        add(list, "Terminal", "Run Active File in Terminal", "", this::runInTerminal);

        add(list, "Git", "Refresh Source Control", "", () -> git.refreshAsync(true));
        add(list, "Git", "Clone Repository", "", this::cloneRepository);
        add(list, "Git", "Switch Branch...", "", this::showBranchPicker);

        add(list, "Help", "Welcome", "", () -> showView("welcome"));
        add(list, "Help", "About CodeStudio", "", this::showAbout);

        // Plugin commands go last so the built-in palette order never shifts. Their category and
        // title are shown exactly as the plugin authored them: a plugin's own words are not in the
        // translation table, and inventing a translation for text we do not own would be wrong.
        // The id keeps the built-in "category/title" shape so palette identity stays uniform.
        for (PluginManager.Command command : plugins.commands()) {
            list.add(new QuickOpen.Command(command.category() + "/" + command.title(),
                    command.category(), command.title(), command.keybinding(), command.action()));
        }
        return list;
    }

    /**
     * Registers a palette command. The id stays the English "category/title" so it remains a stable
     * identifier across languages; only the two displayed fields are translated.
     */
    private void add(List<QuickOpen.Command> list, String category, String title, String key, Runnable action) {
        list.add(new QuickOpen.Command(category + "/" + title,
                Strings.get(category), Strings.get(title), key, action));
    }

    @Override
    public List<OutlinePanel.Symbol> symbols() {
        EditorPanel p = activeEditor();
        if (p == null) {
            return Collections.emptyList();
        }
        return OutlinePanel.parse(p.editor().text(), p.bundle().language);
    }

    @Override
    public File activeFile() {
        EditorPanel p = activeEditor();
        return p == null ? null : p.bundle().file;
    }

    @Override
    public void openFile(File file, int line, int column) {
        openAt(file, line, column, 0);
    }

    /* ------------------------------------------------------------------ */
    /* open / save                                                         */
    /* ------------------------------------------------------------------ */

    private EditorPanel openDocument(DocumentBundle b) {
        return openDocument(b, 0, 0);
    }

    private EditorPanel openDocument(DocumentBundle b, int line, int column) {
        if (b == null) {
            return null;
        }
        EditorGroup target = currentGroup();
        for (EditorGroup g : groups) {
            if (g != target) {
                EditorPanel moved = g.find(b);
                if (moved != null) {
                    g.release(moved);
                }
            }
        }
        EditorPanel panel = target.open(b);
        if (line > 0 || column > 0) {
            SwingUtilities.invokeLater(() -> panel.editor().gotoLine(line, column));
        }
        hookAutoSave(panel);
        updateActiveEditor();
        return panel;
    }

    private void hookAutoSave(EditorPanel panel) {
        if (autoSaveHooked.add(panel.editor())) {
            panel.editor().addStateListener(this::onEditorStateChanged);
        }
        panel.bundle().addDirtyListener(this::updateTitle);
    }

    private void onEditorStateChanged() {
        if (!currentGroup().editors().contains(activeEditor())) {
            return;
        }
        String mode = settings.get("editor.autoSave");
        if ("afterDelay".equals(mode)) {
            autoSaveTimer.setInitialDelay(Math.max(300, settings.getInt("editor.autoSaveDelay")));
            autoSaveTimer.restart();
        }
        outlineTimer.restart();
    }

    private EditorPanel activeEditor() {
        return currentGroup().active();
    }

    private EditorPanel findPanel(DocumentBundle b) {
        for (EditorGroup g : groups) {
            EditorPanel p = g.find(b);
            if (p != null) {
                return p;
            }
        }
        return null;
    }

    private EditorGroup groupOf(EditorPanel panel) {
        if (panel == null) {
            return null;
        }
        for (EditorGroup g : groups) {
            if (g.editors().contains(panel)) {
                return g;
            }
        }
        return null;
    }

    private boolean saveBundle(DocumentBundle b) {
        if (b == null) {
            return false;
        }
        EditorPanel p = findPanel(b);
        if (p != null) {
            p.saveCaret();
        }
        return b.file == null ? SavePrompt.saveAs(this, b, settings, this)
                : SavePrompt.save(this, b, settings, this);
    }

    private void saveActive() {
        EditorPanel p = activeEditor();
        if (p == null) {
            notify("No editor to save", false);
            return;
        }
        saveBundle(p.bundle());
    }

    private void saveActiveAs() {
        EditorPanel p = activeEditor();
        if (p == null) {
            return;
        }
        if (SavePrompt.saveAs(this, p.bundle(), settings, this)) {
            workspace.register(p.bundle());
            explorer.refreshAll();
            updateActiveEditor();
        }
    }

    private void saveAll() {
        int count = 0;
        for (DocumentBundle b : new ArrayList<>(workspace.dirtyDocuments())) {
            if (b.file == null) {
                saveBundle(b);
            } else if (SavePrompt.save(this, b, settings, this)) {
                count++;
            }
        }
        if (count > 0) {
            statusBar.setMessage("Saved " + count + " file" + (count == 1 ? "" : "s"), 2500);
        }
    }

    private void autoSaveNow() {
        for (DocumentBundle b : new ArrayList<>(workspace.dirtyDocuments())) {
            if (b.file != null) {
                try {
                    b.save(settings);
                } catch (IOException ignored) {
                    // reported through the normal save path
                }
            }
        }
    }

    private void closeActiveEditor() {
        EditorPanel p = activeEditor();
        if (p == null) {
            return;
        }
        if (currentGroup().close(p)) {
            workspace.close(p.bundle());
            updateActiveEditor();
        }
    }

    private void closeAllEditors() {
        for (EditorGroup g : new ArrayList<>(groups)) {
            g.closeAll();
        }
        updateActiveEditor();
    }

    private void nextEditor(int delta) {
        EditorGroup g = currentGroup();
        List<EditorPanel> editors = g.editors();
        if (editors.size() < 2) {
            return;
        }
        EditorPanel active = g.active();
        int index = editors.indexOf(active);
        int next = Math.floorMod(index + delta, editors.size());
        g.setActive(editors.get(next));
    }

    /* ------------------------------------------------------------------ */
    /* panel / sidebar / view helpers                                      */
    /* ------------------------------------------------------------------ */

    private void showView(String viewId) {
        setSideBarVisible(true);
        sideBar.show(viewId);
        activityBar.setActive("settings".equals(viewId) ? "settings" : viewId);
    }

    private void showPanelView(String id) {
        panelArea.show(id);
        setPanelVisible(true);
    }

    private void toggleTerminal() {
        if (panelVisible && PanelArea.TERMINAL.equals(panelArea.currentView())) {
            setPanelVisible(false);
            return;
        }
        panelArea.show(PanelArea.TERMINAL);
        setPanelVisible(true);
        TerminalView view = panelArea.terminals().current();
        if (view != null) {
            SwingUtilities.invokeLater(view::focusInput);
        }
    }

    private void toggleSideBar() {
        setSideBarVisible(!sideBar.isVisible());
    }

    private void togglePanel() {
        setPanelVisible(!panelVisible);
    }

    private void setSideBarVisible(boolean visible) {
        sideBar.setVisible(true);
        settings.set("workbench.sideBarVisible", String.valueOf(visible));
        applyVisibility();
    }

    private void setPanelVisible(boolean visible) {
        settings.set("workbench.panelVisible", String.valueOf(visible));
        applyVisibility();
    }

    private void applyVisibility() {
        boolean sideVisible = settings.getBool("workbench.sideBarVisible");
        boolean panelShown = settings.getBool("workbench.panelVisible");
        panelVisible = panelShown && !maximizedPanel;

        horizontal.setLeftComponent(sideVisible ? sideBar : null);
        horizontal.setDividerSize(sideVisible ? 5 : 0);
        if (sideVisible) {
            int width = Math.max(170, settings.getInt("workbench.sideBarWidth"));
            horizontal.setDividerLocation(Math.min(width, Math.max(170, getWidth() - 420)));
        }

        if (maximizedPanel) {
            vertical.setTopComponent(null);
            vertical.setBottomComponent(panelArea);
            panelArea.setVisible(true);
            vertical.setDividerSize(0);
            vertical.setResizeWeight(0);
        } else if (panelShown) {
            vertical.setTopComponent(editorArea);
            vertical.setBottomComponent(panelArea);
            panelArea.setVisible(true);
            vertical.setDividerSize(5);
            vertical.setResizeWeight(1);
            int height = Math.max(80, settings.getInt("workbench.panelHeight"));
            int loc = Math.max(80, vertical.getHeight() - height - vertical.getDividerSize());
            if (vertical.getHeight() > 0) {
                vertical.setDividerLocation(loc);
            } else {
                SwingUtilities.invokeLater(() -> vertical.setDividerLocation(
                        Math.max(80, vertical.getHeight() - height - vertical.getDividerSize())));
            }
        } else {
            vertical.setTopComponent(editorArea);
            vertical.setBottomComponent(null);
            vertical.setDividerSize(0);
            vertical.setResizeWeight(1);
        }
        vertical.revalidate();
        vertical.repaint();
        horizontal.revalidate();
        horizontal.repaint();
    }

    private void toggleMaximizedPanel() {
        maximizedPanel = !maximizedPanel;
        if (maximizedPanel) {
            settings.set("workbench.panelVisible", "true");
            panelVisible = true;
        }
        applyVisibility();
    }

    private void toggleFullScreen() {
        if ((getExtendedState() & MAXIMIZED_BOTH) == MAXIMIZED_BOTH) {
            setExtendedState(NORMAL);
        } else {
            setExtendedState(MAXIMIZED_BOTH);
        }
    }

    private void splitEditorLayoutRefresh() {
        if (editorSplit != null) {
            editorSplit.setBackground(theme.editorBorder);
            editorSplit.setDividerSize(5);
        }
    }

    private void applyEditorLayout() {
        editorArea.removeAll();
        editorSplit = null;
        if (groups.size() == 1) {
            editorArea.add(groups.get(0), BorderLayout.CENTER);
        } else {
            editorSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, groups.get(0), groups.get(1));
            editorSplit.setBorder(null);
            editorSplit.setDividerSize(5);
            editorSplit.setContinuousLayout(true);
            editorSplit.setResizeWeight(0.5);
            editorSplit.setBackground(theme.editorBorder);
            editorArea.add(editorSplit, BorderLayout.CENTER);
            SwingUtilities.invokeLater(() -> editorSplit.setDividerLocation(0.5));
        }
        editorArea.revalidate();
        editorArea.repaint();
        for (EditorGroup g : groups) {
            g.setTheme(theme);
        }
        updateActiveEditor();
    }

    private void setActiveGroup(int index) {
        if (index < 0 || index >= groups.size()) {
            return;
        }
        activeGroupIndex = index;
        EditorPanel p = groups.get(index).active();
        if (p != null) {
            p.activate();
        }
        updateActiveEditor();
    }

    private void openQuick(String mode) {
        if (quickOpen == null) {
            quickOpen = new QuickOpen(this, this, workspace, theme);
        }
        quickOpen.open(mode, null);
    }

    private void openFind(boolean replace) {
        EditorPanel p = activeEditor();
        if (p != null) {
            p.openFind(replace);
        }
    }

    private void formatActive() {
        EditorPanel p = activeEditor();
        if (p == null) {
            return;
        }
        p.editor().formatDocument();
        notify("Document formatted", false);
    }

    /* ------------------------------------------------------------------ */
    /* folding                                                             */
    /* ------------------------------------------------------------------ */

    private void toggleFoldActive() {
        EditorPanel p = activeEditor();
        if (p == null || !p.editor().toggleFoldAtCaret()) {
            notify("Nothing to fold on this line", true);
        }
    }

    private void foldActive() {
        EditorPanel p = activeEditor();
        if (p != null && !p.editor().foldAtCaret()) {
            notify("Nothing to fold on this line", true);
        }
    }

    private void unfoldActive() {
        EditorPanel p = activeEditor();
        if (p != null) {
            p.editor().unfoldAtCaret();
        }
    }

    private void foldAllActive() {
        EditorPanel p = activeEditor();
        if (p == null) {
            notify("Open a file to fold", true);
            return;
        }
        p.editor().foldAll();
        int count = p.editor().foldedLines().size();
        notify(count == 0 ? "Nothing to fold in this file"
                : Strings.format("{0} block(s) folded", count), false);
    }

    private void unfoldAllActive() {
        EditorPanel p = activeEditor();
        if (p != null) {
            p.editor().unfoldAll();
        }
    }

    /* ------------------------------------------------------------------ */
    /* go to definition / references / rename                              */
    /* ------------------------------------------------------------------ */

    /** The identifier under the caret in the active editor, or an empty string. */
    private String currentWord() {
        EditorPanel p = activeEditor();
        if (p == null) {
            return "";
        }
        return Navigator.identifierAt(p.editor().text(), p.editor().getCaretPosition());
    }

    private void goToDefinition() {
        if (activeEditor() == null) {
            notify("Open a file first", true);
            return;
        }
        String word = currentWord();
        if (word.isEmpty()) {
            notify("Put the caret on a symbol first", true);
            return;
        }
        scanSymbols(word, hits -> {
            List<Navigator.Hit> definitions = new ArrayList<>();
            for (Navigator.Hit hit : hits) {
                if (hit.definition) {
                    definitions.add(hit);
                }
            }
            if (definitions.isEmpty()) {
                notify(Strings.format("No definition found for {0}", word), true);
                return;
            }
            if (definitions.size() == 1) {
                openHit(definitions.get(0));
                return;
            }
            showHits(Strings.format("Definitions of {0}", word), definitions);
        });
    }

    private void findAllReferences() {
        if (activeEditor() == null) {
            notify("Open a file first", true);
            return;
        }
        String word = currentWord();
        if (word.isEmpty()) {
            notify("Put the caret on a symbol first", true);
            return;
        }
        scanSymbols(word, hits -> {
            if (hits.isEmpty()) {
                notify(Strings.format("No references found for {0}", word), true);
                return;
            }
            showHits(Strings.format("References to {0}", word), hits);
        });
    }

    private void showHits(String title, List<Navigator.Hit> hits) {
        new ResultPicker(this, theme, title, hits, workspace.getRoot(), this::openHit).showPicker();
    }

    /**
     * Runs a workspace symbol scan off the event thread and hands the hits back on it.
     *
     * <p>The scan reads every indexed file, which is the same order of work as a project-wide
     * search, so it follows the same rule: the event thread posts the request and never waits.
     */
    private void scanSymbols(String word, java.util.function.Consumer<List<Navigator.Hit>> onDone) {
        statusBar.setMessage(Strings.format("Searching for {0}...", word), 1500);
        Thread worker = new Thread(() -> {
            List<Navigator.Hit> hits;
            try {
                hits = Navigator.references(workspace, word);
            } catch (Throwable t) {
                hits = Collections.emptyList();
            }
            List<Navigator.Hit> result = hits;
            SwingUtilities.invokeLater(() -> onDone.accept(result));
        }, "codestudio-symbol-scan");
        worker.setDaemon(true);
        worker.start();
    }

    /** Opens one search hit, converting the 1-based line and column to the editor's 0-based ones. */
    private void openHit(Navigator.Hit hit) {
        if (hit == null || hit.file == null) {
            return;
        }
        openAt(hit.file, Math.max(0, hit.line - 1), Math.max(0, hit.column - 1), 0);
    }

    /**
     * Renames a symbol everywhere the workspace mentions it.
     *
     * <p>Open buffers are edited in memory so their undo stacks and caret survive, which also
     * means a modified buffer keeps winning over the copy on disk - the same rule the rest of the
     * IDE follows. Files that are not open are rewritten directly.
     */
    private void renameSymbol() {
        if (activeEditor() == null) {
            notify("Open a file first", true);
            return;
        }
        String word = currentWord();
        if (word.isEmpty()) {
            notify("Put the caret on a symbol first", true);
            return;
        }
        String typed = Dialogs.prompt(this, theme, Strings.get("Rename Symbol"),
                Strings.format("Rename {0} to:", word), word);
        if (typed == null) {
            return;
        }
        String next = typed.trim();
        if (next.isEmpty() || next.equals(word)) {
            return;
        }
        if (!Navigator.isIdentifier(next)) {
            notify("That is not a valid identifier: " + next, true);
            return;
        }
        scanSymbols(word, hits -> applyRename(word, next, hits));
    }

    /** Confirms and then performs the rewrite a rename was asked for. */
    private void applyRename(String word, String next, List<Navigator.Hit> hits) {
        List<File> files = new ArrayList<>(filesOf(hits));
        if (files.isEmpty()) {
            notify(Strings.format("Nothing to rename for {0}", word), true);
            return;
        }
        int choice = Dialogs.confirm(this, theme, Strings.get("Rename Symbol"),
                Strings.format("Replace {0} occurrences across {1} files?\n\nThis overwrites the"
                        + " files on disk.", hits.size(), files.size()),
                Strings.get("Rename"), Strings.get("Cancel"));
        if (choice != 0) {
            return;
        }

        int occurrences = 0;
        int rewritten = 0;
        for (File file : files) {
            DocumentBundle open = workspace.get(file);
            if (open != null) {
                int[] count = new int[1];
                String updated = Navigator.replaceWholeWord(open.content(), word, next, count);
                if (count[0] > 0) {
                    int caret = Math.max(0, Math.min(open.caret, updated.length()));
                    open.replaceAll(updated);
                    open.caret = caret;
                    occurrences += count[0];
                    rewritten++;
                }
                continue;
            }
            int count = Navigator.renameInFile(file, word, next);
            if (count > 0) {
                occurrences += count;
                rewritten++;
            } else if (count < 0) {
                notify("Could not write " + file.getName(), true);
            }
        }
        for (EditorGroup group : groups) {
            for (EditorPanel p : group.editors()) {
                if (files.contains(p.bundle().file)) {
                    p.editor().setCaretPosition(
                            Math.min(p.bundle().caret, p.editor().getDocument().getLength()));
                    p.syncAfterExternalChange();
                }
            }
        }
        explorer.refreshAll();
        git.refreshAsync(true);
        notify(Strings.format("Renamed {0} occurrence(s) in {1} file(s)", occurrences, rewritten), false);
    }

    private static Set<File> filesOf(List<Navigator.Hit> hits) {
        Set<File> files = new java.util.LinkedHashSet<>();
        for (Navigator.Hit hit : hits) {
            if (hit.file != null) {
                files.add(hit.file);
            }
        }
        return files;
    }

    /* ------------------------------------------------------------------ */
    /* zen mode                                                            */
    /* ------------------------------------------------------------------ */

    /**
     * Hides everything but the editor, the way VS Code's Zen Mode does: menu bar, activity bar,
     * side bar, panel, status bar and window decorations all go, and the settings that were
     * changed are put back on the way out.
     */
    private void toggleZenMode() {
        zenMode = !zenMode;
        if (zenMode) {
            zenSideBar = settings.getBool("workbench.sideBarVisible");
            zenPanel = settings.getBool("workbench.panelVisible");
            zenMaximized = (getExtendedState() & MAXIMIZED_BOTH) == MAXIMIZED_BOTH;
            setJMenuBar(null);
            activityBar.setVisible(false);
            statusBar.setVisible(false);
            settings.set("workbench.sideBarVisible", "false");
            settings.set("workbench.panelVisible", "false");
            setExtendedState(MAXIMIZED_BOTH);
        } else {
            if (menuBar != null) {
                setJMenuBar(menuBar);
            }
            activityBar.setVisible(true);
            statusBar.setVisible(true);
            settings.set("workbench.sideBarVisible", String.valueOf(zenSideBar));
            settings.set("workbench.panelVisible", String.valueOf(zenPanel));
            setExtendedState(zenMaximized ? MAXIMIZED_BOTH : NORMAL);
        }
        applyVisibility();
        revalidate();
        repaint();
        notify(zenMode ? "Zen Mode on. Ctrl+K Z leaves it." : "Zen Mode off.", false);
    }

    private void toggleWordWrap() {
        settings.set("editor.wordWrap", String.valueOf(!settings.getBool("editor.wordWrap")));
        settingsPanel.rebuild();
        statusBar.setMessage("Word wrap " + (settings.getBool("editor.wordWrap") ? "on" : "off"), 2000);
    }

    private void zoom(int direction) {
        int size = settings.getInt("editor.fontSize");
        int next = direction == 0 ? 14 : Math.max(8, Math.min(48, size + direction));
        settings.set("editor.fontSize", String.valueOf(next));
        settings.set("terminal.fontSize", String.valueOf(Math.max(8, Math.min(40, next - 1))));
        settingsPanel.rebuild();
        statusBar.setMessage("Font size " + next, 2000);
    }

    private void runInTerminal() {
        EditorPanel p = activeEditor();
        File target = p == null || p.bundle().file == null ? workspace.getRoot()
                : p.bundle().file.getParentFile();
        runInTerminal(target);
    }

    private void revealActiveInExplorer() {
        EditorPanel p = activeEditor();
        if (p != null && p.bundle().file != null) {
            setSideBarVisible(true);
            showView("explorer");
            explorer.reveal(p.bundle().file);
        }
    }

    private void goToProblem(int direction) {
        List<Problems.Problem> all = problems.all();
        if (all.isEmpty()) {
            notify("No problems detected", false);
            return;
        }
        problemCursor = Math.floorMod(problemCursor + direction, all.size());
        Problems.Problem p = all.get(problemCursor);
        if (p.file != null) {
            openAt(p.file, p.line, p.column, 0);
        }
    }

    private void activeText(java.util.function.Consumer<CodeTextPane> action) {
        EditorPanel p = activeEditor();
        if (p != null) {
            action.accept(p.editor());
            p.editor().requestFocusInWindow();
        }
    }

    private void textAction(String name) {
        EditorPanel p = activeEditor();
        if (p == null) {
            return;
        }
        switch (name) {
            case "cut" -> p.editor().cut();
            case "copy" -> p.editor().copy();
            case "paste" -> p.editor().paste();
            default -> {
                // nothing else is wired
            }
        }
    }

    private void copyToClipboard(String text) {
        Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new java.awt.datatransfer.StringSelection(text), null);
        statusBar.setMessage("Copied: " + text, 2000);
    }

    private void pickFromList(String[] items, int selected, java.util.function.IntConsumer onPick) {
        JPopupMenu menu = new JPopupMenu();
        menu.setBackground(theme.widgetBg);
        for (int i = 0; i < items.length; i++) {
            JMenuItem item = new JMenuItem(items[i]);
            item.setFont(UI.ui(12.5f));
            item.setForeground(theme.panelFg);
            item.setBackground(theme.widgetBg);
            if (i == selected) {
                item.setIcon(Icons.of("check", 13, theme.accent));
            }
            final int index = i;
            item.addActionListener(e -> SwingUtilities.invokeLater(() -> onPick.accept(index)));
            menu.add(item);
        }
        Dimension d = menu.getPreferredSize();
        int x = Math.max(8, statusBar.getWidth() - d.width - 14);
        menu.show(statusBar, x, -Math.max(24, d.height));
    }

    /* ------------------------------------------------------------------ */
    /* state refresh                                                       */
    /* ------------------------------------------------------------------ */

    @Override
    public void activeEditorChanged() {
        updateActiveEditor();
    }

    private void updateActiveEditor() {
        EditorPanel p = activeEditor();
        if (p == null) {
            statusBar.setLanguage(null);
            statusBar.setCaret(1, 1, 0);
            statusBar.setEncoding(settings.get("files.defaultEncoding"));
            statusBar.setEol("LF");
            syncExplorerEditors();
            explorer.outline().update("", null);
            updateTitle();
            return;
        }
        CodeTextPane text = p.editor();
        DocumentBundle b = p.bundle();
        Language lang = b.language;
        int caret = text.getCaretPosition();
        statusBar.setCaret(text.caretLine() + 1, text.caretColumn() + 1,
                Math.abs(text.getSelectionEnd() - text.getCaretPosition()));
        statusBar.setLanguage(lang);
        statusBar.setEncoding(b.encoding);
        statusBar.setEol(b.eol.equals("\r\n") ? "CRLF" : "LF");
        statusBar.setIndentation(settings.getInt("editor.tabSize"), settings.getBool("editor.insertSpaces"));
        if (settings.getBool("workbench.autoRevealInExplorer") && b.file != null) {
            explorer.setActiveFile(b.file);
        }
        outlineTimer.restart();
        syncExplorerEditors();
        updateTitle();
    }

    private void refreshOutline() {
        EditorPanel p = activeEditor();
        if (p == null) {
            explorer.outline().update("", null);
            return;
        }
        explorer.outline().update(p.editor().text(), p.bundle().language);
    }

    private void syncExplorerEditors() {
        List<DocumentBundle> open = new ArrayList<>();
        for (EditorGroup g : groups) {
            for (EditorPanel p : g.editors()) {
                if (!open.contains(p.bundle())) {
                    open.add(p.bundle());
                }
            }
        }
        EditorPanel active = activeEditor();
        explorer.setOpenEditors(open, active == null ? null : active.bundle());
    }

    private void updateTitle() {
        EditorPanel p = activeEditor();
        String name = p == null ? "" : (p.bundle().isDirty() ? "● " : "") + p.bundle().name();
        String folder = workspace.getRoot() == null ? "" : workspace.rootName();
        StringBuilder sb = new StringBuilder();
        if (!name.isEmpty()) {
            sb.append(name).append(" - ");
        }
        if (!folder.isEmpty()) {
            sb.append(folder).append(" - ");
        }
        sb.append("CodeStudio");
        String title = sb.toString();
        if (!title.equals(getTitle())) {
            setTitle(title);
        }
    }

    private void onSettingsChanged() {
        SwingUtilities.invokeLater(() -> {
            // Returns true only when the language actually in effect changed, so flipping between
            // "system" and "en" on an English machine does not rebuild the whole window.
            if (Strings.setLanguage(settings.get("workbench.language"))) {
                applyLanguage();
            }
            Theme wanted = Theme.get(settings.get("workbench.colorTheme"));
            if (wanted.dark != theme.dark) {
                applyTheme(wanted);
            }
            for (EditorGroup g : groups) {
                g.refreshPrefs();
            }
            explorer.refreshAll();
            applyVisibility();
            updateActiveEditor();
        });
    }

    /**
     * Re-applies every visible string after a language change. The menu bar is rebuilt outright
     * (it is only ever constructed here and in {@link #applyTheme}) while each panel re-reads its
     * own labels, mirroring how {@link #applyTheme} walks the same components.
     */
    private void applyLanguage() {
        setJMenuBar(buildMenuBar());
        activityBar.retranslate();
        sideBar.retranslate();
        explorer.retranslate();
        search.retranslate();
        git.retranslate();
        runPanel.retranslate();
        settingsPanel.retranslate();
        welcome.retranslate();
        panelArea.retranslate();
        statusBar.retranslate();
        notifications.retranslate();
        for (EditorGroup g : groups) {
            g.retranslate();
        }
        // Breadcrumbs, outline and the caret/encoding segments all carry text too.
        updateActiveEditor();
        refreshOutline();
        getContentPane().invalidate();
        getContentPane().validate();
        repaint();
    }

    private void applyTheme(Theme t) {
        this.theme = t;
        t.applyToUIManager();
        getContentPane().setBackground(t.editorBg);
        activityBar.setTheme(t);
        sideBar.setTheme(t);
        explorer.setTheme(t);
        search.setTheme(t);
        git.setTheme(t);
        runPanel.setTheme(t);
        settingsPanel.setTheme(t);
        welcome.setTheme(t);
        panelArea.setTheme(t);
        statusBar.setTheme(t);
        notifications.setTheme(t);
        highlighter.setTheme(t);
        editorArea.setBackground(t.editorBg);
        horizontal.setBackground(t.editorBorder);
        vertical.setBackground(t.editorBorder);
        for (EditorGroup g : groups) {
            g.setTheme(t);
        }
        splitEditorLayoutRefresh();
        if (quickOpen != null) {
            quickOpen.updateTheme(t);
        }
        setJMenuBar(buildMenuBar());
        getContentPane().invalidate();
        getContentPane().validate();
        repaint();
    }

    private void refreshGitInfo() {
        final File root = Git.findRoot(workspace.getRoot());
        if (root == null) {
            statusBar.setBranch("No repository");
            activityBar.setBadge("scm", 0);
            return;
        }
        Thread thread = new Thread(() -> {
            Git.Status status = Git.status(root);
            SwingUtilities.invokeLater(() -> {
                if (!status.isRepo()) {
                    statusBar.setBranch("No repository");
                    return;
                }
                String branch = status.branch == null || status.branch.isBlank() ? "HEAD" : status.branch;
                if (status.ahead > 0) {
                    branch = branch + " ↑" + status.ahead;
                }
                if (status.behind > 0) {
                    branch = branch + " ↓" + status.behind;
                }
                statusBar.setBranch(branch);
                activityBar.setBadge("scm", git.changeCount());
            });
        }, "git-status");
        thread.setDaemon(true);
        thread.start();
    }

    private void checkExternalChanges() {
        for (DocumentBundle b : new ArrayList<>(workspace.documents())) {
            if (b.file == null || !b.file.isFile()) {
                continue;
            }
            long modified = b.file.lastModified();
            if (b.lastModified != 0 && modified != b.lastModified && !b.isDirty()) {
                b.lastModified = modified;
                try {
                    b.reload(new String(Files.readAllBytes(b.file.toPath()),
                            Charset.forName(b.encoding == null ? "UTF-8" : b.encoding)));
                    EditorPanel p = findPanel(b);
                    if (p != null) {
                        p.syncAfterExternalChange();
                    }
                    notify("Reloaded " + b.name() + " from disk", false);
                } catch (Exception ignored) {
                    // the file may be locked; the next tick retries
                }
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* session                                                             */
    /* ------------------------------------------------------------------ */

    private void restoreWindow() {
        int w = Math.max(720, settings.getInt("window.width"));
        int h = Math.max(480, settings.getInt("window.height"));
        setSize(w, h);
        int x = settings.getInt("window.x");
        int y = settings.getInt("window.y");
        Point center = GraphicsEnvironmentCheck.center();
        if (x < 0 || y < 0) {
            setLocation(center.x - w / 2, center.y - h / 2);
        } else {
            setLocation(x, y);
        }
        if (settings.getBool("window.maximized")) {
            setExtendedState(MAXIMIZED_BOTH);
        }
    }

    private void restoreSession() {
        installFocusTracking();
        restoreSessionState();
    }

    /**
     * The part of session restore that can run more than once: reads the live session keys and
     * rebuilds the workbench from them.
     *
     * <p>Separate from {@link #restoreSession()} because installing the focus tracking listener is
     * not idempotent, and an account switch restores a session without wanting a second listener.
     */
    private void restoreSessionState() {
        String last = settings.get("files.lastFolder");
        if (!last.isBlank() && new File(last).isDirectory()) {
            workspace.setRoot(new File(last));
        } else {
            sideBar.show("welcome");
        }
        String openFiles = settings.get("workspace.openFiles");
        for (String path : openFiles.split("\\s*;\\s*")) {
            if (path.isBlank()) {
                continue;
            }
            File f = new File(path);
            if (f.isFile()) {
                openFile(f);
            }
        }
        String active = settings.get("workspace.activeFile");
        if (!active.isBlank()) {
            DocumentBundle b = workspace.get(new File(active));
            if (b != null) {
                EditorPanel p = findPanel(b);
                if (p != null) {
                    currentGroup().setActive(p);
                }
            }
        }
        updateActiveEditor();
        showView(settings.get("workbench.activityView"));
        statusBar.setIndentation(settings.getInt("editor.tabSize"), settings.getBool("editor.insertSpaces"));
        statusBar.setEncoding(settings.get("files.defaultEncoding"));
        SwingUtilities.invokeLater(() -> {
            applyVisibility();
            refreshGitInfo();
            EditorPanel p = activeEditor();
            if (p != null) {
                p.activate();
            }
        });
    }

    private void saveSession() {
        settings.set("window.maximized", String.valueOf((getExtendedState() & MAXIMIZED_BOTH) == MAXIMIZED_BOTH));
        if ((getExtendedState() & MAXIMIZED_BOTH) == 0) {
            settings.set("window.width", String.valueOf(getWidth()));
            settings.set("window.height", String.valueOf(getHeight()));
            settings.set("window.x", String.valueOf(getX()));
            settings.set("window.y", String.valueOf(getY()));
        }
        settings.set("workbench.sideBarWidth", String.valueOf(Math.max(170, horizontal.getDividerLocation())));
        settings.set("workbench.panelHeight", String.valueOf(Math.max(80, vertical.getHeight()
                - vertical.getDividerLocation() - vertical.getDividerSize())));
        StringBuilder sb = new StringBuilder();
        for (EditorGroup g : groups) {
            for (EditorPanel p : g.editors()) {
                DocumentBundle b = p.bundle();
                if (b.file == null) {
                    continue;
                }
                if (sb.length() > 0) {
                    sb.append(';');
                }
                sb.append(b.file.getAbsolutePath());
            }
        }
        settings.set("workspace.openFiles", sb.toString());
        EditorPanel active = activeEditor();
        settings.set("workspace.activeFile", active != null && active.bundle().file != null
                ? active.bundle().file.getAbsolutePath() : "");
        explorer.saveLayout(settings);
        settings.saveNow();
    }

    /** Asks about unsaved work, then shuts the IDE down. */
    public void exit() {
        List<DocumentBundle> dirty = new ArrayList<>(workspace.dirtyDocuments());
        if (!dirty.isEmpty()) {
            int choice = Dialogs.confirm(this, theme, "CodeStudio",
                    dirty.size() + " file" + (dirty.size() == 1 ? " has" : "s have")
                            + " unsaved changes.\n\nDo you want to save them before quitting?",
                    "Save All", "Don't Save", "Cancel");
            if (choice == 2 || choice == -1) {
                return;
            }
            if (choice == 0) {
                for (DocumentBundle b : dirty) {
                    if (!saveBundle(b)) {
                        return;
                    }
                }
            }
        }
        gitTimer.stop();
        filesTimer.stop();
        outlineTimer.stop();
        autoSaveTimer.stop();
        runner.stop();
        panelArea.terminals().disposeAll();
        saveSession();
        dispose();
    }

    public void start() {
        setVisible(true);
        SwingUtilities.invokeLater(() -> {
            applyVisibility();
            EditorPanel p = activeEditor();
            if (p != null) {
                p.activate();
            }
        });
    }

    /* ------------------------------------------------------------------ */

    private static final String SHORTCUTS =
            "General\n"
                    + "  Ctrl+Shift+P      Show All Commands\n"
                    + "  Ctrl+P            Go to File...\n"
                    + "  Ctrl+Shift+O      Go to Symbol in Editor...\n"
                    + "  Ctrl+G            Go to Line/Column...\n"
                    + "  Ctrl+,            Settings\n"
                    + "  Ctrl+B            Toggle Primary Side Bar\n"
                    + "  Ctrl+J            Toggle Panel\n"
                    + "  Ctrl+`            Toggle Terminal\n"
                    + "  F11               Full Screen\n"
                    + "\nBasic Editing\n"
                    + "  Ctrl+X / C / V    Cut / Copy / Paste\n"
                    + "  Ctrl+Z / Y        Undo / Redo\n"
                    + "  Ctrl+/            Toggle Line Comment\n"
                    + "  Ctrl+D            Duplicate Selection\n"
                    + "  Ctrl+Shift+K      Delete Line\n"
                    + "  Alt+Up / Down     Move Line Up / Down\n"
                    + "  Shift+Alt+Up/Down Copy Line Up / Down\n"
                    + "  Tab / Shift+Tab   Indent / Outdent\n"
                    + "  Ctrl+] / Ctrl+[   Indent / Outdent Line\n"
                    + "  Ctrl+Shift+I      Format Document\n"
                    + "  Ctrl+Space        Trigger Suggest\n"
                    + "  F2                Rename Symbol\n"
                    + "  Ctrl+Shift+[ / ]  Fold / Unfold\n"
                    + "  Ctrl+K Ctrl+0     Fold All\n"
                    + "  Ctrl+K Ctrl+J     Unfold All\n"
                    + "  Click the gutter  Fold / Unfold a Block\n"
                    + "\nMulti-cursor and Selection\n"
                    + "  Ctrl+A            Select All\n"
                    + "  Ctrl+L            Select Current Line\n"
                    + "  Shift+Arrows      Extend Selection\n"
                    + "\nSearch and Replace\n"
                    + "  Ctrl+F            Find\n"
                    + "  Ctrl+H            Replace\n"
                    + "  Ctrl+Shift+F      Find in Files\n"
                    + "\nNavigation\n"
                    + "  Ctrl+Tab          Next Editor\n"
                    + "  Ctrl+Shift+Tab    Previous Editor\n"
                    + "  F8 / Shift+F8     Next / Previous Problem\n"
                    + "  F12 / Shift+F12   Go to Definition / All References\n"
                    + "  Ctrl+W            Close Editor\n"
                    + "  Ctrl+Alt+W        Close All Editors\n"
                    + "\nRun and Debug\n"
                    + "  F5                Start Debugging\n"
                    + "  Ctrl+F5           Run Without Debugging\n"
                    + "  Shift+F5          Stop\n"
                    + "  Click the gutter  Toggle Breakpoint\n"
                    + "\nDisplay\n"
                    + "  Alt+Z             Toggle Word Wrap\n"
                    + "  Ctrl+= / Ctrl+-   Zoom In / Out\n"
                    + "  Ctrl+0            Reset Zoom\n"
                    + "  Ctrl+K Z          Zen Mode\n"
                    + "  Ctrl+Shift+E/F/G/D  Explorer / Search / SCM / Run\n";

    /**
     * The same cheat sheet in Chinese. Kept as a whole block rather than assembled from translated
     * fragments because the two columns are hand-aligned: the key names must not be translated, and
     * the widths differ once the descriptions change language.
     */
    private static final String SHORTCUTS_ZH =
            "常规\n"
                    + "  Ctrl+Shift+P      显示所有命令\n"
                    + "  Ctrl+P            转到文件...\n"
                    + "  Ctrl+Shift+O      转到编辑器中的符号...\n"
                    + "  Ctrl+G            转到行/列...\n"
                    + "  Ctrl+,            设置\n"
                    + "  Ctrl+B            切换主侧边栏\n"
                    + "  Ctrl+J            切换面板\n"
                    + "  Ctrl+`            切换终端\n"
                    + "  F11               全屏\n"
                    + "\n基础编辑\n"
                    + "  Ctrl+X / C / V    剪切 / 复制 / 粘贴\n"
                    + "  Ctrl+Z / Y        撤销 / 重做\n"
                    + "  Ctrl+/            切换行注释\n"
                    + "  Ctrl+D            复制当前行\n"
                    + "  Ctrl+Shift+K      删除行\n"
                    + "  Alt+Up / Down     上移 / 下移当前行\n"
                    + "  Shift+Alt+Up/Down 向上 / 向下复制行\n"
                    + "  Tab / Shift+Tab   缩进 / 减少缩进\n"
                    + "  Ctrl+] / Ctrl+[   缩进 / 减少缩进行\n"
                    + "  Ctrl+Shift+I      格式化文档\n"
                    + "  Ctrl+Space        触发建议\n"
                    + "  F2                重命名符号\n"
                    + "  Ctrl+Shift+[ / ]  折叠 / 展开\n"
                    + "  Ctrl+K Ctrl+0     全部折叠\n"
                    + "  Ctrl+K Ctrl+J     全部展开\n"
                    + "  点击左侧装订区    折叠 / 展开代码块\n"
                    + "\n多光标与选择\n"
                    + "  Ctrl+A            全选\n"
                    + "  Ctrl+L            选中当前行\n"
                    + "  Shift+Arrows      扩展选择\n"
                    + "\n搜索与替换\n"
                    + "  Ctrl+F            查找\n"
                    + "  Ctrl+H            替换\n"
                    + "  Ctrl+Shift+F      在文件中查找\n"
                    + "\n导航\n"
                    + "  Ctrl+Tab          下一个编辑器\n"
                    + "  Ctrl+Shift+Tab    上一个编辑器\n"
                    + "  F8 / Shift+F8     下一个 / 上一个问题\n"
                    + "  F12 / Shift+F12   转到定义 / 查找所有引用\n"
                    + "  Ctrl+W            关闭编辑器\n"
                    + "  Ctrl+Alt+W        关闭所有编辑器\n"
                    + "\n运行与调试\n"
                    + "  F5                开始调试\n"
                    + "  Ctrl+F5           以非调试模式运行\n"
                    + "  Shift+F5          停止\n"
                    + "  点击左侧装订区    切换断点\n"
                    + "\n显示\n"
                    + "  Alt+Z             切换自动换行\n"
                    + "  Ctrl+= / Ctrl+-   放大 / 缩小\n"
                    + "  Ctrl+0            重置缩放\n"
                    + "  Ctrl+K Z          禅模式\n"
                    + "  Ctrl+Shift+E/F/G/D  资源管理器 / 搜索 / 源代码管理 / 运行\n";

    private static String shortcutsText() {
        return Strings.isChinese() ? SHORTCUTS_ZH : SHORTCUTS;
    }

    /** Small helper so the window code does not depend on java.awt.GraphicsEnvironment directly. */
    private static final class GraphicsEnvironmentCheck {
        static Point center() {
            java.awt.GraphicsEnvironment env = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment();
            java.awt.Rectangle bounds = env.getMaximumWindowBounds();
            return new Point(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2);
        }
    }
}
