package com.codestudio.ui;

import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** Collapsible section header such as "EXPLORER", "OUTLINE", "OPEN EDITORS". */
public class SectionHeader extends JPanel {

    private final Theme theme;
    private final JLabel chevron = new JLabel();
    private final JLabel title = new JLabel();
    private final JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 1, 0));
    private final List<Runnable> listeners = new ArrayList<>();
    /** Action buttons paired with their untranslated tooltip, so {@link #retranslate} can redo them. */
    private final Map<JButton, String> actionTooltips = new LinkedHashMap<>();

    private String titleKey;
    private boolean expanded = true;
    private boolean hovering;

    public SectionHeader(String text, Theme theme) {
        super(new BorderLayout(2, 0));
        this.theme = theme;
        setOpaque(true);
        setBackground(theme.sidebarBg);
        setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
        left.setOpaque(false);
        chevron.setPreferredSize(new Dimension(14, 16));
        chevron.setIcon(Icons.of("chevron-down", 14, theme.sectionHeader));
        setTitleText(text);
        title.setFont(UI.uiBold(11f));
        title.setForeground(theme.sectionHeader);
        left.add(chevron);
        left.add(title);
        add(left, BorderLayout.WEST);

        actions.setOpaque(false);
        add(actions, BorderLayout.EAST);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hovering = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovering = false;
                repaint();
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                toggle();
            }
        });
    }

    public void toggle() {
        setExpanded(!expanded);
    }

    public void setExpanded(boolean value) {
        this.expanded = value;
        chevron.setIcon(Icons.of(value ? "chevron-down" : "chevron-right", 14, theme.sectionHeader));
        for (Runnable r : new ArrayList<>(listeners)) {
            r.run();
        }
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void addToggleListener(Runnable r) {
        listeners.add(r);
    }

    /** Adds a small action button to the right of the header. */
    public JButton addAction(String icon, String tooltip, Runnable action) {
        JButton b = UI.iconButton(Icons.of(icon, 14, theme.sidebarFg), Strings.get(tooltip), theme, action);
        b.setPreferredSize(new Dimension(20, 20));
        b.setMaximumSize(new Dimension(20, 20));
        actions.add(b);
        actionTooltips.put(b, tooltip);
        return b;
    }

    public void setTitleText(String text) {
        this.titleKey = text;
        title.setText(Strings.get(text).toUpperCase());
    }

    /**
     * Re-applies the title and action tooltips after a language change. Safe to call at any time:
     * a title holding dynamic text such as "Problems (3)" has no translation and is left alone,
     * and text that is already translated passes through unchanged.
     */
    public void retranslate() {
        if (titleKey != null) {
            title.setText(Strings.get(titleKey).toUpperCase());
        }
        for (Map.Entry<JButton, String> e : actionTooltips.entrySet()) {
            e.getKey().setToolTipText(Strings.get(e.getValue()));
        }
    }

    public void setTheme(Theme t) {
        setBackground(t.sidebarBg);
        title.setForeground(t.sectionHeader);
        chevron.setIcon(Icons.of(expanded ? "chevron-down" : "chevron-right", 14, t.sectionHeader));
        for (java.awt.Component c : actions.getComponents()) {
            if (c instanceof UI.FlatButton fb) {
                fb.setTheme(t);
            }
        }
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!hovering) {
            return;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(UI.alpha(theme.hover, 140));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.dispose();
    }
}
