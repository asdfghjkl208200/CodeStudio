package com.codestudio.ui;

import com.codestudio.core.Theme;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/**
 * The code overview on the right hand side of the editor. Renders a scaled
 * copy of the buffer (with its real syntax colors) and a draggable viewport
 * slider, just like VS Code.
 */
public class Minimap extends JComponent {

    private static final int MAX_LINES_FOR_TEXT = 20000;

    private final CodeTextPane text;
    private Theme theme;
    private BufferedImage buffer;
    private boolean dirty = true;
    private boolean dragging;
    private int dragOffset;

    public Minimap(CodeTextPane text, Theme theme) {
        this.text = text;
        this.theme = theme;
        setOpaque(true);
        setBackground(theme.editorBg);
        setPreferredSize(new Dimension(84, 10));
        setToolTipText("Code overview - click or drag to navigate");

        text.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                invalidateBuffer();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                invalidateBuffer();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                invalidateBuffer();
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (!SwingUtilities.isLeftMouseButton(e)) {
                    return;
                }
                Rectangle slider = sliderRect();
                if (slider.contains(e.getPoint())) {
                    dragging = true;
                    dragOffset = e.getY() - slider.y;
                } else {
                    scrollToY(e.getY() - getHeight() / 2);
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                dragging = false;
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (dragging) {
                    scrollToY(e.getY() - dragOffset);
                }
            }
        });
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.editorBg);
        invalidateBuffer();
    }

    public void invalidateBuffer() {
        dirty = true;
        repaint();
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(84, 10);
    }

    @Override
    public Dimension getMaximumSize() {
        return new Dimension(84, Integer.MAX_VALUE);
    }

    /* ------------------------------------------------------------------ */

    private JViewport viewport() {
        return (JViewport) SwingUtilities.getAncestorOfClass(JViewport.class, text);
    }

    private void scrollToY(int y) {
        JViewport vp = viewport();
        if (vp == null) {
            return;
        }
        double ratio = Math.max(0, Math.min(1, y / (double) Math.max(1, getHeight())));
        int total = text.getPreferredSize().height;
        int target = (int) (ratio * total) - vp.getHeight() / 2;
        target = Math.max(0, Math.min(Math.max(0, total - vp.getHeight()), target));
        vp.setViewPosition(new Point(vp.getViewPosition().x, target));
    }

    private Rectangle sliderRect() {
        JViewport vp = viewport();
        if (vp == null) {
            return new Rectangle(0, 0, getWidth(), 20);
        }
        int total = Math.max(1, text.getPreferredSize().height);
        int h = getHeight();
        int top = (int) (vp.getViewPosition().y / (double) total * h);
        int height = Math.max(18, (int) (vp.getHeight() / (double) total * h));
        return new Rectangle(0, Math.max(0, Math.min(h - height, top)), getWidth(), Math.min(height, h));
    }

    /* ------------------------------------------------------------------ */

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        try {
            g2.setColor(theme.editorBg);
            g2.fillRect(0, 0, getWidth(), getHeight());
            if (getWidth() <= 0 || getHeight() <= 0) {
                return;
            }
            if (dirty || buffer == null || buffer.getWidth() != getWidth()
                    || buffer.getHeight() != getHeight()) {
                renderBuffer();
            }
            if (buffer != null) {
                g2.drawImage(buffer, 0, 0, null);
            }
            Rectangle slider = sliderRect();
            g2.setColor(theme.minimapSlider);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.fillRoundRect(0, slider.y, getWidth(), slider.height, 4, 4);
        } finally {
            g2.dispose();
        }
    }

    private void renderBuffer() {
        int w = Math.max(1, getWidth());
        int h = Math.max(1, getHeight());
        buffer = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = buffer.createGraphics();
        try {
            g.setColor(theme.editorBg);
            g.fillRect(0, 0, w, h);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            StyledDocument doc = text.bundle().doc;
            Element root = doc.getDefaultRootElement();
            int lines = root.getElementCount();
            if (lines <= 1) {
                dirty = false;
                return;
            }
            FontMetrics fm = text.getFontMetrics(text.getFont());
            int fullHeight = fm.getHeight();
            float scale = Math.min(1f, h / (float) Math.max(1, lines * fullHeight));

            if (lines > MAX_LINES_FOR_TEXT) {
                renderBars(g, doc, root, lines, w, h);
                dirty = false;
                return;
            }

            Graphics2D sg = (Graphics2D) g.create();
            sg.scale(scale, scale);
            sg.setFont(text.getFont());
            sg.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.85f));
            int baseline = fm.getAscent();
            for (int line = 0; line < lines; line++) {
                Element el = root.getElement(line);
                int from = el.getStartOffset();
                int to = Math.min(el.getEndOffset(), doc.getLength());
                if (from >= to) {
                    continue;
                }
                int y = (int) (line * fullHeight + baseline);
                int x = 0;
                int off = from;
                while (off < to) {
                    Element run = doc.getCharacterElement(off);
                    int runEnd = Math.min(run.getEndOffset(), to);
                    if (runEnd <= off) {
                        break;
                    }
                    Color c = StyleConstants.getForeground(run.getAttributes());
                    String s = doc.getText(off, runEnd - off);
                    sg.setColor(c == null ? theme.editorFg : c);
                    sg.drawString(s, x, y);
                    x += fm.stringWidth(s);
                    off = runEnd;
                }
            }
            sg.dispose();
            dirty = false;
        } catch (Exception e) {
            dirty = false;
        } finally {
            g.dispose();
        }
    }

    private void renderBars(Graphics2D g, StyledDocument doc, Element root, int lines, int w, int h) {
        g.setColor(UI.alpha(theme.gutterFg, 150));
        for (int line = 0; line < lines; line++) {
            int y = (int) (line / (double) lines * h);
            Element el = root.getElement(line);
            int len = el.getEndOffset() - el.getStartOffset();
            if (len <= 1) {
                continue;
            }
            int barW = (int) Math.min(w - 4, 2 + len * 1.6);
            g.drawLine(2, y, 2 + barW, y);
        }
    }
}
