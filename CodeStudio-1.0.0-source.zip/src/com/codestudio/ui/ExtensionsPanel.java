package com.codestudio.ui;

import com.codestudio.core.Runner;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import com.codestudio.core.plugin.PluginManager;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * The Extensions view: every plugin the {@link PluginManager} discovered, whether it loaded
 * cleanly or not.
 *
 * <p>Like {@link GitPanel} it is a {@link SectionHeader} with actions over a scrollable list of
 * rows, and like {@link SettingsPanel} the whole list is thrown away and rebuilt whenever the
 * theme, the language or the plugin set changes. Nothing is cached between rebuilds, so a row can
 * never show a stale enable state or a translation from the previous language.
 *
 * <p>The one thing this view exists to report is a plugin that failed to load, so a failed row is
 * drawn with the error accent and shows the manager's reason in full — word wrapped, selectable,
 * and copyable with one click. The reason is never run through {@code Strings}: it is a diagnostic
 * from the plugin, not interface text.
 */
public class ExtensionsPanel extends JPanel implements ThemeAware {

    /** Optional hook so the host can put a message in the notification centre. */
    public interface Actions {

        void notify(String message, boolean error);

        /**
         * A plugin was installed, enabled, disabled, reloaded or removed.
         *
         * <p>The host has to act on this: what a plugin contributes lives in the window — its view,
         * its activity bar item, its status segment, its commands — and {@link PluginManager} can
         * only drop it from its own registries. Without this callback, disabling a plugin would
         * leave its view sitting in the sidebar until the next restart.
         */
        default void pluginsChanged() {
        }
    }

    private final PluginManager plugins;
    private Theme theme;
    private Actions actions;

    private final SectionHeader header;
    private final JPanel list = UI.column();
    private final JScrollPane scroll;
    private final JLabel footer = new JLabel(" ");

    /** Width the list was last measured at, so a resize re-measures the wrapped failure reasons. */
    private int measuredWidth = -1;
    private boolean rebuilding;

    public ExtensionsPanel(PluginManager plugins, Theme theme) {
        super(new BorderLayout());
        this.plugins = plugins;
        this.theme = theme;
        setBackground(theme.sidebarBg);

        header = new SectionHeader("Extensions", theme);
        header.addAction("plus", "Install from jar...", this::installFromJar);
        header.addAction("open-folder", "Open plugins folder", this::openPluginsFolder);
        header.addAction("refresh", "Reload", this::reload);

        list.setBackground(theme.sidebarBg);
        list.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));
        // A wrapped failure reason is measured from the width it is actually given, so it has to be
        // measured again — once the tree is realised, and again whenever the sidebar is resized.
        list.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if (list.getWidth() != measuredWidth) {
                    measuredWidth = list.getWidth();
                    list.revalidate();
                    list.repaint();
                }
            }
        });

        scroll = UI.scroll(list, theme);
        scroll.getViewport().setBackground(theme.sidebarBg);
        scroll.getVerticalScrollBar().setUnitIncrement(18);

        footer.setFont(UI.ui(11.5f));
        footer.setForeground(UI.alpha(theme.sidebarFg, 180));
        footer.setBorder(BorderFactory.createEmptyBorder(4, 10, 5, 8));

        add(header, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(footer, BorderLayout.SOUTH);

        refresh();
    }

    public void setActions(Actions a) {
        this.actions = a;
    }

    /* ------------------------------------------------------------------ */
    /* theming and translation                                             */
    /* ------------------------------------------------------------------ */

    @Override
    public void setTheme(Theme t) {
        try {
            this.theme = t;
            setBackground(t.sidebarBg);
            header.setTheme(t);
            scroll.getViewport().setBackground(t.sidebarBg);
            UI.themeScrollBar(scroll, t);
            footer.setForeground(UI.alpha(t.sidebarFg, 180));
            rebuild();
        } catch (Throwable e) {
            report(e);
        }
    }

    @Override
    public void retranslate() {
        try {
            header.retranslate();
            rebuild();
        } catch (Throwable e) {
            report(e);
        }
    }

    /**
     * Re-reads {@link PluginManager#plugins()} and rebuilds the list. The host calls this after a
     * plugin is loaded, installed, enabled or removed.
     */
    public void refresh() {
        if (!SwingUtilities.isEventDispatchThread()) {
            SwingUtilities.invokeLater(this::refresh);
            return;
        }
        try {
            rebuild();
        } catch (Throwable e) {
            report(e);
        }
    }

    /* ------------------------------------------------------------------ */
    /* the list                                                            */
    /* ------------------------------------------------------------------ */

    private void rebuild() {
        if (rebuilding) {
            return;
        }
        rebuilding = true;
        try {
            List<PluginManager.Info> infos = new ArrayList<>(plugins.plugins());
            list.removeAll();
            if (infos.isEmpty()) {
                list.add(emptyState());
            } else {
                for (PluginManager.Info info : infos) {
                    list.add(new Row(info));
                }
            }
            list.add(Box.createVerticalGlue());
            updateFooter(infos);
        } finally {
            rebuilding = false;
        }
        list.revalidate();
        list.repaint();
        // Measure again once the rows have a real width; the first pass sees width 0 and cannot
        // know how many lines a wrapped failure reason will need.
        SwingUtilities.invokeLater(() -> {
            measuredWidth = list.getWidth();
            list.revalidate();
            list.repaint();
        });
    }

    private void updateFooter(List<PluginManager.Info> infos) {
        int failed = 0;
        for (PluginManager.Info info : infos) {
            if (info.failed()) {
                failed++;
            }
        }
        boolean anyFailed = failed > 0;
        footer.setText(anyFailed
                ? Strings.format("{0} extensions, {1} failed", infos.size(), failed)
                : Strings.format("{0} extensions", infos.size()));
        footer.setForeground(anyFailed ? theme.error : UI.alpha(theme.sidebarFg, 180));
    }

    private JPanel emptyState() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(theme.sidebarBg);
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 8, 10));
        p.setAlignmentX(LEFT_ALIGNMENT);
        // Wrapped, not a JLabel. This is the longest sentence in the panel and the sidebar is
        // narrow; a label would lay it out on one line and run it off the edge, which is exactly
        // what it did before this used the same wrapping area the failure reasons use.
        WrapArea l = new WrapArea(Strings.format(
                "No extensions installed yet. Plugins are loaded from {0}. Add a jar containing a "
                        + "plugin.json manifest, or a folder containing a declarative plugin.json.",
                plugins.directory()));
        l.setFont(UI.ui(11.5f));
        l.setForeground(UI.alpha(theme.sidebarFg, 170));
        p.add(l, BorderLayout.CENTER);
        return p;
    }

    /* ------------------------------------------------------------------ */
    /* header actions                                                      */
    /* ------------------------------------------------------------------ */

    private void installFromJar() {
        try {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle(Strings.get("Install from jar..."));
            chooser.setAcceptAllFileFilterUsed(false);
            chooser.setFileFilter(new FileNameExtensionFilter(Strings.get("Plugin jar"), "jar"));
            if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
                return;
            }
            Path jar = chooser.getSelectedFile().toPath();
            Path installed = plugins.install(jar);
            if (installed == null) {
                notify(Strings.format("Could not install {0}. The plugin was not copied into {1}.",
                        jar.getFileName(), plugins.directory()), true);
            } else {
                notify(Strings.format("Installed {0}", installed.getFileName()), false);
            }
        } catch (Throwable e) {
            report(e);
        }
        refresh();
        changed();
    }

    private void openPluginsFolder() {
        try {
            Path dir = plugins.directory();
            Files.createDirectories(dir);
            openInFileManager(dir);
        } catch (Throwable e) {
            report(e);
        }
    }

    /** The same shell-out {@code MainWindow.revealInOS} uses; there is no Desktop in this build. */
    private void openInFileManager(Path dir) throws IOException {
        String path = dir.toAbsolutePath().toString();
        if (Runner.isWindows()) {
            new ProcessBuilder("explorer.exe", path).start();
        } else if (System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT).contains("mac")) {
            new ProcessBuilder("open", path).start();
        } else {
            new ProcessBuilder("xdg-open", path).start();
        }
    }

    private void reload() {
        try {
            plugins.reload();
        } catch (Throwable e) {
            report(e);
        }
        refresh();
        changed();
    }

    private void toggle(PluginManager.Info info) {
        try {
            plugins.setEnabled(info.id(), !info.enabled());
        } catch (Throwable e) {
            report(e);
        }
        refresh();
        changed();
    }

    /** Destructive and outward facing: it deletes files, so it always names them and confirms. */
    private void uninstall(PluginManager.Info info) {
        try {
            int choice = Dialogs.confirm(this, theme, Strings.get("Uninstall Extension"),
                    Strings.format("Uninstall \"{0}\"?\n\nIts files will be deleted from disk "
                            + "({1}). This cannot be undone.", info.name(), plugins.directory()
                            .resolve(info.source() == null ? info.id() : info.source())),
                    Strings.get("Uninstall"), Strings.get("Cancel"));
            if (choice != 0) {
                return;
            }
            boolean removed = plugins.uninstall(info.id());
            if (removed) {
                notify(Strings.format("Uninstalled {0}", info.name()), false);
            } else {
                notify(Strings.format("Could not uninstall {0}.", info.name()), true);
            }
        } catch (Throwable e) {
            report(e);
        }
        refresh();
        changed();
    }

    private void notify(String message, boolean error) {
        if (actions != null) {
            actions.notify(message, error);
        } else if (error) {
            Dialogs.error(this, theme, Strings.get("Extensions"), message);
        }
    }

    /** Tells the host that the set of loaded plugins changed, so it can re-install the workbench. */
    private void changed() {
        if (actions != null) {
            actions.pluginsChanged();
        }
    }

    /** Reports a failure rather than letting it reach the event thread. */
    private void report(Throwable e) {
        String detail = e.getMessage() == null || e.getMessage().isBlank()
                ? e.getClass().getSimpleName()
                : e.getClass().getSimpleName() + ": " + e.getMessage();
        try {
            if (actions != null) {
                actions.notify(detail, true);
            } else {
                Dialogs.error(this, theme, Strings.get("Extensions"),
                        Strings.format("The extensions view hit an error: {0}", detail));
            }
        } catch (Throwable ignored) {
            // A failure while reporting a failure: drop it rather than kill the event thread.
        }
    }

    /* ------------------------------------------------------------------ */
    /* rows                                                                */
    /* ------------------------------------------------------------------ */

    /** One installed plugin. Rebuilt from scratch, so it always reflects the current state. */
    private final class Row extends JPanel {

        private final PluginManager.Info info;

        Row(PluginManager.Info info) {
            super(new BorderLayout(8, 0));
            this.info = info;
            boolean failed = info.failed();
            setBackground(theme.sidebarBg);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, failed ? 3 : 0, 1, 0,
                            failed ? theme.error : theme.sectionBorder),
                    BorderFactory.createEmptyBorder(6, failed ? 7 : 10, 6, 8)));
            setAlignmentX(LEFT_ALIGNMENT);

            JLabel icon = new JLabel(failed
                    ? Icons.of("error", 16, theme.error)
                    : Icons.of("extensions", 16, theme.sidebarFg));
            icon.setVerticalAlignment(JLabel.TOP);
            add(icon, BorderLayout.WEST);

            JPanel body = new JPanel();
            body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
            body.setOpaque(false);
            body.setAlignmentX(LEFT_ALIGNMENT);

            body.add(titleRow(failed));
            body.add(metaLabel());
            WrapArea description = descriptionLabel();
            if (description != null) {
                body.add(description);
            }
            if (failed) {
                body.add(reasonBlock());
            }
            body.add(buttonRow());

            add(body, BorderLayout.CENTER);
        }

        private JPanel titleRow(boolean failed) {
            JPanel row = new JPanel(new BorderLayout(6, 0));
            row.setOpaque(false);
            row.setAlignmentX(LEFT_ALIGNMENT);
            JLabel name = new JLabel(info.name() == null || info.name().isBlank()
                    ? info.id() : info.name());
            name.setFont(UI.uiBold(12.5f));
            name.setForeground(failed ? theme.error : theme.sidebarFg);
            name.setToolTipText(info.id());
            row.add(name, BorderLayout.WEST);
            if (info.version() != null && !info.version().isBlank()) {
                JLabel version = new JLabel(info.version());
                version.setFont(UI.ui(11f));
                version.setForeground(UI.alpha(theme.sidebarFg, 150));
                row.add(version, BorderLayout.EAST);
            }
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, row.getPreferredSize().height));
            return row;
        }

        private JLabel metaLabel() {
            String muted = String.format("%06X", theme.sidebarFg.getRGB() & 0xFFFFFF);
            String text = "<html>" + UI.esc(info.id())
                    + " <font color='#" + muted + "99'>&#183; " + UI.esc(sourceText())
                    + " &#183; " + UI.esc(kindText()) + "</font></html>";
            JLabel l = new JLabel(text);
            l.setFont(UI.ui(11.5f));
            l.setForeground(theme.sidebarFg);
            l.setAlignmentX(LEFT_ALIGNMENT);
            l.setToolTipText(plugins.directory().resolve(
                    info.source() == null ? info.id() : info.source()).toString());
            l.setMaximumSize(new Dimension(Integer.MAX_VALUE, l.getPreferredSize().height));
            return l;
        }

        /**
         * The plugin's own description, wrapped. It is written by the plugin author, so its length is
         * not ours to predict — a plain {@code JLabel} would sit at its unwrapped width and push the
         * whole list wider than the sidebar.
         */
        private WrapArea descriptionLabel() {
            String text = info.description();
            if (text == null || text.isBlank()) {
                return null;
            }
            WrapArea area = new WrapArea(text);
            area.setFont(UI.ui(11.5f));
            area.setForeground(UI.alpha(theme.sidebarFg, 170));
            area.setAlignmentX(LEFT_ALIGNMENT);
            return area;
        }

        /**
         * The failure reason, in full. It is shown in a selectable read-only text area so the whole
         * diagnostic can be copied out, and it is never truncated or passed through {@code Strings}
         * — it is the plugin's own message, not interface text.
         */
        private JPanel reasonBlock() {
            JPanel p = new JPanel(new BorderLayout(0, 2));
            p.setOpaque(false);
            p.setAlignmentX(LEFT_ALIGNMENT);
            p.setBorder(BorderFactory.createEmptyBorder(3, 0, 2, 0));

            WrapArea area = new WrapArea(info.error());
            area.setFont(UI.ui(11.5f));
            area.setForeground(theme.error);
            area.setSelectionColor(theme.selection);
            area.setSelectedTextColor(theme.editorFg);
            area.setCaretColor(theme.error);
            p.add(area, BorderLayout.CENTER);

            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
            buttons.setOpaque(false);
            String message = info.error();
            buttons.add(UI.smallButton(Strings.get("Copy Message"), theme,
                    () -> copyToClipboard(message)));
            p.add(buttons, BorderLayout.SOUTH);
            return p;
        }

        private JPanel buttonRow() {
            JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
            p.setOpaque(false);
            p.setAlignmentX(LEFT_ALIGNMENT);
            p.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));

            // The live state from the manager, not Info.enabled: the record is a snapshot taken at
            // discovery time, and the toggle must reflect what the next click will actually do.
            boolean enabled = plugins.isEnabled(info.id());
            JButton toggle = UI.smallButton(Strings.get(enabled ? "Disable" : "Enable"), theme,
                    () -> ExtensionsPanel.this.toggle(info));
            toggle.setToolTipText(Strings.get(enabled
                    ? "Disable this extension without removing it"
                    : "Enable this extension"));
            p.add(toggle);

            JButton remove = UI.smallButton(Strings.get("Uninstall"), theme,
                    () -> ExtensionsPanel.this.uninstall(info));
            remove.setForeground(theme.error);
            remove.setToolTipText(Strings.format("Delete {0} from disk", info.name()));
            p.add(remove);
            return p;
        }

        private String sourceText() {
            return info.source() == null || info.source().isBlank() ? info.id() : info.source();
        }

        private String kindText() {
            String kind = info.kind() == null ? "" : info.kind();
            boolean declarative = kind.contains("declarative");
            String base;
            if (kind.startsWith("jar")) {
                base = Strings.get("jar");
            } else if (kind.startsWith("directory")) {
                base = Strings.get("directory");
            } else {
                base = Strings.get("unknown");
            }
            return declarative ? Strings.get(base + " (declarative)") : base;
        }

        @Override
        public Dimension getMaximumSize() {
            // Fixed height, full width: the row must never be stretched by the BoxLayout, and the
            // height has to follow whatever the wrapped reason measured at the current width.
            return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
        }
    }

    private void copyToClipboard(String text) {
        try {
            java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(
                    new java.awt.datatransfer.StringSelection(text == null ? "" : text), null);
        } catch (Throwable e) {
            report(e);
        }
    }

    /** Exposed for the host's command palette; the count of plugins currently listed. */
    public int count() {
        return plugins.plugins().size();
    }

    /** Exposed for the host; the number of plugins that failed to load. */
    public int failureCount() {
        int failed = 0;
        for (PluginManager.Info info : plugins.plugins()) {
            if (info.failed()) {
                failed++;
            }
        }
        return failed;
    }
}
