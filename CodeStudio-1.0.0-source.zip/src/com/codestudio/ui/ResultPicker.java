package com.codestudio.ui;

import com.codestudio.core.Navigator;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;

/**
 * The list of places a symbol was found: definitions from "Go to Definition", every hit from
 * "Find All References" and "Rename Symbol".
 */
public class ResultPicker extends JDialog {

    /** Called with the hit the user picked. */
    public interface Actions {
        void open(Navigator.Hit hit);
    }

    private static final int ROW_HEIGHT = 22;
    private static final int VISIBLE_ROWS = 14;

    private final DefaultListModel<Navigator.Hit> model = new DefaultListModel<>();
    private final JList<Navigator.Hit> list = new JList<>(model);
    private final Actions actions;

    public ResultPicker(Window owner, Theme theme, String title, List<Navigator.Hit> hits,
                        File root, Actions actions) {
        super(owner, ModalityType.APPLICATION_MODAL);
        this.actions = actions;
        setTitle(Strings.get(title));
        setUndecorated(false);

        for (Navigator.Hit hit : hits) {
            model.addElement(hit);
        }

        list.setBackground(theme.widgetBg);
        list.setForeground(theme.panelFg);
        list.setFont(UI.ui(12.5f));
        list.setFixedCellHeight(ROW_HEIGHT);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setCellRenderer(new Renderer(theme, root, hits.isEmpty()));
        if (!hits.isEmpty()) {
            list.setSelectedIndex(0);
        }

        JScrollPane scroll = UI.scroll(list, theme);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(theme.widgetBg);

        JLabel header = new JLabel(hits.isEmpty()
                ? Strings.get("No results")
                : Strings.format("{0} result(s)", hits.size()));
        header.setFont(UI.ui(11.5f));
        header.setForeground(UI.alpha(theme.panelFg, 160));
        header.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        header.setOpaque(true);
        header.setBackground(theme.widgetBg);

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(theme.widgetBg);
        content.setBorder(BorderFactory.createLineBorder(theme.widgetBorder));
        content.add(header, BorderLayout.NORTH);
        content.add(scroll, BorderLayout.CENTER);
        setContentPane(content);

        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                choose();
            }
        });
        list.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    e.consume();
                    choose();
                } else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    e.consume();
                    dispose();
                }
            }
        });

        int rows = Math.max(1, Math.min(VISIBLE_ROWS, Math.max(1, hits.size())));
        list.setPreferredSize(new Dimension(700, rows * ROW_HEIGHT + 4));
        setSize(720, Math.min(460, rows * ROW_HEIGHT + 60));
        setLocationRelativeTo(owner);
        getRootPane().setDefaultButton(null);
    }

    /** Shows the picker and blocks until the user picks a hit or closes it. */
    public void showPicker() {
        SwingUtilities.invokeLater(list::requestFocusInWindow);
        setVisible(true);
    }

    private void choose() {
        Navigator.Hit hit = list.getSelectedValue();
        if (hit == null) {
            return;
        }
        dispose();
        actions.open(hit);
    }

    /* ------------------------------------------------------------------ */

    private static class Renderer implements ListCellRenderer<Navigator.Hit> {
        private final Theme theme;
        private final File root;
        private final boolean empty;
        private final JPanel row = new JPanel(new BorderLayout(8, 0));
        private final JLabel where = new JLabel();
        private final JLabel what = new JLabel();

        Renderer(Theme theme, File root, boolean empty) {
            this.theme = theme;
            this.root = root;
            this.empty = empty;
            row.setOpaque(true);
            row.setBorder(BorderFactory.createEmptyBorder(1, 8, 1, 8));
            where.setFont(UI.mono(UI.MONO_FAMILY, 11.5f));
            what.setFont(UI.ui(12f));
            row.add(where, BorderLayout.WEST);
            row.add(what, BorderLayout.CENTER);
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends Navigator.Hit> list,
                                                      Navigator.Hit value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            row.setBackground(isSelected ? theme.listActive : theme.widgetBg);
            Color fg = isSelected ? theme.listActiveFg : theme.panelFg;
            if (empty) {
                where.setText("");
                what.setForeground(UI.alpha(theme.panelFg, 150));
                what.setText(Strings.get("No results"));
                return row;
            }
            where.setForeground(isSelected ? UI.alpha(theme.listActiveFg, 200) : UI.alpha(theme.panelFg, 150));
            what.setForeground(fg);
            where.setText(relative(value.file) + ":" + value.line);
            what.setText(value.text);
            row.setToolTipText(value.file == null ? "" : value.file.getAbsolutePath());
            return row;
        }

        private String relative(File f) {
            if (f == null) {
                return "?";
            }
            if (root != null) {
                String base = root.getAbsolutePath();
                String path = f.getAbsolutePath();
                if (path.startsWith(base)) {
                    String rest = path.substring(base.length());
                    if (rest.startsWith(File.separator)) {
                        rest = rest.substring(1);
                    }
                    if (!rest.isEmpty()) {
                        return rest;
                    }
                }
            }
            return f.getName();
        }
    }
}
