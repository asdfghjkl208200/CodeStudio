package com.codestudio.ui;

import com.codestudio.core.DocumentBundle;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.SyntaxHighlighter;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.plaf.basic.BasicTabbedPaneUI;

/** A group of editor tabs (VS Code calls these "editor groups"). */
public class EditorGroup extends JPanel {

    public interface Listener {
        /** Called when a document becomes visible, becomes active or is closed. */
        void activeEditorChanged();
    }

    private final JTabbedPane tabs;
    private final List<EditorPanel> editors = new ArrayList<>();
    private final List<Listener> listeners = new ArrayList<>();

    private final Settings settings;
    private final Workspace workspace;
    private final SyntaxHighlighter highlighter;
    private final EditorPanel.Actions actions;
    private Theme theme;

    public EditorGroup(Settings settings, Workspace workspace, SyntaxHighlighter highlighter,
                       Theme theme, EditorPanel.Actions actions) {
        super(new BorderLayout());
        this.settings = settings;
        this.workspace = workspace;
        this.highlighter = highlighter;
        this.theme = theme;
        this.actions = actions;

        setBackground(theme.editorBg);
        setOpaque(true);

        tabs = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
        tabs.setUI(new FlatTabUI());
        tabs.setBackground(theme.tabInactiveBg);
        tabs.setOpaque(true);
        tabs.setBorder(BorderFactory.createEmptyBorder());
        tabs.setFocusable(false);

        tabs.addChangeListener(e -> {
            int idx = tabs.getSelectedIndex();
            for (int i = 0; i < editors.size(); i++) {
                EditorPanel p = editors.get(i);
                boolean sel = i == idx;
                TabHeader h = headerOf(p);
                if (h != null) {
                    h.setSelected(sel);
                }
                if (!sel) {
                    p.saveCaret();
                }
            }
            EditorPanel active = active();
            if (active != null) {
                active.activate();
            }
            fire();
        });

        tabs.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isMiddleMouseButton(e)) {
                    int idx = tabs.indexAtLocation(e.getX(), e.getY());
                    if (idx >= 0 && idx < editors.size()) {
                        close(editors.get(idx));
                    }
                }
            }
        });

        add(tabs, BorderLayout.CENTER);
    }

    public void addListener(Listener l) {
        listeners.add(l);
    }

    private void fire() {
        for (Listener l : new ArrayList<>(listeners)) {
            l.activeEditorChanged();
        }
    }

    /* ------------------------------------------------------------------ */

    public List<EditorPanel> editors() {
        return editors;
    }

    public boolean isEmpty() {
        return editors.isEmpty();
    }

    public int count() {
        return editors.size();
    }

    public EditorPanel active() {
        int idx = tabs.getSelectedIndex();
        if (idx < 0 || idx >= editors.size()) {
            return null;
        }
        return editors.get(idx);
    }

    public EditorPanel find(DocumentBundle b) {
        for (EditorPanel p : editors) {
            if (p.bundle() == b) {
                return p;
            }
        }
        return null;
    }

    /** Opens a document in this group, focusing it when already present. */
    public EditorPanel open(DocumentBundle b) {
        EditorPanel existing = find(b);
        if (existing != null) {
            tabs.setSelectedComponent(existing);
            existing.activate();
            return existing;
        }
        EditorPanel panel = new EditorPanel(b, settings, workspace, highlighter, theme, actions);
        editors.add(panel);
        tabs.addTab(b.name(), panel);
        TabHeader header = new TabHeader(panel);
        tabs.setTabComponentAt(editors.size() - 1, header);
        tabs.setSelectedComponent(panel);
        panel.editor().addStateListener(this::fire);
        panel.activate();
        revalidate();
        repaint();
        fire();
        return panel;
    }

    public void setActive(EditorPanel panel) {
        if (editors.contains(panel)) {
            tabs.setSelectedComponent(panel);
        }
    }

    public boolean close(EditorPanel panel) {
        if (!editors.contains(panel)) {
            return true;
        }
        if (panel.bundle().isDirty()) {
            int choice = SavePrompt.ask(this, panel.bundle(), theme);
            if (choice == SavePrompt.CANCEL) {
                return false;
            }
            if (choice == SavePrompt.SAVE) {
                panel.saveCaret();
                if (!SavePrompt.save(this, panel.bundle(), settings, actions)) {
                    return false;
                }
            }
        }
        editors.remove(panel);
        tabs.remove(panel);
        panel.dispose();
        revalidate();
        repaint();
        fire();
        return true;
    }

    /**
     * Removes a tab without prompting and without touching its document. Used when a
     * document moves to another editor group, where it keeps its buffer and dirty flag.
     */
    public void release(EditorPanel panel) {
        if (!editors.contains(panel)) {
            return;
        }
        editors.remove(panel);
        tabs.remove(panel);
        revalidate();
        repaint();
        fire();
    }

    public void closeAll() {
        for (EditorPanel p : new ArrayList<>(editors)) {
            if (!close(p)) {
                break;
            }
        }
    }

    public void closeOthers(EditorPanel keep) {
        for (EditorPanel p : new ArrayList<>(editors)) {
            if (p != keep && !close(p)) {
                break;
            }
        }
    }

    public void closeSaved() {
        for (EditorPanel p : new ArrayList<>(editors)) {
            if (!p.bundle().isDirty()) {
                close(p);
            }
        }
    }

    public void closeToRight(EditorPanel from) {
        int idx = editors.indexOf(from);
        for (int i = editors.size() - 1; i > idx; i--) {
            if (!close(editors.get(i))) {
                break;
            }
        }
    }

    private TabHeader headerOf(EditorPanel p) {
        int idx = editors.indexOf(p);
        if (idx < 0) {
            return null;
        }
        java.awt.Component c = tabs.getTabComponentAt(idx);
        return c instanceof TabHeader ? (TabHeader) c : null;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.editorBg);
        tabs.setBackground(t.tabInactiveBg);
        tabs.setUI(new FlatTabUI());
        for (EditorPanel p : editors) {
            p.setTheme(t);
        }
        for (int i = 0; i < tabs.getTabCount(); i++) {
            java.awt.Component c = tabs.getTabComponentAt(i);
            if (c instanceof TabHeader h) {
                h.setTheme(t);
            }
        }
        repaint();
    }

    public void refreshPrefs() {
        for (EditorPanel p : editors) {
            p.refreshPrefs();
        }
    }

    /**
     * Re-applies every visible string after a language change. The tab context menu is built fresh
     * on each pop up, so it is already translated at construction; only the persistent chrome —
     * the tab tooltips and the "no editors open" empty state — needs redoing here. Each editor
     * panel re-reads its own breadcrumb and tooltips.
     */
    public void retranslate() {
        for (EditorPanel p : editors) {
            p.retranslate();
        }
        for (int i = 0; i < tabs.getTabCount(); i++) {
            java.awt.Component c = tabs.getTabComponentAt(i);
            if (c instanceof TabHeader h) {
                h.refresh();
            }
        }
        repaint();
    }

    /* ------------------------------------------------------------------ */

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!editors.isEmpty()) {
            return;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        try {
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(UI.alpha(theme.editorFg, 40));
            g2.setFont(UI.ui(28f));
            String msg = Strings.get("No editors open");
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(msg, getWidth() / 2 - fm.stringWidth(msg) / 2, getHeight() / 2);
        } finally {
            g2.dispose();
        }
    }

    /* ------------------------------------------------------------------ */
    /* tab header                                                          */
    /* ------------------------------------------------------------------ */

    public class TabHeader extends JPanel {
        private final EditorPanel panel;
        private final JLabel label = new JLabel();
        private final JLabel close = new JLabel();
        private boolean selected;
        private boolean hovering;
        private boolean closeHovering;

        TabHeader(EditorPanel panel) {
            super(new BorderLayout(4, 0));
            this.panel = panel;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 4));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            label.setFont(UI.ui(12.5f));
            label.setIcon(Icons.of("file", 14, badgeColor()));
            add(label, BorderLayout.CENTER);
            close.setPreferredSize(new Dimension(18, 16));
            close.setHorizontalAlignment(SwingConstants.CENTER);
            add(close, BorderLayout.EAST);

            panel.bundle().addDirtyListener(this::refresh);
            refresh();

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovering = false;
                    closeHovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (e.getSource() == close || close.getBounds().contains(e.getPoint())) {
                        close(panel);
                    } else {
                        tabs.setSelectedComponent(panel);
                        panel.editor().requestFocusInWindow();
                    }
                }
            });
            close.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    closeHovering = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    closeHovering = false;
                    repaint();
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    close(panel);
                }
            });
        }

        private Color badgeColor() {
            String hex = panel.bundle().language == null ? "#888888" : panel.bundle().language.color;
            try {
                return Color.decode(hex);
            } catch (Exception e) {
                return theme.gutterFg;
            }
        }

        void setSelected(boolean sel) {
            this.selected = sel;
            refresh();
        }

        void setTheme(Theme t) {
            refresh();
            repaint();
        }

        private void refresh() {
            DocumentBundle b = panel.bundle();
            label.setText(b.name());
            label.setIcon(Icons.of("file", 14, badgeColor()));
            String tip = b.file == null ? Strings.get("Unsaved") : b.file.getAbsolutePath();
            setToolTipText(b.isDirty() ? Strings.format("{0}  -  modified", tip) : tip);
            repaint();
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            d.width = Math.min(240, Math.max(110, d.width + 26));
            return d;
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg;
                if (selected) {
                    bg = theme.tabActiveBg;
                } else if (hovering) {
                    bg = UI.mix(theme.tabInactiveBg, theme.editorFg, 0.06f);
                } else {
                    bg = theme.tabInactiveBg;
                }
                g.setColor(bg);
                g.fillRect(0, 0, getWidth(), getHeight());

                if (selected) {
                    g.setColor(theme.tabBorderTop);
                    g.fillRect(0, 0, getWidth(), 1);
                }
                g.setColor(UI.alpha(theme.dark ? Color.BLACK : new Color(0xE0E0E0), 110));
                g.drawLine(getWidth() - 1, 3, getWidth() - 1, getHeight() - 4);
            } finally {
                g.dispose();
            }

            label.setForeground(selected ? theme.tabActiveFg : theme.tabInactiveFg);

            DocumentBundle b = panel.bundle();
            if (b.isDirty() && !(hovering || closeHovering)) {
                close.setIcon(new DotIcon(theme.tabActiveFg));
            } else {
                close.setIcon(Icons.of("close", 13, closeHovering ? theme.tabActiveFg
                        : (hovering ? theme.tabInactiveFg : theme.tabInactiveFg)));
            }
            super.paintComponent(g0);
        }
    }

    /** Small filled circle marking an unsaved buffer. */
    public static class DotIcon implements javax.swing.Icon {
        private final Color color;

        public DotIcon(Color color) {
            this.color = color;
        }

        @Override
        public int getIconWidth() {
            return 13;
        }

        @Override
        public int getIconHeight() {
            return 13;
        }

        @Override
        public void paintIcon(java.awt.Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.fillOval(x + 3, y + 3, 7, 7);
            g2.dispose();
        }
    }

    /** Tabbed pane UI that leaves the painting to our own tab components. */
    private static class FlatTabUI extends BasicTabbedPaneUI {
        @Override
        protected void installDefaults() {
            super.installDefaults();
            tabAreaInsets = new Insets(0, 0, 0, 0);
            tabInsets = new Insets(0, 0, 0, 0);
            selectedTabPadInsets = new Insets(0, 0, 0, 0);
            contentBorderInsets = new Insets(0, 0, 0, 0);
        }

        @Override
        protected int getTabLabelShiftX(int tabPlacement, int tabIndex, boolean isSelected) {
            return 0;
        }

        @Override
        protected int getTabLabelShiftY(int tabPlacement, int tabIndex, boolean isSelected) {
            return 0;
        }

        @Override
        protected void paintTabArea(Graphics g, int tabPlacement, int selectedIndex) {
            Rectangle bounds = tabPane.getBounds();
            g.setColor(tabPane.getBackground());
            if (tabPlacement == TOP) {
                g.fillRect(0, 0, bounds.width, Math.min(bounds.height, calculateTabAreaHeight(tabPlacement, 1, 1)));
            }
            super.paintTabArea(g, tabPlacement, selectedIndex);
        }

        @Override
        protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h,
                                          boolean isSelected) {
            // handled by the tab component
        }

        @Override
        protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h,
                                      boolean isSelected) {
            // handled by the tab component
        }

        @Override
        protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
            // no content border in this theme
        }

        @Override
        protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex,
                                           Rectangle iconRect, Rectangle textRect, boolean isSelected) {
            // no focus ring
        }
    }
}
