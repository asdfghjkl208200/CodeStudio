package com.codestudio.ui;

import com.codestudio.core.Language;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import com.codestudio.core.Workspace;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** The unified quick input: commands, file search, symbols, go to line and help. */
public class QuickOpen extends JDialog {

    /** A palette command. */
    public static class Command {
        public final String id;
        public final String title;
        public final String category;
        public final String keybinding;
        public final Runnable action;

        public Command(String id, String category, String title, String keybinding, Runnable action) {
            this.id = id;
            this.category = category;
            this.title = title;
            this.keybinding = keybinding;
            this.action = action;
        }

        public String fullTitle() {
            return category == null || category.isBlank() ? title : category + ": " + title;
        }
    }

    /** Supplies the available commands and navigation callbacks. */
    public interface Provider {
        List<Command> commands();

        void openFile(File file, int line, int column);

        List<OutlinePanel.Symbol> symbols();

        File activeFile();
    }

    public static final String MODE_COMMAND = ">";
    public static final String MODE_FILE = "";
    public static final String MODE_SYMBOL = "@";
    public static final String MODE_LINE = ":";
    public static final String MODE_HELP = "?";

    private static final int MAX_ROWS = 13;
    private static final int ROW_HEIGHT = 24;
    private static final int WIDTH = 620;

    private final Provider provider;
    private final Workspace workspace;
    private final Theme theme;

    private final JTextField field = new JTextField();
    private final DefaultListModel<Item> model = new DefaultListModel<>();
    private final JList<Item> list = new JList<>(model);
    private final JLabel hint = new JLabel(" ");
    private final JScrollPane scroll;
    private final JPanel content;

    private String mode = MODE_COMMAND;

    public QuickOpen(Window owner, Provider provider, Workspace workspace, Theme theme) {
        super(owner, ModalityType.APPLICATION_MODAL);
        this.provider = provider;
        this.workspace = workspace;
        this.theme = theme;

        setUndecorated(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        field.setFont(UI.ui(14f));
        field.setBackground(theme.inputBg);
        field.setForeground(theme.inputFg);
        field.setCaretColor(theme.inputFg);
        field.setBorder(BorderFactory.createEmptyBorder(9, 10, 9, 10));

        list.setBackground(theme.widgetBg);
        list.setForeground(theme.panelFg);
        list.setFont(UI.ui(13f));
        list.setFixedCellHeight(ROW_HEIGHT);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setCellRenderer(new Renderer());
        list.setFocusable(false);

        scroll = new JScrollPane(list);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, theme.widgetBorder));
        scroll.getVerticalScrollBar().setUI(new UI.FlatScrollBarUI(theme));
        scroll.getViewport().setBackground(theme.widgetBg);

        hint.setFont(UI.ui(11f));
        hint.setForeground(UI.alpha(theme.panelFg, 150));
        hint.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 8));

        content = new JPanel(new BorderLayout());
        content.setBackground(theme.widgetBg);
        content.setBorder(BorderFactory.createLineBorder(theme.widgetBorder));
        content.add(field, BorderLayout.NORTH);
        content.add(scroll, BorderLayout.CENTER);
        content.add(hint, BorderLayout.SOUTH);
        setContentPane(content);

        field.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                update();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                update();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                update();
            }
        });

        field.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_ESCAPE -> {
                        e.consume();
                        close();
                    }
                    case KeyEvent.VK_DOWN -> {
                        e.consume();
                        move(1);
                    }
                    case KeyEvent.VK_UP -> {
                        e.consume();
                        move(-1);
                    }
                    case KeyEvent.VK_PAGE_DOWN -> {
                        e.consume();
                        move(MAX_ROWS);
                    }
                    case KeyEvent.VK_PAGE_UP -> {
                        e.consume();
                        move(-MAX_ROWS);
                    }
                    case KeyEvent.VK_ENTER -> {
                        e.consume();
                        choose();
                    }
                    case KeyEvent.VK_TAB -> {
                        e.consume();
                        cycleMode();
                    }
                    default -> {
                        // typed characters are handled by the document listener
                    }
                }
            }
        });

        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int index = list.locationToIndex(e.getPoint());
                if (index >= 0) {
                    list.setSelectedIndex(index);
                    choose();
                }
            }
        });
    }

    /** Opens the dialog in the given mode; {@code seed} pre-fills the text. */
    public void open(String mode, String seed) {
        this.mode = mode;
        field.setText(seed == null ? mode : mode + seed);
        field.setCaretPosition(field.getText().length());
        update();
        setTheme(theme);
        packToSize();

        if (getOwner() != null) {
            Rectangle b = getOwner().getBounds();
            setLocation(b.x + (b.width - getWidth()) / 2, b.y + Math.max(60, b.height / 8));
        }
        SwingUtilities.invokeLater(() -> {
            field.requestFocusInWindow();
            setVisible(true);
        });
    }

    private void packToSize() {
        int rows = Math.max(1, Math.min(MAX_ROWS, model.size()));
        int height = 44 + rows * ROW_HEIGHT + 26;
        setSize(WIDTH, height);
        scroll.setPreferredSize(new Dimension(WIDTH, rows * ROW_HEIGHT));
    }

    public void updateTheme(Theme t) {
        setTheme(t);
    }

    private void setTheme(Theme t) {
        content.setBackground(t.widgetBg);
        content.setBorder(BorderFactory.createLineBorder(t.widgetBorder));
        field.setBackground(t.inputBg);
        field.setForeground(t.inputFg);
        field.setCaretColor(t.inputFg);
        list.setBackground(t.widgetBg);
        list.setForeground(t.panelFg);
        list.setCellRenderer(new Renderer());
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, t.widgetBorder));
        scroll.getVerticalScrollBar().setUI(new UI.FlatScrollBarUI(t));
        scroll.getViewport().setBackground(t.widgetBg);
        hint.setForeground(UI.alpha(t.panelFg, 150));
        repaint();
    }

    private void close() {
        setVisible(false);
        dispose();
    }

    private void move(int delta) {
        if (model.isEmpty()) {
            return;
        }
        int index = list.getSelectedIndex();
        int next = index + delta;
        if (next < 0) {
            next = model.size() - 1;
        }
        if (next >= model.size()) {
            next = 0;
        }
        list.setSelectedIndex(next);
        list.ensureIndexIsVisible(next);
    }

    private void cycleMode() {
        String text = field.getText().trim();
        if (text.startsWith(MODE_COMMAND)) {
            mode = MODE_FILE;
            field.setText(text.substring(1));
        } else if (text.startsWith(MODE_SYMBOL) || text.startsWith(MODE_LINE)) {
            mode = MODE_FILE;
            field.setText(text.substring(1));
        } else {
            mode = MODE_COMMAND;
            field.setText(MODE_COMMAND + " ");
        }
        field.setCaretPosition(field.getText().length());
        update();
    }

    private void choose() {
        Item item = list.getSelectedValue();
        if (item == null && !model.isEmpty()) {
            item = model.get(0);
        }
        if (item == null) {
            close();
            return;
        }
        final Item chosen = item;
        close();
        SwingUtilities.invokeLater(chosen::run);
    }

    /* ------------------------------------------------------------------ */

    private void update() {
        String text = field.getText();
        if (!text.startsWith(">") && !text.startsWith("@") && !text.startsWith(":") && !text.startsWith("?")) {
            mode = MODE_FILE;
        } else {
            mode = text.substring(0, 1);
        }
        String query = text.length() > 0 && isPrefix(text.charAt(0)) ? text.substring(1).trim() : text.trim();

        List<Item> items = new ArrayList<>();
        switch (mode) {
            case MODE_COMMAND -> items = commandItems(query);
            case MODE_SYMBOL -> items = symbolItems(query);
            case MODE_LINE -> items = lineItems(query);
            case MODE_HELP -> items = helpItems(query);
            default -> items = fileItems(query);
        }

        model.clear();
        for (Item item : items) {
            model.addElement(item);
        }
        if (!model.isEmpty()) {
            list.setSelectedIndex(0);
        }
        packToSize();

        // The prompt shown while the field is empty, one per mode. Swing reads this client
        // property when it paints, so setting it here covers every keystroke and every mode switch.
        String prompt = switch (mode) {
            case MODE_SYMBOL -> Strings.get("Go to symbol...");
            case MODE_LINE -> Strings.get("Go to line...");
            case MODE_HELP -> Strings.get("Show keyboard shortcuts...");
            case MODE_FILE -> Strings.get("Go to file...");
            default -> Strings.get("Show all commands...");
        };
        field.putClientProperty("JTextField.placeholderText", prompt);

        // The hint line: either what the list holds, or the empty state when nothing matches.
        String hintText;
        if (model.isEmpty()) {
            hintText = switch (mode) {
                case MODE_COMMAND -> Strings.get("No matching commands");
                case MODE_SYMBOL -> Strings.get("No matching symbols");
                case MODE_LINE -> Strings.get("No matching results");
                case MODE_HELP -> Strings.get("No matching shortcuts");
                default -> Strings.get("No matching files");
            };
        } else {
            String label = switch (mode) {
                case MODE_COMMAND -> Strings.format("{0} commands", model.size());
                case MODE_SYMBOL -> Strings.format("{0} symbols", model.size());
                case MODE_LINE -> Strings.get("Go to line");
                case MODE_HELP -> Strings.get("Keyboard shortcuts");
                default -> Strings.format("{0} files", model.size());
            };
            hintText = label + "   -   " + Strings.get("Enter to open, Tab to switch, Esc to dismiss");
        }
        hint.setText(hintText);
        revalidate();
        repaint();
    }

    private static boolean isPrefix(char c) {
        return c == '>' || c == '@' || c == ':' || c == '?';
    }

    private List<Item> commandItems(String query) {
        List<Item> out = new ArrayList<>();
        for (Command c : provider.commands()) {
            int score = fuzzyScore(query, c.fullTitle());
            if (score >= 0) {
                out.add(new Item(c, score, query));
            }
        }
        out.sort(Comparator.comparingInt((Item i) -> -i.score));
        return out;
    }

    private List<Item> fileItems(String query) {
        List<Item> out = new ArrayList<>();
        List<File> files = workspace.indexFiles();
        for (File f : files) {
            String rel = workspace.relative(f);
            int score = fuzzyScore(query, rel);
            if (score < 0 && !query.isEmpty()) {
                score = fuzzyScore(query, f.getName());
                if (score >= 0) {
                    score -= 40;
                }
            }
            if (score >= 0) {
                out.add(new Item(f, score, query));
            }
        }
        out.sort(Comparator.comparingInt((Item i) -> -i.score));
        if (out.size() > 200) {
            out = new ArrayList<>(out.subList(0, 200));
        }
        return out;
    }

    private List<Item> symbolItems(String query) {
        List<Item> out = new ArrayList<>();
        for (OutlinePanel.Symbol s : provider.symbols()) {
            int score = fuzzyScore(query, s.name);
            if (score >= 0) {
                out.add(new Item(s, score, query));
            }
        }
        out.sort(Comparator.comparingInt((Item i) -> -i.score));
        return out;
    }

    private List<Item> lineItems(String query) {
        List<Item> out = new ArrayList<>();
        String digits = query.trim();
        int line = 0;
        try {
            line = digits.isEmpty() ? 1 : Integer.parseInt(digits);
        } catch (NumberFormatException e) {
            return out;
        }
        final int target = Math.max(1, line);
        out.add(new Item(new Command("goto.line", "", Strings.format("Go to Line {0}", target), "", () -> {
            File f = provider.activeFile();
            if (f != null) {
                provider.openFile(f, target - 1, 0);
            }
        }), 100 - Math.abs(line - 1), ""));
        return out;
    }

    private List<Item> helpItems(String query) {
        List<Item> out = new ArrayList<>();
        for (Command c : provider.commands()) {
            if (c.keybinding == null || c.keybinding.isBlank()) {
                continue;
            }
            int score = fuzzyScore(query, c.fullTitle() + " " + c.keybinding);
            if (score >= 0) {
                out.add(new Item(new Command(c.id, c.category, c.title, c.keybinding, () -> {
                    if (c.action != null) {
                        c.action.run();
                    }
                }), score, query));
            }
        }
        out.sort(Comparator.comparingInt((Item i) -> i.keybinding().isEmpty() ? 1 : 0));
        return out;
    }

    /* ------------------------------------------------------------------ */
    /* fuzzy matching                                                      */
    /* ------------------------------------------------------------------ */

    /** Subsequence match returning a score, or -1 when the pattern does not match. */
    public static int fuzzyScore(String pattern, String text) {
        if (pattern == null || pattern.isEmpty()) {
            return 1;
        }
        if (text == null) {
            return -1;
        }
        String p = pattern.toLowerCase(Locale.ROOT);
        String t = text.toLowerCase(Locale.ROOT);
        int score = 0;
        int ti = 0;
        int consecutive = 0;
        for (int pi = 0; pi < p.length(); pi++) {
            char pc = p.charAt(pi);
            if (pc == ' ') {
                continue;
            }
            int found = t.indexOf(pc, ti);
            if (found < 0) {
                return -1;
            }
            if (found == ti) {
                consecutive++;
                score += 12 + consecutive * 4;
            } else {
                consecutive = 0;
                score += 4;
                score -= Math.min(6, found - ti);
            }
            if (found == 0 || t.charAt(found - 1) == ' ' || t.charAt(found - 1) == '/' || t.charAt(found - 1) == '.') {
                score += 10;
            }
            ti = found + 1;
        }
        score -= Math.max(0, t.length() - p.length()) / 6;
        if (t.equals(p)) {
            score += 60;
        }
        return score;
    }

    /** Characters of {@code text} that match {@code pattern}, marked for the renderer. */
    private static String highlight(String pattern, String text) {
        if (pattern == null || pattern.isEmpty()) {
            return UI.esc(text);
        }
        String p = pattern.toLowerCase(Locale.ROOT);
        String t = text.toLowerCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder();
        boolean matched = false;
        int ti = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (ti < p.length() && p.charAt(ti) == t.charAt(i)) {
                if (!matched) {
                    sb.append("<b><u>");
                    matched = true;
                }
                ti++;
            } else if (matched) {
                sb.append("</u></b>");
                matched = false;
            }
            sb.append(UI.esc(String.valueOf(c)));
        }
        if (matched) {
            sb.append("</u></b>");
        }
        return sb.toString();
    }

    /* ------------------------------------------------------------------ */

    /** One row of the list. */
    private class Item {
        final Command command;
        final File file;
        final OutlinePanel.Symbol symbol;
        final int score;
        final String pattern;

        Item(Command command, int score, String pattern) {
            this.command = command;
            this.file = null;
            this.symbol = null;
            this.score = score;
            this.pattern = pattern;
        }

        Item(File file, int score, String pattern) {
            this.command = null;
            this.file = file;
            this.symbol = null;
            this.score = score;
            this.pattern = pattern;
        }

        Item(OutlinePanel.Symbol symbol, int score, String pattern) {
            this.command = null;
            this.file = null;
            this.symbol = symbol;
            this.score = score;
            this.pattern = pattern;
        }

        String keybinding() {
            return command == null || command.keybinding == null ? "" : command.keybinding;
        }

        String title() {
            if (command != null) {
                return command.fullTitle();
            }
            if (file != null) {
                return workspace.relative(file);
            }
            return symbol == null ? "" : symbol.name;
        }

        String iconName() {
            if (command != null) {
                return "settings";
            }
            if (file != null) {
                return "file";
            }
            return "run";
        }

        Color iconColor() {
            if (file != null) {
                Language lang = Language.detect(file.getName());
                try {
                    return Color.decode(lang == null ? "#888888" : lang.color);
                } catch (Exception e) {
                    return theme.gutterFg;
                }
            }
            if (symbol != null) {
                return switch (symbol.kind) {
                    case "class", "interface", "enum", "record" -> theme.synType;
                    case "function", "method" -> theme.synFunction;
                    default -> theme.gutterFg;
                };
            }
            return theme.gutterFg;
        }

        void run() {
            if (command != null) {
                if (command.action != null) {
                    command.action.run();
                }
            } else if (file != null) {
                provider.openFile(file, 0, 0);
            } else if (symbol != null) {
                File f = provider.activeFile();
                if (f != null) {
                    provider.openFile(f, symbol.line, 0);
                }
            }
        }
    }

    private class Renderer implements ListCellRenderer<Item> {
        private final JPanel panel = new JPanel(new BorderLayout(8, 0));
        private final JLabel left = new JLabel();
        private final JLabel right = new JLabel();

        Renderer() {
            panel.setOpaque(true);
            panel.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
            right.setFont(UI.ui(11f));
            panel.add(left, BorderLayout.CENTER);
            panel.add(right, BorderLayout.EAST);
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends Item> list, Item value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            panel.setBackground(isSelected ? theme.listActive : theme.widgetBg);
            Color fg = isSelected ? theme.listActiveFg : theme.panelFg;
            left.setText("<html>" + highlight(value.pattern, value.title()) + "</html>");
            left.setFont(UI.ui(13f));
            left.setForeground(fg);
            left.setIcon(Icons.of(value.iconName(), 15, isSelected ? fg : value.iconColor()));
            right.setText(value.keybinding());
            right.setForeground(isSelected ? fg : theme.accent);
            panel.setToolTipText(value.title());
            return panel;
        }
    }

    /** Draws a soft border under the dialog so it reads as a floating widget. */
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(theme.shadow);
        g2.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
        g2.dispose();
    }
}
