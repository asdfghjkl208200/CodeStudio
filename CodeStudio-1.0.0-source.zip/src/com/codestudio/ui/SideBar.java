package com.codestudio.ui;

import com.codestudio.core.Settings;
import com.codestudio.core.Theme;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JPanel;

/** Hosts the swappable sidebar views (Explorer, Search, Source Control, ...). */
public class SideBar extends JPanel {

    private final CardLayout cards = new CardLayout();
    private final Map<String, JComponent> views = new LinkedHashMap<>();
    private final Settings settings;
    private final JPanel host = new JPanel(cards);
    private Theme theme;
    private String current = "";

    public SideBar(Settings settings, Theme theme) {
        super(new BorderLayout());
        this.settings = settings;
        this.theme = theme;
        setBackground(theme.sidebarBg);
        host.setBackground(theme.sidebarBg);
        add(host, BorderLayout.CENTER);
    }

    /**
     * Registers a view; the first registered view becomes the initial one.
     *
     * <p>Registering the same id twice replaces the previous view instead of failing: a plugin that
     * is reloaded, or one that re-registers an id it already owns, must not leave a stale card in
     * the layout.
     */
    public void addView(String id, JComponent view) {
        if (id == null || view == null) {
            return;
        }
        JComponent previous = views.get(id);
        if (previous == view) {
            return;
        }
        if (previous != null) {
            host.remove(previous);
        }
        views.put(id, view);
        host.add(view, id);
        if (current.isEmpty()) {
            current = id;
            cards.show(host, id);
        }
        host.revalidate();
        host.repaint();
    }

    /**
     * Withdraws a view, e.g. when a plugin that contributed it is unloaded.
     *
     * @return whether a view with this id was registered. If it was the current one, the first
     *         remaining view is shown instead; if it was the last one, the sidebar simply goes empty.
     */
    public boolean removeView(String id) {
        if (id == null) {
            return false;
        }
        JComponent view = views.remove(id);
        if (view == null) {
            return false;
        }
        // Deactivate before the view leaves the map: setActiveState looks the id up, and after the
        // removal above there is nothing left to look up. A view withdrawn while it was current
        // would otherwise go on believing it is still visible.
        if (view instanceof ActiveAware a) {
            a.setActive(false);
        }
        host.remove(view);
        if (id.equals(current)) {
            current = views.isEmpty() ? "" : views.keySet().iterator().next();
            if (!current.isEmpty()) {
                cards.show(host, current);
                setActiveState(current, true);
            }
        }
        host.revalidate();
        host.repaint();
        return true;
    }

    public void show(String id) {
        if (id == null || !views.containsKey(id)) {
            return;
        }
        current = id;
        cards.show(host, id);
        JComponent view = views.get(id);
        view.revalidate();
        view.repaint();
        setActiveState(id, true);
        for (Map.Entry<String, JComponent> e : views.entrySet()) {
            if (!e.getKey().equals(id)) {
                setActiveState(e.getKey(), false);
            }
        }
    }

    private void setActiveState(String id, boolean active) {
        JComponent view = views.get(id);
        if (view instanceof ActiveAware a) {
            a.setActive(active);
        }
    }

    public String currentView() {
        return current;
    }

    /**
     * Re-applies text after a language change. The sidebar owns no captions of its own — every
     * caption lives in one of the hosted views — so the container forwards the call to every view
     * that is {@link ThemeAware}. {@code MainWindow.applyLanguage} also retranslates the built-in
     * views directly, which is harmless, but a view contributed by a plugin is unknown to
     * {@code MainWindow}, so forwarding here is the only thing that reaches it.
     */
    public void retranslate() {
        for (JComponent view : views.values()) {
            if (view instanceof ThemeAware a) {
                a.retranslate();
            }
        }
    }

    public JComponent view(String id) {
        return views.get(id);
    }

    public boolean isVisibleView(String id) {
        return id != null && id.equals(current);
    }

    /** Hides the sidebar entirely (View > Appearance > Side Bar). */
    public void setSideBarVisible(boolean visible) {
        setVisible(visible);
    }

    public int preferredWidth() {
        return Math.max(170, settings.getInt("workbench.sideBarWidth"));
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension d = super.getPreferredSize();
        d.width = preferredWidth();
        return d;
    }

    public void setTheme(Theme t) {
        this.theme = t;
        setBackground(t.sidebarBg);
        host.setBackground(t.sidebarBg);
        for (JComponent view : views.values()) {
            if (view instanceof ThemeAware aware) {
                aware.setTheme(t);
            }
        }
        repaint();
    }
}
