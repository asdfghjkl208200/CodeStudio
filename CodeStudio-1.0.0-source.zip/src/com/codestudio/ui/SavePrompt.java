package com.codestudio.ui;

import com.codestudio.core.DocumentBundle;
import com.codestudio.core.Settings;
import com.codestudio.core.Strings;
import com.codestudio.core.Theme;
import java.awt.Component;
import java.io.File;
import java.io.IOException;

/** Save / discard / cancel handling shared by every "close" path. */
public final class SavePrompt {

    public static final int SAVE = 0;
    public static final int DONT_SAVE = 1;
    public static final int CANCEL = 2;

    private SavePrompt() {
    }

    public static int ask(Component parent, DocumentBundle b, Theme theme) {
        int r = Dialogs.confirm(parent, theme, "CodeStudio",
                Strings.get("Do you want to save the changes you made to ")
                        + b.name()
                        + Strings.get("?\n\nYour changes will be lost if you don't save them."),
                Strings.get("Save"), Strings.get("Don't Save"), Strings.get("Cancel"));
        if (r == 0) {
            return SAVE;
        }
        return r == 1 ? DONT_SAVE : CANCEL;
    }

    public static boolean save(Component parent, DocumentBundle b, Settings settings,
                               EditorPanel.Actions actions) {
        if (b.file == null) {
            return saveAs(parent, b, settings, actions);
        }
        try {
            b.save(settings);
            if (actions != null) {
                actions.notify(Strings.get("Saved ") + b.name());
            }
            return true;
        } catch (IOException e) {
            Dialogs.error(parent, Theme.get(settings.get("workbench.colorTheme")),
                    Strings.get("Save Failed"),
                    Strings.get("Could not save ") + b.name() + "\n\n" + e.getMessage());
            return false;
        }
    }

    public static boolean saveAs(Component parent, DocumentBundle b, Settings settings,
                                 EditorPanel.Actions actions) {
        Theme theme = Theme.get(settings.get("workbench.colorTheme"));
        File start = b.file != null ? b.file.getParentFile() : null;
        File target = Dialogs.chooseFile(parent, theme, true, b.name(), start);
        if (target == null) {
            return false;
        }
        try {
            boolean hadFile = b.file != null;
            b.saveAs(target, settings);
            if (actions != null) {
                actions.notify(Strings.get("Saved ") + target.getName());
            }
            if (!hadFile) {
                b.setDirty(false);
            }
            return true;
        } catch (IOException e) {
            Dialogs.error(parent, theme, Strings.get("Save Failed"),
                    Strings.get("Could not save ") + target + "\n\n" + e.getMessage());
            return false;
        }
    }
}
