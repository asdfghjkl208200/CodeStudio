@echo off
setlocal
cd /d "%~dp0"

rem ============================================================
rem  Packages CodeStudio as a native Windows application.
rem  Produces dist\CodeStudio\CodeStudio.exe plus a private
rem  trimmed Java runtime, so the result needs no JDK installed.
rem
rem  Steps: build the jar -> draw the .ico -> jpackage app-image.
rem  Override the version with:  package.bat 1.2.0
rem ============================================================

set APP_VERSION=%~1
if "%APP_VERSION%"=="" set APP_VERSION=1.0.0

where jpackage >nul 2>nul
if errorlevel 1 (
    echo.
    echo jpackage was not found on PATH.
    echo It ships with the JDK ^(17 or newer^) - a plain JRE does not include it.
    exit /b 1
)

echo === 1/5  Build the jar ===
rem %~dp0 rather than a bare name: cmd does not search the current directory when
rem NoDefaultCurrentDirectoryInExePath is set, which some shells and policy settings do.
call "%~dp0build.bat"
if errorlevel 1 exit /b 1

echo.
echo === 2/5  Draw the application icon ===
if not exist build mkdir build
if not exist tools\out mkdir tools\out
javac -encoding UTF-8 -d tools\out tools\MakeIcon.java
if errorlevel 1 (
    echo ICON BUILD FAILED
    exit /b 1
)
java -cp tools\out MakeIcon build\CodeStudio.ico
if errorlevel 1 (
    echo ICON BUILD FAILED
    exit /b 1
)

echo.
echo === 3/5  Stage the input ===
rem Only the jar goes in, so no loose class files or sources leak into the app.
if exist build\stage rmdir /s /q build\stage
mkdir build\stage
copy /y codestudio.jar build\stage\ >nul
if errorlevel 1 (
    echo STAGING FAILED
    exit /b 1
)

echo.
echo === 4/5  jpackage ===
if exist dist\CodeStudio rmdir /s /q dist\CodeStudio

rem jlink is told exactly which modules to keep:
rem   java.desktop  Swing, Java2D, ImageIO - the whole UI
rem   jdk.compiler  javac, so the shipped IDE can compile Java with no JDK present
rem   the rest      base/XML/prefs/logging pulled in by the above
jpackage ^
  --type app-image ^
  --name CodeStudio ^
  --app-version %APP_VERSION% ^
  --vendor CodeStudio ^
  --description "A Visual Studio Code style IDE written in pure Java" ^
  --icon build\CodeStudio.ico ^
  --input build\stage ^
  --main-jar codestudio.jar ^
  --main-class com.codestudio.Main ^
  --dest dist ^
  --add-modules java.base,java.desktop,java.logging,java.net.http,java.prefs,java.xml,jdk.compiler ^
  --jlink-options "--strip-debug --no-header-files --no-man-pages --compress zip-6" ^
  --java-options "-Xmx1g" ^
  --java-options "-Dsun.java2d.dpiaware=true"

if errorlevel 1 (
    echo.
    echo PACKAGING FAILED
    exit /b 1
)

echo.
echo === 5/5  Zip the folder ===
REM The exe is useless without app\ and runtime\ beside it, and a zip is how
REM the folder travels. Made here rather than by hand so it can never lag the
REM exe it is supposed to contain - it did once: the exe had been rebuilt
REM twice over while the zip still held the version before both.
if exist "dist\CodeStudio-%APP_VERSION%-win-x64.zip" del "dist\CodeStudio-%APP_VERSION%-win-x64.zip"
powershell -NoProfile -Command "Compress-Archive -Path 'dist\CodeStudio' -DestinationPath 'dist\CodeStudio-%APP_VERSION%-win-x64.zip'" >nul 2>&1
if errorlevel 1 (
    echo Could not create the zip. The folder is still complete.
)

echo.
echo ============================================================
echo  Done:  dist\CodeStudio\CodeStudio.exe
echo         dist\CodeStudio-%APP_VERSION%-win-x64.zip
echo.
echo  The whole dist\CodeStudio folder is the application - the
echo  exe needs the runtime\ and app\ folders next to it, so
echo  copy the folder, not just the exe.
echo.
echo  Verify the packaged build:
echo      dist\CodeStudio\CodeStudio.exe --smoke
echo ============================================================
endlocal
